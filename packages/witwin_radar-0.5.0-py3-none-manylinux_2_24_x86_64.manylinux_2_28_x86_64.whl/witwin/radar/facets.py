"""Mesh facets as scatter sites: the facet model, its sites and one frame's geometry.

A mesh target scatters as physical-optics facets (R-ADR-042). This module owns
everything about the facets that is not the scattering coefficient itself:

* which faces of which Core structures scatter, read once per topology from
  the snapshot - the authored faces with zero-area and duplicate faces dropped,
  and the material each face carries, evaluated at the carrier;
* how faces are grouped into sites: one facet per site by default, or the
  facets of one cubic cell per site under a declared cluster size or site
  budget;
* one frame's facet corners and site positions, from the snapshot's world
  vertices, through the native ``facet_geometry`` operator and its exact
  forward and reverse companions;
* the material tables the response reads, which are differentiable inputs of
  the facet response when a Core material's permittivity, conductivity,
  thickness, permeability or front-roughness rms height is a leaf (R-ADR-052).

The coefficient is :class:`witwin.radar.scattering.FacetScatterResponse`; the
target record is :class:`witwin.radar.targets.MeshTargets`; the binding reads
the sites through :class:`witwin.radar.binding.ScatterSitePolicy`.

World vertices follow Core's documented pose convention, the one Channel's
compiler applies to the same snapshot: a deformation replaces (or offsets) the
authored local vertices, which are recentred when the mesh says so, scaled,
rotated by the authored rotation and placed at the authored position; a rigid
motion then rotates about the world origin (Euler ``(yaw, pitch, roll)``
intrinsic Z-Y-X, or a scalar-first quaternion) and translates. That is a fixed
handful of tensor library calls per structure; every per-facet quantity is
native.
"""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import numpy as np
import torch

from .cuda import native_ops as _ops
from .policy import first_order_only

#: ``material_params`` model column: a planar layer stack in vacuum.
MODEL_LAYERED = 0
#: ``material_params`` model column: a perfect conductor.
MODEL_PEC = 1
_VACUUM_PERMITTIVITY_F_PER_M = 8.8541878128e-12


@dataclass(frozen=True, slots=True, eq=False)
class FacetModel:
    """One topology's facet tables, built on the host once and uploaded once.

    Faces index the concatenation of the selected structures' vertices, in
    ascending structure-ID order. ``site_offsets``/``site_facets`` is the CSR of
    facets per site and ``facet_site`` its inverse; ``vertex_offsets``/
    ``vertex_entries`` lists each vertex's ``(facet * 3 + corner)`` incidences,
    the order the reverse pass sums in.
    """

    structure_ids: tuple[int, ...]
    vertex_counts: tuple[int, ...]
    faces: torch.Tensor
    site_offsets: torch.Tensor
    site_facets: torch.Tensor
    facet_site: torch.Tensor
    vertex_offsets: torch.Tensor
    vertex_entries: torch.Tensor
    facet_material: torch.Tensor
    material_params: torch.Tensor
    layer_offsets: torch.Tensor
    layers: torch.Tensor
    key: tuple
    #: The most layers any one material has: the stride of the material reverse pass.
    max_layers: int = 0

    @property
    def facet_count(self) -> int:
        return int(self.faces.shape[0])

    @property
    def site_count(self) -> int:
        return int(self.site_offsets.shape[0]) - 1

    @property
    def vertex_count(self) -> int:
        return int(self.vertex_offsets.shape[0]) - 1


@dataclass(frozen=True, slots=True, eq=False)
class FacetFrame:
    """One frame's facets: the static model plus this instant's geometry.

    ``corners`` is ``(F, 9)`` float32 world metres and ``sites`` ``(S, 3)`` float64 (the
    precise site the join computes path lengths from, R-ADR-040); both carry the
    tape of the snapshot's vertices. ``material_params`` and ``layers`` are the
    model's tables, carrying the tape of any material leaf.
    """

    model: FacetModel
    corners: torch.Tensor
    sites: torch.Tensor
    material_params: torch.Tensor
    layers: torch.Tensor


class _FacetGeometry(torch.autograd.Function):
    """Native facet corners and site positions, linear in the world vertices."""

    @staticmethod
    def forward(vertices: torch.Tensor, model: FacetModel) -> tuple[torch.Tensor, torch.Tensor]:
        corners = torch.empty((model.facet_count, 9), dtype=torch.float32, device=vertices.device)
        sites = torch.empty((model.site_count, 3), dtype=torch.float64, device=vertices.device)
        _ops().facet_geometry_forward(vertices, model.faces, model.site_offsets, model.site_facets, corners, sites)
        return corners, sites

    @staticmethod
    def setup_context(ctx: Any, inputs: tuple[Any, ...], output: Any) -> None:
        model = inputs[1]
        ctx.model = model
        # The operator is linear, so its tape is the topology: the vertex
        # incidence CSR the reverse pass reduces over, the face table the
        # forward-mode pass gathers through.
        tables = (model.vertex_offsets, model.vertex_entries, model.facet_site, model.site_offsets, model.site_facets)
        ctx.save_for_backward(*tables)
        ctx.save_for_forward(model.faces, model.site_offsets, model.site_facets)

    @staticmethod
    @first_order_only
    def backward(ctx: Any, grad_corners: torch.Tensor, grad_sites: torch.Tensor) -> tuple[torch.Tensor, None]:
        vertex_offsets, vertex_entries, facet_site, site_offsets, site_facets = ctx.saved_tensors
        grad_vertices = torch.empty(
            (int(vertex_offsets.shape[0]) - 1, 3), dtype=torch.float32, device=grad_corners.device
        )
        _ops().facet_geometry_backward(
            vertex_offsets,
            vertex_entries,
            facet_site,
            site_offsets,
            site_facets,
            grad_corners.contiguous(),
            grad_sites.contiguous(),
            grad_vertices,
        )
        return grad_vertices, None

    @staticmethod
    def jvp(ctx: Any, tan_vertices: torch.Tensor, tan_model: Any) -> tuple[torch.Tensor, torch.Tensor]:
        faces, site_offsets, site_facets = ctx.saved_tensors
        corners = torch.empty((int(faces.shape[0]), 9), dtype=torch.float32, device=tan_vertices.device)
        sites = torch.empty((int(site_offsets.shape[0]) - 1, 3), dtype=torch.float64, device=tan_vertices.device)
        _ops().facet_geometry_jvp(tan_vertices.contiguous(), faces, site_offsets, site_facets, corners, sites)
        return corners, sites


class FacetSites:
    """The site source of a mesh target: resolves a snapshot into a :class:`FacetFrame`.

    The model is built on first use and rebuilt only when the selected
    structures' topology or materials change (a new face tensor, a different
    material object or version); a deformation or a rigid motion moves the
    vertices and keeps the model.
    """

    def __init__(
        self,
        *,
        structure_ids: tuple[int, ...] | None,
        carrier_hz: float,
        cluster_size_m: float | None,
        max_sites: int | None,
    ) -> None:
        self.structure_ids = structure_ids
        self.carrier_hz = float(carrier_hz)
        self.cluster_size_m = cluster_size_m
        self.max_sites = max_sites
        self._model: FacetModel | None = None
        self._frame: tuple[torch.device, tuple, FacetFrame] | None = None
        #: The model's material tables on the tape of their leaves, when any is one.
        self._materials: tuple[torch.Tensor, torch.Tensor] | None = None

    def resolve(self, snapshot: Any, *, device: torch.device, admit: Callable[[str, object], None]) -> FacetFrame:
        """One frame's facets; ``admit(leaf, tensor)`` refuses world vertices whose derivative the legs drop."""

        states = _selected_states(snapshot, self.structure_ids)
        key = tuple(
            (
                int(state.structure_id),
                _faces_identity(state),
                id(state.structure.material),
                int(getattr(state.structure.material, "version", 0)),
            )
            for state in states
        )
        # The objects a frame's world vertices are a function of. When every one
        # is the same object as last time and none carries a derivative, the
        # previous frame is this frame: a still mesh costs no upload and no
        # launch per observation. The objects themselves are held, so an
        # identity comparison cannot be fooled by a recycled id.
        sources = tuple(
            (state.structure.geometry, state.rigid_motion, state.deformation, state.structure.material)
            for state in states
        )
        cached = self._frame
        if (
            cached is not None
            and cached[0] == device
            and len(cached[1]) == len(sources)
            and all(a is b for old, new in zip(cached[1], sources, strict=True) for a, b in zip(old, new, strict=True))
        ):
            return cached[2]
        vertices = [_world_vertices(state, device=device) for state in states]
        stacked = vertices[0] if len(vertices) == 1 else torch.cat(vertices, dim=0)
        # The vertices place every facet site, so a derivative they carry moves
        # leg endpoints; the binding's policy admits it before anything reads them.
        admit("the MeshTargets world-vertex tensor (mesh, deformation or rigid motion)", stacked)
        model = self._model
        if model is None or model.key != key or model.faces.device != device:
            model = self._build(states, vertices, key=key, device=device)
            self._model = model
        corners, sites = _FacetGeometry.apply(stacked.contiguous(), model)
        material_params, layers = self._materials or (model.material_params, model.layers)
        frame = FacetFrame(model=model, corners=corners, sites=sites, material_params=material_params, layers=layers)
        live = stacked.requires_grad or _carries_tangent(stacked)
        self._frame = None if live else (device, sources, frame)
        return frame

    def _build(
        self, states: list[Any], vertices: list[torch.Tensor], *, key: tuple, device: torch.device
    ) -> FacetModel:
        """Host tables for one topology: one device-to-host copy of the vertices, at freeze time."""

        faces_list: list[np.ndarray] = []
        materials: list[tuple[float, Any, list[list[Any]]]] = []
        offsets = 0
        material_index: dict[int, int] = {}
        facet_material: list[np.ndarray] = []
        host_vertices = []
        for state, world in zip(states, vertices, strict=True):
            structure = state.structure
            faces = _authored_faces(structure)
            points = world.detach().to(device="cpu", dtype=torch.float64).numpy()
            kept = _kept_faces(points, faces)
            local = np.flatnonzero(kept)
            faces_list.append(faces[kept] + offsets)
            slot = material_index.setdefault(id(structure.material), len(materials))
            if slot == len(materials):
                materials.append(_material_rows(structure.material, self.carrier_hz))
            facet_material.append(np.full(local.shape[0], slot, dtype=np.int64))
            host_vertices.append(points)
            offsets += points.shape[0]
        faces = np.concatenate(faces_list, axis=0)
        if faces.shape[0] == 0:
            raise ValueError("the selected structures carry no face with a non-zero area; a mesh target needs one")
        points = np.concatenate(host_vertices, axis=0)
        centroids = points[faces].mean(axis=1)
        site_of = _cluster(centroids, cluster_size_m=self.cluster_size_m, max_sites=self.max_sites)
        site_facets = _anchored_order(site_of, centroids)
        site_counts = np.bincount(site_of, minlength=int(site_of.max()) + 1)
        site_offsets = np.concatenate(([0], np.cumsum(site_counts)))
        incidence = faces.reshape(-1)
        vertex_entries = np.argsort(incidence, kind="stable")
        vertex_counts = np.bincount(incidence, minlength=points.shape[0])
        vertex_offsets = np.concatenate(([0], np.cumsum(vertex_counts)))
        params = np.asarray([[row[0], _host(row[1])] for row in materials], dtype=np.float32)
        layer_rows = [[_host(value) for value in layer] for row in materials for layer in row[2]]
        layer_counts = [len(row[2]) for row in materials]
        layer_offsets = np.concatenate(([0], np.cumsum(layer_counts)))
        layers = np.asarray(layer_rows if layer_rows else [[0.0, 1.0, 0.0, 1.0]], dtype=np.float32).reshape(-1, 4)
        self._materials = _live_material_tables(materials, device=device)

        # Every table crosses to the device in two copies, one per dtype, and
        # is published as views of those buffers.
        integer_tables: tuple[np.ndarray, ...] = (
            faces,
            site_offsets,
            site_facets,
            site_of,
            vertex_offsets,
            vertex_entries,
        )
        integer_tables += (np.concatenate(facet_material), layer_offsets)
        integers = torch.from_numpy(
            np.concatenate([np.asarray(table, dtype=np.int64).reshape(-1) for table in integer_tables])
        ).to(device)
        views = torch.split(integers, [int(np.asarray(table).size) for table in integer_tables])
        floats = torch.from_numpy(np.concatenate((params.reshape(-1), layers.reshape(-1))).astype(np.float32)).to(
            device
        )
        material_params, layer_values = torch.split(floats, [params.size, layers.size])
        return FacetModel(
            structure_ids=tuple(int(state.structure_id) for state in states),
            vertex_counts=tuple(int(value.shape[0]) for value in host_vertices),
            faces=views[0].view(-1, 3),
            site_offsets=views[1],
            site_facets=views[2],
            facet_site=views[3],
            vertex_offsets=views[4],
            vertex_entries=views[5],
            facet_material=views[6],
            material_params=material_params,
            layer_offsets=views[7],
            layers=layer_values,
            key=key,
            max_layers=max(layer_counts),
        )


def _carries_tangent(tensor: torch.Tensor) -> bool:
    import torch.autograd.forward_ad as forward_ad

    return forward_ad.unpack_dual(tensor).tangent is not None


def _faces_identity(state: Any) -> int:
    faces = getattr(state.structure.geometry, "faces", None)
    return id(faces) if faces is not None else id(state.structure.geometry)


def _selected_states(snapshot: Any, structure_ids: tuple[int, ...] | None) -> list[Any]:
    states = getattr(snapshot, "structures", None)
    if states is None:
        raise TypeError("snapshot must expose structures; pass a witwin.core SceneSnapshot")
    by_id = {int(state.structure_id): state for state in states}
    if structure_ids is None:
        selected = sorted(by_id)
    else:
        selected = sorted(int(value) for value in structure_ids)
        missing = [value for value in selected if value not in by_id]
        if missing:
            raise ValueError(
                f"MeshTargets structure_ids {missing} are not in this snapshot, which carries {sorted(by_id)}"
            )
    if not selected:
        raise ValueError("a mesh target needs at least one structure; the snapshot carries none")
    return [by_id[value] for value in selected]


def _authored_faces(structure: Any) -> np.ndarray:
    faces = getattr(structure.geometry, "faces", None)
    if not isinstance(faces, torch.Tensor):
        faces = structure.geometry.to_mesh()[1]
    faces = faces.detach().to(device="cpu", dtype=torch.int64).numpy()
    if faces.ndim != 2 or faces.shape[1] != 3:
        raise ValueError(f"structure {int(structure.structure_id)} faces must have shape (F, 3)")
    return faces


def _kept_faces(points: np.ndarray, faces: np.ndarray) -> np.ndarray:
    """Faces with a non-zero area, each distinct vertex triple once.

    A duplicate face would scatter twice; a zero-area one has no normal.
    """

    corners = points[faces]
    area2 = np.linalg.norm(np.cross(corners[:, 1] - corners[:, 0], corners[:, 2] - corners[:, 0]), axis=1)
    scale = max(float(np.abs(points).max()) if points.size else 0.0, 1.0)
    kept = area2 > (1e-12 * scale) ** 2
    _, first = np.unique(np.sort(faces, axis=1), axis=0, return_index=True)
    unique = np.zeros(faces.shape[0], dtype=bool)
    unique[first] = True
    return kept & unique


def _cluster(centroids: np.ndarray, *, cluster_size_m: float | None, max_sites: int | None) -> np.ndarray:
    """Site index per facet: identity, cubic cells of a declared edge, or the finest cells within a budget.

    Sites are numbered in ascending order of their first member facet, so the
    site order is a function of the face order alone.
    """

    count = centroids.shape[0]
    if cluster_size_m is None and (max_sites is None or count <= max_sites):
        return np.arange(count, dtype=np.int64)
    if cluster_size_m is not None:
        return _cells(centroids, float(cluster_size_m))
    span = float(np.ptp(centroids, axis=0).max()) if count > 1 else 1.0
    low, high = span * 1e-6, max(span, 1e-9) * 2.0
    best = _cells(centroids, high)
    for _ in range(24):
        middle = math.sqrt(low * high)
        labels = _cells(centroids, middle)
        if int(labels.max()) + 1 <= int(max_sites):  # type: ignore[arg-type]
            best, high = labels, middle
        else:
            low = middle
    return best


def _anchored_order(site_of: np.ndarray, centroids: np.ndarray) -> np.ndarray:
    """Facets grouped by site, each site's anchor first: the member nearest the members' mean.

    The site is placed at its anchor's centroid. A mean of a curved patch's
    centroids lies inside a closed body, where every leg to it would be
    occluded; the anchor keeps the site on the surface.
    """

    counts = np.bincount(site_of)
    means = np.zeros((counts.shape[0], 3))
    np.add.at(means, site_of, centroids)
    means /= counts[:, None]
    distance = np.linalg.norm(centroids - means[site_of], axis=1)
    # Grouped by site, nearest first within a site; ties keep face order.
    return np.lexsort((np.arange(site_of.shape[0]), distance, site_of))


def _cells(centroids: np.ndarray, size: float) -> np.ndarray:
    cells = np.floor(centroids / size).astype(np.int64)
    cells -= cells.min(axis=0)
    extent = cells.max(axis=0) + 1
    keys = (cells[:, 0] * extent[1] + cells[:, 1]) * extent[2] + cells[:, 2]
    _, first, inverse = np.unique(keys, return_index=True, return_inverse=True)
    order = np.argsort(np.argsort(first, kind="stable"), kind="stable")
    return order[inverse.reshape(-1)].astype(np.int64)


def _host(value: Any) -> float:
    return float(value.detach()) if isinstance(value, torch.Tensor) else float(value)


def _live(value: Any) -> bool:
    return isinstance(value, torch.Tensor) and (value.requires_grad or _carries_tangent(value))


def _live_material_tables(materials: list, *, device: torch.device) -> tuple[torch.Tensor, torch.Tensor] | None:
    """The material tables as expressions of their leaves, or ``None`` when no entry is one.

    The same rows, in the same order, as the host tables the model uploads; a
    constant entry is a constant here. A handful of library calls per
    topology, never per frame.
    """

    entries = [row[1] for row in materials] + [value for row in materials for layer in row[2] for value in layer]
    if not any(_live(value) for value in entries):
        return None

    def scalar(value: Any) -> torch.Tensor:
        if isinstance(value, torch.Tensor):
            return value.to(device=device, dtype=torch.float32).reshape(())
        return torch.tensor(float(value), dtype=torch.float32, device=device)

    params = torch.stack([torch.stack((scalar(row[0]), scalar(row[1]))) for row in materials])
    rows = [torch.stack([scalar(value) for value in layer]) for row in materials for layer in row[2]]
    layers = torch.stack(rows) if rows else torch.tensor([[0.0, 1.0, 0.0, 1.0]], dtype=torch.float32, device=device)
    return params.reshape(-1).contiguous(), layers.reshape(-1).contiguous()


#: The Core material fields a mesh target carries to its facet tables with
#: their tape, and the AD modes each supports (R-ADR-052). A rough-surface
#: ``rms_height_m`` leaf at exactly zero is refused (one-sided derivative).
MATERIAL_LEAVES: dict[str, tuple[str, ...]] = dict.fromkeys(
    ("eps_r", "sigma_e", "thickness_m", "mu_r", "rms_height_m"), ("jvp", "vjp")
)


def _material_rows(material: Any, carrier_hz: float) -> tuple[float, Any, list[list[Any]]]:
    """``(model, rms_height_m, layers)`` of one Core material at the carrier.

    A perfect conductor is the exact ``r_TE = -1``, ``r_TM = +1``. Anything else
    is its layer stack in vacuum - the authored ``layers``, or one layer of the
    material itself of ``thickness_m`` - each layer ``(thickness_m, Re eps,
    Im eps, mu_r)`` with ``eps`` the complex relative permittivity Core
    evaluates at the carrier (``Im eps <= 0``). The front roughness's rms
    height drives the coherent loss and the diffuse term.

    An entry stays a tensor when Core hands one back, so a leaf on the
    material (``eps_r``, ``sigma_e``, ``thickness_m``, ``mu_r`` or the
    roughness's ``rms_height_m``) reaches the tables with its tape. A leaf rms
    of exactly zero is refused: the diffuse amplitude grows like ``|h|`` there,
    so the surface sits on the edge of the model's domain and has only a
    one-sided derivative.
    """

    from witwin.core import MaterialLayer

    roughness = getattr(material, "roughness_front", None)
    rms: Any = 0.0 if roughness is None else roughness.rms_height_m
    if isinstance(rms, torch.Tensor) and _live(rms) and float(rms.detach()) == 0.0:
        raise RuntimeError(
            "the material's front roughness rms_height_m is a leaf at exactly zero: the diffuse term's amplitude "
            "grows like |h| there, so a smooth surface is the edge of the roughness model's domain and has only "
            "a one-sided derivative. Start the rms at a positive height, or keep it a host value."
        )
    if not isinstance(rms, torch.Tensor):
        rms = float(rms)
    if getattr(material, "conductor_model", None) == "perfect":
        return float(MODEL_PEC), rms, []
    layers = tuple(getattr(material, "layers", ()) or ())
    if not layers:
        layers = (
            MaterialLayer(
                thickness_m=material.thickness_m,
                eps_r=material.eps_r,
                sigma_e=material.sigma_e,
                mu_r=material.mu_r,
                dispersion=material.dispersion,
            ),
        )
    rows = []
    for layer in layers:
        sample = layer.evaluate_at_frequency(carrier_hz)
        eps, mu = sample.eps_r, sample.mu_r
        if abs(complex(_host_complex(mu)).imag) > 0.0:
            raise NotImplementedError("a magnetic loss tangent is not part of the facet reflection law")
        thickness = layer.thickness_m if isinstance(layer.thickness_m, torch.Tensor) else float(layer.thickness_m)
        rows.append([thickness, _real(eps), _loss(eps), _real(mu)])
    return float(MODEL_LAYERED), rms, rows


def _host_complex(value: Any) -> complex:
    return complex(value.detach()) if isinstance(value, torch.Tensor) else complex(value)


def _real(value: Any) -> Any:
    if isinstance(value, torch.Tensor):
        return value.real if value.is_complex() else value
    return complex(value).real


def _loss(value: Any) -> Any:
    """``min(Im eps, 0)``: a passive medium; a tensor keeps its tape (the clamp passes it at and below zero)."""

    if isinstance(value, torch.Tensor):
        imaginary = value.imag if value.is_complex() else torch.zeros_like(value)
        return torch.clamp(imaginary, max=0.0)
    return min(complex(value).imag, 0.0)


def _world_vertices(state: Any, *, device: torch.device) -> torch.Tensor:
    """One structure's world vertices at the snapshot, float32 on ``device``."""

    from witwin.core import Mesh
    from witwin.core.math import quat_from_euler, quat_to_rotation_matrix

    geometry = state.structure.geometry
    deformation = state.deformation
    if deformation is not None:
        if not isinstance(geometry, Mesh):
            raise TypeError("a deformed mesh target requires witwin.core.Mesh geometry")
        local = deformation.vertices if deformation.vertices is not None else geometry.vertices + deformation.offsets
        local = local.to(device=device, dtype=torch.float32)
        if geometry.recenter:
            local = local - 0.5 * (local.amin(dim=0) + local.amax(dim=0))
        rotation = geometry.rotation.to(device=device, dtype=torch.float32)
        quaternion = rotation if rotation.shape == (4,) else quat_from_euler(*rotation, device=device)
        vertices = (local * geometry.scale.to(device=device, dtype=torch.float32)) @ quat_to_rotation_matrix(
            quaternion
        ).T + geometry.position.to(device=device, dtype=torch.float32)
    else:
        vertices = geometry.to_mesh()[0].to(device=device, dtype=torch.float32)
    motion = state.rigid_motion
    if motion is not None:
        if motion.rotation is not None:
            value = torch.as_tensor(motion.rotation, device=device, dtype=torch.float32)
            quaternion = value if value.shape == (4,) else quat_from_euler(value[2], value[1], value[0], device=device)
            vertices = vertices @ quat_to_rotation_matrix(quaternion).T
        if motion.translation is not None:
            vertices = vertices + motion.translation.to(device=device, dtype=torch.float32)
    return vertices


__all__: list[str] = []
