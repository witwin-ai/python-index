"""What Radar refuses in AD: the wall, and the first-order-only rule.

Two rules live here, plus the two host admissions every domain shares: the
speed of light and the device-placement check.

**One: the non-differentiability wall.** The simulation chain and the linear
signal processing above it are differentiable. Below the first DISCRETE
DECISION nothing is, and :func:`refuse_derivative` is the single guard that
says so. The wall sits at the first discrete decision rather than at
"post-processing", which is a much later and much less defensible line: a
matched filter, a range transform, a Doppler transform, a beam cube and a MUSIC
pseudo-spectrum are all smooth functions of their input and stay live. A
threshold comparison, a ``topk`` peak pick, an ``argmax`` bin index, an
``argwhere`` detection list and a ``round`` are not, and every stage built on
one refuses at its entry.

The refusal happens BEFORE any compute, so no result object exists when it
fires. That is the point rather than a nicety: a stage that computes a full
detection list and then complains has already spent the frame, and a caller who
catches the exception is holding a half-built answer.

**Two: first order only.** :func:`first_order_only` decorates every registered
``backward`` in the package. Radar publishes first derivatives and nothing
higher. ``create_graph=True`` is precisely what leaves grad mode enabled while a
backward runs, so the check is an exact detector that fires before any launch
and names the owner that cannot answer. It also refuses a ``grad_output`` that
itself carries a derivative, which is the forward-over-reverse composition and
the worse failure of the two: without the check the mixed second derivative
comes back as an exact zero with no error at all.

This module owns both AD admission and host-parameter admission because both
rules are cross-domain. ``processing`` and ``frontend`` both need the wall;
``paths``, ``scattering``, ``sensors``, ``synthesis`` and ``frontend`` all need
the first-order rule. Putting either one inside a domain package would mean a
domain importing a sibling domain purely to reach a validator, and would end
with two copies and two wordings - which is exactly the state the guard exists
to remove.

Both refusals name the owner, and both say WHY the derivative does not exist,
because "not differentiable" alone sends the reader looking for a bug rather
than for the modelling decision.
``docs/dev/radar-ad-capability-matrix.md`` carries the same reasons as ``REF``
rows.
"""

from __future__ import annotations

import functools
import math
import numbers
from collections.abc import Callable
from typing import Any

import torch

#: Exact SI definition, m/s. The one owner: ``radar``, ``sensors``,
#: ``scattering`` and ``synthesis`` all read it from here, so no two modules can
#: disagree about a wavelength.
SPEED_OF_LIGHT_M_PER_S = 299792458.0


def resolve_device(device: torch.device | str | int, *, owner: str) -> torch.device:
    """The device an owner places itself on, refusing a CUDA default with no CUDA.

    ``owner`` is the class that defaults to CUDA and appears in the message. A
    CPU device is accepted as given: construction and non-rendering work run
    there, and the caller says so by naming it.
    """

    resolved = device if isinstance(device, torch.device) else torch.device(device)
    if resolved.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(
            f"{owner} defaults to CUDA, but torch.cuda.is_available() is False. "
            "Install a CUDA-enabled PyTorch build, or pass device='cpu' explicitly."
        )
    return resolved


def _carries_derivative(value: object) -> str | None:
    """``"a gradient"`` / ``"a forward tangent"`` / ``None`` for one value.

    Both AD modes are checked, always. Checking only ``requires_grad`` is not
    enough: a forward dual carries a live
    tangent through a stage that has no business publishing one, and
    ``requires_grad`` is ``False`` the whole time.
    """

    if not isinstance(value, torch.Tensor):
        return None
    if value.requires_grad:
        return "a gradient"
    if torch.autograd.forward_ad.unpack_dual(value).tangent is not None:
        return "a forward tangent"
    return None


def require_leg_ad_mode(leaf: str, value: object, ad_mode: str, *, moves: str) -> None:
    """Refuse a leg endpoint leaf whose derivative ``ad_mode`` would not carry.

    A leaf that moves an endpoint of the propagation legs - a radar element, a
    scatter site - reaches the cube through Channel's fixed-topology replay,
    which publishes the endpoint-position derivative only in the AD mode the
    verb asks for: ``"vjp"`` for a gradient and ``"jvp"`` for a forward
    tangent. Under ``"none"`` the legs are discovery's detached rows, and in
    the other mode they carry the other kind, so what reached the caller would
    be the Radar-side stages' part alone (the join, the pattern, a facet's
    response) - a silently partial derivative, or none. It is refused instead.

    ``leaf`` names the input, ``moves`` says which endpoints it moves. Host
    metadata only (``requires_grad`` and the forward-AD unpack): no device
    work and no synchronization, so it may run once per frame.
    """

    carrier = _carries_derivative(value)
    if carrier is None:
        return
    wanted = "vjp" if carrier == "a gradient" else "jvp"
    if ad_mode != wanted:
        raise RuntimeError(
            f"{leaf} carries {carrier}, which {moves}, and the legs carry that derivative only when the verb asks "
            f"Channel for it: pass ad_mode={wanted!r} (got ad_mode={ad_mode!r}), or detach it to simulate without "
            "the derivative."
        )


def refuse_derivative(stage: str, reason: str, **tensors: object) -> None:
    """Refuse a differentiable input to a stage below the wall, at its entry.

    ``stage`` is the dotted owner - module and function - so the message names
    the code that cannot answer rather than the layer that noticed. ``reason``
    is the modelling statement: which discrete decision the stage is built on.
    ``tensors`` are the stage's inputs by name; non-tensors are ignored, so a
    caller can hand the whole argument set without filtering it.

    Checked in the order given, so the message always names the first offender
    in signature order rather than in dict-iteration luck.
    """

    for name, value in tensors.items():
        carrier = _carries_derivative(value)
        if carrier is None:
            continue
        raise RuntimeError(
            f"{stage} is not differentiable and {name} carries {carrier}: "
            f"{reason} This stage ships no backward and no jvp, so the "
            "derivative it would publish is the derivative of a value at a "
            "frozen discrete choice - a plausible number describing the wrong "
            "function. A straight-through or soft surrogate is an explicit "
            "modelling decision with its own design, not something this stage "
            "may choose. Detach at the call site, deliberately, so the "
            "severing is visible where it is made."
        )


def first_order_only(backward: Callable[..., Any]) -> Callable[..., Any]:
    """The one backward decorator: first-order guard over ``once_differentiable``.

    Radar publishes first derivatives only, in both modes, and every
    second-order request fails loudly before any partial second-order result.
    Three compositions, and what happens to each:

    * **reverse over reverse** (``create_graph=True``): grad mode is left
      enabled while the backward runs, which is what the check below detects.
      Without it the first gradient comes back silently detached and the
      failure surfaces one step later as a generic Torch message that names
      Torch rather than the owner - or, with ``allow_unused=True``, as a silent
      ``None``.
    * **forward over reverse**: the ``grad_output`` carries a forward tangent.
      This is the worse of the two, because today it does not fail at all: the
      gradient value is right, its tangent is ``None``, and the mixed second
      derivative reads as an exact zero.
    * a ``grad_output`` that itself ``requires_grad``, which is the same request
      spelled differently and is equally unanswerable.

    ``torch.autograd.function.once_differentiable`` is applied UNDERNEATH, as
    defence in depth, from here rather than from every call site. It cannot
    replace the check and the nesting order is not cosmetic: ``once`` runs the
    backward body inside ``torch.no_grad()``, so a check written inside the body
    sees grad mode already off even under ``create_graph=True``. Measured, not
    assumed.
    """

    once = torch.autograd.function.once_differentiable(backward)
    owner = f"{backward.__module__}.{backward.__qualname__}"

    @functools.wraps(backward)
    def guarded(ctx: Any, *grad_outputs: Any) -> Any:
        if torch.is_grad_enabled():
            raise NotImplementedError(
                f"{owner} is first-order only: Radar does not support "
                "higher-order AD. This is a create_graph=True (grad-of-grad) "
                "request, and it fails here rather than returning a detached "
                "first gradient whose second derivative would come back None "
                "with nothing to say so."
            )
        for index, grad_output in enumerate(grad_outputs):
            carrier = _carries_derivative(grad_output)
            if carrier is None:
                continue
            raise NotImplementedError(
                f"{owner} is first-order only: Radar does not support "
                f"higher-order AD. Cotangent {index} carries {carrier}, which "
                "is a second-order request - a forward tangent through a "
                "backward is a mixed second derivative, and this family would "
                "otherwise publish it as an exact zero with no error at all."
            )
        return once(ctx, *grad_outputs)

    return guarded


def require_real(name: str, value: object) -> float:
    """A finite real host number, or a refusal that names ``name``.

    A string that parses as a number (``"60e12"``), a bool, a complex value and
    NaN or infinity are refused at construction: each would otherwise be
    coerced by ``float()`` or carried into a kernel and surface, if at all, as
    an unrelated error deep inside a run.
    """

    if isinstance(value, bool) or not isinstance(value, numbers.Real):
        raise TypeError(f"{name} must be a real number, got {type(value).__name__} {value!r}")
    parsed = float(value)
    if not math.isfinite(parsed):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return parsed


def require_host_float(name: str, value: object, *, owner: str, reason: str) -> None:
    """Refuse a tensor where a host float is the contract, and a value that is not a finite real number.

    ``name`` is the field, ``owner`` the class that declares it, and ``reason``
    the modelling statement that says why no derivative flows through it. All
    three appear in the message. ``None`` is accepted (it is how an optional
    field says "not given"), and so is a bool flag.
    """

    if value is None or isinstance(value, bool):
        return
    if not isinstance(value, torch.Tensor):
        require_real(f"{owner}.{name}", value)
        return
    carrier = "a requires_grad tensor" if value.requires_grad else f"a {tuple(value.shape)} torch.Tensor"
    raise TypeError(
        f"{owner}.{name} must be a host float and got {carrier}. {reason} There "
        "is no tangent or gradient slot for it in either AD mode, so a tensor "
        "handed here would be flattened by float() and the derivative the "
        "caller asked for would come back None with nothing to say so. Pass "
        "the number; if this value has to be optimised, that is a new "
        "capability with its own decision rather than something a spec may "
        "accept quietly."
    )


def require_host_floats(owner: str, reason: str, **fields: object) -> None:
    """:func:`require_host_float` over one owner's whole field set.

    One call per ``__post_init__`` with one reason for the whole spec, because
    the reason is a property of the OWNER - a waveform declaration, a device
    description, a unit convention - and repeating it per field would invite
    the reasons to drift apart.

    Fields are checked in the order given, so the message always names the
    first offender in declaration order rather than in dict-iteration luck.
    """

    for name, value in fields.items():
        require_host_float(name, value, owner=owner, reason=reason)


__all__ = ["first_order_only", "refuse_derivative", "require_host_float", "require_host_floats", "require_real"]
