"""The shared Torch pieces every processing stage is built from.

Four things live here: the window family, the pulsed replica and its
correlation, the published convention constants, and the two records every
stage reads - :class:`ProcessingAxes` and :class:`ProcessingCube`.

**Windows are built from ``arange`` and ``cos``, not from
``torch.hamming_window``.** The frozen vendor-DSP primitive list does not
contain the window constructors, and this package is not allowed to grow that
list. The definitions here are PERIODIC: a symmetric window makes the transform
of a pure tone asymmetric about its bin, which is exactly the property an
exact-bin assertion leans on.

**The correlation does not upcast the signal to ``complex128``.** The upcast
would double the transform cost of every pulsed frame to buy precision the
float32 input never had. The REPLICA is still built in float64, because it is a
per-frame constant of a few hundred elements whose accuracy sets the accuracy of
every delay estimate downstream, and it is cast to the signal's dtype only at
the multiply.
"""

import math
from collections.abc import Callable
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, cast

import torch

from ..display import compact_repr
from ..sensors import SensorArraySpec
from ..synthesis.assembly import (
    BEAT_PHASOR,
    CHANNEL_PHASOR,
    SPEED_OF_LIGHT_M_PER_S,
    FmcwSpec,
    OfdmSpec,
    PulsedSpec,
    SynthesisResult,
    assemble_frame_cube,
)

if TYPE_CHECKING:
    from ..radar import Radar

#: The window family, named so a caller comparing against an analytic
#: unwindowed spectrum can turn it off by name rather than by passing ``None``
#: and hoping.
WINDOWS = ("rectangular", "hann", "hamming", "blackman")

#: What ``window=None`` means. Named rather than special cased, so that every
#: published :class:`RangeProfile` carries a window string and never a ``None``
#: that a reader has to interpret.
DEFAULT_WINDOW = "rectangular"


def window_values(name: str, length: int, *, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    """The periodic window ``w[0..length-1]``, as a real tensor.

    ``rectangular`` is exactly ones, so a caller asserting against an analytic
    unwindowed transform gets the analytic answer bit for bit rather than a
    window that is one to within rounding.
    """

    if name not in WINDOWS:
        raise ValueError(f"window must be one of {WINDOWS}, got {name!r}")
    if type(length) is not int or length < 1:
        raise ValueError(f"length must be a positive int, got {length!r}")
    if name == "rectangular":
        return torch.ones(length, dtype=dtype, device=device)
    index = torch.arange(length, dtype=dtype, device=device)
    turn = index * (2.0 * math.pi / length)
    if name == "hann":
        return 0.5 - 0.5 * torch.cos(turn)
    if name == "hamming":
        return 0.54 - 0.46 * torch.cos(turn)
    return 0.42 - 0.5 * torch.cos(turn) + 0.08 * torch.cos(2.0 * turn)


def real_dtype_of(tensor: torch.Tensor) -> torch.dtype:
    """The real dtype that matches ``tensor``'s precision: float64 for a
    float64 or complex128 tensor, float32 otherwise."""

    return torch.float64 if tensor.dtype in (torch.float64, torch.complex128) else torch.float32


#: ``mean(w)`` in closed form, per window. Written down rather than reduced on
#: the device: a ``float(w.mean())`` is a device-to-host read, and this package
#: is post-synthesis Torch by the owner directive, not permission to add an
#: unattributed synchronization to every processing call. The identities are
#: exact for a PERIODIC window because ``sum_n cos(2 pi k n / N)`` is exactly
#: zero for every integer ``k`` that is not a multiple of ``N``.
_COHERENT_GAIN = {"rectangular": 1.0, "hann": 0.5, "hamming": 0.54, "blackman": 0.42}


def window_coherent_gain(name: str, length: int) -> float:
    """``mean(w)``, on the host, with no device reduction.

    The closed form needs the cosine sums to vanish, which they do once the
    window is at least three samples long (the Blackman term is at ``2 n / N``).
    Below that the mean is computed from the two or one values directly, so the
    published gain is never a formula that quietly stops holding at a degenerate
    length.
    """

    if name not in WINDOWS:
        raise ValueError(f"window must be one of {WINDOWS}, got {name!r}")
    if type(length) is not int or length < 1:
        raise ValueError(f"length must be a positive int, got {length!r}")
    if length >= 3 or name == "rectangular":
        return _COHERENT_GAIN[name]
    values = window_values(name, length, dtype=torch.float64, device=torch.device("cpu"))
    return float(values.sum()) / length


def taper(signal: torch.Tensor, name: str, *, dim: int) -> torch.Tensor:
    """Multiply ``signal`` by the window along ``dim``."""

    length = int(signal.shape[dim])
    values = window_values(name, length, dtype=real_dtype_of(signal), device=signal.device)
    shape = [1] * signal.dim()
    shape[dim] = length
    return signal * values.reshape(shape)


def remove_mean(signal: torch.Tensor, *, dim: int) -> torch.Tensor:
    """Subtract the mean along ``dim``.

    A named function behind an explicit flag that defaults to off, because it
    is a clutter operation: a component-export test that asks for the clutter
    cube and silently gets the clutter removed from it would be comparing two
    different quantities.
    """

    return signal - signal.mean(dim=dim, keepdim=True)


def pulse_samples(spec: PulsedSpec, device: torch.device | str = "cpu") -> torch.Tensor:
    """The transmitted replica on the ADC grid, as ``complex128[M_p]``.

    ``M_p = round(T_p / T_s)`` samples at ``u = m T_s``, with the amplitude
    ``spec.replica_amplitude = 1 / E_s`` (``1 / T_p`` for every unit-modulus
    envelope) and the envelope's own phase and chip magnitude: the function
    the pulsed synthesis kernel evaluates at a continuous fractional delay,
    scaled so that the correlation is a unit-gain filter. In
    float64 because it is a per-frame constant of a few hundred elements whose
    accuracy sets the accuracy of every delay estimate downstream.

    Discrete gain. ``sum_m |r[m]| T_s`` is exactly ``M_p T_s / T_p``, which
    is 1 when the pulse spans a whole number of samples and is reported by
    ``spec.pulse_grid_is_commensurate`` when it does not. The replica is NOT
    renormalised to force the discrete gain to 1: doing so would make this
    sequence a different function from the one the kernel evaluates, and the
    matched-filter peak identity - the thing that ties the two together - would
    then be true by construction instead of being a measurement.

    The LFM phase is accumulated in float64 and wrapped before the
    trigonometric call, because ``pi B u^2 / T_p`` reaches a hundred cycles at a
    20 MHz, 10 us sweep and a single-precision argument there costs about
    1e-5 rad.
    """

    count = int(spec.pulse_sample_count)
    if count < 1:
        raise ValueError(
            f"the pulse spans {count} samples on this grid: it is shorter than "
            "one sample period, so there is no replica to correlate against"
        )
    target = torch.device(device)
    u = torch.arange(count, dtype=torch.float64, device=target) * float(spec.sample_period_s)
    envelope = torch.full((count,), float(spec.replica_amplitude), dtype=torch.float64, device=target)
    if spec.is_linear_fm:
        cycles = 0.5 * float(spec.bandwidth_hz) * u * u / float(spec.pulse_width_s)
    elif spec.is_coded:
        # The chip a replica sample falls in, and that chip's phase and
        # frequency: the same piecewise envelope the kernel holds per chip.
        # The index is ``floor(m T_s / T_c)`` with a sample on a chip boundary
        # belonging to the chip that starts there; the guard of 1e-9 chip keeps
        # the float64 product ``m (T_s / T_c)`` from landing just below an
        # integer when the sample rate is a multiple of the chip rate.
        table = torch.tensor(spec.chip_table(), dtype=torch.float64, device=target)
        width = float(spec.chip_width_s)
        position = torch.arange(count, dtype=torch.float64, device=target) * (float(spec.sample_period_s) / width)
        chip = torch.clamp(torch.floor(position + 1e-9).to(torch.int64), 0, int(table.shape[0]) - 1)
        entry = table.index_select(0, chip)
        envelope = envelope * entry[:, 0]
        cycles = entry[:, 1] + entry[:, 2] * (u - chip.to(torch.float64) * width)
    else:
        cycles = torch.zeros_like(u)
    phase = math.tau * (cycles - torch.floor(cycles))
    return torch.complex(envelope * torch.cos(phase), envelope * torch.sin(phase))


def correlate(
    signal: torch.Tensor,
    replica: torch.Tensor,
    *,
    sample_period_s: float,
    oversample: int,
    window: str,
    periodic: bool = False,
) -> torch.Tensor:
    """Correlate the trailing axis against ``conj(replica)``.

    ``periodic`` is the CYCLIC correlation of a continuously transmitted code
    (PMCW): the gate holds exactly one code period, so the echo is a cyclic
    shift of the replica and the transform length is the gate's own ``M`` -
    zero padding would cut the shifted code in two. The replica must then be
    exactly ``M`` samples long.

    ``signal`` is ``[..., M]``; the result is ``[..., M * oversample]``, indexed
    by lag from the range-gate start. Three conventions, all of which change the
    answer:

    * the transform length is ``M + M_p`` so the correlation's negative-lag
      tail - which is real and a full pulse wide - does not wrap onto the
      positive lags and invent an echo at the far end of the gate;
    * correlation, not convolution: the replica is CONJUGATED and NOT reversed,
      because convolving would put the peak at ``tau + T_p`` and would look
      entirely plausible;
    * the ``T_s`` factor makes the sum approximate the continuous integral, so
      with the unit-amplitude pulse and the ``1 / T_p`` replica the spec pins,
      an isolated row's peak is exactly its complex coefficient with no
      sample-count factor.

    The window tapers the correlation SPECTRUM, which is the direct analogue of
    what the FMCW and OFDM backends do: in all three the window tapers the input
    of the final transform. It is applied in the unshifted spectral order via
    ``ifftshift``, so bin zero of the taper lands on DC.
    """

    if oversample < 1:
        raise ValueError(f"oversample must be at least 1, got {oversample}")
    samples = int(signal.shape[-1])
    if periodic and int(replica.shape[0]) != samples:
        raise ValueError(
            f"a cyclic correlation needs the gate to hold exactly one code period: the gate has {samples} samples "
            f"and the code period {int(replica.shape[0])}"
        )
    length = samples if periodic else samples + int(replica.shape[0])
    spectrum = torch.fft.fft(signal, n=length, dim=-1) * torch.conj(torch.fft.fft(replica.to(signal.dtype), n=length))
    if window != DEFAULT_WINDOW:
        values = window_values(window, length, dtype=real_dtype_of(signal), device=signal.device)
        spectrum = spectrum * torch.fft.ifftshift(values)
    if oversample > 1:
        # Zero-insert the middle of the lag spectrum: exact band-limited
        # interpolation of the sampled correlation, not a smoothing. The scale
        # keeps the inverse transform an interpolation of the same signal
        # rather than a rescaled copy of it.
        fine = torch.zeros((*spectrum.shape[:-1], length * oversample), dtype=spectrum.dtype, device=spectrum.device)
        half = length // 2
        fine[..., :half] = spectrum[..., :half]
        fine[..., length * oversample - (length - half) :] = spectrum[..., half:]
        spectrum = fine * oversample
        length = length * oversample
    correlation = torch.fft.ifft(spectrum, n=length, dim=-1)
    return correlation[..., : samples * oversample] * float(sample_period_s)


#: A positive Doppler bin is a closing target, in every waveform. The FMCW beat
#: cube is the conjugate of Channel's phasor, so its raw slow-time tone sits at
#: ``+f_ref tau_rate`` while the OFDM and pulsed tones sit at
#: ``-f_ref tau_rate``; the two are reconciled EXACTLY ONCE, inside
#: :func:`~witwin.radar.processing.range_doppler.range_doppler_map`, driven by
#: :attr:`ProcessingAxes.doppler_sign`. Nothing else in this package may look
#: at a phasor.
PROCESSING_DOPPLER_CONVENTION = "positive_doppler_bin_is_closing"

#: Every range profile and every Range-Doppler map is an AMPLITUDE estimate,
#: normalised so that an isolated path row peaks at ``|C_rt|`` times the
#: window's coherent gain. The three waveforms' native transforms have three
#: different gains (``N`` for an unnormalised beat FFT, ``1`` for a CIR inverse
#: transform, ``1`` for a unit-gain matched filter), and publishing all three
#: would make a cross-waveform amplitude comparison a per-waveform bookkeeping
#: exercise.
PROCESSING_AMPLITUDE_CONVENTION = "peak = |C_rt| * window_coherent_gain; transforms are amplitude normalised"

#: The name of the slow-time axis per waveform.
SLOW_TIME_NAMES = {"fmcw": "chirp", "ofdm": "symbol", "pulsed": "pulse"}

#: Every published scalar and axis, with its SI unit. A quantity that is not in
#: this mapping is not part of the published metadata contract.
PROCESSING_UNITS = {
    "slow_time_period_s": "s",
    "range_bin_m": "m",
    "range_origin_m": "m",
    "max_unambiguous_range_m": "m",
    "velocity_bin_mps": "m/s",
    "max_unambiguous_speed_mps": "m/s",
    "wavelength_m": "m",
    "reference_frequency_hz": "Hz",
    "element_spacing_m": "m",
    "range_m": "m",
    "velocity_mps": "m/s",
}


def _require_complex(name: str, value: object) -> torch.Tensor:
    if not isinstance(value, torch.Tensor):
        raise TypeError(f"{name} must be a torch.Tensor, got {type(value).__name__}")
    if not value.is_complex():
        raise TypeError(
            f"{name} must be complex; a magnitude has already thrown away the "
            f"phase every later stage needs, got {value.dtype}"
        )
    return value


WAVEFORMS = ("fmcw", "ofdm", "pulsed")


def _doppler_sign_from_phasor(phasor: str) -> int:
    """``+1`` when the cube is conjugated relative to Channel, ``-1`` otherwise.

    This is the whole of the cross-waveform sign trap, written down once. It
    reads the phasor the synthesis owner published as DATA; it does not look at
    the waveform's name, because a waveform's name is not what decides whether
    its product was conjugated.
    """

    if phasor == BEAT_PHASOR:
        return 1
    if phasor == CHANNEL_PHASOR:
        return -1
    raise ValueError(
        f"unknown phasor convention {phasor!r}: this package knows "
        f"{BEAT_PHASOR!r} (the FMCW beat cube, conjugated) and "
        f"{CHANNEL_PHASOR!r} (everything else). A third convention needs its "
        "own Doppler sign decided deliberately, not defaulted"
    )


@dataclass(frozen=True, slots=True, eq=False)
class ProcessingAxes:
    """Everything a processing stage needs to know about a synthesis product.

    The single physical-axis owner for every waveform. It is built from the SI
    waveform SPEC, the ``SensorArraySpec`` and the ``SynthesisResult``'s own
    published conventions, never from the engineering-unit radar configuration:
    a second reader of those units would be a second conversion, and a
    conversion that is wrong once is wrong everywhere.

    The two materialised axes are float64 and are the ONLY place a bin index
    becomes a physical quantity. Every stage reads them; no stage re-derives
    them. That is what makes the cross-waveform criterion - one physical target,
    three waveforms, one range in metres and one signed velocity - a comparison
    of three axis records rather than a comparison of three ad-hoc formulas.

    ``doppler_sign`` is DERIVED from the cube's published ``phasor`` - not from
    the waveform's name, and not by editing the phasor constants - and
    :func:`~witwin.radar.processing.range_doppler.range_doppler_map` is the one
    place it is applied.
    """

    __repr__ = compact_repr

    waveform: str
    output_domain: str
    fast_time_name: str
    slow_time_name: str
    slow_time_period_s: float

    range_bin_count: int
    doppler_bin_count: int
    range_bin_m: float
    range_origin_m: float
    max_unambiguous_range_m: float

    velocity_bin_mps: float
    max_unambiguous_speed_mps: float

    wavelength_m: float
    reference_frequency_hz: float

    phasor: str
    doppler_sign: int

    num_tx: int
    num_rx: int
    element_spacing_m: float
    tx_loc_half_wavelength: tuple[tuple[float, float, float], ...]
    rx_loc_half_wavelength: tuple[tuple[float, float, float], ...]

    range_m: torch.Tensor
    velocity_mps: torch.Tensor

    #: Pulsed only. The matched-filter replica and the fast-time sample period
    #: it was built on travel with the axes because the range-profile entry
    #: takes ONE metadata record and must not learn what a waveform spec is.
    range_oversample: int = 1
    matched_filter_replica: torch.Tensor | None = None
    matched_filter_sample_period_s: float = 0.0
    #: Pulsed only: the code is transmitted continuously, so the matched filter
    #: is the cyclic correlation over one code period.
    matched_filter_periodic: bool = False
    #: How the transmitters shared the frame: ``tdm``, ``ddm`` or ``bpm``
    #: (R-ADR-048). A DDM or BPM cube records every transmitter on each receiver
    #: until :func:`~witwin.radar.processing.demultiplex` separates them.
    mimo: str = "tdm"
    #: DDM and BPM: each transmitter's code per slow-time sample, ``[slow,
    #: num_tx]`` complex128, in the CUBE's phasor convention.
    transmit_code: torch.Tensor | None = None
    #: The code period in chirps a demultiplexer decimates by (DDM sub-bands,
    #: BPM block length). One for TDM.
    code_period: int = 1
    #: Whether this record describes a demultiplexed virtual-array cube.
    demultiplexed: bool = False
    #: Time-domain OFDM: the transmitted symbols ``X[symbol, subcarrier]``,
    #: complex128, which demodulation divides by and ISAC processing reads.
    ofdm_symbols: torch.Tensor | None = None

    def __post_init__(self) -> None:
        if self.waveform not in WAVEFORMS:
            raise ValueError(f"waveform must be one of {WAVEFORMS}, got {self.waveform!r}")
        if self.doppler_sign not in (1, -1):
            raise ValueError(f"doppler_sign must be +1 or -1, got {self.doppler_sign!r}")
        if int(self.range_m.shape[0]) != self.range_bin_count:
            raise ValueError(
                f"range_m holds {int(self.range_m.shape[0])} bins but range_bin_count is {self.range_bin_count}"
            )
        if int(self.velocity_mps.shape[0]) != self.doppler_bin_count:
            raise ValueError(
                f"velocity_mps holds {int(self.velocity_mps.shape[0])} bins but "
                f"doppler_bin_count is {self.doppler_bin_count}"
            )
        if self.range_m.dtype != torch.float64:
            raise TypeError("range_m must be float64: it is a coordinate, and a float32 metre at 300 m has a 2 cm ulp")
        if self.velocity_mps.dtype != torch.float64:
            raise TypeError("velocity_mps must be float64, for the same reason")
        if (self.matched_filter_replica is None) != (self.waveform != "pulsed"):
            raise ValueError(
                "a matched-filter replica belongs to the pulsed waveform and to "
                f"no other; this record is {self.waveform!r}"
            )
        if self.waveform != "pulsed" and self.range_oversample != 1:
            raise ValueError(
                f"range_oversample={self.range_oversample} is a matched-filter "
                "lag-grid refinement and means nothing for a transform whose "
                "bin grid is the waveform's own; only the pulsed backend "
                "accepts it"
            )

    # -- the published unit contract ---------------------------------------

    @property
    def units(self) -> dict[str, str]:
        """Every published scalar and axis, with its SI unit."""

        return dict(PROCESSING_UNITS)

    @property
    def sensor_pair_count(self) -> int:
        return self.num_tx * self.num_rx

    @property
    def transmit_channels(self) -> int:
        """How many transmit channels the described cube records separately.

        ``num_tx`` for TDM and for a demultiplexed cube; one for a DDM or BPM
        cube as received, which holds every transmitter on each receiver.
        """

        return self.num_tx if (self.mimo == "tdm" or self.demultiplexed) else 1

    @property
    def device(self) -> torch.device:
        return self.range_m.device

    # -- construction -------------------------------------------------------

    @classmethod
    def from_synthesis(
        cls,
        result: SynthesisResult,
        spec: FmcwSpec | OfdmSpec | PulsedSpec,
        array: SensorArraySpec,
        *,
        range_oversample: int = 1,
    ) -> "ProcessingAxes":
        """Read one synthesis result, its waveform spec, and the array.

        The result supplies the CUBE's shape and its published conventions, the
        spec supplies the SI waveform grid, and the array supplies the element
        geometry. All three are checked against each other before anything is
        derived: a cube synthesized from one spec and described by another is a
        configuration error whose only symptom would be a range axis that is
        quietly the wrong scale.
        """

        return cls._build(result, spec, array, range_oversample=range_oversample, device=result.cube.device)

    @classmethod
    def from_radar(
        cls, radar: "Radar", *, range_oversample: int = 1, device: torch.device | str | None = None
    ) -> "ProcessingAxes":
        """The record a cube this radar produces is described by, with no cube.

        ``radar`` is a :class:`witwin.radar.Radar`. Its waveform spec and its
        array are the same two records the echo builds ``Result.axes`` from, and
        the cube's published conventions - axis names, phasor, output domain -
        come from the same :class:`SynthesisResult` factory the synthesis owner
        calls, evaluated on a shape-only ``meta`` tensor. So for any radar,
        ``ProcessingAxes.from_radar(radar)`` and the ``Result.axes`` of a frame
        it simulated describe the same grid, field for field.

        This is the entry for a RECORDED or externally synthesized cube. It
        assumes the cube follows this package's conventions: an FMCW cube is in
        the de-chirped BEAT phasor (a target at positive range is a positive
        beat frequency), OFDM and pulsed cubes are in Channel's phasor, and the
        FMCW fast axis is whatever ``Fmcw.output`` declares - ADC samples are
        ``output="beat"``. A device whose IQ runs the other way is conjugated by
        the caller before it reaches here.

        ``device`` is where the two float64 axes are placed; it defaults to the
        radar's own device.
        """

        # Read by its interface rather than imported: the radar record imports the
        # session, which imports this package.
        if not (hasattr(radar, "waveform_spec") and hasattr(radar, "system_config") and hasattr(radar, "device")):
            raise TypeError(f"from_radar takes a witwin.radar.Radar, got {type(radar).__name__}")
        spec = radar.waveform_spec()
        array = radar.system_config.sensors.array
        result = _shape_only_result(spec, array.sensor_pair_count)
        target = radar.device if device is None else torch.device(device)
        return cls._build(result, spec, array, range_oversample=range_oversample, device=target)

    @classmethod
    def _build(
        cls,
        result: SynthesisResult,
        spec: FmcwSpec | OfdmSpec | PulsedSpec,
        array: SensorArraySpec,
        *,
        range_oversample: int,
        device: torch.device,
    ) -> "ProcessingAxes":
        cube = result.cube
        if cube.dim() != 3:
            raise ValueError(
                "a synthesis result is a rank-3 (slow_time, sensor_pair, "
                f"fast_time) cube; got shape {tuple(cube.shape)}"
            )
        kind = str(result.kind)
        if kind not in WAVEFORMS:
            raise ValueError(f"no processing owner for waveform kind {kind!r}")
        reference = float(result.reference_frequency_hz)
        if float(spec.reference_frequency_hz) != reference:
            raise ValueError(
                f"the cube was synthesized at {reference} Hz but the spec "
                f"declares {float(spec.reference_frequency_hz)} Hz"
            )
        if float(array.reference_frequency_hz) != reference:
            raise ValueError(
                f"the cube was synthesized at {reference} Hz but the array's "
                f"element spacing is defined at "
                f"{float(array.reference_frequency_hz)} Hz; the two are the "
                "same physical quantity"
            )
        simultaneous = kind == "fmcw" and bool(cast(FmcwSpec, spec).simultaneous)
        recorded = array.num_rx if simultaneous else array.sensor_pair_count
        if int(cube.shape[1]) != recorded:
            raise ValueError(
                f"the cube spans {int(cube.shape[1])} sensor pairs but the array "
                f"is {array.num_tx} x {array.num_rx} = "
                f"{array.sensor_pair_count} pairs"
                + (f", recorded on {array.num_rx} receivers under {cast(FmcwSpec, spec).mimo}" if simultaneous else "")
            )
        if type(range_oversample) is not int or range_oversample < 1:
            raise ValueError(f"range_oversample must be a positive int, got {range_oversample!r}")

        slow_count = int(cube.shape[0])
        fast_count = int(cube.shape[2])
        wavelength = SPEED_OF_LIGHT_M_PER_S / reference

        replica: torch.Tensor | None = None
        replica_period = 0.0
        periodic = False
        mimo, code_period = "tdm", 1
        code: torch.Tensor | None = None
        symbols: torch.Tensor | None = None
        if kind == "fmcw":
            spec = cast(FmcwSpec, spec)
            if simultaneous:
                mimo = str(spec.mimo)
                physical = spec.transmit_code()
                # The beat cube carries the conjugate of the physical code.
                in_cube = physical.conj() if str(result.phasor) == BEAT_PHASOR else physical
                code = torch.from_numpy(in_cube).to(device=device, dtype=torch.complex128)
                code_period = int(spec.ddm_bands or spec.num_tx) if spec.mimo == "ddm" else int(spec.num_tx)
            slow_period = float(spec.slot_period_s)
            max_speed = float(spec.max_unambiguous_speed_mps)
            range_count = fast_count
            range_bin = (
                SPEED_OF_LIGHT_M_PER_S
                * float(spec.sample_rate_hz)
                / (2.0 * float(spec.slope_hz_per_s) * int(spec.num_samples))
            )
            range_origin = 0.0
            max_range = range_bin * range_count
        elif kind == "ofdm":
            spec = cast(OfdmSpec, spec)
            if spec.time_domain:
                symbols = torch.from_numpy(spec.symbol_table()).to(device=device, dtype=torch.complex128)
            slow_period = float(spec.symbol_period_s)
            max_speed = float(spec.max_unambiguous_speed_mps)
            range_count = fast_count
            range_bin = float(spec.range_resolution_m)
            range_origin = 0.0
            max_range = SPEED_OF_LIGHT_M_PER_S * float(spec.max_unambiguous_delay_s) / 2.0
        else:
            spec = cast(PulsedSpec, spec)
            slow_period = float(spec.pri_s)
            max_speed = float(spec.max_unambiguous_speed_m_s)
            range_count = fast_count * range_oversample
            range_bin = SPEED_OF_LIGHT_M_PER_S * float(spec.sample_period_s) / (2.0 * range_oversample)
            range_origin = SPEED_OF_LIGHT_M_PER_S * float(spec.range_gate_start_s) / 2.0
            max_range = float(spec.max_unambiguous_range_m)
            replica_period = float(spec.sample_period_s)
            replica = pulse_samples(spec, device=device)
            periodic = bool(spec.periodic)

        return cls(
            waveform=kind,
            output_domain=str(result.output_domain),
            fast_time_name=str(result.axes[-1]),
            slow_time_name=SLOW_TIME_NAMES[kind],
            slow_time_period_s=slow_period,
            range_bin_count=range_count,
            doppler_bin_count=slow_count,
            range_bin_m=range_bin,
            range_origin_m=range_origin,
            max_unambiguous_range_m=max_range,
            velocity_bin_mps=wavelength / (2.0 * slow_count * slow_period),
            max_unambiguous_speed_mps=max_speed,
            wavelength_m=wavelength,
            reference_frequency_hz=reference,
            phasor=str(result.phasor),
            doppler_sign=_doppler_sign_from_phasor(str(result.phasor)),
            num_tx=int(array.num_tx),
            num_rx=int(array.num_rx),
            element_spacing_m=float(array.element_spacing_m),
            tx_loc_half_wavelength=cast(
                "tuple[tuple[float, float, float], ...]",
                tuple(tuple(float(value) for value in row) for row in array.tx_loc),
            ),
            rx_loc_half_wavelength=cast(
                "tuple[tuple[float, float, float], ...]",
                tuple(tuple(float(value) for value in row) for row in array.rx_loc),
            ),
            range_m=_range_axis(range_count, range_bin, range_origin, device),
            velocity_mps=_velocity_axis(slow_count, slow_period, wavelength, device),
            range_oversample=range_oversample,
            matched_filter_replica=replica,
            matched_filter_sample_period_s=replica_period,
            matched_filter_periodic=periodic,
            mimo=mimo,
            transmit_code=code,
            code_period=code_period,
            ofdm_symbols=symbols,
        )

    def with_bin_counts(self, *, range_bins: int | None = None, doppler_bins: int | None = None) -> "ProcessingAxes":
        """The record of a product whose transforms have other lengths.

        ``range_bins`` is a zero-padded range transform: the span
        ``range_bin_count * range_bin_m`` is unchanged and the bin shrinks to
        span / ``range_bins``. ``doppler_bins`` is the length of the slow-time
        transform, for a zero-padded Doppler transform or for a slow-time filter
        that shortened the sequence; the slow-time period is unchanged, so the
        velocity bin is ``lambda / (2 * doppler_bins * T_slow)`` and the axis
        is the same ``fftshift``ed formula :meth:`from_synthesis` publishes.

        A pulsed range grid is refined with ``range_oversample``, which is exact
        band-limited interpolation of the matched filter; a second refinement
        knob for one grid is refused.
        """

        record = self
        if range_bins is not None:
            if type(range_bins) is not int or range_bins < 1:
                raise ValueError(f"range_bins must be a positive int, got {range_bins!r}")
            if self.waveform == "pulsed":
                raise ValueError(
                    "the pulsed range grid is refined by range_oversample on the axes record, which interpolates "
                    "the matched filter exactly; range_bins does not apply to it"
                )
            span = self.range_bin_m * self.range_bin_count
            bin_m = span / range_bins
            record = replace(
                record,
                range_bin_count=range_bins,
                range_bin_m=bin_m,
                range_m=_range_axis(range_bins, bin_m, self.range_origin_m, self.device),
            )
        if doppler_bins is not None:
            if type(doppler_bins) is not int or doppler_bins < 1:
                raise ValueError(f"doppler_bins must be a positive int, got {doppler_bins!r}")
            period = self.slow_time_period_s
            record = replace(
                record,
                doppler_bin_count=doppler_bins,
                velocity_bin_mps=self.wavelength_m / (2.0 * doppler_bins * period),
                velocity_mps=_velocity_axis(doppler_bins, period, self.wavelength_m, self.device),
            )
        return record


def _range_axis(count: int, bin_m: float, origin_m: float, device: torch.device) -> torch.Tensor:
    """``origin + k * bin`` in float64 metres: the one formula behind every range axis."""

    return (torch.arange(count, dtype=torch.float64, device=device) * bin_m + origin_m).contiguous()


def _velocity_axis(count: int, period_s: float, wavelength_m: float, device: torch.device) -> torch.Tensor:
    """``lambda f / 2`` over the ``fftshift``ed slow-time frequencies, closing positive."""

    frequency = torch.fft.fftshift(torch.fft.fftfreq(count, d=period_s, dtype=torch.float64, device=device))
    return (frequency * (wavelength_m / 2.0)).contiguous()


def _shape_only_result(spec: FmcwSpec | OfdmSpec | PulsedSpec, pairs: int) -> SynthesisResult:
    """The :class:`SynthesisResult` a frame of ``spec`` would publish, on a ``meta`` cube.

    The factory is the one the synthesis owner calls, so the axis names, the
    phasor and the output domain come from their single owner rather than from
    a second table here. A ``meta`` tensor has a shape and no storage.
    """

    build: Callable[[torch.Tensor, Any], SynthesisResult]
    if isinstance(spec, FmcwSpec):
        recorded = spec.num_rx if spec.simultaneous else pairs
        shape, build = (spec.num_chirps, recorded, spec.num_samples), SynthesisResult.from_fmcw
    elif isinstance(spec, OfdmSpec):
        fast = spec.samples_per_symbol if spec.output_domain == "time" else spec.num_subcarriers
        shape, build = (spec.num_symbols, pairs, fast), SynthesisResult.from_ofdm
    elif isinstance(spec, PulsedSpec):
        shape, build = (spec.num_pulses, pairs, spec.num_samples), SynthesisResult.from_pulsed
    else:
        raise TypeError(f"no processing owner for a {type(spec).__name__}")
    return build(torch.empty(shape, dtype=torch.complex64, device="meta"), cast(Any, spec))


@dataclass(frozen=True, slots=True, eq=False)
class ProcessingCube:
    """``[TX, RX, C, S]`` complex, with the metadata record it was built with.

    ``C`` is the slow-time axis (chirps, symbols or pulses) and ``S`` the
    fast-time axis (samples or subcarriers); which is which is named on the
    axes record rather than inferred from the waveform.

    Nothing here knows about ``row_valid``. A dead row is masked on the WEIGHT
    before the waveform kernel launches, so its contribution to the cube is a
    literal zero and no downstream stage has anything to mask.
    """

    __repr__ = compact_repr

    data: torch.Tensor
    axes: ProcessingAxes

    def __post_init__(self) -> None:
        if not isinstance(self.data, torch.Tensor):
            raise TypeError(f"data must be a torch.Tensor, got {type(self.data).__name__}")
        if not self.data.is_complex():
            raise TypeError(
                "a processing cube is complex IQ; a magnitude has already "
                f"thrown away the phase every later stage needs, got {self.data.dtype}"
            )
        if self.data.dim() != 4:
            raise ValueError(f"a processing cube is [tx, rx, slow_time, fast_time]; got shape {tuple(self.data.shape)}")
        expected = (self.axes.transmit_channels, self.axes.num_rx)
        if tuple(self.data.shape[:2]) != expected:
            raise ValueError(
                f"the cube's array axes are {tuple(self.data.shape[:2])} but the axes record declares {expected}"
            )
        if int(self.data.shape[2]) != int(self.axes.doppler_bin_count):
            raise ValueError(
                f"the cube has {int(self.data.shape[2])} slow-time samples but "
                f"the axes record's Doppler transform is "
                f"{int(self.axes.doppler_bin_count)} long"
            )

    @property
    def device(self) -> torch.device:
        return self.data.device

    @classmethod
    def from_synthesis(cls, result: SynthesisResult, axes: ProcessingAxes) -> "ProcessingCube":
        """Pack one rank-3 synthesis cube into the rank-4 array layout.

        The axes record is passed in rather than rebuilt, so that the record
        used to pack the cube and the record every later stage reads are the
        same object. Rebuilding it here would let a caller process a cube
        against a different array than the one it was assembled for.

        The transpose from the SINK-MAJOR composed pair rank to the TX-MAJOR
        virtual-antenna index is ``synthesis/assembly.py::assemble_frame_cube``,
        CALLED here rather than reimplemented: two packers for one layout is
        how a TX/RX swap ships silently on a square array.
        """

        if tuple(result.axes) != (axes.slow_time_name, "sensor_pair", axes.fast_time_name):
            raise ValueError(
                f"this result publishes axes {tuple(result.axes)} but the "
                f"metadata record describes ({axes.slow_time_name}, "
                f"sensor_pair, {axes.fast_time_name}); the two describe "
                "different products"
            )
        if str(result.phasor) != axes.phasor:
            raise ValueError(
                f"this result is in the {result.phasor!r} convention but the "
                f"metadata record was built for {axes.phasor!r}; the Doppler "
                "sign is derived from that string and would be reconciled "
                "backwards"
            )
        return cls(data=assemble_frame_cube(result.cube, num_tx=axes.transmit_channels, num_rx=axes.num_rx), axes=axes)

    @classmethod
    def from_tensor(cls, cube: torch.Tensor, radar: "Radar", *, range_oversample: int = 1) -> "ProcessingCube":
        """A recorded or synthetic complex cube, described by the radar that took it.

        Two layouts are accepted, told apart by rank:

        * ``[slow, pair, fast]`` - the synthesis layout. The pair axis is SINK
          MAJOR, ``pair = rx * num_tx + tx`` (``PAIR_RANK_LAYOUT``), exactly as
          ``Result.synthesis.cube`` publishes it. It is transposed to the
          TX-major array layout by ``assemble_frame_cube``, the one packer.
        * ``[tx, rx, slow, fast]`` - already in the array layout, used as is.

        ``slow`` is chirp slots (one slot fires every transmitter once under
        TDM), symbols or pulses; ``fast`` is what the radar's waveform declares
        (for FMCW, ADC samples need ``Fmcw(output="beat")``). Both lengths and
        the TX and RX counts must equal the radar's; nothing is inferred from
        the shape. The axes record is :meth:`ProcessingAxes.from_radar` on the
        cube's device, so the conventions are the ones that method documents.
        """

        if not isinstance(cube, torch.Tensor):
            raise TypeError(f"cube must be a torch.Tensor, got {type(cube).__name__}")
        axes = ProcessingAxes.from_radar(radar, range_oversample=range_oversample, device=cube.device)
        fast = axes.range_bin_count // axes.range_oversample
        slow = axes.doppler_bin_count
        channels = axes.transmit_channels
        expected: tuple[int, ...]
        if cube.dim() == 3:
            expected = (slow, channels * axes.num_rx, fast)
            if tuple(cube.shape) != expected:
                raise ValueError(
                    f"a [slow, pair, fast] cube for this radar is {expected}, got {tuple(cube.shape)}; the pair axis "
                    "is sink major, pair = rx * num_tx + tx"
                )
            _require_complex("cube", cube)
            return cls(data=assemble_frame_cube(cube, num_tx=channels, num_rx=axes.num_rx), axes=axes)
        if cube.dim() == 4:
            expected = (channels, axes.num_rx, slow, fast)
            if tuple(cube.shape) != expected:
                raise ValueError(f"a [tx, rx, slow, fast] cube for this radar is {expected}, got {tuple(cube.shape)}")
            return cls(data=cube, axes=axes)
        raise ValueError(
            f"a cube is [slow, pair, fast] (sink-major pairs) or [tx, rx, slow, fast]; got shape {tuple(cube.shape)}"
        )
