"""The input contract every waveform synthesis kernel consumes, and the
waveform descriptions that go with it.

This module is pure and CPU-testable on purpose: the unit conversions between
the radar config's engineering units and SI are exactly the kind of thing that
is wrong once and then wrong everywhere, and they should not require a GPU to
check. The same is true of the provenance rules below, which decide whether a
weight and a waveform spec may be used together at all.

Two contracts live here and they are not the same statement:

* :class:`~witwin.radar.paths.RadarPathBatch` is what the two-way
  composer PRODUCED.
* :class:`SynthesisPathBatch` is what a waveform kernel is ALLOWED TO ASSUME
  about a weight.

The difference is provenance. Every double-count hazard in this family is a
combination of a weight and a spec that nobody validates against each other: a
Channel coefficient already carries
``exp(-j 2 pi f_ref tau_rt)``, ``lambda/(4 pi d)`` per leg, and
``sqrt(tx_power)``, so a kernel that applies any of them again is silently
wrong by a factor nobody notices. Recording that on the batch and validating
the spec against it at construction turns six documented hazards into four
impossible states, which is the difference between a rule and a comment.
"""

import cmath
import math
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any, ClassVar, Protocol, runtime_checkable

import numpy as np
import torch

from ..display import compact_repr
from ..paths import RadarComponentIndex, RadarPathBatch, RadarPathTopology
from ..policy import SPEED_OF_LIGHT_M_PER_S, first_order_only, require_host_floats

#: Why no waveform spec scalar is differentiable, stated once and quoted by all
#: three specs.
#:
#: A waveform spec DECLARES a transmission: how fast the ramp sweeps, how far
#: apart the subcarriers sit, how long the pulse is, where the gate opens. None
#: of that is scene state - it is the radar's own configuration, chosen before
#: a frame exists, and the kernels consume every one of these numbers by value
#: on the host. The differentiable inputs of this family are the per-row
#: tensors ``total_delay_s``, ``delay_rate`` and the complex weight, and they
#: are covered leaf by leaf.
#:
#: Waveform-parameter optimisation is a real thing to want, and the reason it
#: is not simply enabled is that a spec scalar changes the SHAPE of the output
#: as often as its value: ``num_samples``, ``num_subcarriers`` and
#: ``pulse_width_s`` all move a sampling grid, and a derivative taken across a
#: grid change is not the derivative of a fixed function. That is a modelling
#: decision with its own ADR, not a slot to open quietly.
WAVEFORM_SPEC_REASON = (
    "a waveform spec DECLARES the transmission - the ramp, the subcarrier "
    "grid, the pulse, the gate - and is host configuration rather than scene "
    "state. Its kernels read every scalar here by value on the host, and the "
    "differentiable inputs of this family are the per-row delay, delay rate "
    "and complex weight."
)


#: Channel's phasor convention, which the OFDM CFR cube is published in
#: unchanged. Quoted verbatim from ``witwin.channel.constants.PHASOR``.
CHANNEL_PHASOR = "exp(-j*k*d)"

#: Channel's time-dependence convention, quoted verbatim from
#: ``witwin.channel.constants.TIME_DEPENDENCE``.
CHANNEL_TIME_DEPENDENCE = "exp(+j*2*pi*f*t)"

#: The FMCW beat cube's convention, which is the CONJUGATE of Channel's.
#: De-chirping multiplies the transmitted chirp by the conjugate of the echo, so
#: the beat-domain phasor advances with ``+j`` while a Channel transport advances
#: with ``-j``. Both are correct and they are different products; naming the beat
#: one here is what lets a result carry its convention as data instead of a
#: reader inferring it from the waveform's name.
BEAT_PHASOR = "conj(exp(-j*k*d))"


def require_single_carrier_home(carrier_hz: float, carrier_rate_hz: float) -> None:
    """Refuse a spec that names the absolute carrier in both of its homes.

    Shared by every waveform spec, because it is one rule about one physical
    quantity rather than a per-waveform convention: the absolute
    reference-frequency phase either lives in the weight, in which case the
    kernel applies it only to the delay CHANGE (``carrier_rate_hz``), or it
    lives in the kernel, which applies it to the full delay (``carrier_hz``)
    and therefore already walks across slow time. Naming both counts the
    carrier twice.

    This is a spec-INTERNAL consistency check. The batch-versus-spec checks are
    rules R1-R4 of :func:`require_compatible`, and neither subsumes the other:
    this one catches a self-contradictory spec before a batch is even in hand.
    """

    if carrier_hz != 0.0 and carrier_rate_hz != 0.0:
        raise ValueError(
            "carrier_hz and carrier_rate_hz name the same carrier in two "
            "different homes; setting both double counts it. Use "
            "carrier_hz=fc with carrier_rate_hz=0 when the kernel owns the "
            "carrier phase, or carrier_hz=0 with carrier_rate_hz=fc when a "
            "Channel-sourced weight already carries it."
        )


FMCW_OUTPUT_SPECTRUM = "spectrum"
FMCW_OUTPUT_BEAT = "beat"
FMCW_OUTPUT_DOMAINS = (FMCW_OUTPUT_SPECTRUM, FMCW_OUTPUT_BEAT)

#: How the transmitters share a frame (R-ADR-048). ``tdm`` fires them one per
#: chirp slot; ``ddm`` fires all of them every chirp, transmitter ``t`` carrying
#: the phase ramp ``exp(+j 2 pi t c / ddm_bands)`` across chirps ``c``; ``bpm``
#: fires all of them every chirp with the Hadamard sign ``H[c mod T, t]``.
MIMO_TDM = "tdm"
MIMO_DDM = "ddm"
MIMO_BPM = "bpm"
MIMO_SCHEMES = (MIMO_TDM, MIMO_DDM, MIMO_BPM)


def hadamard(order: int) -> np.ndarray:
    """The Sylvester Hadamard matrix of a power-of-two ``order``, as ``int64``."""

    if order < 1 or order & (order - 1):
        raise ValueError(f"a Sylvester Hadamard order is a power of two, got {order}")
    matrix = np.ones((1, 1), dtype=np.int64)
    while matrix.shape[0] < order:
        matrix = np.block([[matrix, matrix], [matrix, -matrix]])
    return matrix


@dataclass(frozen=True, slots=True)
class FmcwSpec:
    """One chirp frame's sampling grid and ramp, in SI units.

    The carrier phase ``2 * pi * f_c * tau`` has two legitimate homes, and the
    two carrier parameters together say which one. Exactly one of them is
    nonzero:

    * ``carrier_hz = fc``, ``carrier_rate_hz = 0``  -  the kernel owns the whole
      carrier phase, applied to the full delay ``tau``.
    * ``carrier_hz = 0``, ``carrier_rate_hz = fc``  -  the production path for
      Channel-sourced weights, where the absolute carrier phase already sits
      inside the natively computed coefficient. That placement is more accurate,
      because the coefficient's phase was formed against a float64 delay inside
      the native kernel, while a float32 ``tau`` re-multiplied by 77 GHz loses
      roughly 2e-4 rad at 2 m and 1e-2 rad at 100 m.

    ``carrier_rate_hz`` is not a second copy of the carrier and not a tuning
    knob. A Channel coefficient is frozen at the per-frame ``tau_rt``, so the
    carrier phase it holds does NOT advance across chirps. Without this term the
    slow-time phase walk keeps only ``slope * (t_start - tau + t_m) * tau_rate``
    and understates intra-frame Doppler by 21x to 215x across the fast-time axis
    - silently, because the primal still looks like a plausible radar cube.
    ``carrier_rate_hz`` applies the carrier to the delay CHANGE
    ``(tau - tau_rt)`` only. For linear motion this change includes both the
    TDM slot time and the chirp-local ADC time.

    Setting both to ``fc`` double counts the carrier and is refused. Both
    supported settings are exact; neither is a fallback for the other.

    ``num_tx`` and ``num_rx`` describe the TDM-MIMO array. They belong on the
    spec rather than on the batch because they are a property of the WAVEFORM's
    time structure: TDM fires the transmitters sequentially, so the slow-time
    coordinate of a sensor pair is its slot ``chirp * num_tx + tx``, not the
    chirp index. ``num_tx = 1`` is the degenerate single-transmitter case where
    slot and chirp coincide.
    """

    #: The beat kernel has no ``lambda / (4 pi d)`` term at all: free-space
    #: spreading is Channel transport's, per leg, once. This is a statement
    #: about the kernel and not a setting, so it is a class attribute rather
    #: than a field nobody may change.
    applies_spreading: ClassVar[bool] = False

    #: The convention the published cube is in, carried as data so that a
    #: consumer never has to infer it from the waveform's name. This is the ONE
    #: waveform whose product is conjugated relative to Channel's, and stating
    #: it here is what makes a cross-waveform phase comparison writable.
    phasor: ClassVar[str] = BEAT_PHASOR
    time_dependence: ClassVar[str] = CHANNEL_TIME_DEPENDENCE

    num_samples: int
    num_chirps: int
    sample_period_s: float
    chirp_period_s: float
    slope_hz_per_s: float
    t_start_s: float
    reference_frequency_hz: float
    carrier_hz: float = 0.0
    carrier_rate_hz: float = 0.0
    num_tx: int = 1
    num_rx: int = 1
    output_domain: str = FMCW_OUTPUT_SPECTRUM
    #: Start frequency of the ramp relative to ``reference_frequency_hz``, Hz.
    #: The weight carries only the reference frequency, so the kernel applies
    #: the offset to the FULL delay.
    start_offset_hz: float = 0.0
    #: A chirp sequence (R-ADR-047): one ``(slope [Hz/s], start offset [Hz],
    #: idle [s], ADC start [s], ramp end [s])`` profile per slot of a loop,
    #: repeated cyclically across the frame's slots. Slot ``s`` occupies its
    #: ramp then its idle, and its ramp starts at the sum of the earlier slots'
    #: ``idle + ramp_end``. Empty is the uniform ramp the scalar fields describe.
    sequence: tuple[tuple[float, float, float, float, float], ...] = ()
    #: The transmitted ramp's phase error ``E(t) = sum_i c_i t^(i + 2)`` in
    #: CYCLES, ``t`` the time since the ramp start, coefficients in cycles/s^k.
    phase_error_cycles: tuple[float, ...] = ()
    #: The receiver digitises only the in-phase channel: the published samples
    #: are ``Re`` of the complex baseband after the receive chain.
    real_adc: bool = False
    mimo: str = MIMO_TDM
    #: DDM only: how many Doppler sub-bands the phase ramp divides the band
    #: into, at least ``num_tx``. Zero means ``num_tx``.
    ddm_bands: int = 0

    def __post_init__(self) -> None:
        require_host_floats(
            "FmcwSpec", WAVEFORM_SPEC_REASON, start_offset_hz=self.start_offset_hz, ddm_bands=self.ddm_bands
        )
        require_host_floats(
            "FmcwSpec",
            WAVEFORM_SPEC_REASON,
            num_samples=self.num_samples,
            num_chirps=self.num_chirps,
            sample_period_s=self.sample_period_s,
            chirp_period_s=self.chirp_period_s,
            slope_hz_per_s=self.slope_hz_per_s,
            t_start_s=self.t_start_s,
            reference_frequency_hz=self.reference_frequency_hz,
            carrier_hz=self.carrier_hz,
            carrier_rate_hz=self.carrier_rate_hz,
            num_tx=self.num_tx,
            num_rx=self.num_rx,
        )
        if self.num_samples < 1:
            raise ValueError("num_samples must be positive")
        if self.num_chirps < 1:
            raise ValueError("num_chirps must be positive")
        if self.sample_period_s <= 0.0:
            raise ValueError("sample_period_s must be positive")
        if self.chirp_period_s <= 0.0:
            raise ValueError("chirp_period_s must be positive")
        if not self.reference_frequency_hz > 0.0:
            raise ValueError(
                "reference_frequency_hz must be positive; it is the frequency "
                "the weight this spec will consume was evaluated at, and "
                "require_compatible refuses a mismatch"
            )
        if self.num_tx < 1:
            raise ValueError("num_tx must be positive")
        if self.num_rx < 1:
            raise ValueError("num_rx must be positive")
        if self.output_domain not in FMCW_OUTPUT_DOMAINS:
            raise ValueError(f"output_domain must be one of {FMCW_OUTPUT_DOMAINS}, got {self.output_domain!r}")
        require_single_carrier_home(self.carrier_hz, self.carrier_rate_hz)
        if not math.isfinite(self.start_offset_hz):
            raise ValueError("start_offset_hz must be finite")
        window_end_s = self.t_start_s + (self.num_samples - 1) * self.sample_period_s
        if window_end_s >= self.chirp_period_s:
            raise ValueError(
                f"the ADC window ends {window_end_s:.6g} s after the ramp starts (ADC start + (N - 1) / f_s), past "
                f"the chirp period of {self.chirp_period_s:.6g} s (idle + ramp end): its last samples would be taken "
                "on the next chirp"
            )
        for index, profile in enumerate(self.sequence):
            if len(profile) != 5 or not all(math.isfinite(float(value)) for value in profile):
                raise ValueError(f"sequence[{index}] must be five finite numbers (slope, offset, idle, adc, ramp end)")
            _, _, idle, adc_start, ramp_end = (float(value) for value in profile)
            if idle < 0.0 or ramp_end <= 0.0:
                raise ValueError(f"sequence[{index}] needs a non-negative idle and a positive ramp end")
            if adc_start + (self.num_samples - 1) * self.sample_period_s >= idle + ramp_end:
                raise ValueError(f"sequence[{index}]'s ADC window overruns its slot (idle + ramp end)")
        if not all(math.isfinite(float(value)) for value in self.phase_error_cycles):
            raise ValueError("phase_error_cycles must be finite")
        if self.mimo not in MIMO_SCHEMES:
            raise ValueError(f"mimo must be one of {MIMO_SCHEMES}, got {self.mimo!r}")
        if self.mimo == MIMO_BPM:
            if self.num_tx & (self.num_tx - 1):
                raise ValueError(f"BPM codes the transmitters with a Hadamard matrix; num_tx={self.num_tx} is not 2^k")
            if self.num_chirps % self.num_tx:
                raise ValueError(
                    f"BPM codes blocks of num_tx={self.num_tx} chirps; num_chirps={self.num_chirps} is not a multiple"
                )
        if type(self.ddm_bands) is not int or self.ddm_bands < 0:
            raise ValueError(f"ddm_bands must be a non-negative int, got {self.ddm_bands!r}")
        if self.ddm_bands and (self.mimo != MIMO_DDM or self.ddm_bands < self.num_tx):
            raise ValueError("ddm_bands belongs to DDM and must be at least num_tx")

    # -- the frame's slots ----------------------------------------------------

    @property
    def simultaneous(self) -> bool:
        """Every transmitter fires every chirp (DDM, BPM) rather than one per slot."""

        return self.mimo != MIMO_TDM

    @property
    def transmit_channels(self) -> int:
        """How many separately recorded transmit channels the published cube has.

        ``num_tx`` under TDM, whose slots record each transmitter apart; one
        under DDM and BPM, whose receivers hear every transmitter at once until
        processing demultiplexes them.
        """

        return 1 if self.simultaneous else self.num_tx

    @property
    def slot_count(self) -> int:
        """The frame's chirp slots: ``num_chirps * num_tx`` under TDM, else ``num_chirps``."""

        return self.num_chirps * (1 if self.simultaneous else self.num_tx)

    @property
    def uniform(self) -> bool:
        """Whether every slot is the scalar ramp: no sequence and no start offset."""

        return not self.sequence and self.start_offset_hz == 0.0

    @property
    def admits_direct_spectrum(self) -> bool:
        """Whether the closed-form Dirichlet range spectrum describes this ramp.

        It needs one slope and one window on every chirp, a linear ramp and a
        complex receiver. Anything else is synthesized as beat samples and
        transformed by processing.
        """

        return not self.sequence and not self.phase_error_cycles and not self.real_adc

    def slot_profiles(self) -> np.ndarray:
        """``float64[slot_count, 4]``: each slot's ramp start [s], slope, start offset, ADC start.

        Uniform ramps put slot ``s`` at ``s * chirp_period_s``, which is the
        kernel's own scalar expression. A sequence accumulates its profiles'
        ``idle + ramp_end`` in float64.
        """

        count = self.slot_count
        if not self.sequence:
            slots = np.arange(count, dtype=np.float64)
            return np.stack(
                (
                    slots * self.chirp_period_s,
                    np.full(count, self.slope_hz_per_s),
                    np.full(count, self.start_offset_hz),
                    np.full(count, self.t_start_s),
                ),
                axis=1,
            )
        loop = np.asarray(self.sequence, dtype=np.float64)
        rows = loop[np.arange(count) % len(loop)]
        periods = rows[:, 2] + rows[:, 4]
        starts = np.concatenate(([0.0], np.cumsum(periods)[:-1]))
        return np.stack((starts, rows[:, 0], rows[:, 1], rows[:, 3]), axis=1)

    def slot_spec(self, slot: int) -> "FmcwSpec":
        """The uniform one-chirp spec of frame slot ``slot``: its slope, offset and ADC start."""

        _, slope, offset, adc_start = self.slot_profiles()[int(slot)]
        return replace(
            self, sequence=(), slope_hz_per_s=float(slope), start_offset_hz=float(offset), t_start_s=float(adc_start)
        )

    def transmit_code(self) -> np.ndarray:
        """``complex128[num_chirps, num_tx]``: each transmitter's physical phase per chirp.

        DDM: ``exp(+j 2 pi t c / B)``, ``B = ddm_bands or num_tx``. BPM:
        ``H[c mod num_tx, t]``. TDM: ones (it codes in time, not in phase).
        Physical means Channel's convention; the beat cube carries its
        conjugate, because the receiver mixes the echo against an uncoded ramp.
        """

        chirps = np.arange(self.num_chirps)
        transmitters = np.arange(self.num_tx)
        if self.mimo == MIMO_DDM:
            bands = self.ddm_bands or self.num_tx
            return np.exp(2j * np.pi * np.outer(chirps, transmitters) / bands)
        if self.mimo == MIMO_BPM:
            return hadamard(self.num_tx)[chirps % self.num_tx].astype(np.complex128)
        return np.ones((self.num_chirps, self.num_tx), dtype=np.complex128)

    @property
    def sample_rate_hz(self) -> float:
        return 1.0 / self.sample_period_s

    @property
    def sensor_pair_count(self) -> int:
        """The TDM-MIMO virtual array size the pair partition must span."""

        return self.num_tx * self.num_rx

    @property
    def wavelength_m(self) -> float:
        return SPEED_OF_LIGHT_M_PER_S / self.reference_frequency_hz

    @property
    def slot_period_s(self) -> float:
        """Slow-time spacing between two chirps of the SAME transmitter.

        With ``num_tx`` transmitters sharing the frame in TDM, a given
        transmitter revisits its slot once every ``num_tx`` chirp periods. This
        is the period the Doppler FFT actually samples at, and it is why TDM
        costs a factor ``num_tx`` of unambiguous velocity. DDM and BPM fire
        every transmitter every chirp, so their physical cube is sampled once a
        chirp. A sequence publishes its mean: the frame length over the chirps.
        """

        if self.sequence:
            profiles = self.slot_profiles()
            last = np.asarray(self.sequence, dtype=np.float64)[(self.slot_count - 1) % len(self.sequence)]
            return float(profiles[-1, 0] + last[2] + last[4]) / self.num_chirps
        return self.chirp_period_s * (1 if self.simultaneous else self.num_tx)

    @property
    def max_unambiguous_speed_mps(self) -> float:
        """``lambda / (4 * T_chirp * num_tx)``, the aliasing bound on ``|v_r|``.

        Half a wavelength of two-way path change per slow-time sample is half a
        cycle of Doppler phase; beyond it the sign of the velocity is not
        recoverable.
        """

        return self.wavelength_m / (4.0 * self.slot_period_s)

    def beat_frequency_hz(self, round_trip_delay_s: float) -> float:
        """``f_beat = slope * tau``, with ``tau`` the ROUND-TRIP delay.

        There is no factor of two here. A two-leg round trip already knows its
        own total delay; doubling it would be a monostatic assumption that this
        contract does not make.
        """

        return self.slope_hz_per_s * float(round_trip_delay_s)

    def beat_bin(self, round_trip_delay_s: float) -> float:
        """Fractional FFT bin of the beat tone over ``num_samples``."""

        return self.beat_frequency_hz(round_trip_delay_s) * self.num_samples / self.sample_rate_hz


#: The only supported OFDM subcarrier origin: ``f_n = f_ref + n * df`` with
#: ``n`` running ``[0, N_sc)``, so subcarrier 0 sits exactly at the frequency
#: the weight was evaluated at. Centring the band instead would put a
#: half-band phase offset between ``H[0][p][0]`` and ``C_rt`` and force a phase
#: correction into every cross-waveform amplitude comparison.
SUBCARRIER_ORIGIN_F_REF_AT_N0 = "f_ref_at_n0"

#: The OFDM output domains: the channel frequency response, or the received
#: post-prefix time samples of the modulated symbol stream (R-ADR-046).
OFDM_OUTPUT_CFR = "cfr"
OFDM_OUTPUT_TIME = "time"
OFDM_OUTPUT_DOMAINS = (OFDM_OUTPUT_CFR, OFDM_OUTPUT_TIME)

#: Subcarrier modulations and their unit-mean-power constellations. ``ones``
#: is the unmodulated comb every subcarrier of the ideal CFR assumes.
OFDM_MODULATIONS = ("ones", "bpsk", "qpsk", "qam16", "qam64")
_QAM_LEVELS = {"bpsk": (np.array([-1.0, 1.0]), 1.0), "qpsk": (np.array([-1.0, 1.0]), math.sqrt(2.0))}
_QAM_LEVELS["qam16"] = (np.array([-3.0, -1.0, 1.0, 3.0]), math.sqrt(10.0))
_QAM_LEVELS["qam64"] = (np.arange(-7.0, 8.0, 2.0), math.sqrt(42.0))


@dataclass(frozen=True, slots=True)
class OfdmSpec:
    """One OFDM frame's subcarrier grid and symbol timing, in SI units.

    The product is a channel frequency response cube
    ``H[symbol, sensor_pair, subcarrier]``, not a time-domain waveform. A CFR is
    the exact analogue of the FMCW beat cube: it is what per-subcarrier
    equalisation ``H = Y / X`` leaves after the transmitted symbols are removed,
    and it needs no per-sample IFFT inside the kernel. A time-domain OFDM
    waveform, if one is ever needed, is a
    downstream IFFT plus cyclic-prefix insertion in DSP glue, not synthesis
    physics.

    **Phasor convention.** This cube is published in the CHANNEL convention
    :data:`CHANNEL_PHASOR`, NOT conjugated. Equalisation removes the transmitted
    symbol but not the carrier convention, so there is nothing to conjugate and
    no conversion site anywhere in the OFDM family. The FMCW beat cube IS
    conjugated, because de-chirping multiplies by the conjugate of the
    transmitted chirp. The two are different products rather than an
    inconsistency, and both carry their convention as data.

    **Subcarrier origin.** ``n = 0`` is pinned to ``reference_frequency_hz``, so
    ``f_n = f_ref + n * df``. With ``carrier_hz = 0``, ``carrier_rate_hz =
    f_ref`` and a stationary row, ``H[0][p][0]`` is exactly the Channel
    coefficient ``C_rt``. That identity is what pinning the origin buys.

    **Narrowband, and what it costs.** The cube is synthesized under the
    narrowband offset law ``H(f_ref + df) = C(f_ref) * exp(-j 2 pi df delay_s)``:
    one coefficient per row, so the material and antenna response is FROZEN at
    ``f_ref`` across the whole band and only the propagation delay is
    frequency-dependent. Channel publishes what that costs, as data on
    ``convention.narrowband_frequency_offset_error_law``:

    * ``O(df / f_ref)`` in SPREADING. The ``lambda/(4*pi*d)`` factor gives an
      exact ``f_ref/(f_ref + n*df)`` magnitude tilt with zero phase - 0.5% across
      a 400 MHz band at 77 GHz, deterministic and closed form.
    * ``O(df / df_fringe)`` in MATERIAL response, where
      ``df_fringe = c / (2 * Re(sqrt(eps_r)) * thickness_m * cos(theta_t))`` is
      the layer stack's Airy fringe. A 0.1 m concrete wall at ``eps_r = 4`` has a
      750 MHz fringe, so a 400 MHz band spans half of one: under the narrowband
      law every subcarrier gets the same wall reflectivity and the IDFT of one
      tap is a clean sinc, while the true per-tap filter ``r_k(f)`` makes it
      smeared and asymmetric. That asymmetry is the material-thickness signature
      a wideband radar is actually measuring, and narrowband OFDM cannot express
      it at all.
    * ZEROTH order in dispersion. A ``DispersionSpec`` is evaluated once, at
      compile, so ``d(eps_r)/df`` is not tracked.

    **Cyclic prefix.** ``max_expected_delay_s`` is a CONFIGURED bound - the
    range window the radar is set up for - and never a measured maximum delay,
    which would be a per-frame device-to-host transfer.
    :func:`require_ofdm_compatible` refuses ``max_expected_delay_s >=
    cyclic_prefix_s`` outright. There is no clamp, no warning, and no
    reduced-accuracy mode, because outside the CP window the single-tap
    per-subcarrier form gains an inter-symbol term this kernel does not have.

    ``carrier_hz`` and ``carrier_rate_hz`` are the same two carrier homes as in
    :class:`FmcwSpec` and obey the same rule through the same helper: the
    absolute phase either lives in the weight, and the kernel applies the
    carrier to the delay CHANGE only, or it lives in the kernel, which applies
    it to the full delay. Naming both counts it twice. Dropping the rate term on
    a frozen Channel weight leaves only the ``n * df`` slow-time phase and
    understates Doppler by ``f_ref / (n * df)`` - a factor of about 1e4 at the
    top of a 64 x 120 kHz band at 77 GHz, and infinite at ``n = 0``.
    """

    #: The CFR kernel has no ``lambda / (4 pi d)`` term at all: free-space
    #: spreading is Channel transport's, per leg, once. A statement about the
    #: kernel rather than a setting, so a class attribute rather than a field.
    applies_spreading: ClassVar[bool] = False

    #: The convention the published cube is in, carried as data so that a
    #: consumer never has to infer it from the waveform's name.
    phasor: ClassVar[str] = CHANNEL_PHASOR
    time_dependence: ClassVar[str] = CHANNEL_TIME_DEPENDENCE

    num_subcarriers: int
    num_symbols: int
    subcarrier_spacing_hz: float
    cyclic_prefix_s: float
    reference_frequency_hz: float
    max_expected_delay_s: float
    carrier_hz: float = 0.0
    carrier_rate_hz: float = 0.0
    subcarrier_origin: str = SUBCARRIER_ORIGIN_F_REF_AT_N0
    #: The subcarrier constellation, one of :data:`OFDM_MODULATIONS`. Anything
    #: but ``ones`` is synthesized in the time domain.
    modulation: str = "ones"
    #: Every ``pilot_spacing``-th subcarrier (``n % pilot_spacing == 0``)
    #: carries the known pilot ``1``. Zero is no pilot comb.
    pilot_spacing: int = 0
    #: Seed of the data symbols: the table is a pure function of the seed, the
    #: modulation and the grid.
    symbol_seed: int = 0
    output_domain: str = OFDM_OUTPUT_CFR
    #: Time domain only: post-prefix samples per output symbol. Zero is the
    #: whole useful symbol, ``num_subcarriers`` samples.
    num_samples: int = 0

    def __post_init__(self) -> None:
        if self.modulation not in OFDM_MODULATIONS:
            raise ValueError(f"modulation must be one of {OFDM_MODULATIONS}, got {self.modulation!r}")
        if self.output_domain not in OFDM_OUTPUT_DOMAINS:
            raise ValueError(f"output_domain must be one of {OFDM_OUTPUT_DOMAINS}, got {self.output_domain!r}")
        for name in ("pilot_spacing", "symbol_seed", "num_samples"):
            value = getattr(self, name)
            if type(value) is not int or value < 0:
                raise ValueError(f"{name} must be a non-negative int, got {value!r}")
        if self.num_samples > self.num_subcarriers:
            raise ValueError("num_samples cannot exceed the useful symbol's num_subcarriers samples")
        require_host_floats(
            "OfdmSpec",
            WAVEFORM_SPEC_REASON,
            num_subcarriers=self.num_subcarriers,
            num_symbols=self.num_symbols,
            subcarrier_spacing_hz=self.subcarrier_spacing_hz,
            cyclic_prefix_s=self.cyclic_prefix_s,
            reference_frequency_hz=self.reference_frequency_hz,
            max_expected_delay_s=self.max_expected_delay_s,
            carrier_hz=self.carrier_hz,
            carrier_rate_hz=self.carrier_rate_hz,
        )
        if self.num_subcarriers < 1:
            raise ValueError("num_subcarriers must be positive")
        if self.num_symbols < 1:
            raise ValueError("num_symbols must be positive")
        if self.subcarrier_spacing_hz <= 0.0:
            raise ValueError("subcarrier_spacing_hz must be positive")
        if self.cyclic_prefix_s <= 0.0:
            raise ValueError(
                "cyclic_prefix_s must be positive; a zero-length cyclic prefix "
                "cannot contain any echo, so the single-tap per-subcarrier form "
                "this spec describes would never be valid"
            )
        if self.max_expected_delay_s < 0.0:
            raise ValueError("max_expected_delay_s must be non-negative")
        if not self.reference_frequency_hz > 0.0:
            raise ValueError(
                "reference_frequency_hz must be positive; it is the frequency "
                "subcarrier 0 sits at and the frequency the weight this spec "
                "will consume was evaluated at"
            )
        if self.subcarrier_origin != SUBCARRIER_ORIGIN_F_REF_AT_N0:
            raise ValueError(
                "subcarrier_origin must be "
                f"{SUBCARRIER_ORIGIN_F_REF_AT_N0!r}; a centred band is a "
                "different frequency grid and would need its own kernel term, "
                "not a relabelling"
            )
        require_single_carrier_home(self.carrier_hz, self.carrier_rate_hz)

    @property
    def useful_symbol_time_s(self) -> float:
        """``T_u = 1 / df``, the FFT window one symbol is transformed over."""

        return 1.0 / self.subcarrier_spacing_hz

    @property
    def symbol_period_s(self) -> float:
        """``T_sym = T_u + T_cp``, the slow-time sampling period.

        The cyclic prefix does not change the CFR closed form, but it does
        lengthen the symbol, which is why it appears in the unambiguous-velocity
        bound: slow time is sampled once per SYMBOL, prefix included.
        """

        return self.useful_symbol_time_s + self.cyclic_prefix_s

    @property
    def waveform_sample_period_s(self) -> float:
        """``T_s = 1 / (N_sc * df)``, the time grid the CIR lands on."""

        return 1.0 / (self.num_subcarriers * self.subcarrier_spacing_hz)

    @property
    def delay_resolution_s(self) -> float:
        """One CIR sample: the delay resolution the whole band buys.

        Identical to :attr:`waveform_sample_period_s` by construction; both
        names exist because one is a property of the waveform's time grid and
        the other is the estimator's resolution, and reading a range resolution
        off a sample period is exactly the step where a factor of two goes
        missing.
        """

        return self.waveform_sample_period_s

    @property
    def occupied_bandwidth_hz(self) -> float:
        """``N_sc * df``, the band the delay resolution comes from."""

        return self.num_subcarriers * self.subcarrier_spacing_hz

    @property
    def range_resolution_m(self) -> float:
        """``c0 / (2 * N_sc * df)`` - the round trip halves the delay."""

        return SPEED_OF_LIGHT_M_PER_S / (2.0 * self.occupied_bandwidth_hz)

    @property
    def max_unambiguous_delay_s(self) -> float:
        """``1 / df``: beyond one useful symbol time the CIR wraps."""

        return self.useful_symbol_time_s

    @property
    def wavelength_m(self) -> float:
        return SPEED_OF_LIGHT_M_PER_S / self.reference_frequency_hz

    @property
    def max_unambiguous_speed_mps(self) -> float:
        """``c0 / (4 * f_ref * T_sym)``, the aliasing bound on ``|v_r|``.

        Equivalently ``lambda / (4 * T_sym)``. Half a wavelength of two-way path
        change per slow-time sample is half a cycle of Doppler phase; beyond it
        the sign of the velocity is not recoverable and a receding target reads
        as an approaching one.
        """

        return SPEED_OF_LIGHT_M_PER_S / (4.0 * self.reference_frequency_hz * self.symbol_period_s)

    @property
    def time_domain(self) -> bool:
        """Whether the frame is synthesized as received time samples.

        A modulated stream or a time output needs the time-domain kernel; the
        unmodulated comb published as a CFR keeps the closed-form CFR kernel.
        """

        return self.modulation != "ones" or self.output_domain == OFDM_OUTPUT_TIME

    @property
    def samples_per_symbol(self) -> int:
        return self.num_samples or self.num_subcarriers

    def pilot_mask(self) -> np.ndarray:
        """``bool[num_subcarriers]``: the subcarriers that carry the pilot."""

        mask = np.zeros(self.num_subcarriers, dtype=bool)
        if self.pilot_spacing:
            mask[:: self.pilot_spacing] = True
        return mask

    def symbol_table(self) -> np.ndarray:
        """``complex128[num_symbols, num_subcarriers]``: the transmitted symbols ``X``.

        Unit mean power for every constellation, so the time envelope has unit
        mean power and the noise contract holds sample by sample. The data
        symbols are drawn from a PCG64 generator seeded by ``symbol_seed``;
        pilots overwrite their subcarriers with ``1``.
        """

        shape = (self.num_symbols, self.num_subcarriers)
        if self.modulation == "ones":
            table = np.ones(shape, dtype=np.complex128)
        else:
            levels, scale = _QAM_LEVELS[self.modulation]
            generator = np.random.Generator(np.random.PCG64(self.symbol_seed))
            real = levels[generator.integers(0, len(levels), size=shape)]
            imag = (
                np.zeros(shape) if self.modulation == "bpsk" else levels[generator.integers(0, len(levels), size=shape)]
            )
            table = (real + 1j * imag) / scale
        table[:, self.pilot_mask()] = 1.0
        return table

    def subcarrier_frequency_hz(self, subcarrier: int) -> float:
        """``f_n = f_ref + n * df`` under the pinned origin."""

        return self.reference_frequency_hz + subcarrier * self.subcarrier_spacing_hz

    def subcarrier_phase_step_rad(self, round_trip_delay_s: float) -> float:
        """``-2 pi df tau``, the phase step between adjacent subcarriers.

        The sign is negative because the cube is in Channel's ``exp(-j k d)``
        convention. This is the exact, bin-free delay statement a CFR carries;
        an IDFT peak is the same information quantised to ``T_s``.
        """

        return -math.tau * self.subcarrier_spacing_hz * float(round_trip_delay_s)

    def cir_peak_sample(self, round_trip_delay_s: float) -> float:
        """``tau / T_s``, the fractional CIR sample the echo peaks at."""

        return float(round_trip_delay_s) / self.waveform_sample_period_s


#: The pulse shapes. Every one is a closed-form function of a CONTINUOUS
#: argument: the kernel evaluates ``s(t - tau)`` at the exact fractional delay
#: and nothing is snapped to a sample. ``rect`` and ``lfm`` are analytic;
#: ``coded`` is a piecewise envelope of ``num_chips`` chips of width
#: ``T_p / num_chips``, chip ``i`` being ``a_i exp(j 2 pi f_i (u - i T_c))``.
#: That one family covers a binary phase code (PMCW), a frequency-hopped code
#: (FSK) and a user-sampled complex envelope held for one chip per sample, the
#: zero-order hold a DAC outputs (R-ADR-046).
PULSE_KIND_RECT = "rect"
PULSE_KIND_LFM = "lfm"
PULSE_KIND_CODED = "coded"
PULSE_KINDS = frozenset({PULSE_KIND_RECT, PULSE_KIND_LFM, PULSE_KIND_CODED})

#: How far above one a chip magnitude may round before it is refused. A chip of
#: magnitude one is the full transmit amplitude ``sqrt(P_t)``.
_CHIP_MAGNITUDE_SLACK = 1e-9

#: ``|p(t)| = 1`` inside the pulse: the envelope is dimensionless, so a received
#: sample is ``C_rt`` in sqrt(W) at the receive port and ``|y|^2`` is the power
#: the antenna delivers while the echo is present. That is the noise contract
#: every waveform shares (R-ADR-029): physical-amplitude samples and a thermal
#: stage that adds ``k T_sys f_s`` per complex sample. The matched-filter peak
#: is still exactly ``C_rt`` because the REPLICA, not the pulse, carries the
#: ``1 / T_p`` that makes the filter unit-gain (:attr:`PulsedSpec.replica_amplitude`).
PULSE_NORMALIZATION_UNIT_AMPLITUDE = "unit_amplitude"


@dataclass(frozen=True, slots=True)
class PulsedSpec:
    """One pulsed frame's fast-time gate, pulse shape, and PRI, in SI units.

    The product is the complex baseband received pulse train
    ``y[pulse, sensor_pair, sample]``  -  the matched-filter INPUT, not its
    output. The matched filter itself is a correlation and lives in DSP glue
    (:mod:`witwin.radar.processing.range_doppler`), because synthesis owns the
    received waveform and processing owns the filter. Putting the correlation
    in the kernel would fuse a modelling decision (which replica, which window,
    which oversampling) into the physics.

    **The pulse is evaluated at the exact fractional delay.** ``u = t_g + m T_s
    - tau_k(l)`` is a continuous number and ``p(u)`` is evaluated from its
    analytic form there, never snapped to the nearest sample. Snapping would
    quantise the delay by ``T_s / 2``, which at 50 MSPS is 10 ns, three metres
    of range, and it would destroy the closed form that every assertion below
    is written against. This is why both supported pulse kinds are analytic.

    **Phasor convention.** Like the OFDM CFR cube and unlike the FMCW beat cube,
    this train is published in the CHANNEL convention :data:`CHANNEL_PHASOR`.
    There is no de-chirping here, so there is nothing to conjugate and no
    conversion site anywhere in the family.

    **Structural parallel.** The three waveforms differ only in one factor. FMCW
    contributes ``exp(+j 2 pi S tau t_m)``, OFDM contributes
    ``exp(-j 2 pi n df tau)``, and this family contributes ``p(t - tau)``. The
    slow-time factor - the carrier applied to the delay CHANGE - is identical in
    all three, which is the whole point of a shared input contract.

    ``bandwidth_hz`` is the LFM sweep for ``pulse_kind = "lfm"`` and ``1 / T_p``
    for ``pulse_kind = "rect"``, which is the rectangular pulse's own
    matched-filter bandwidth. It is a declared field rather than an inferred one
    because it sets the range cell and the range-migration bound, and inferring
    it differently in two places is how those two quietly disagree. It is NOT
    the receiver's noise bandwidth: the samples are complex at ``1 / T_s`` and
    the thermal stage integrates over that sample rate, like every waveform.

    **The pulse support is half-open**, ``0 <= u < T_p``, and that is a contract
    rather than an accident of writing the comparison one way. A closed support
    puts exactly one extra sample inside the pulse whenever the delay lands on
    the sample grid and not otherwise, so the received pulse would be
    ``M_p + 1`` samples long at one delay and ``M_p`` at the next. The matched
    filter's replica has a fixed length, so that one sample is a mismatched tap:
    it costs about 0.2 percent of the peak magnitude and biases the estimated
    delay by nearly two thousandths of a sample, at one delay in every ``M_p``.
    Half-open makes the sampled pulse exactly :attr:`pulse_sample_count` samples
    long at EVERY delay, and it leaves the continuous matched-filter integral
    unchanged because a single point has measure zero.

    ``max_expected_delay_rate`` is a CONFIGURED bound on ``|d(tau_rt)/dt|`` - the
    velocity window the radar is set up for - and never a measured maximum,
    which would be a per-frame device-to-host transfer.
    :func:`require_pulsed_compatible` uses it for the range-migration check.
    """

    #: This kernel has no ``lambda / (4 pi d)`` term at all: free-space spreading
    #: is Channel transport's, per leg, once. A statement about the kernel rather
    #: than a setting, so a class attribute rather than a field.
    applies_spreading: ClassVar[bool] = False

    #: The convention the published train is in, carried as data so that a
    #: consumer never has to infer it from the waveform's name.
    phasor: ClassVar[str] = CHANNEL_PHASOR
    time_dependence: ClassVar[str] = CHANNEL_TIME_DEPENDENCE

    num_pulses: int
    num_samples: int
    sample_period_s: float
    pri_s: float
    range_gate_start_s: float
    pulse_kind: str
    pulse_width_s: float
    bandwidth_hz: float
    reference_frequency_hz: float
    max_expected_delay_rate: float
    carrier_hz: float = 0.0
    carrier_rate_hz: float = 0.0
    pulse_normalization: str = PULSE_NORMALIZATION_UNIT_AMPLITUDE
    #: ``coded`` only: the complex chip amplitudes ``a_i``, each of magnitude at
    #: most one (one is the full transmit amplitude). Empty for every other kind.
    chips: tuple[complex, ...] = ()
    #: ``coded`` only: the frequency ``f_i`` of each chip, Hz. Empty is all zero.
    chip_frequencies_hz: tuple[float, ...] = ()
    #: Stepped-frequency carrier offset between consecutive pulses, Hz: pulse
    #: ``l`` is transmitted at ``f_ref + l * frequency_step_hz``. Zero is a
    #: fixed carrier.
    frequency_step_hz: float = 0.0
    #: The envelope is the periodic extension of one code period: a code that
    #: is transmitted continuously (PMCW). Requires ``pri_s == pulse_width_s``.
    periodic: bool = False

    def __post_init__(self) -> None:
        require_host_floats(
            "PulsedSpec",
            WAVEFORM_SPEC_REASON,
            frequency_step_hz=self.frequency_step_hz,
            num_pulses=self.num_pulses,
            num_samples=self.num_samples,
            sample_period_s=self.sample_period_s,
            pri_s=self.pri_s,
            range_gate_start_s=self.range_gate_start_s,
            pulse_width_s=self.pulse_width_s,
            bandwidth_hz=self.bandwidth_hz,
            reference_frequency_hz=self.reference_frequency_hz,
            max_expected_delay_rate=self.max_expected_delay_rate,
            carrier_hz=self.carrier_hz,
            carrier_rate_hz=self.carrier_rate_hz,
        )
        if self.num_pulses < 1:
            raise ValueError("num_pulses must be positive")
        if self.num_samples < 1:
            raise ValueError("num_samples must be positive")
        if self.sample_period_s <= 0.0:
            raise ValueError("sample_period_s must be positive")
        if self.pri_s <= 0.0:
            raise ValueError("pri_s must be positive")
        if self.range_gate_start_s < 0.0:
            raise ValueError("range_gate_start_s must be non-negative")
        if self.pulse_width_s <= 0.0:
            raise ValueError("pulse_width_s must be positive")
        if self.bandwidth_hz <= 0.0:
            raise ValueError("bandwidth_hz must be positive")
        if self.max_expected_delay_rate < 0.0:
            raise ValueError("max_expected_delay_rate must be non-negative")
        if not self.reference_frequency_hz > 0.0:
            raise ValueError(
                "reference_frequency_hz must be positive; it is the frequency "
                "the weight this spec will consume was evaluated at, and "
                "require_compatible refuses a mismatch"
            )
        if self.pulse_kind not in PULSE_KINDS:
            raise ValueError(
                f"pulse_kind must be one of {sorted(PULSE_KINDS)}, got {self.pulse_kind!r}; a sampled envelope is "
                "the 'coded' kind, held for one chip per sample"
            )
        if self.pulse_kind == PULSE_KIND_CODED:
            if not self.chips:
                raise ValueError("a coded pulse needs at least one chip")
            for chip in self.chips:
                if not (math.isfinite(complex(chip).real) and math.isfinite(complex(chip).imag)):
                    raise ValueError("chip amplitudes must be finite")
                if abs(complex(chip)) > 1.0 + _CHIP_MAGNITUDE_SLACK:
                    raise ValueError(
                        f"a chip of magnitude {abs(complex(chip)):.6g} exceeds one, the full transmit amplitude "
                        "sqrt(P_t); scale the envelope so its peak is at most one"
                    )
            if self.chip_frequencies_hz and len(self.chip_frequencies_hz) != len(self.chips):
                raise ValueError(
                    f"chip_frequencies_hz holds {len(self.chip_frequencies_hz)} values for {len(self.chips)} chips"
                )
            if not all(math.isfinite(float(value)) for value in self.chip_frequencies_hz):
                raise ValueError("chip frequencies must be finite")
            if not any(abs(complex(chip)) > 0.0 for chip in self.chips):
                raise ValueError("a coded pulse whose every chip is zero transmits nothing")
        elif self.chips or self.chip_frequencies_hz:
            raise ValueError(f"only a coded pulse carries chips; this pulse is {self.pulse_kind!r}")
        if not math.isfinite(self.frequency_step_hz):
            raise ValueError("frequency_step_hz must be finite")
        if self.periodic and abs(self.pri_s - self.pulse_width_s) > 1e-12 * self.pulse_width_s:
            raise ValueError(
                "a periodic code is transmitted continuously, one code period per slow-time sample, so pri_s must "
                f"equal pulse_width_s; got pri_s={self.pri_s}, pulse_width_s={self.pulse_width_s}"
            )
        if self.pulse_normalization != PULSE_NORMALIZATION_UNIT_AMPLITUDE:
            raise ValueError(
                "pulse_normalization must be "
                f"{PULSE_NORMALIZATION_UNIT_AMPLITUDE!r}; a unit-amplitude envelope is "
                "what keeps every published sample in sqrt(W), so the thermal stage's "
                "k T_sys f_s per sample is the right noise for it. A unit-energy pulse "
                "publishes sqrt(W / s) and overstates the SNR by f_s / (B T_p)"
            )
        require_single_carrier_home(self.carrier_hz, self.carrier_rate_hz)

    @property
    def sample_rate_hz(self) -> float:
        return 1.0 / self.sample_period_s

    @property
    def wavelength_m(self) -> float:
        return SPEED_OF_LIGHT_M_PER_S / self.reference_frequency_hz

    @property
    def is_linear_fm(self) -> bool:
        return self.pulse_kind == PULSE_KIND_LFM

    @property
    def is_coded(self) -> bool:
        return self.pulse_kind == PULSE_KIND_CODED

    @property
    def chip_width_s(self) -> float:
        """``T_c = T_p / num_chips``; the whole pulse for an uncoded kind."""

        return self.pulse_width_s / max(len(self.chips), 1)

    def chip_table(self) -> tuple[tuple[float, float, float], ...]:
        """``(|a_i|, arg(a_i) / 2pi, f_i)`` per chip, the table the kernel reads.

        The phase is stored in CYCLES so the kernel adds it to its double cycle
        count before the single wrap, like every other phase term.
        """

        frequencies = self.chip_frequencies_hz or (0.0,) * len(self.chips)
        return tuple(
            (abs(complex(chip)), cmath.phase(complex(chip)) / math.tau, float(frequency))
            for chip, frequency in zip(self.chips, frequencies, strict=True)
        )

    @property
    def envelope_energy_s(self) -> float:
        """``int |s(u)|^2 du`` over one pulse, s (the envelope is dimensionless).

        ``T_p`` for the rectangle and the LFM; ``T_c sum_i |a_i|^2`` for a coded
        pulse. It is the coherent observation time of one pulse in the noise
        contract (R-ADR-029), and the matched-filter replica divides by it.
        """

        if not self.is_coded:
            return self.pulse_width_s
        return self.chip_width_s * sum(abs(complex(chip)) ** 2 for chip in self.chips)

    @property
    def pulse_amplitude(self) -> float:
        """``1``, the dimensionless unit-amplitude envelope height.

        Both kinds share it: the LFM differs from the rectangle only by a phase,
        and a phase does not change ``|p|``. Passed to the kernel as a scalar so
        that the normalisation lives on this spec rather than inside the kernel.
        With it a sample inside the pulse is ``C_rt`` in sqrt(W), the unit the
        receive chain's thermal stage is written in.
        """

        return 1.0

    @property
    def replica_amplitude(self) -> float:
        """``1 / E_s`` [1/s], the matched-filter replica height (``1 / T_p`` uncoded).

        :attr:`envelope_energy_s` is ``T_p`` for every unit-modulus envelope.

        The correlation ``sum_m y[m] conj(r[m]) T_s`` against a replica of this
        height returns ``C_rt * M_p T_s / T_p``, exactly ``C_rt`` when the pulse
        is commensurate with the grid: a UNIT-GAIN filter, so the published
        range profile follows the processing amplitude convention (peak equals
        the row's coefficient) while the synthesised samples stay physical. The
        filter's output noise is then ``k T_sys / T_p``, and the per-pulse SNR is
        the textbook ``E / N0 = P_r T_p / (k T_sys)``.
        """

        return 1.0 / self.envelope_energy_s

    @property
    def pulse_sample_count(self) -> int:
        """How many fast-time samples the pulse spans, rounded to the grid.

        Used by the matched-filter replica, not by the kernel: the kernel never
        discretises the pulse. The discrete replica has EXACTLY unit gain when
        ``T_p`` is a whole number of samples, which is what
        :attr:`pulse_grid_is_commensurate` reports.
        """

        return int(round(self.pulse_width_s / self.sample_period_s))

    @property
    def pulse_grid_is_commensurate(self) -> bool:
        """Whether ``T_p`` is an exact whole number of sample periods.

        When it is, the sampled replica's discrete gain ``sum_m |r[m]| T_s`` is
        exactly 1 and the matched-filter peak is exactly ``C_rt``. When it is
        not, the gain is ``round(T_p / T_s) * T_s / T_p`` and the peak carries
        that same factor -
        a property of the DISCRETE replica, not of the kernel, which is why it is
        reported rather than silently corrected.
        """

        return abs(self.pulse_sample_count * self.sample_period_s - self.pulse_width_s) <= 1e-12 * self.pulse_width_s

    @property
    def range_gate_end_s(self) -> float:
        """``t_g + M T_s``, the last fast-time instant the gate observes."""

        return self.range_gate_start_s + self.num_samples * self.sample_period_s

    @property
    def duty_cycle(self) -> float:
        """``T_p / T_pri``."""

        return self.pulse_width_s / self.pri_s

    @property
    def range_resolution_m(self) -> float:
        """``c0 / (2 B)`` for the LFM, ``c0 T_p / 2`` for the rectangle.

        Two expressions rather than one because they are two different physical
        statements: the LFM's (and a code's) resolution comes from its SWEEP
        or chip rate and is independent of its length, while the rectangle's
        comes from its length alone. The
        two coincide only at ``B = 1 / T_p``, which is exactly the value this
        spec requires a rectangular pulse to declare, so the branch is a
        readability choice and not a numerical one.
        """

        if self.pulse_kind == PULSE_KIND_RECT:
            return SPEED_OF_LIGHT_M_PER_S * self.pulse_width_s / 2.0
        return SPEED_OF_LIGHT_M_PER_S / (2.0 * self.bandwidth_hz)

    @property
    def max_unambiguous_range_m(self) -> float:
        """``c0 T_pri / 2``: beyond it an echo lands in the next PRI."""

        return SPEED_OF_LIGHT_M_PER_S * self.pri_s / 2.0

    @property
    def max_unambiguous_speed_m_s(self) -> float:
        """``c0 / (4 f_ref T_pri)``, equivalently ``lambda / (4 T_pri)``.

        Half a wavelength of two-way path change per pulse is half a cycle of
        Doppler phase; beyond it the sign of the velocity is not recoverable and
        a receding target reads as an approaching one.
        """

        return SPEED_OF_LIGHT_M_PER_S / (4.0 * self.reference_frequency_hz * self.pri_s)

    @property
    def coherent_processing_interval_s(self) -> float:
        """``L T_pri``, the span the slow-time transform is taken over."""

        return self.num_pulses * self.pri_s

    @property
    def range_cell_delay_s(self) -> float:
        """``1 / B``, one range cell expressed as a delay."""

        return 1.0 / self.bandwidth_hz

    @property
    def range_migration_delay_s(self) -> float:
        """How far the delay walks over one coherent processing interval.

        ``max_expected_delay_rate * L * T_pri``. Compared against
        :attr:`range_cell_delay_s` by :func:`require_pulsed_compatible`: if the
        walk exceeds one range cell the peak smears across cells and the
        single-cell closed form this family is written against stops holding.
        """

        return self.max_expected_delay_rate * self.coherent_processing_interval_s

    def instantaneous_pulse_frequency_hz(self, envelope_time_s: float) -> float:
        """``B u / T_p`` for the LFM, ``0`` for the rectangle.

        The derivative of the pulse's own phase with respect to its argument,
        expressed as a frequency. It is the pulsed analogue of the OFDM
        subcarrier offset ``n df``: a small, envelope-position-dependent
        addition to the carrier that the slow-time phase step carries and that a
        constant-envelope model would miss.
        """

        if self.is_coded:
            frequencies = self.chip_frequencies_hz or (0.0,)
            chip = min(max(int(float(envelope_time_s) // self.chip_width_s), 0), len(frequencies) - 1)
            return float(frequencies[chip])
        if not self.is_linear_fm:
            return 0.0
        return self.bandwidth_hz * float(envelope_time_s) / self.pulse_width_s

    def slow_time_phase_step_rad(self, delay_rate: float, envelope_time_s: float = 0.0) -> float:
        """Phase advance per pulse at a fixed fast-time sample, in radians.

        ``-2 pi tau_rate T_pri (f_c + f_r + B u / T_p)``. The first two terms are
        the carrier in whichever of its two homes it lives in - they enter the
        same way because a kernel-owned carrier multiplies the full delay and
        therefore already walks. The third is the LFM's own phase moving with the
        drifting envelope position, which is a correction of relative size
        ``B u / (T_p f_ref)``: about 1.3e-4 at the middle of a 20 MHz, 10 us
        sweep at 77 GHz. Small, but larger than the tolerance the slow-time slope
        is asserted to, so it is part of the closed form rather than noise.
        """

        return (
            -math.tau
            * float(delay_rate)
            * self.pri_s
            * (self.carrier_hz + self.carrier_rate_hz + self.instantaneous_pulse_frequency_hz(envelope_time_s))
        )

    def doppler_frequency_hz(self, delay_rate: float) -> float:
        """``-f_ref tau_rate``: the physical Doppler in Channel's convention.

        Negative for a receding row. The published train is in that same
        convention, so this IS the tone the slow-time transform shows - unlike
        the FMCW beat cube, whose single conjugation puts its tone at ``+f_ref
        tau_rate``.
        """

        return -self.reference_frequency_hz * float(delay_rate)


class SlowTimeMode(str, Enum):
    """How the weight and the slow-time axis divide the Doppler phase.

    These two are mutually exclusive, and they are ONE enum rather than two
    independently-settable fields because the combination "the caller refreshed
    the weight at every slot AND the kernel still applies a carrier rate"
    applies Doppler twice and looks like a plausible radar cube while doing it.
    Frozen synthesis extrapolates delay linearly from its reference observation.
    FMCW uses ``tau_rt + tau_rate * (t_slot + u)`` including chirp-local ADC
    time ``u``. Constant delay rate does not capture transverse curvature,
    moving reflector geometry, amplitude changes, or path births. A Doppler
    aliasing bound does not bound those approximation errors.

    ``Radar.echo`` picks the mode from the ``Motion`` the trace was taken with:
    ``Motion.static`` freezes the weight for the frame, while ``Motion.chirp``,
    ``Motion.adc`` and ``Motion.adaptive`` refresh it per slot. A caller that
    builds a :class:`SynthesisPathBatch` directly chooses the mode and owns the
    validity of its path history; the enum never changes parameter JVPs into
    velocity.
    """

    #: The weight was computed once, at the frame's ``tau_rt``, and does not
    #: walk across chirps/symbols/pulses. The slow-time carrier phase is the
    #: waveform kernel's job.
    FROZEN_WEIGHT_WITH_CARRIER_RATE = "frozen_weight_with_carrier_rate"

    #: The weight is re-evaluated at every slow-time slot, so it already walked.
    #: A carrier-rate term on top of it would double the Doppler.
    REFRESHED_WEIGHT_NO_RATE = "refreshed_weight_no_rate"


@runtime_checkable
class WaveformSpecProtocol(Protocol):
    """Exactly the attributes :func:`require_compatible` reads.

    Declared as a Protocol rather than a base class because the three waveform
    specs have nothing else in common: an FMCW ramp, an OFDM subcarrier grid,
    and a pulse envelope share no fields. What they DO share is a position on
    the four questions that decide whether a weight may be handed to them.
    """

    # Read-only members: the specs are frozen dataclasses and
    # ``applies_spreading`` is a class constant, so none of them is settable.

    @property
    def carrier_hz(self) -> float:
        """Absolute reference-frequency carrier the KERNEL applies, in Hz.

        Zero means the kernel applies none because the weight already carries it.
        """

    @property
    def carrier_rate_hz(self) -> float:
        """Reference frequency applied to the delay CHANGE only, in Hz. Zero means the kernel applies none."""

    @property
    def reference_frequency_hz(self) -> float:
        """The frequency the weight was evaluated at. Must equal the batch's."""

    @property
    def applies_spreading(self) -> bool:
        """Whether the waveform owner multiplies by ``lambda/(4 pi d)`` itself."""


def _require_tensor(
    name: str, value: object, *, dtype: torch.dtype, shape: tuple[int, ...], device: torch.device
) -> torch.Tensor:
    if not isinstance(value, torch.Tensor):
        raise TypeError(f"{name} must be a torch.Tensor, got {type(value).__name__}")
    if value.dtype != dtype:
        raise TypeError(f"{name} must use {dtype}, got {value.dtype}")
    if tuple(value.shape) != shape:
        raise ValueError(f"{name} must have shape {shape}, got {tuple(value.shape)}")
    if not value.is_contiguous():
        raise ValueError(
            f"{name} must be contiguous; a synthesis kernel indexes it linearly "
            "and the contract will not hide a copy on the hot path"
        )
    if value.device != device:
        raise ValueError(
            f"{name} is on {value.device} but the batch is on {device}; a synthesis batch is single-device by contract"
        )
    return value


@dataclass(frozen=True, slots=True, eq=False)
class SynthesisPathBatch:
    """What a waveform synthesis kernel may assume about a set of path rows.

    Geometry is ``total_delay_s`` (the ROUND-TRIP delay ``tau_rt``, in seconds,
    never a one-way distance) and ``delay_rate`` (``d(tau_rt)/dt``,
    dimensionless). A kernel consumes those two and nothing else about the
    geometry: it may never reconstruct a distance, and it may never re-apply a
    ``1/(4 pi d)``.

    ``complex_transfer_ref`` is in the CHANNEL phasor convention,
    ``exp(-j k d)`` under ``exp(+j 2 pi f t)`` time dependence, evaluated at
    ``reference_frequency_hz``. It is NOT a beat weight; converting to one is
    the FMCW owner's single call site.

    The five provenance fields are the whole reason this type exists. They say
    what is ALREADY inside the weight, so :func:`require_compatible` can refuse
    a spec that would apply it a second time. They are set by the two
    classmethods below rather than by a caller, because a caller that could
    assert its own provenance could assert the convenient one.

    ``weight_includes_antenna_pattern`` is the one of the five that a composer
    cannot know, so it is CARRIED rather than asserted: it is read off the
    composed batch, where
    :meth:`witwin.radar.sensors.RoundTripPatternStage.apply` set it. No
    synthesis rule consumes it - a waveform kernel has never applied an antenna
    pattern and still does not - which is exactly why it has to be recorded
    here: it is the only surviving statement of whether the array's gain is in
    the cube, and a consumer that has to guess would guess the one that makes
    its numbers agree.

    Validation is host-only: shapes, dtypes, contiguity, device, and flags. It
    reads no tensor VALUE, so constructing this contract costs no
    device-to-host transfer and no synchronization. In particular
    ``pair_offsets[0] == 0`` and ``pair_offsets[-1] == path_count`` are a
    documented producer obligation, exactly as in ``RadarPathBatch``, not a
    device read.
    """

    # ---- cardinality (host ints, already published by the compact contract) --
    sensor_pair_count: int
    path_count: int

    # ---- row -> segment partition -------------------------------------------
    sensor_pair_index: torch.Tensor
    pair_offsets: torch.Tensor

    # ---- geometry ------------------------------------------------------------
    total_delay_s: torch.Tensor
    delay_rate: torch.Tensor | None

    # ---- transfer ------------------------------------------------------------
    complex_transfer_ref: torch.Tensor
    reference_frequency_hz: float

    # ---- identity ------------------------------------------------------------
    topology: RadarPathTopology
    row_valid: torch.Tensor | None

    # ---- provenance ----------------------------------------------------------
    weight_includes_reference_phase: bool
    weight_includes_spreading: bool
    weight_includes_tx_power: bool
    slow_time_mode: SlowTimeMode
    weight_includes_antenna_pattern: bool = False
    #: The composed rows' per-frequency weights, ``[path_count, F]``, from a
    #: wideband run; see :class:`~witwin.radar.paths.RadarPathBatch`. Only the
    #: OFDM family consumes it, one column per subcarrier.
    complex_transfer_band: torch.Tensor | None = None
    frequency_offsets_hz: tuple[float, ...] | None = None
    #: The composed rows' float32 delay residual (R-ADR-040): the delay is
    #: ``total_delay_s + total_delay_residual_s`` in float64. Non-differentiable;
    #: ``None`` when the rows carry the float32 delay alone.
    total_delay_residual_s: torch.Tensor | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.slow_time_mode, SlowTimeMode):
            raise TypeError(f"slow_time_mode must be a SlowTimeMode member, got {self.slow_time_mode!r}")
        if type(self.sensor_pair_count) is not int or self.sensor_pair_count < 1:
            raise ValueError("sensor_pair_count must be a positive int")
        if type(self.path_count) is not int or self.path_count < 0:
            raise ValueError("path_count must be a non-negative int")
        for name in (
            "weight_includes_reference_phase",
            "weight_includes_spreading",
            "weight_includes_tx_power",
            "weight_includes_antenna_pattern",
        ):
            if type(getattr(self, name)) is not bool:
                raise TypeError(f"{name} must be a bool")
        if type(self.reference_frequency_hz) is not float or not self.reference_frequency_hz > 0.0:
            raise ValueError(
                "reference_frequency_hz must be a positive float; it is the "
                "frequency the weight was evaluated at, not an optional label"
            )

        device = self.total_delay_s.device
        rows = (self.path_count,)
        _require_tensor("total_delay_s", self.total_delay_s, dtype=torch.float32, shape=rows, device=device)
        _require_tensor("sensor_pair_index", self.sensor_pair_index, dtype=torch.int64, shape=rows, device=device)
        _require_tensor(
            "pair_offsets", self.pair_offsets, dtype=torch.int64, shape=(self.sensor_pair_count + 1,), device=device
        )
        _require_tensor(
            "complex_transfer_ref", self.complex_transfer_ref, dtype=torch.complex64, shape=rows, device=device
        )
        if self.delay_rate is not None:
            _require_tensor("delay_rate", self.delay_rate, dtype=torch.float32, shape=rows, device=device)
        if self.total_delay_residual_s is not None:
            _require_tensor(
                "total_delay_residual_s", self.total_delay_residual_s, dtype=torch.float32, shape=rows, device=device
            )
        if self.row_valid is not None:
            _require_tensor("row_valid", self.row_valid, dtype=torch.bool, shape=rows, device=device)
        if self.topology.row_count != self.path_count:
            raise ValueError("topology must have exactly path_count rows")

    @property
    def device(self) -> torch.device:
        return self.total_delay_s.device

    @classmethod
    def from_radar_paths(cls, paths: RadarPathBatch, *, slow_time_mode: SlowTimeMode) -> "SynthesisPathBatch":
        """Wrap a composed round-trip batch, zero-copy, with Channel provenance.

        Every tensor passes through by reference. Nothing is cloned, made
        contiguous, or moved: row identity, row order, storage aliasing, stride,
        dtype, device, and gradient state are all preserved, and a test asserts
        object identity rather than value equality.

        Three of the four provenance booleans are Channel's published contract,
        not a caller's opinion, which is why they are written here:

        * ``coefficient_reference = "includes_reference_frequency_phase"``
        * ``FREE_SPACE_AMPLITUDE = "sqrt(tx_power)*wavelength/(4*pi*distance)"``

        The fourth, ``weight_includes_antenna_pattern``, is READ off the batch
        instead. Channel has no antenna pattern to publish a contract about, and
        whether Radar applied its own is a fact about what ran upstream rather
        than about what Channel guarantees; asserting ``True`` here would be a
        claim about a stage that may not have run.

        ``slow_time_mode`` is the one thing the caller must say, because only
        the caller knows whether it froze the weight for the frame or refreshes
        it per slot. It has no default: defaulting it would make a double-counted
        Doppler a silent wrong answer instead of a refusal.
        """

        if not isinstance(paths, RadarPathBatch):
            raise TypeError(f"from_radar_paths needs a RadarPathBatch, got {type(paths).__name__}")
        return cls(
            sensor_pair_count=paths.sensor_pair_count,
            path_count=paths.path_count,
            sensor_pair_index=paths.sensor_pair_index,
            pair_offsets=paths.pair_offsets,
            total_delay_s=paths.total_delay_s,
            delay_rate=paths.delay_rate,
            complex_transfer_ref=paths.complex_transfer_ref,
            reference_frequency_hz=float(paths.reference_frequency_hz),
            topology=paths.topology,
            row_valid=paths.row_valid,
            complex_transfer_band=paths.complex_transfer_band,
            frequency_offsets_hz=paths.frequency_offsets_hz,
            total_delay_residual_s=paths.total_delay_residual_s,
            weight_includes_reference_phase=True,
            weight_includes_spreading=True,
            weight_includes_tx_power=True,
            slow_time_mode=slow_time_mode,
            weight_includes_antenna_pattern=bool(paths.weight_includes_antenna_pattern),
        )


#: What one frame's synthesis actually observed the world at, published on
#: :attr:`SynthesisResult.observation_schedule` so a consumer never infers it
#: from the requested ``Motion``:
#:
#: * ``frame``: one observation for the whole frame; the kernel extrapolates
#:   the delay linearly with the row's delay rate.
#: * ``slow_time``: one observation per slow-time slot (a TDM chirp slot, a
#:   symbol, a pulse), held across that slot's fast time (stop and hop).
#: * ``fast_time``: one observation per fast-time sample (an ADC instant), the
#:   exhaustive reference.
#: * ``adaptive``: fast-time values interpolated between error-controlled
#:   probes.
OBSERVATION_FRAME = "frame"
OBSERVATION_SLOW_TIME = "slow_time"
OBSERVATION_FAST_TIME = "fast_time"
OBSERVATION_ADAPTIVE = "adaptive"
OBSERVATION_SCHEDULES = (OBSERVATION_FRAME, OBSERVATION_SLOW_TIME, OBSERVATION_FAST_TIME, OBSERVATION_ADAPTIVE)

#: The axis names each waveform's rank-3 product is indexed by.
FMCW_BEAT_AXES = ("chirp", "sensor_pair", "sample")
FMCW_SPECTRUM_AXES = ("chirp", "sensor_pair", "range_bin")
OFDM_AXES = ("symbol", "sensor_pair", "subcarrier")
OFDM_TIME_AXES = ("symbol", "sensor_pair", "sample")
PULSED_AXES = ("pulse", "sensor_pair", "sample")

#: The output domains the OFDM and pulsed products are published in. FMCW's
#: are :data:`FMCW_OUTPUT_DOMAINS`.
PULSED_OUTPUT_TIME = "time"

#: The fast-time axis name each output domain implies, so a result whose axes
#: disagree with its domain is refused at construction.
FAST_AXIS_BY_OUTPUT_DOMAIN = {
    FMCW_OUTPUT_SPECTRUM: "range_bin",
    FMCW_OUTPUT_BEAT: "sample",
    OFDM_OUTPUT_CFR: "subcarrier",
    PULSED_OUTPUT_TIME: "sample",
}


@dataclass(frozen=True, slots=True)
class SynthesisResult:
    """One synthesis product with waveform, phasor, axes, and domain as data."""

    __repr__ = compact_repr

    cube: torch.Tensor
    kind: str
    axes: tuple[str, ...]
    phasor: str
    time_dependence: str
    reference_frequency_hz: float
    output_domain: str
    #: When the world was observed for this cube; one of
    #: :data:`OBSERVATION_SCHEDULES`. The factories publish ``frame``, the
    #: frame's own row synthesis; a session that refreshed its rows restates it.
    observation_schedule: str = OBSERVATION_FRAME

    def __post_init__(self) -> None:
        if self.observation_schedule not in OBSERVATION_SCHEDULES:
            raise ValueError(
                f"observation_schedule must be one of {OBSERVATION_SCHEDULES}, got {self.observation_schedule!r}"
            )
        if self.cube.dim() != len(self.axes):
            raise ValueError(
                f"a {self.kind} cube has {len(self.axes)} axes {self.axes}, got shape {tuple(self.cube.shape)}"
            )
        if self.axes[-1] != FAST_AXIS_BY_OUTPUT_DOMAIN.get(self.output_domain):
            raise ValueError(f"output_domain={self.output_domain!r} disagrees with axes {self.axes}")

    @classmethod
    def from_fmcw(cls, cube: torch.Tensor, spec: FmcwSpec) -> "SynthesisResult":
        axes = FMCW_SPECTRUM_AXES if spec.output_domain == FMCW_OUTPUT_SPECTRUM else FMCW_BEAT_AXES
        return cls(
            cube=cube,
            kind="fmcw",
            axes=axes,
            phasor=spec.phasor,
            time_dependence=spec.time_dependence,
            reference_frequency_hz=float(spec.reference_frequency_hz),
            output_domain=spec.output_domain,
        )

    @classmethod
    def from_ofdm(cls, cube: torch.Tensor, spec: OfdmSpec) -> "SynthesisResult":
        return cls(
            cube=cube,
            kind="ofdm",
            axes=OFDM_AXES if spec.output_domain == OFDM_OUTPUT_CFR else OFDM_TIME_AXES,
            phasor=spec.phasor,
            time_dependence=spec.time_dependence,
            reference_frequency_hz=float(spec.reference_frequency_hz),
            output_domain=spec.output_domain,
        )

    @classmethod
    def from_pulsed(cls, cube: torch.Tensor, spec: PulsedSpec) -> "SynthesisResult":
        return cls(
            cube=cube,
            kind="pulsed",
            axes=PULSED_AXES,
            phasor=spec.phasor,
            time_dependence=spec.time_dependence,
            reference_frequency_hz=float(spec.reference_frequency_hz),
            output_domain=PULSED_OUTPUT_TIME,
        )


def require_compatible(batch: SynthesisPathBatch, spec: WaveformSpecProtocol) -> None:
    """Refuse any weight/spec pair that would count a factor twice.

    Called by every waveform entry point before any kernel launch. Each rule
    below names the hazard it prevents, because the failure it prevents is
    always a plausible-looking number rather than a crash, and an error message
    that only says "invalid configuration" would send the reader looking for a
    bug in the physics.

    R3 is enforced as "the delay change has exactly one owner, chosen by the
    provenance" rather than as a flat ``carrier_rate_hz == f_ref``: a weight
    that carries no reference phase (``weight_includes_reference_phase =
    False``) needs ``carrier_hz = f_ref`` by R2, and a spec with both carrier
    parameters nonzero is refused by the spec itself. The physics allows it -
    differentiating the FMCW phase with respect to slow time gives the same
    bracket for ``(f_ref, 0)`` and ``(0, f_ref)``, because a kernel-owned
    carrier multiplies the FULL ``tau(t)`` and therefore already walks. So the
    weight's carrier home decides which of the two parameters must equal
    ``f_ref``.
    """

    if not isinstance(batch, SynthesisPathBatch):
        raise TypeError(f"require_compatible needs a SynthesisPathBatch, got {type(batch).__name__}")
    if batch.complex_transfer_band is not None and not isinstance(spec, OfdmSpec):
        raise NotImplementedError(
            "a wideband batch carries one weight per frequency column, and only the OFDM family consumes one "
            "(a column per subcarrier); this spec would silently use the reference column alone"
        )
    if not isinstance(spec, WaveformSpecProtocol):
        raise TypeError(
            f"{type(spec).__name__} does not declare carrier_hz, carrier_rate_hz, "
            "reference_frequency_hz and applies_spreading, so it cannot be "
            "checked against a weight's provenance; a waveform spec must satisfy "
            "WaveformSpecProtocol"
        )

    carrier_hz = float(spec.carrier_hz)
    carrier_rate_hz = float(spec.carrier_rate_hz)
    f_ref = batch.reference_frequency_hz

    # R1 - hazard H1: the Channel coefficient already holds
    # exp(-j 2 pi f_ref tau_rt).
    if batch.weight_includes_reference_phase and carrier_hz != 0.0:
        raise ValueError(
            "double-counted carrier phase: the weight already carries "
            "exp(-j*2*pi*f_ref*tau_rt) (coefficient_reference = "
            "'includes_reference_frequency_phase'), so carrier_hz must be 0; "
            f"got carrier_hz={carrier_hz}"
        )

    # R2 - the mirror image: nobody owns the absolute carrier at all.
    if not batch.weight_includes_reference_phase and carrier_hz == 0.0 and carrier_rate_hz == 0.0:
        raise ValueError(
            "missing carrier phase: this weight carries no reference-frequency "
            "phase, and neither carrier_hz nor carrier_rate_hz is set, so the "
            "absolute carrier has no owner and the synthesized IQ would have no "
            "range phase at all"
        )

    # R3 - hazard H4, first half: a frozen weight does not walk across slow
    # time, so the delay CHANGE needs exactly one owner and the provenance says
    # which parameter it is.
    if batch.slow_time_mode is SlowTimeMode.FROZEN_WEIGHT_WITH_CARRIER_RATE:
        if batch.weight_includes_reference_phase:
            if carrier_rate_hz != f_ref:
                raise ValueError(
                    "understated Doppler: the weight is frozen at the frame's "
                    "tau_rt and carries the reference phase, so the delay "
                    f"change has no other home; carrier_rate_hz must be {f_ref}, "
                    f"got {carrier_rate_hz}. Dropping it understates intra-frame "
                    "Doppler by one to two orders of magnitude while still "
                    "producing a plausible-looking cube"
                )
        elif carrier_hz != f_ref:
            raise ValueError(
                "understated Doppler: the weight carries no reference phase, so "
                "the kernel must own the absolute carrier and thereby the delay "
                f"change; carrier_hz must be {f_ref}, got {carrier_hz}"
            )

    # R4 - hazard H4, second half: a refreshed weight already walked.
    if batch.slow_time_mode is SlowTimeMode.REFRESHED_WEIGHT_NO_RATE:
        if carrier_rate_hz != 0.0:
            raise ValueError(
                "double-counted Doppler: this weight is re-evaluated at every "
                "slow-time slot, so it already carries the delay change; "
                f"carrier_rate_hz must be 0, got {carrier_rate_hz}"
            )
        if batch.delay_rate is not None:
            raise ValueError(
                "double-counted Doppler: a refreshed weight walks by itself, so "
                "the batch must not also publish delay_rate for a kernel to "
                "apply"
            )

    # R5 - hazard F1: free-space spreading is Channel transport's, per leg,
    # once.
    if batch.weight_includes_spreading and bool(spec.applies_spreading):
        raise ValueError(
            "double-counted free-space spreading: the weight already contains "
            "wavelength/(4*pi*distance) per leg (FREE_SPACE_AMPLITUDE), so the "
            "waveform owner must not apply it again; set applies_spreading=False"
        )

    # R7 - the weight was evaluated at one frequency and means nothing at
    # another. This mirrors Channel's own request/compile frequency rule.
    if float(spec.reference_frequency_hz) != f_ref:
        raise ValueError(
            "reference frequency mismatch: the weight was evaluated at "
            f"{f_ref} Hz but the waveform spec declares "
            f"{float(spec.reference_frequency_hz)} Hz; a narrowband coefficient "
            "is not transferable between reference frequencies"
        )


def require_ofdm_compatible(batch: SynthesisPathBatch, spec: OfdmSpec) -> None:
    """The shared provenance rules, plus OFDM's cyclic-prefix contract.

    Called by :func:`~witwin.radar.synthesis.ofdm.synthesize_ofdm`
    before any kernel launch. Two checks beyond :func:`require_compatible`, both
    on CONFIGURED values and never on measured device delays - reading a
    per-frame maximum delay to the host would be exactly the hot-path
    device-to-host transfer the fixed-topology capability exists to avoid:

    1. ``max_expected_delay_s < cyclic_prefix_s``. This is the standard
       OFDM-radar assumption: there is no timing synchronisation to the echo, so
       the whole echo has to land inside the cyclic-prefix window for ``Y / X``
       to be exactly ``exp(-j 2 pi n df tau)``. Outside it the response gains an
       inter-symbol term that the closed form does not have, and the cube would
       be wrong in a way that looks like a slightly defocused range profile.

    2. The delay SPREAD bound ``max_k(tau_k) - min_k(tau_k) < T_cp``, which the
       single-tap-per-subcarrier form also requires. It is the same inequality:
       every round-trip delay is non-negative and bounded above by
       ``max_expected_delay_s``, so check 1 implies it. It is documented here
       rather than checked separately because checking it for real would mean
       reducing over the device delays.

    Both refusals name ``cyclic_prefix_s``. There is no clamp and no
    reduced-accuracy mode. The time-domain route models the inter-symbol term
    (an echo past the prefix reads the previous symbol), so it is exempt.
    """

    if not isinstance(spec, OfdmSpec):
        raise TypeError(f"require_ofdm_compatible needs an OfdmSpec, got {type(spec).__name__}")
    require_compatible(batch, spec)
    if spec.max_expected_delay_s >= spec.cyclic_prefix_s and not spec.time_domain:
        raise ValueError(
            "the configured echo window does not fit inside the cyclic prefix: "
            f"max_expected_delay_s={spec.max_expected_delay_s} is not less than "
            f"cyclic_prefix_s={spec.cyclic_prefix_s}. The single-tap "
            "per-subcarrier response H = Y/X is exactly "
            "exp(-j*2*pi*n*df*tau) only while the whole echo lands inside the "
            "cyclic-prefix window; beyond it there is an inter-symbol term this "
            "kernel does not model. Shorten the range window or lengthen "
            "cyclic_prefix_s - there is no clamped or reduced-accuracy mode"
        )


def require_pulsed_compatible(batch: SynthesisPathBatch, spec: PulsedSpec) -> None:
    """The shared provenance rules, plus the pulsed timing and migration bounds.

    Called by :func:`~witwin.radar.synthesis.pulsed.synthesize_pulsed`
    before any kernel launch. Three checks beyond :func:`require_compatible`, all
    on CONFIGURED values and never on measured device delays - reducing over the
    device delays to find a maximum would be exactly the hot-path
    device-to-host transfer the fixed-topology capability exists to avoid:

    1. ``pulse_width_s < pri_s``. A pulse at least as long as the repetition
       interval never stops transmitting, so there is no receive window at all.

    2. ``range_gate_start_s + num_samples * sample_period_s <= pri_s``. The gate
       must close before the next pulse fires; a gate that overruns is observing
       the next transmission, not an echo.

    3. ``max_expected_delay_rate * num_pulses * pri_s < 1 / bandwidth_hz``. Within
       a coherent processing interval of ``L`` pulses the delay walks by
       ``tau_rate L T_pri``. If that walk exceeds one range cell the echo migrates
       between cells, the peak smears, and the single-cell closed form this
       family is written against stops holding - quietly, as a loss of range
       resolution that looks like a defocused target. A fixture must satisfy the
       bound or assert the migration explicitly; there is no clamp and no
       reduced-accuracy mode.
    """

    if not isinstance(spec, PulsedSpec):
        raise TypeError(f"require_pulsed_compatible needs a PulsedSpec, got {type(spec).__name__}")
    require_compatible(batch, spec)
    if spec.pulse_width_s >= spec.pri_s and not spec.periodic:
        raise ValueError(
            f"pulse_width_s={spec.pulse_width_s} is not shorter than "
            f"pri_s={spec.pri_s}; a pulse at least as long as the repetition "
            "interval leaves no receive window, so there is no echo to gate"
        )
    # Relative slack for the rounding of M * T_s: a continuous code's gate is
    # exactly one period, which floating point may round a hair past pri_s.
    if spec.range_gate_end_s > spec.pri_s * (1.0 + 1e-12):
        raise ValueError(
            "the range gate overruns the pulse repetition interval: "
            f"range_gate_start_s + num_samples * sample_period_s="
            f"{spec.range_gate_end_s} exceeds pri_s={spec.pri_s}. The gate must "
            "close before the next pulse fires; past that instant the samples "
            "observe the next transmission rather than an echo"
        )
    if spec.range_migration_delay_s >= spec.range_cell_delay_s:
        raise ValueError(
            "range migration over the coherent processing interval: the delay "
            f"walks by max_expected_delay_rate * num_pulses * pri_s="
            f"{spec.range_migration_delay_s} s, which is not less than one range "
            f"cell 1 / bandwidth_hz={spec.range_cell_delay_s} s. The echo then "
            "moves between range cells within one coherent processing interval, "
            "the matched-filter peak smears, and the single-cell closed form "
            "this family is written against stops holding. Shorten the coherent "
            "processing interval, narrow the velocity window, or widen the range "
            "cell - there is no clamped or reduced-accuracy mode"
        )


#: The composed pair numbering, stated once. It comes from
#: :func:`witwin.radar.paths.sink_major_rank`, which mirrors the Channel
#: consumer's own ``sink_row_index * source_count + source_row_index`` so that
#: Radar does not put a second, silently different, virtual-array numbering on
#: the same data. Quoted by the tests that pin it against that function.
PAIR_RANK_LAYOUT = "sink_major: pair = rx_rank * num_tx + tx_rank"


def delay_residual(total_delay_s: torch.Tensor, residual: torch.Tensor | None) -> torch.Tensor:
    """The synthesis kernels' ``tau_lo`` input: the residual, detached and contiguous, or an empty tensor.

    The residual of the join's float32 delay pair (R-ADR-040) refines the
    delay the kernels read to ``tau_hi + tau_lo`` in float64; it carries no
    derivative, so it never enters the tape. An empty tensor selects the
    float32 delay alone.
    """

    if residual is None:
        return total_delay_s.new_empty(0).detach()
    if residual.shape != total_delay_s.shape:
        raise ValueError("total_delay_residual_s and total_delay_s must have the same shape")
    return residual.detach().contiguous()


def segment_of_each_row(pair_offsets: torch.Tensor, path_count: int) -> torch.Tensor:
    """Map each compact row to its sensor-pair segment, as ``int64[K]``.

    The inverse of the CSR partition: ``pair_offsets`` says where each segment
    starts, and a backward kernel that owns one gradient slot per ROW needs the
    other direction. Forward and JVP kernels read the offsets table directly and
    never call this.

    ``right=True`` is required. An offsets table is a half-open partition, so a
    row whose index equals a boundary belongs to the NEXT segment; ``right=False``
    puts it in the previous one, which is wrong for exactly one row per segment
    boundary and therefore invisible in any single-segment test.

    The output shape comes from ``path_count``, a host int the compact contract
    already published, so this adds no cardinality observation and no
    device-to-host transfer.
    """

    rows = torch.arange(path_count, device=pair_offsets.device, dtype=torch.int64)
    return torch.bucketize(rows, pair_offsets[1:], right=True)


def _require_array(num_tx: int, num_rx: int) -> int:
    if type(num_tx) is not int or num_tx < 1:
        raise ValueError(f"num_tx must be a positive int, got {num_tx!r}")
    if type(num_rx) is not int or num_rx < 1:
        raise ValueError(f"num_rx must be a positive int, got {num_rx!r}")
    return num_tx * num_rx


def pair_tx_index(*, num_tx: int, num_rx: int, sensor_pair_count: int, device: torch.device | str) -> torch.Tensor:
    """Which transmitter drives each sensor pair, as ``int32[pair_count]``.

    Under :data:`PAIR_RANK_LAYOUT` the transmitter rank is ``pair % num_tx``
    and the receiver rank is ``pair // num_tx``, not ``pair // num_rx``.
    Getting that backwards assigns the wrong TDM slot to every pair, which
    shifts each channel's Doppler phase by a whole chirp period and still
    produces a cube that looks entirely reasonable. This is the one place the
    numbering is written as code; :func:`assemble_frame_cube` is the same
    statement as a transpose.

    The pair count is checked against the declared array rather than trusted:
    a batch frozen over a different front end than the waveform spec describes
    is a configuration error, and reinterpreting its pairs as this array's is
    exactly the silent wrong answer the TDM slot table exists to prevent.
    """

    expected = _require_array(num_tx, num_rx)
    if sensor_pair_count != expected:
        raise ValueError(
            f"this batch spans {sensor_pair_count} sensor pairs but the waveform "
            f"spec declares a {num_tx} x {num_rx} array, which is {expected} "
            "pairs; the pair partition and the array must be the same front end"
        )
    ranks = torch.arange(expected, device=device, dtype=torch.int32)
    return torch.remainder(ranks, num_tx)


def tdm_slot_count(*, num_chirps: int, num_tx: int) -> int:
    """How many TDM slots one frame occupies.

    A frame is ``num_chirps`` chirp periods per transmitter and the
    transmitters are time division multiplexed, so the frame is
    ``num_chirps * num_tx`` slots long. This is the slot count a batched
    propagation replay is given, and it is stated here, next to
    :func:`pair_tx_index`, so the slow-time slot table has exactly one owner.
    """

    if type(num_chirps) is not int or num_chirps < 1:
        raise ValueError(f"num_chirps must be a positive int, got {num_chirps!r}")
    if type(num_tx) is not int or num_tx < 1:
        raise ValueError(f"num_tx must be a positive int, got {num_tx!r}")
    return num_chirps * num_tx


def waveform_sampling(
    spec: FmcwSpec | OfdmSpec | PulsedSpec, *, num_tx: int, num_rx: int, device: torch.device | str
) -> tuple[tuple[float, ...], torch.Tensor, FmcwSpec | OfdmSpec | PulsedSpec]:
    """World-time offsets, pair gather indices, and a single-slot waveform.

    Every refreshed coefficient belongs to exactly one world instant. TDM
    pairs select their transmitter's instant; OFDM and pulsed pairs share it.
    Geometry is not interpolated across rows or topology epochs.
    """

    pairs = _require_array(num_tx, num_rx)
    single: FmcwSpec | OfdmSpec | PulsedSpec
    if isinstance(spec, FmcwSpec):
        if spec.simultaneous:
            # Every transmitter fires every chirp: one slot per chirp, heard by
            # every pair.
            count = spec.num_chirps
            index = torch.arange(count, device=device).reshape(-1, 1).expand(-1, pairs)
        else:
            count = tdm_slot_count(num_chirps=spec.num_chirps, num_tx=num_tx)
            index = pair_slot_index(
                num_chirps=spec.num_chirps, num_tx=num_tx, num_rx=num_rx, sensor_pair_count=pairs, device=device
            )
        if spec.sequence:
            times = tuple(float(value) for value in spec.slot_profiles()[:, 0])
        else:
            times = tuple(slot * spec.chirp_period_s for slot in range(count))
        # The one-chirp spec is uniform: a sequence's slot profile reaches each
        # observation through its refreshed schedule (or :meth:`FmcwSpec.slot_spec`).
        single = replace(spec, num_chirps=1, carrier_rate_hz=0.0, sequence=(), mimo=MIMO_TDM, ddm_bands=0)
    else:
        if isinstance(spec, OfdmSpec):
            count, period = spec.num_symbols, spec.symbol_period_s
            single = replace(spec, num_symbols=1, carrier_rate_hz=0.0)
        elif isinstance(spec, PulsedSpec):
            count, period = spec.num_pulses, spec.pri_s
            single = replace(spec, num_pulses=1, carrier_rate_hz=0.0)
        else:
            raise TypeError("unsupported waveform sampling contract")
        times = tuple(slot * period for slot in range(count))
        index = torch.arange(count, device=device).reshape(-1, 1).expand(-1, pairs)
    return times, index, single


def fast_time_grid(spec: FmcwSpec | OfdmSpec | PulsedSpec) -> tuple[float, float, int]:
    """``(first, period, count)``: a slot's fast-time instants ``first + m period``, s.

    The instants a fast-time refreshed frame observes the world at within one
    slow-time slot: the ADC window of an FMCW chirp, the range gate of a pulse.
    Refused for a waveform with no fast-time sampling of its own.
    """

    if isinstance(spec, FmcwSpec):
        return float(spec.t_start_s), float(spec.sample_period_s), int(spec.num_samples)
    if isinstance(spec, PulsedSpec):
        return float(spec.range_gate_start_s), float(spec.sample_period_s), int(spec.num_samples)
    if isinstance(spec, OfdmSpec) and spec.time_domain:
        return float(spec.cyclic_prefix_s), float(spec.waveform_sample_period_s), int(spec.samples_per_symbol)
    raise NotImplementedError(f"{type(spec).__name__} has no fast-time observation grid")


def fast_time_offsets(spec: FmcwSpec | OfdmSpec | PulsedSpec, slot_offsets: np.ndarray) -> np.ndarray:
    """Every fast-time observation instant of a frame, slot major, s.

    ``slot_offsets`` is each slot's start (:func:`waveform_sampling`). The
    uniform case is ``slot + first + m * period``, the same additions in the
    same order for every waveform; a chirp sequence takes each slot's own ADC
    start.
    """

    first, period, count = fast_time_grid(spec)
    if isinstance(spec, FmcwSpec) and spec.sequence:
        starts = spec.slot_profiles()[:, 3]
        return (slot_offsets[:, None] + starts[:, None] + np.arange(count) * period).ravel()
    return (slot_offsets[:, None] + first + np.arange(count) * period).ravel()


def fast_count(spec: FmcwSpec | OfdmSpec | PulsedSpec) -> int:
    """The length of a cube's fast axis under ``spec``: samples, subcarriers or post-prefix samples."""

    if isinstance(spec, OfdmSpec):
        return spec.samples_per_symbol if spec.output_domain == OFDM_OUTPUT_TIME else spec.num_subcarriers
    return int(spec.num_samples)


def fast_time_single(single: FmcwSpec | OfdmSpec | PulsedSpec) -> FmcwSpec | OfdmSpec | PulsedSpec:
    """The one-sample spec each fast-time observation is synthesized with.

    ``single`` is the one-slot spec :func:`waveform_sampling` returns; the
    sample's own instant arrives per segment through the refreshed schedule
    (:func:`refreshed_schedule`).
    """

    if isinstance(single, FmcwSpec):
        return replace(single, num_samples=1, output_domain=FMCW_OUTPUT_BEAT)
    return replace(single, num_samples=1)


def refreshed_schedule(
    working: FmcwSpec | OfdmSpec | PulsedSpec, slot: np.ndarray, sample: np.ndarray | None
) -> np.ndarray:
    """The per-segment schedule a refreshed slot batch is synthesized with.

    ``slot`` is each segment's frame slot and ``sample`` its fast-time sample,
    or ``None`` when one observation covers the whole slot. FMCW returns
    ``float64[n, 3]``: the ADC window start [s], the slot's slope [Hz/s] and its
    start offset [Hz]; a pulsed train returns
    ``float64[n, 2]``: the gate start [s] and the pulse's stepped carrier
    offset [Hz]. Each entry is formed exactly as a one-instant spec's scalar
    would be, so a scheduled launch equals per-observation launches bit for bit.
    """

    if isinstance(working, FmcwSpec):
        profile = working.slot_profiles()[slot]
        start = profile[:, 3] if sample is None else profile[:, 3] + sample.astype(np.float64) * working.sample_period_s
        return np.stack((start, profile[:, 1], profile[:, 2]), axis=1)
    if isinstance(working, OfdmSpec) and working.time_domain:
        first = working.cyclic_prefix_s
        start = (
            np.full(len(slot), first, dtype=np.float64)
            if sample is None
            else first + sample.astype(np.float64) * working.waveform_sample_period_s
        )
        return np.stack((start, slot.astype(np.float64)), axis=1)
    if isinstance(working, PulsedSpec):
        start = (
            np.full(len(slot), working.range_gate_start_s, dtype=np.float64)
            if sample is None
            else working.range_gate_start_s + sample.astype(np.float64) * working.sample_period_s
        )
        offset = slot.astype(np.float64) * working.frequency_step_hz
        return np.stack((start, offset), axis=1)
    raise NotImplementedError(f"{type(working).__name__} has no refreshed slot schedule")


def pair_slot_index(
    *, num_chirps: int, num_tx: int, num_rx: int, sensor_pair_count: int, device: torch.device | str
) -> torch.Tensor:
    """Which TDM slot each ``(chirp, sensor pair)`` sits in, ``int64[C, P]``.

    This is the Python statement of the slot index
    ``witwin/radar/cuda/fmcw_beat.cu`` already computes:

        ``slot(c, p) = c * num_tx + segment_tx_index[p]``

    and it is built by CALLING :func:`pair_tx_index` rather than by rederiving
    ``pair % num_tx``, so the beat kernel and a batched propagation replay
    cannot drift onto two different slot tables. The kernel multiplies the same
    index by the chirp period. Every index is below
    ``tdm_slot_count(num_chirps, num_tx)`` by construction.
    """

    transmitter = pair_tx_index(num_tx=num_tx, num_rx=num_rx, sensor_pair_count=sensor_pair_count, device=device).to(
        torch.int64
    )
    chirp = torch.arange(num_chirps, device=device, dtype=torch.int64)
    return chirp.mul(num_tx).reshape(-1, 1) + transmitter.reshape(1, -1)


def assemble_frame_cube(cube: torch.Tensor, *, num_tx: int, num_rx: int) -> torch.Tensor:
    """``[chirp, pair, sample]`` -> ``[TX, RX, chirp, sample]``.

    A waveform kernel produces ``[chirp, sensor_pair, sample]`` because a
    sensor pair is the partition the path rows are grouped by. Every processing
    stage wants ``[TX, RX, chirp, sample]``, because the virtual-antenna index
    :class:`~witwin.radar.processing.angle.ArrayGeometry` steers is TX MAJOR,
    ``va = tx * num_rx + rx``, while the composed pair rank is SINK MAJOR
    (:data:`PAIR_RANK_LAYOUT`). The two are transposes of each other, so a bare
    ``view`` would swap TX and RX channels whenever ``num_tx != num_rx`` and
    silently mis-steer every angle whenever ``num_tx == num_rx``. The transpose
    is performed here, once, and the same statement of the numbering drives
    :func:`pair_tx_index`.

    Pure structural packing: one permute to bring the pair axis to the front,
    one view that splits it into ``(rx, tx)`` because the rank is sink major,
    one permute that puts TX first, and one contiguous copy. No tensor value is
    read, no arithmetic is performed, and the gradient passes straight through,
    so this runs inside the per-frame host observation budget.

    The pair-count check is the reshape's precondition, not a physics check:
    a cube whose pair axis is not exactly ``num_tx * num_rx`` long cannot be
    split into the array at all.
    """

    expected = _require_array(num_tx, num_rx)
    if cube.dim() != 3:
        raise ValueError(f"a synthesis cube must have shape (chirps, sensor_pairs, samples), got {tuple(cube.shape)}")
    if cube.shape[1] != expected:
        raise ValueError(
            f"this cube spans {cube.shape[1]} sensor pairs but the array is {num_tx} x {num_rx} = {expected} pairs"
        )
    num_chirps = int(cube.shape[0])
    num_samples = int(cube.shape[2])
    return cube.permute(1, 0, 2).reshape(num_rx, num_tx, num_chirps, num_samples).permute(1, 0, 2, 3).contiguous()


"""Export one scene component from a batch, without touching row identity.

Exporting the clutter alone, or the target alone, is the same operation the
waveform kernels already perform on a dead row: zero its WEIGHT before the
launch. ``synthesize_fmcw`` does exactly that with ``torch.where``, and it
does it on the weight rather than on the output precisely so the row is inert
in the primal AND carries no gradient back to anything it was built from. A
component mask is that operation with a different predicate.

Three consequences, all of them load bearing:

* the exported batch shares the SAME
  :class:`~witwin.radar.paths.RadarPathTopology` OBJECT, so "row
  identity is unchanged" is assertable with ``is`` rather than with an
  elementwise comparison that a rebuilt-but-equal topology would also pass;
* row order, dtype, device and ``row_valid`` pass through untouched, so every
  export has the same shape and the same pair partition and the per-component
  cubes are addable;
* the waveform kernel accumulates over the rows of a pair segment in the same
  order regardless of masking, and a masked row contributes a literal ``0.0``
  in its own slot. Summing the per-component cubes therefore reproduces the
  full cube up to float re-association of the partial sums, and NOT bitwise:
  ``(a + 0 + c) + (0 + b + 0)`` is not ``(a + b + c)`` in float32. The
  acceptance test states a tolerance and records the measured residual.

There is no kernel change here and there is no incoherent mode. A component is
a row subset of one topology, evaluated by the same launches; combining two
components in POWER is a post-synthesis operation and lives in
:mod:`witwin.radar.processing`.
"""


def select_component(batch: SynthesisPathBatch, index: RadarComponentIndex, name: str) -> SynthesisPathBatch:
    """The same batch with every row outside ``name`` made inert.

    ``index`` must have been built from the batch's own topology. That is
    checked by OBJECT IDENTITY, not by row count: two topologies of the same
    length are the commonest way to mask the wrong rows, and the resulting cube
    is a perfectly plausible frame of the wrong scene.
    """

    if not isinstance(batch, SynthesisPathBatch):
        raise TypeError(f"select_component needs a SynthesisPathBatch, got {type(batch).__name__}")
    if not isinstance(index, RadarComponentIndex):
        raise TypeError(f"select_component needs a RadarComponentIndex, got {type(index).__name__}")
    if index.topology is not batch.topology:
        raise ValueError(
            "the component index was built from a different topology object "
            "than this batch carries; a component mask addresses rows by "
            "position within ONE frozen topology, and masking with another "
            "topology's classification would publish a plausible cube of the "
            "wrong scene"
        )
    mask = index.mask(name)
    weight = torch.where(mask, batch.complex_transfer_ref, torch.zeros_like(batch.complex_transfer_ref))
    return replace(batch, complex_transfer_ref=weight)


# ---------------------------------------------------------------------------
# Cross-radar synthesis (R-ADR-051): one autograd bridge for every family
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True, eq=False)
class CrossRouting:
    """The constant routing of one cross-radar launch (R-ADR-051).

    ``row_link`` and ``row_tx`` (``int32[rows_per_slot]``) give each row of one
    slot its link in ``link_table`` (``float64[links, width]``, the family's
    columns; ``-1`` is a row the receiver does not hear through this family)
    and its transmitter's index within its own radar. ``aux`` is the
    transmitters' tables (chips ``float64[n, 3]``, or OFDM symbols
    ``float32[n, 2]``). ``segment_rows`` (``int64[cells, 2]``) is each receive
    cell's half-open row range and ``segment_schedule`` (``float64[cells, 3]``)
    its slot start in the receiver's frame [s], its first sample's offset from
    that start [s] and the receiver's LO offset for the cell [Hz].
    ``row_segment_offsets`` / ``row_segments`` are the inverse map the backward
    reads. Every member is schedule or waveform data and carries no derivative.
    """

    row_link: torch.Tensor
    row_tx: torch.Tensor
    link_table: torch.Tensor
    aux: torch.Tensor
    segment_rows: torch.Tensor
    segment_schedule: torch.Tensor
    row_segment_offsets: torch.Tensor
    row_segments: torch.Tensor
    rows_per_slot: int
    num_samples: int
    sample_period_s: float

    @property
    def cell_count(self) -> int:
        return int(self.segment_schedule.shape[0])

    def tables(self) -> tuple[torch.Tensor, ...]:
        return (self.row_link, self.row_tx, self.link_table, self.aux)

    def scalars(self) -> tuple[int, int, float]:
        return (self.rows_per_slot, self.num_samples, self.sample_period_s)


def _cross_operators(family: str) -> tuple:
    """The forward, backward and jvp operators of one cross family: ``fmcw``, ``pulsed`` or ``ofdm``."""

    from ..cuda import native_ops

    ops = native_ops()
    if family == "fmcw":
        return ops.fmcw_cross_forward, ops.fmcw_cross_backward, ops.fmcw_cross_jvp
    if family == "pulsed":
        return ops.pulsed_cross_forward, ops.pulsed_cross_backward, ops.pulsed_cross_jvp
    if family == "ofdm":
        return ops.ofdm_cross_forward, ops.ofdm_cross_backward, ops.ofdm_cross_jvp
    raise ValueError(f"no cross-radar family {family!r}")


class _CrossSynthesis(torch.autograd.Function):
    """Autograd bridge of the native cross-radar families; ``family`` names the operators."""

    @staticmethod
    def forward(
        transfer: torch.Tensor,
        tau_rt: torch.Tensor,
        tau_lo: torch.Tensor,
        valid: torch.Tensor,
        routing: CrossRouting,
        family: str,
    ) -> torch.Tensor:
        out = transfer.new_empty((routing.cell_count, routing.num_samples, 2))
        forward, _, _ = _cross_operators(family)
        forward(
            transfer,
            tau_rt,
            tau_lo,
            valid,
            *routing.tables(),
            routing.segment_rows,
            routing.segment_schedule,
            out,
            *routing.scalars(),
        )
        return out

    @staticmethod
    def setup_context(ctx: Any, inputs: tuple[Any, ...], output: torch.Tensor) -> None:
        transfer, tau_rt, tau_lo, valid, routing, family = inputs
        ctx.routing, ctx.family = routing, family
        ctx.save_for_backward(transfer, tau_rt, tau_lo, valid)
        ctx.save_for_forward(transfer, tau_rt, tau_lo, valid)

    @staticmethod
    @first_order_only
    def backward(ctx: Any, grad_out: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, None, None, None, None]:
        transfer, tau_rt, tau_lo, valid = ctx.saved_tensors
        routing = ctx.routing
        grad_transfer = torch.empty_like(transfer)
        grad_tau = torch.empty_like(tau_rt)
        _, backward, _ = _cross_operators(ctx.family)
        backward(
            transfer,
            tau_rt,
            tau_lo,
            valid,
            *routing.tables(),
            routing.row_segment_offsets,
            routing.row_segments,
            routing.segment_schedule,
            grad_out.contiguous(),
            grad_transfer,
            grad_tau,
            *routing.scalars(),
        )
        return grad_transfer, grad_tau, None, None, None, None

    @staticmethod
    def jvp(
        ctx: Any,
        tan_transfer: torch.Tensor | None,
        tan_tau_rt: torch.Tensor | None,
        tan_tau_lo: Any,
        tan_valid: Any,
        tan_routing: Any,
        tan_family: Any,
    ) -> torch.Tensor:
        transfer, tau_rt, tau_lo, valid = ctx.saved_tensors
        routing = ctx.routing
        tan_transfer = torch.zeros_like(transfer) if tan_transfer is None else tan_transfer.contiguous()
        tan_tau_rt = torch.zeros_like(tau_rt) if tan_tau_rt is None else tan_tau_rt.contiguous()
        tan_out = transfer.new_empty((routing.cell_count, routing.num_samples, 2))
        _, _, jvp = _cross_operators(ctx.family)
        jvp(
            transfer,
            tau_rt,
            tau_lo,
            valid,
            *routing.tables(),
            routing.segment_rows,
            routing.segment_schedule,
            tan_transfer,
            tan_tau_rt,
            tan_out,
            *routing.scalars(),
        )
        return tan_out


def synthesize_cross(
    family: str,
    transfer: torch.Tensor,
    delay: torch.Tensor,
    residual: torch.Tensor | None,
    valid: torch.Tensor | None,
    routing: CrossRouting,
) -> torch.Tensor:
    """Every receive cell's cross-radar samples, ``complex64[cells, num_samples]`` (R-ADR-051).

    ``family`` is ``"fmcw"`` (an FMCW receiver's beat), ``"pulsed"`` or
    ``"ofdm"`` (a sampled receiver hearing a pulse train or emitter, or an
    OFDM stream).
    ``transfer`` is the rows' Channel coefficient (``complex64[rows]``),
    ``delay`` the float32 round-trip delay and ``residual`` its float64
    remainder or ``None``. A row whose ``valid`` entry is false contributes
    exactly zero and receives no gradient. Differentiable in ``transfer`` and
    ``delay`` in both modes; the gates are discrete and contribute their
    almost-everywhere derivative. No complex tensor crosses the autograd
    boundary: the coefficient enters as ``view_as_real``.
    """

    if transfer.dtype != torch.complex64 or delay.dtype != torch.float32:
        raise TypeError("cross-radar rows are a complex64 transfer and a float32 delay")
    empty = delay.new_empty(0)
    flags = torch.empty(0, dtype=torch.bool, device=delay.device) if valid is None else valid.contiguous()
    out = _CrossSynthesis.apply(
        torch.view_as_real(transfer.contiguous()),
        delay.contiguous(),
        empty if residual is None else residual.contiguous(),
        flags,
        routing,
        family,
    )
    return torch.view_as_complex(out)
