"""witwin_run - in-run reporting helper (RFC-009).

Importable inside a run script launched by the witwin run subsystem::

    from witwin_run import progress, partial, frame, metric

    for i in range(1000):
        ...
        progress(i / 1000, f"iter {i}/1000")
        if i % 50 == 0:
            frame({"loss": current_loss})

It writes sentinel-tagged JSON lines to stdout. The run executor recognises
these lines and turns them into ``run_progress`` / ``run_partial`` /
``run_metric`` stream events instead of ordinary ``run_log`` lines. Plain ``print`` output is untouched (it
stays a log line) because the sentinel prefix never collides with normal text.

This module is intentionally dependency-free (stdlib only) so it can be imported
by an isolated child process (``python -I``) that has nothing but the standard
library and this single file on its path. It is therefore also the single source
of truth for the wire format; the server-side parser re-uses it
(:mod:`witwin_server.plugins_builtin.runs.report`).
"""
from __future__ import annotations

import json
import sys
import threading
from typing import Any, Optional

# ASCII Unit Separator + tag. Chosen so it never collides with normal prints.
SENTINEL = "\x1f@witwin "

_seq_lock = threading.Lock()
_seq = 0


def _next_seq() -> int:
    global _seq
    with _seq_lock:
        s = _seq
        _seq += 1
    return s


def _json_default(obj: Any) -> Any:
    """Best-effort JSON coercion for common numeric containers (e.g. numpy/torch)
    without importing them, so a partial frame can carry array-ish data."""
    tolist = getattr(obj, "tolist", None)
    if callable(tolist):
        try:
            return tolist()
        except Exception:  # noqa: BLE001 - never let reporting crash the run
            pass
    item = getattr(obj, "item", None)
    if callable(item):
        try:
            return item()
        except Exception:  # noqa: BLE001
            pass
    return str(obj)


def encode(kind: str, **fields: Any) -> str:
    """Encode a report record as a single sentinel-tagged line (no newline)."""
    payload = {"kind": kind, **fields}
    return SENTINEL + json.dumps(payload, separators=(",", ":"), default=_json_default)


def parse(line: str) -> Optional[dict]:
    """Parse a sentinel-tagged line into its record dict, or ``None``.

    Returns ``None`` for ordinary (non-tagged) lines and for malformed tagged
    lines, so the caller can always fall back to treating the line as a log.
    """
    if not line.startswith(SENTINEL):
        return None
    try:
        rec = json.loads(line[len(SENTINEL):])
    except (ValueError, TypeError):
        return None
    if not isinstance(rec, dict) or "kind" not in rec:
        return None
    return rec


def _emit(line: str) -> None:
    # Single write + flush so the executor's line reader sees the record
    # promptly and whole, even from a tight loop.
    sys.stdout.write(line + "\n")
    sys.stdout.flush()


def progress(frac: float, message: Optional[str] = None) -> None:
    """Report fractional progress in ``[0, 1]`` with an optional message."""
    try:
        frac = float(frac)
    except (TypeError, ValueError):
        frac = 0.0
    frac = max(0.0, min(1.0, frac))
    fields: dict = {"frac": frac}
    if message is not None:
        fields["message"] = str(message)
    _emit(encode("progress", **fields))


def partial(data: Any, seq: Optional[int] = None) -> int:
    """Stream an intermediate result frame; returns the sequence number.

    ``seq`` is monotonic per process so the client can order frames and detect
    drops. Pass an explicit ``seq`` to override the auto counter. Keep payloads
    small and lossy-tolerant (scalar metrics, a downsampled slice, a preview
    handle); large artifacts belong in Results / stage-out, not here.
    """
    if seq is None:
        seq = _next_seq()
    _emit(encode("partial", seq=seq, data=data))
    return seq


def frame(data: Any, seq: Optional[int] = None) -> int:
    """Stream a per-frame runtime update; returns the sequence number."""
    if seq is None:
        seq = _next_seq()
    _emit(encode("frame", seq=seq, data=data))
    return seq


def metric(rows: Any) -> None:
    """Report metric rows; the server appends them to the Run's ``metrics.jsonl``.

    A row is ``{"step": int, "epoch"?: number, "t": seconds, "values": {name: number}}``
    (``witwin.studio._runs``). Scripts normally call ``witwin.studio.log``, which
    batches rows and sends them through this record kind; send a list, not one
    line per value, since each line costs the reader a parse.
    """
    _emit(encode("metric", rows=list(rows)))


__all__ = ["SENTINEL", "encode", "parse", "progress", "partial", "frame", "metric"]
