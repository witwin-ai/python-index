"""``witwin_agent.project.path``: the Project root as a string."""
from __future__ import annotations

import os
from pathlib import Path

MANIFEST = "witwin.toml"


def find_root(start: str | os.PathLike | None = None) -> Path:
    """The nearest folder at or above ``start`` (default: cwd) with ``witwin.toml``.

    Falls back to ``start`` itself, which is what the old runner reported (it
    ran scripts with the Project root as cwd).
    """
    here = Path(start or os.getcwd()).resolve()
    for folder in (here, *here.parents):
        if (folder / MANIFEST).is_file():
            return folder
    return here


path = str(find_root())
