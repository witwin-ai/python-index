"""Compatibility module for scripts written for the Agent's script runner.

Earlier, ``script.run`` generated a ``witwin_agent`` stand-in that existed only
inside the ProjectServer's runner, so these scripts failed with
``python scripts/x.py``. This package is that API as a real module:

- inside ``script.run`` (``WITWIN_AGENT_RUNNER=1``), ``scene.apply_batch``
  hands the operations to the ProjectServer, which applies them to the open
  scene in one transaction, as before;
- anywhere else, it applies them to the Project's main scene file through
  ``witwin.studio`` and saves it.

New code should use ``witwin.studio`` directly. This module stays for two
minor versions of ``witwin-studio`` (design ``project-as-python-codebase.md``
§3.5), so Agent-written scripts in users' Projects keep working. It imports
only the standard library until a script applies operations outside the runner.
"""
from . import project, results, scene  # noqa: F401

__all__ = ["project", "results", "scene"]
