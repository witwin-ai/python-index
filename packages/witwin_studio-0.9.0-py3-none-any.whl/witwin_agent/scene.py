"""``witwin_agent.scene``: build ``scene.batch`` operations and apply them.

The op shape and the runner protocol (one stdout line ``BATCH_MARKER`` +
JSON) are unchanged from the old in-runner stand-in; the ProjectServer's
``tools/script_tools.py`` reads that line.

``create_mesh_op`` is the one op that carries geometry. The triangles never go
through JSON or stdout: the op writes them as a ``.meshbin`` file into the
folder the runner names in ``MESH_DIR_ENV``, and the op holds only that path.
The ProjectServer accepts paths inside that run's folder only.
"""
from __future__ import annotations

import json
import os
import tempfile
import uuid
from typing import Any, Dict, List, Optional, Sequence

from . import project

BATCH_MARKER = "__WITWIN_BATCH__"
# Set by the ProjectServer's script runner (script.run).
RUNNER_ENV = "WITWIN_AGENT_RUNNER"
# Set by script.run to a folder that exists for that run only.
MESH_DIR_ENV = "WITWIN_AGENT_MESH_DIR"

_ops: List[Dict[str, Any]] = []
_local_mesh_dir: Optional[str] = None


def create_object_op(name: Optional[str] = None, mesh_type: Optional[str] = None,
                     position: Optional[Sequence[float]] = None, parent_id: Optional[str] = None, *,
                     size: Any = None, radius: Optional[float] = None, height: Optional[float] = None,
                     tube_radius: Optional[float] = None, rotation: Optional[Sequence[float]] = None,
                     scale: Optional[Sequence[float]] = None,
                     material: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """One ``create_object`` op. ``tempId`` is ``op<n>``, counted per process.

    Arguments are those of the ``scene.create_object`` Tool, in meters:
    ``size`` (Cube ``[x, y, z]`` or one number, Plane ``[x, z]``), ``radius``
    (Sphere, Cylinder, Cone; Torus centre line), ``height`` (Cylinder, Cone,
    along Y), ``tube_radius`` (Torus). Give a size or ``scale``, not both.
    ``rotation`` is Euler angles in degrees ``(x, y, z)``; ``material`` is a
    dict of ``color``, ``metalness``, ``roughness``. ``parent_id`` may name an
    earlier op's ``tempId``; the transform is then local to that parent. The
    ProjectServer (or ``apply_batch`` outside a run) checks the values.
    """
    op: Dict[str, Any] = {"op": "create_object", "tempId": "op%d" % len(_ops)}
    if name is not None:
        op["name"] = name
    if mesh_type is not None:
        op["meshType"] = mesh_type
    if position is not None:
        op["position"] = list(position)
    if rotation is not None:
        op["rotation"] = [float(v) for v in rotation]
    if scale is not None:
        op["scale"] = list(scale)
    if size is not None:
        op["size"] = list(size) if isinstance(size, (list, tuple)) else size
    # The op keys are the Tool's camelCase names.
    for key, value in (("radius", radius), ("height", height), ("tubeRadius", tube_radius)):
        if value is not None:
            op[key] = value
    if material is not None:
        op["material"] = dict(material)
    if parent_id is not None:
        op["parentId"] = parent_id
    _ops.append(op)
    return op


def _mesh_dir() -> str:
    """The runner's folder for this run; outside the runner a private temp folder."""
    global _local_mesh_dir
    folder = os.environ.get(MESH_DIR_ENV)
    if folder:
        return folder
    if _local_mesh_dir is None:
        _local_mesh_dir = tempfile.mkdtemp(prefix="witwin-mesh-")
    return _local_mesh_dir


def create_mesh_op(name: str, mesh: Any, *, material: Any = None, fill: Optional[str] = None,
                   role: Optional[str] = None, anchors: Optional[Sequence[Any]] = None,
                   parent_id: Optional[str] = None, unit: str = "m",
                   position: Optional[Sequence[float]] = None, rotation: Optional[Sequence[float]] = None,
                   scale: Optional[Sequence[float]] = None, grid: Any = None,
                   max_triangles: Optional[int] = None, force: bool = False,
                   surface_thickness: Optional[float] = None, up: Optional[str] = None) -> Dict[str, Any]:
    """One ``create_mesh`` op: a new object holding ``mesh``.

    Arguments are those of ``witwin.studio.Scene.add_mesh``. ``mesh`` is a
    ``witwin.studio.Body``, ``(vertices, faces)`` arrays, or a trimesh /
    manifold3d / build123d / CadQuery object (several parts are merged into
    one mesh). ``unit`` is the unit of the vertices, anchors and
    ``position``; ``rotation`` is Euler angles in degrees ``(x, y, z)``, as
    in every ``scene.batch`` op and the Properties panel (``Scene.add_mesh``
    itself takes a quaternion); ``parent_id`` may name an earlier op's
    ``tempId``. ``surface_thickness`` is the real thickness of a
    ``fill="surface"`` sheet, always in meters (``GeometryBody.surface_thickness``;
    a ``witwin.studio.layout`` body carries its own). ``up="z"`` turns a
    Z-up (CAD / layout) mesh into the Y-up Scene frame; None takes the Body's
    (a layout body is ``"z"``), else ``"y"``. The mesh is checked
    here: errors raise ``GeometryValidationError`` unless ``force``. The
    ProjectServer checks it again in world space and returns the report in
    the batch result.

    Needs numpy and ``witwin-studio`` in the Project environment
    (``pip install "witwin-studio[geometry]"``); the other ops do not.
    """
    try:
        from witwin.studio import meshbin
        from witwin.studio._mesh_entities import prepare_op_mesh
        from witwin.studio._ops import degrees_to_quat
        from witwin.studio.geometry import material_properties
    except ImportError as exc:  # pragma: no cover - depends on the Project environment
        raise ImportError("create_mesh_op needs numpy and witwin-studio in the Project environment: "
                          'pip install "witwin-studio[geometry]"') from exc

    degrees = [float(v) for v in rotation] if rotation is not None else None
    part, position_si, _ = prepare_op_mesh(
        name, mesh, material=material, fill=fill, role=role, anchors=anchors, unit=unit, position=position,
        rotation=degrees_to_quat(degrees) if degrees is not None else None, scale=scale, grid=grid,
        max_triangles=max_triangles, force=force, surface_thickness=surface_thickness, up=up)
    temp_id = "op%d" % len(_ops)
    path = os.path.join(_mesh_dir(), "%s-%s%s" % (temp_id, uuid.uuid4().hex[:12], meshbin.EXTENSION))
    with open(path, "wb") as f:
        f.write(meshbin.encode_mesh(part.mesh.vertices, part.mesh.faces, normals=part.mesh.normals))
    op: Dict[str, Any] = {"op": "create_mesh", "tempId": temp_id, "name": name, "meshbinPath": path,
                          "fill": part.fill, "role": part.role}
    if part.material is not None:
        op["material"] = material_properties(part.material)
    if part.anchors:
        op["anchors"] = [a.to_dict() for a in part.anchors]
    if part.surface_thickness:
        op["surfaceThickness"] = part.surface_thickness
    if position_si is not None:
        op["position"] = position_si
    if degrees is not None:
        op["rotation"] = degrees
    if scale is not None:
        op["scale"] = [float(v) for v in scale]
    if parent_id is not None:
        op["parentId"] = parent_id
    if grid is not None:
        op["grid"] = grid
    if max_triangles is not None:
        op["maxTriangles"] = int(max_triangles)
    if force:
        op["force"] = True
    _ops.append(op)
    return op


def in_runner() -> bool:
    return os.environ.get(RUNNER_ENV) == "1"


def apply_batch(ops: Sequence[Dict[str, Any]], label: Optional[str] = None) -> Dict[str, Any]:
    """Apply ``ops`` to the scene, all or nothing.

    In the runner, the ProjectServer applies them to the open scene after the
    script prints them. Elsewhere they go into the Project's main scene file;
    a failing op leaves the file unchanged.
    """
    payload = {"operations": list(ops), "label": label}
    if in_runner():
        print(BATCH_MARKER + json.dumps(payload), flush=True)
        return {"submitted": len(payload["operations"]), "label": label}

    import witwin.studio as ws
    from witwin.studio._ops import apply_ops

    scene = ws.open_project(project.path).scene()
    applied = apply_ops(scene, payload["operations"])
    scene.save()
    return {"submitted": len(payload["operations"]), "label": label, "scene_id": scene.id, **applied}
