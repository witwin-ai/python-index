"""``witwin_agent.results``: accepted and ignored, as in the old runner.

Recording Results from a script arrives with headless solving (design phase
P5, ``project.results.record``). Until then these calls do nothing, so old
scripts that call them still run.
"""
from __future__ import annotations


def plot(*args, **kwargs) -> None:
    pass


def commit(*args, **kwargs) -> None:
    pass
