"""Scene document model: edit a ``.wtscene`` as data, without the server.

Every object here is a *view* over the scene document dict that
``wtscene.loads`` returns. Edits write straight into that dict, so keys this
model does not know about (plugin components, timeline, future fields) are
kept and saved unchanged. That is the point of "Scene as data" (decision D11):
a component whose Plugin is not installed is still a plain mapping you can
read, edit and save.

Parameters and field bindings live in the Scene's Formula Graph
(``Scene.formulas``), the same engine the ProjectServer runs. Component
properties and the Transform always hold the evaluated SI numbers
(dev_docs/backend/FORMULA_GRAPH.md); every edit made through ``Scene.parameters``
or ``Entity.bind`` / ``unbind`` / ``set_unit`` recomputes and writes those
numbers at once, so the document is consistent at every step.
"""
from __future__ import annotations

import hashlib
import logging
import math
import os
import tempfile
from pathlib import Path
from typing import (
    TYPE_CHECKING, Any, Callable, Dict, Iterator, List, Mapping, MutableMapping, Optional, Sequence, Tuple, Union,
)

from . import _mesh_entities, wtscene
from ._ids import unique_slug
from .formula import BindingTarget, ErrorCode, FormulaError, FormulaGraph, ParameterInfo
from .units import LENGTH, QUANTITIES, key_to_si

if TYPE_CHECKING:
    from ._animation import Animation

ROOT = "root"
DEFAULT_ENTITY_TYPE = "builtin.group"

logger = logging.getLogger("witwin.studio")

Vec3 = Tuple[float, float, float]
Quat = Tuple[float, float, float, float]

_IDENTITY_POS: Vec3 = (0.0, 0.0, 0.0)
_IDENTITY_ROT: Quat = (0.0, 0.0, 0.0, 1.0)
_IDENTITY_SCL: Vec3 = (1.0, 1.0, 1.0)


class SceneConflictError(RuntimeError):
    """The scene file changed on disk since it was loaded; saving would lose that edit."""


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _floats(values: Sequence[float], n: int, what: str) -> List[float]:
    out = [float(v) for v in values]
    if len(out) != n:
        raise ValueError(f"{what} needs {n} numbers, got {len(out)}")
    return out


# --------------------------------------------------------------------------- #
# Euler angles <-> quaternion
#
# The ProjectServer's Transform.rotation field is three Euler angles in
# radians for SciPy's intrinsic "ZXY" sequence: angle[0] turns about Z, then
# angle[1] about the new X, then angle[2] about the new Y. A rotation binding
# writes one of those angles, so the SDK must convert exactly the same way.
# Pure math here, because witwin.studio must not import scipy or numpy.
# --------------------------------------------------------------------------- #
def _axis_quat(axis: int, angle: float) -> List[float]:
    q = [0.0, 0.0, 0.0, math.cos(angle / 2.0)]
    q[axis] = math.sin(angle / 2.0)
    return q


# Hamilton product of quaternions stored as (x, y, z, w).
def _quat_mul(a: Sequence[float], b: Sequence[float]) -> List[float]:
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return [
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
        aw * bw - ax * bx - ay * by - az * bz,
    ]


def _euler_to_quat(euler: Sequence[float]) -> List[float]:
    z, x, y = (float(v) for v in euler[:3])
    return _quat_mul(_quat_mul(_axis_quat(2, z), _axis_quat(0, x)), _axis_quat(1, y))


def _quat_to_euler(quat: Sequence[float]) -> List[float]:
    x, y, z, w = (float(v) for v in quat)
    norm = math.sqrt(x * x + y * y + z * z + w * w) or 1.0
    x, y, z, w = x / norm, y / norm, z / norm, w / norm
    # Matrix entries of R = Rz(a) Rx(b) Ry(c) that isolate each angle.
    r00 = 1 - 2 * (y * y + z * z)
    r01 = 2 * (x * y - z * w)
    r10 = 2 * (x * y + z * w)
    r11 = 1 - 2 * (x * x + z * z)
    r20 = 2 * (x * z - y * w)
    r21 = 2 * (y * z + x * w)
    r22 = 1 - 2 * (x * x + y * y)
    b = math.asin(max(-1.0, min(1.0, r21)))
    if abs(math.cos(b)) < 1e-9:  # gimbal lock: only a + c is defined; put it all in a
        angles = [math.atan2(r10, r00), b, 0.0]
    else:
        angles = [math.atan2(-r01, r11), b, math.atan2(-r20, r22)]
    return [angle + 0.0 for angle in angles]  # + 0.0 turns -0.0 into 0.0 for the file


# --------------------------------------------------------------------------- #
# Field units for bindings
# --------------------------------------------------------------------------- #
_TRANSFORM_QUANTITY = {"position": "length", "rotation": "angle", "scale": "length"}
# What Studio uses when a binding names no unit: the SI length unit for position
# and scale (their declared default), degrees for rotation (what Properties shows).
_TRANSFORM_DEFAULT_UNIT = {"position": LENGTH[0].key, "rotation": "deg", "scale": LENGTH[0].key}


def _default_unit(target: str) -> Optional[str]:
    component, _, field = target.partition(".")
    return _TRANSFORM_DEFAULT_UNIT.get(field) if component == "Transform" else None


# Refuse a unit the field cannot take; raises FormulaError(unit).
def _check_unit(target: str, unit: Any) -> None:
    """Transform fields take their quantity's units; component fields any known unit key.

    The SDK does not load component classes, so it cannot see a component
    field's own unit list; the ProjectServer checks that list on its side.
    """
    component, _, field = target.partition(".")
    if component == "Transform":
        keys = [u.key for u in QUANTITIES[_TRANSFORM_QUANTITY[field]]]
        if unit not in keys:
            raise FormulaError(ErrorCode.UNIT,
                               f"'{unit}' is not a unit of {target} (allowed: {', '.join(keys)})")
        return
    try:
        key_to_si(1.0, unit)
    except (KeyError, TypeError):
        raise FormulaError(ErrorCode.UNIT, f"'{unit}' is not a known unit key") from None


# A number property value (bool is not a number here).
def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


# The formula text for a number or formula given to Scene.parameters.
def _formula_text(value: Union[str, float, int]) -> str:
    if isinstance(value, str):
        return value
    if not _is_number(value):
        raise TypeError(f"a parameter is a formula string or a number, not {type(value).__name__}")
    if isinstance(value, float) and math.isnan(value):
        raise ValueError("a parameter cannot be NaN")
    if isinstance(value, float) and math.isinf(value):
        return "inf" if value > 0 else "-inf"
    return repr(value)


# Write recomputed values of one Transform field; returns the targets written.
def _write_transform(transform: "Transform", field: str,
                     values: List[Tuple[BindingTarget, float]]) -> List[BindingTarget]:
    vector = transform._euler() if field == "rotation" else list(getattr(transform, field))
    written = []
    for target, value in values:
        if target.index is not None and 0 <= target.index < len(vector):
            vector[target.index] = value
            written.append(target)
    if written:
        if field == "rotation":
            transform._set_euler(vector)
        else:
            setattr(transform, field, vector)
    return written


# Write recomputed values of one component property; returns the targets written.
def _write_property(components: "Components", component: str, field: str,
                    values: List[Tuple[BindingTarget, float]]) -> List[BindingTarget]:
    """A missing component (its Plugin is not installed) or vector slot is skipped."""
    if component not in components:
        return []
    properties = components[component]
    current = properties.get(field)
    vector = list(current) if isinstance(current, (list, tuple)) else None
    written = []
    for target, value in values:
        if target.index is None:
            properties[field] = value
            written.append(target)
        elif vector is not None and target.index < len(vector):
            vector[target.index] = value
            written.append(target)
    if vector is not None and any(target.index is not None for target in written):
        properties[field] = vector
    return written


class Transform:
    """Local transform of one entity. Rotation is a quaternion ``(x, y, z, w)``."""

    def __init__(self, data: Dict[str, Any]):
        self._data = data

    def _get(self, key: str, default: tuple) -> tuple:
        value = self._data.get(key)
        return tuple(float(v) for v in value) if value is not None else default

    def _fill(self) -> None:
        # An empty transform dict means identity. Writing one field must not leave
        # the other two missing, or the codec would read them back as None.
        self._data.setdefault("position", list(_IDENTITY_POS))
        self._data.setdefault("rotation", list(_IDENTITY_ROT))
        self._data.setdefault("scale", list(_IDENTITY_SCL))

    @property
    def position(self) -> Vec3:
        return self._get("position", _IDENTITY_POS)  # type: ignore[return-value]

    @position.setter
    def position(self, value: Sequence[float]) -> None:
        self._fill()
        self._data["position"] = _floats(value, 3, "position")

    @property
    def rotation(self) -> Quat:
        return self._get("rotation", _IDENTITY_ROT)  # type: ignore[return-value]

    @rotation.setter
    def rotation(self, value: Sequence[float]) -> None:
        self._fill()
        self._data["rotation"] = _floats(value, 4, "rotation")
        # The editor stores the Euler angles it last showed next to the
        # quaternion. A new quaternion makes them stale; the editor recomputes
        # them from the quaternion when they are absent.
        self._data.pop("rotation_euler", None)

    @property
    def scale(self) -> Vec3:
        return self._get("scale", _IDENTITY_SCL)  # type: ignore[return-value]

    @scale.setter
    def scale(self, value: Sequence[float]) -> None:
        self._fill()
        self._data["scale"] = _floats(value, 3, "scale")

    # Euler angles in radians, as the ProjectServer's Transform.rotation field holds them.
    def _euler(self) -> List[float]:
        saved = self._data.get("rotation_euler")
        if saved is not None and len(saved) >= 3:
            return [float(v) for v in saved[:3]]
        return _quat_to_euler(self.rotation)

    # Write Euler angles: the quaternion and the saved angles together, so they agree.
    def _set_euler(self, euler: Sequence[float]) -> None:
        self.rotation = _euler_to_quat(euler)
        self._data["rotation_euler"] = [float(v) for v in euler]

    def __repr__(self) -> str:
        return f"Transform(position={self.position}, rotation={self.rotation}, scale={self.scale})"


class Components(Mapping[str, Dict[str, Any]]):
    """An entity's components by type name; each value is its live property dict.

    ``Transform`` is not in here: it is the entity's ``transform``.
    ``on_remove(type_name)`` runs after a component is removed; the Entity uses
    it to drop that component's formula bindings and units.
    """

    def __init__(self, items: List[Dict[str, Any]], *,
                 on_remove: Optional[Callable[[str], None]] = None):
        self._items = items
        self._on_remove = on_remove

    def _find(self, type_name: str) -> Optional[Dict[str, Any]]:
        for item in self._items:
            if item.get("type") == type_name:
                return item
        return None

    def __getitem__(self, type_name: str) -> Dict[str, Any]:
        item = self._find(type_name)
        if item is None:
            raise KeyError(type_name)
        return item.setdefault("properties", {})

    def __iter__(self) -> Iterator[str]:
        return (str(item.get("type")) for item in list(self._items))

    def __len__(self) -> int:
        return len(self._items)

    def add(self, type_name: str, **properties: Any) -> Dict[str, Any]:
        """Add a component and return its property dict."""
        if self._find(type_name) is not None:
            raise ValueError(f"component already present: {type_name}")
        item = {"type": type_name, "properties": dict(properties)}
        self._items.append(item)
        return item["properties"]

    def remove(self, type_name: str) -> None:
        item = self._find(type_name)
        if item is None:
            raise KeyError(type_name)
        self._items.remove(item)
        if self._on_remove is not None:
            self._on_remove(type_name)

    def __repr__(self) -> str:
        return f"Components({list(self)})"


class Entity:
    """One object in a Scene. ``id`` is frozen; ``name`` is the display name."""

    def __init__(self, scene: "Scene", entity_id: str):
        self._scene = scene
        self._id = entity_id
        # The ValidationReport of the add_mesh call that returned this object;
        # None on Entity objects obtained any other way.
        self.validation: Optional[Any] = None

    @property
    def _data(self) -> Dict[str, Any]:
        try:
            return self._scene._objects[self._id]
        except KeyError:
            raise KeyError(f"entity was removed: {self._id}") from None

    @property
    def id(self) -> str:
        return self._id

    @property
    def name(self) -> str:
        return str(self._data.get("name") or self._id)

    @name.setter
    def name(self, value: str) -> None:
        self._data["name"] = str(value)

    @property
    def type(self) -> Optional[str]:
        """Entity type id such as ``builtin.mesh``; None for untyped legacy entities."""
        return self._data.get("entity_type")

    @property
    def parent(self) -> Optional["Entity"]:
        parent_id = self._data.get("parent_id") or ROOT
        return None if parent_id == ROOT else self._scene.objects.get(parent_id)

    @property
    def children(self) -> List["Entity"]:
        order = self._scene._children_order.get(self._id, [])
        return [self._scene.objects[cid] for cid in order if cid in self._scene._objects]

    @property
    def visible(self) -> bool:
        return self._data.get("is_active", True) is not False

    @visible.setter
    def visible(self, value: bool) -> None:
        self._data["is_active"] = bool(value)

    @property
    def transform(self) -> Transform:
        data = self._data
        if not isinstance(data.get("transform"), dict):
            data["transform"] = {}
        return Transform(data["transform"])

    @property
    def components(self) -> Components:
        data = self._data
        if not isinstance(data.get("components"), list):
            data["components"] = []
        return Components(data["components"],
                          on_remove=lambda type_name: self._scene._component_removed(self._id, type_name))

    # -- formula bindings ---------------------------------------------------
    def bind(self, target: str, expr: str, *, unit: Optional[str] = None,
             index: Optional[int] = None) -> None:
        """Bind a field, or one component of a vector field, to a formula.

        ``target`` is ``"Component.field"`` or ``"Transform.position"`` /
        ``"Transform.rotation"`` / ``"Transform.scale"``. Vector fields need
        ``index``; single numbers take none. The formula result is read in the
        field's unit and stored in SI: ``bind("Transform.scale", "w", unit="um",
        index=0)`` with ``w = 2.5`` stores ``2.5e-6``. ``unit=None`` keeps the
        field's current unit, else its default (``m`` for position and scale,
        ``deg`` for rotation, SI for component fields). The value is written
        at once. A refused edit raises ``FormulaError`` (``not_found``,
        ``invalid``, ``unit``, ``field_animated``, ``syntax``, ``unknown_name``)
        and changes nothing.
        """
        scene = self._scene
        key, _ = scene._field_key(self._id, target, index)
        if not isinstance(expr, str) or not expr.strip():
            raise FormulaError(ErrorCode.INVALID, "expr must be a non-empty formula")
        if unit is None:
            unit = scene._formulas.unit(self._id, target) or _default_unit(target)
        else:
            _check_unit(target, unit)
        scene._require_not_animated(self._id, target)
        scene._formulas.bind(key, expr, unit)
        scene.recompute()

    def unbind(self, target: str, *, index: Optional[int] = None) -> None:
        """Remove a field's formula; the field keeps its current number.

        Unbinding a component that is not bound changes nothing.
        """
        key, _ = self._scene._field_key(self._id, target, index)
        self._scene._formulas.unbind(key)
        self._scene.recompute()

    def set_unit(self, target: str, unit: Optional[str]) -> None:
        """Set the unit a field is shown and read in; ``None`` means SI.

        An unbound number does not change. A bound component's formula is read
        in the new unit, so its stored SI number changes (``w`` in ``mm`` is a
        thousand times ``w`` in ``um``).
        """
        self._scene._field_key(self._id, target, None, check_index=False)
        if unit is not None:
            _check_unit(target, unit)
        self._scene._formulas.set_unit(self._id, target, unit)
        self._scene.recompute()

    # -- generated mesh -----------------------------------------------------
    def set_mesh(self, mesh: Any, *, material: Union[str, Mapping[str, Any], None] = None,
                 fill: Optional[str] = None, role: Optional[str] = None,
                 anchors: Optional[Sequence[Any]] = None, unit: str = "m", grid: Any = None,
                 max_triangles: Optional[int] = None, force: bool = False,
                 surface_thickness: Optional[float] = None, up: Optional[str] = None) -> Any:
        """Replace this entity's triangles; see ``Scene.add_mesh`` for the arguments.

        Material, fill, role, anchors and surface thickness not given keep
        their current values.
        Returns the ``ValidationReport``; raises ``GeometryValidationError``
        (nothing changed) when it has errors, unless ``force``.
        """
        return _mesh_entities.set_mesh(self, mesh, material=material, fill=fill, role=role, anchors=anchors,
                                       unit=unit, grid=grid, max_triangles=max_triangles, force=force,
                                       surface_thickness=surface_thickness, up=up)

    def get_mesh(self) -> Optional[Any]:
        """The generated mesh as ``geometry.MeshData`` in meters (local coordinates).

        None when the entity has no generated mesh (a primitive, an imported
        model) or its mesh file is missing.
        """
        return _mesh_entities.get_mesh(self)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Entity) and other._scene is self._scene and other._id == self._id

    def __hash__(self) -> int:
        return hash((id(self._scene), self._id))

    def __repr__(self) -> str:
        return f"Entity(id={self._id!r}, name={self.name!r}, type={self.type!r})"


class _Objects(Mapping[str, Entity]):
    def __init__(self, scene: "Scene"):
        self._scene = scene

    def __getitem__(self, entity_id: str) -> Entity:
        if entity_id not in self._scene._objects:
            raise KeyError(entity_id)
        return Entity(self._scene, entity_id)

    def __iter__(self) -> Iterator[str]:
        return iter(list(self._scene._objects))

    def __len__(self) -> int:
        return len(self._scene._objects)

    def __repr__(self) -> str:
        return f"Objects({list(self)})"


class Parameters(MutableMapping[str, float]):
    """``Scene.parameters``: the Scene's parameters by name, in display order.

        scene.parameters["w"] = "2.5"         # create or update; a formula string or a number
        scene.parameters["gap"] = "w / 10"
        scene.parameters["gap"]               # 0.25
        del scene.parameters["gap"]           # FormulaError(parameter_in_use) while something reads it

    Reading gives the last good value (a float). A parameter whose formula
    never evaluated raises its ``FormulaError``. Every write recomputes the
    Formula Graph and writes bound fields at once. Use ``set`` for the
    description, ``info`` for the full record. Which parameters a Study varies,
    and in what range, is written in the Study (``project.studies``).
    """

    def __init__(self, scene: "Scene"):
        self._scene = scene

    def _find(self, name: str) -> Optional[ParameterInfo]:
        for info in self._scene._formulas.parameters():
            if info.name == name:
                return info
        return None

    def info(self, name: str) -> ParameterInfo:
        """The full record: id, formula, value, error, and whether it is free."""
        found = self._find(name)
        if found is None:
            raise KeyError(name)
        return found

    def set(self, name: str, expr: Union[str, float, int, None] = None, *,
            description: Optional[str] = None) -> ParameterInfo:
        """Create or update the parameter ``name`` and return its record.

        ``expr`` is a formula string or a number; a new parameter needs one.
        ``None`` leaves a field as it is. A refused edit raises
        ``FormulaError`` and changes nothing.
        """
        formulas = self._scene._formulas
        text = None if expr is None else _formula_text(expr)
        found = self._find(name)
        if found is None:
            if text is None:
                raise FormulaError(ErrorCode.INVALID, f"new parameter '{name}' needs a formula")
            param_id = formulas.add_parameter(name, text, description or "")
        else:
            param_id = found.id
            formulas.update_parameter(param_id, expr=text, description=description)
        self._scene.recompute()
        return formulas.parameter(param_id)

    def remove(self, name: str, *, force: bool = False) -> None:
        """Delete a parameter.

        Raises ``FormulaError(parameter_in_use)`` while a binding or another
        parameter reads it, unless ``force``: then bindings that read it are
        removed (fields keep their numbers) and parameters that read it become
        the literal of their last value.
        """
        self._scene._formulas.remove_parameter(self.info(name).id, force=force)
        self._scene.recompute()

    def __getitem__(self, name: str) -> float:
        info = self.info(name)
        if info.value is None:
            raise info.error or FormulaError(ErrorCode.INVALID, f"'{name}' has no value")
        return info.value

    def __setitem__(self, name: str, value: Union[str, float, int]) -> None:  # type: ignore[override]
        self.set(name, value)

    def __delitem__(self, name: str) -> None:
        self.remove(name)

    def __iter__(self) -> Iterator[str]:
        return iter([info.name for info in self._scene._formulas.parameters()])

    def __len__(self) -> int:
        return len(self._scene._formulas.parameters())

    def __repr__(self) -> str:
        values = {info.name: info.value for info in self._scene._formulas.parameters()}
        return f"Parameters({values!r})"


def _check_stage(value: str) -> str:
    if value not in wtscene.STAGES:
        raise ValueError(f"stage must be one of {wtscene.STAGES}, not {value!r}")
    return value


class Scene:
    """A Scene loaded from (or to be saved to) one ``.wtscene`` file.

    Build one with ``Project.scene`` / ``Project.create_scene``, or
    ``Scene.load(path)`` for a loose file.
    """

    def __init__(self, document: Dict[str, Any], path: Optional[Path] = None,
                 *, loaded_text: Optional[str] = None):
        self._doc = document
        self._doc.setdefault("objects", {})
        self._doc.setdefault("children_order", {})
        self.path: Optional[Path] = Path(path) if path is not None else None
        # Hash of the bytes this object was loaded from (None = never on disk).
        # save() refuses to overwrite a file whose bytes changed since then,
        # the same interlock the ProjectServer uses for auto-save (§14.6).
        self._loaded_hash: Optional[str] = _hash(loaded_text) if loaded_text is not None else None
        self._formulas = wtscene.load_formulas(self._doc)
        # Generated-mesh payloads by binary id, written by save() (_mesh_entities).
        self._pending_meshes: Dict[str, bytes] = {}
        # Mesh files this object has referenced; save() deletes the ones it dropped.
        self._known_binary_ids = _mesh_entities.referenced_binary_ids(self._doc)

    # -- construction -------------------------------------------------------
    @classmethod
    def load(cls, path: Path | str) -> "Scene":
        path = Path(path)
        text = path.read_text(encoding="utf-8")
        return cls(wtscene.loads(text), path, loaded_text=text)

    @classmethod
    def new(cls, scene_id: str, name: Optional[str] = None, path: Optional[Path] = None,
            *, stage: str = wtscene.DEFAULT_STAGE) -> "Scene":
        return cls({
            "format_version": wtscene.FORMAT,
            "scene_id": scene_id,
            "name": name or scene_id,
            "role": "normal",
            "stage": _check_stage(stage),
            "capabilities": [],
            "deps": {},
            "objects": {},
            "children_order": {},
        }, path)

    # -- identity -----------------------------------------------------------
    @property
    def id(self) -> str:
        return str(self._doc.get("scene_id") or "scene")

    @property
    def name(self) -> str:
        return str(self._doc.get("name") or self.id)

    @name.setter
    def name(self, value: str) -> None:
        self._doc["name"] = str(value)

    @property
    def stage(self) -> str:
        """How Studio stages this Scene: ``"world"`` or ``"bench"`` (``wtscene.STAGES``)."""
        return wtscene.scene_stage(self._doc.get("stage"))

    @stage.setter
    def stage(self, value: str) -> None:
        self._doc["stage"] = _check_stage(value)

    @property
    def _objects(self) -> Dict[str, Dict[str, Any]]:
        return self._doc["objects"]

    @property
    def _children_order(self) -> Dict[str, List[str]]:
        return self._doc["children_order"]

    # -- objects ------------------------------------------------------------
    @property
    def objects(self) -> Mapping[str, Entity]:
        """Every entity by id, in file order (parents before their children)."""
        return _Objects(self)

    @property
    def roots(self) -> List[Entity]:
        return [self.objects[oid] for oid in self._children_order.get(ROOT, []) if oid in self._objects]

    def find(self, name: str) -> Optional[Entity]:
        """First entity whose display name equals ``name``."""
        for oid, data in self._objects.items():
            if (data.get("name") or oid) == name:
                return Entity(self, oid)
        return None

    def add(
        self,
        name: str,
        *,
        type: Optional[str] = DEFAULT_ENTITY_TYPE,
        id: Optional[str] = None,
        parent: Optional[Entity | str] = None,
        position: Optional[Sequence[float]] = None,
        rotation: Optional[Sequence[float]] = None,
        scale: Optional[Sequence[float]] = None,
    ) -> Entity:
        """Add an entity. The id is a slug of ``name``, made unique in this Scene."""
        parent_id = parent.id if isinstance(parent, Entity) else (parent or ROOT)
        if parent_id != ROOT and parent_id not in self._objects:
            raise KeyError(f"parent not in scene: {parent_id}")
        if id is not None:
            if id in self._objects:
                raise ValueError(f"id already used: {id}")
            entity_id = id
        else:
            entity_id = unique_slug(name, self._objects.keys(), fallback="entity")
        self._objects[entity_id] = {
            "name": name,
            "parent_id": parent_id,
            "is_active": True,
            "tag": None,
            "locked": False,
            "entity_type": type,
            "transform": {},
            "components": [],
        }
        self._children_order.setdefault(parent_id, []).append(entity_id)
        entity = Entity(self, entity_id)
        if position is not None:
            entity.transform.position = position
        if rotation is not None:
            entity.transform.rotation = rotation
        if scale is not None:
            entity.transform.scale = scale
        return entity

    def add_mesh(
        self,
        name: str,
        mesh: Any,
        *,
        material: Union[str, Mapping[str, Any], None] = None,
        fill: Optional[str] = None,
        role: Optional[str] = None,
        anchors: Optional[Sequence[Any]] = None,
        parent: Optional[Entity | str] = None,
        unit: str = "m",
        position: Optional[Sequence[float]] = None,
        rotation: Optional[Sequence[float]] = None,
        scale: Optional[Sequence[float]] = None,
        grid: Any = None,
        max_triangles: Optional[int] = None,
        force: bool = False,
        surface_thickness: Optional[float] = None,
        up: Optional[str] = None,
    ) -> Entity:
        """Add an entity holding a triangle mesh computed in Python.

        ``mesh`` is a ``ws.Body`` or anything ``witwin.studio.geometry.to_mesh``
        accepts: ``(vertices, faces)`` arrays, ``trimesh.Trimesh``,
        ``manifold3d.Manifold``, a build123d or CadQuery shape. A
        ``trimesh.Scene`` becomes a group named ``name`` with one child per
        part. ``unit`` (``m``, ``mm``, ``um``, ``nm``) is the unit of the
        vertices, anchors and ``position``; the file stores meters.
        ``rotation`` is a quaternion ``(x, y, z, w)``, ``scale`` factors.
        ``material`` / ``fill`` / ``role`` / ``anchors`` /
        ``surface_thickness`` override the Body's. ``surface_thickness`` is
        the real thickness of a ``fill="surface"`` sheet in meters, whatever
        ``unit`` is (``GeometryBody.surface_thickness``, for Maxwell's
        ``surface_thickness``); a conductor sheet without it gets the
        ``no_surface_thickness`` warning.

        ``up`` is the frame the vertices and anchors were built in: ``"y"``
        (the Scene frame, Y up) or ``"z"`` (CAD / EM, Z up: build123d
        extrusions, layout stacks). A ``"z"`` mesh is turned once into the
        Scene frame, ``(x, y, z) -> (x, z, -y)``; ``position``, ``rotation``
        and ``scale`` are Scene-frame values and are not turned. None (the
        default) takes the Body's ``up`` and else ``"y"``, so existing calls
        do not change.

        The mesh is checked first (``geometry.validate``; ``grid`` is the
        solver step in meters, ``max_triangles`` defaults to 2,000,000). An
        error raises ``GeometryValidationError`` and adds nothing, unless
        ``force=True``. The returned Entity carries the report as
        ``entity.validation``. The mesh file is written by ``save()``, next to
        the scene file as ``<scene>.binary/gen_<n>.meshbin``.
        """
        return _mesh_entities.add_mesh(self, name, mesh, material=material, fill=fill, role=role,
                                       anchors=anchors, parent=parent, unit=unit, position=position,
                                       rotation=rotation, scale=scale, grid=grid,
                                       max_triangles=max_triangles, force=force,
                                       surface_thickness=surface_thickness, up=up)

    def validate(self, objects: Optional[Sequence[Entity | str]] = None, *, grid: Any = None,
                 max_triangles: Optional[int] = None, domain: Any = None) -> Any:
        """Check the generated meshes of this Scene (all, or ``objects``).

        Returns a ``ValidationReport`` (world space, meters). ``domain`` is
        ``(min_xyz, max_xyz)`` in meters. Primitives and imported models are
        not checked here; the Agent's ``scene.validate`` Tool checks every
        mesh of the open Scene.
        """
        ids = None if objects is None else [getattr(o, "id", o) for o in objects]
        return _mesh_entities.validate_scene(self, ids, grid=grid, max_triangles=max_triangles, domain=domain)

    def remove(self, entity: Entity | str) -> List[str]:
        """Remove an entity and its descendants; returns the removed ids."""
        root_id = entity.id if isinstance(entity, Entity) else entity
        if root_id not in self._objects:
            raise KeyError(root_id)
        removed: List[str] = []

        def visit(oid: str) -> None:
            removed.append(oid)
            for child in list(self._children_order.get(oid, [])):
                visit(child)

        visit(root_id)
        # Also catch children only linked through parent_id (orders can lag).
        changed = True
        while changed:
            changed = False
            for oid, data in self._objects.items():
                if oid not in removed and data.get("parent_id") in removed:
                    removed.append(oid)
                    changed = True
        parent_id = self._objects[root_id].get("parent_id") or ROOT
        siblings = self._children_order.get(parent_id)
        if siblings and root_id in siblings:
            siblings.remove(root_id)
        for oid in removed:
            self._objects.pop(oid, None)
            self._children_order.pop(oid, None)
            self._formulas.remove_entity(oid)
            self.animation.remove(oid)
        return removed

    # -- parameters and formulas --------------------------------------------
    @property
    def parameters(self) -> Parameters:
        """Parameters by name; see ``Parameters``."""
        return Parameters(self)

    @property
    def animation(self) -> "Animation":
        """Keyframe animation, the Timeline clip; see ``Animation``."""
        from ._animation import Animation

        return Animation(self)


    @property
    def formulas(self) -> FormulaGraph:
        """The Scene's Formula Graph: usages, bindings, units, ``compile(backend)``.

        Edits made directly on the graph are written into component values by
        ``recompute()``, which ``save()`` also calls.
        """
        return self._formulas

    def recompute(self) -> List[BindingTarget]:
        """Evaluate pending Formula Graph edits and write changed bound values.

        Each binding's SI value goes into its component property or Transform
        field. Bindings whose entity or component is missing (a Plugin that is
        not installed) are skipped and keep their records. Unlike the
        ProjectServer, the SDK does not know a field's min / max, so it writes
        values without clamping. Returns the targets whose value was written.
        """
        changes = self._formulas.recompute()
        written: List[BindingTarget] = []
        by_field: Dict[Tuple[str, str], List[Tuple[BindingTarget, float]]] = {}
        for target, value in changes:
            by_field.setdefault((target.entity_id, target.target), []).append((target, value))
        for (entity_id, target), values in by_field.items():
            if entity_id not in self._objects:
                continue
            component, _, field = target.partition(".")
            entity = Entity(self, entity_id)
            if component == "Transform":
                done = _write_transform(entity.transform, field, values)
            else:
                done = _write_property(entity.components, component, field, values)
            written.extend(done)
        return written

    # Check a binding target on an entity; returns its graph key and the vector size (None = scalar).
    def _field_key(self, entity_id: str, target: Any, index: Optional[int], *,
                   check_index: bool = True) -> Tuple[BindingTarget, Optional[int]]:
        """Resolve ``target`` the way the ProjectServer's ``bind_field`` does.

        Raises ``FormulaError``: ``not_found`` for a missing component or a
        Transform field other than position / rotation / scale, ``invalid`` for
        a value that is not a number or a list of numbers and for a missing or
        out-of-range ``index``. A component property with no value in the file
        counts as a single number.
        """
        if not isinstance(target, str) or target.count(".") != 1:
            raise FormulaError(ErrorCode.INVALID, "target must be 'Component.field'")
        component, field = target.split(".")
        entity = Entity(self, entity_id)
        if component == "Transform":
            if field not in _TRANSFORM_QUANTITY:
                raise FormulaError(ErrorCode.NOT_FOUND, f"Transform has no bindable field '{field}'")
            size: Optional[int] = 3
        else:
            components = entity.components
            if component not in components:
                raise FormulaError(ErrorCode.NOT_FOUND, f"'{entity.name}' has no {component} component")
            value = components[component].get(field)
            if isinstance(value, (list, tuple)) and value and all(_is_number(v) for v in value):
                size = len(value)
            elif value is None or _is_number(value):
                size = None
            else:
                raise FormulaError(ErrorCode.INVALID, f"{target} is not a number or a vector of numbers, "
                                                      "so it cannot hold a formula")
        if check_index:
            if size is None and index is not None:
                raise FormulaError(ErrorCode.INVALID, f"{target} is a single number; it takes no index")
            if size is not None:
                if isinstance(index, bool) or not isinstance(index, int):
                    raise FormulaError(ErrorCode.INVALID, f"{target} is a vector; index is required")
                if not 0 <= index < size:
                    raise FormulaError(ErrorCode.INVALID,
                                       f"index {index} is out of range for {target} (0..{size - 1})")
        return BindingTarget(entity_id, target, index if size is not None else None), size

    # Refuse binding a field with animation keyframes (plan P3 decision 4).
    def _require_not_animated(self, entity_id: str, target: str) -> None:
        component, _, field = target.partition(".")
        tracks = ((self._doc.get("timeline") or {}).get("clip") or {}).get("tracks") or {}
        for track in tracks.values():
            if (track.get("object_id") == entity_id and track.get("component_name") == component
                    and track.get("field_name") == field and track.get("keyframes")):
                raise FormulaError(ErrorCode.FIELD_ANIMATED,
                                   f"{target} has animation keyframes; remove them before binding a formula")

    def _component_removed(self, entity_id: str, type_name: str) -> None:
        self._formulas.remove_component(entity_id, type_name)
        self.animation._remove_component(entity_id, type_name)

    # Recompute and put the graph's records into the document.
    def _sync(self) -> None:
        self.recompute()
        wtscene.store_formulas(self._doc, self._formulas)

    # -- serialization ------------------------------------------------------
    def to_document(self) -> Dict[str, Any]:
        """A deep copy of the scene document (the ``wtscene.loads`` shape)."""
        import copy

        self._sync()
        return copy.deepcopy(self._doc)

    def dumps(self) -> str:
        """The ``.wtscene`` text; recomputes the Formula Graph first."""
        self._sync()
        return wtscene.dumps(self._doc)

    def save(self, path: Optional[Path | str] = None, *, force: bool = False) -> Path:
        """Write the Scene as ``.wtscene`` (UTF-8, LF), atomically.

        Recomputes the Formula Graph first, so bound fields in the file always
        hold the values their formulas give. Raises SceneConflictError when the target changed on disk since this
        Scene was loaded, or when a new Scene would overwrite an existing
        file. ``force=True`` overwrites anyway.
        """
        target = Path(path) if path is not None else self.path
        if target is None:
            raise ValueError("Scene has no path; pass one to save()")
        if not force and target.exists():
            disk_hash = _hash(target.read_text(encoding="utf-8"))
            if self._loaded_hash is None or target != self.path:
                raise SceneConflictError(f"{target} already exists; pass force=True to overwrite")
            if disk_hash != self._loaded_hash:
                raise SceneConflictError(f"{target} changed on disk since it was loaded")
        text = self.dumps()
        target.parent.mkdir(parents=True, exist_ok=True)
        # Mesh files first: whoever reads the new text must find its meshes.
        referenced = _mesh_entities.flush_binaries(self, target)
        fd, tmp = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
                f.write(text)
            os.replace(tmp, target)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        if self.path is None or target == self.path:
            _mesh_entities.drop_unreferenced(self, target, referenced)
        self.path = target
        self._loaded_hash = _hash(text)
        self._pending_meshes.clear()
        self._known_binary_ids = set(referenced)
        return target

    def __repr__(self) -> str:
        return f"Scene(id={self.id!r}, objects={len(self._objects)}, path={str(self.path) if self.path else None!r})"
