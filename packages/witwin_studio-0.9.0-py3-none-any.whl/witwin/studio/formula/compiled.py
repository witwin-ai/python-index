"""Compiled, backend-agnostic evaluation of a Formula Graph (plan §2.8).

``FormulaGraph.compile(backend)`` resolves names and fixes the topological
order once and returns a ``CompiledFormulas``. Calling it maps free-parameter
values (tensors on a torch backend) to every parameter value and every binding
SI value, so a solver plugin or user script can put the outputs into its own
autograd graph and differentiate a loss with respect to the parameters.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Mapping, Sequence

from .backend import FormulaBackend
from .constants import CONSTANTS
from .errors import ErrorCode, FormulaError
from .parser import Formula

if TYPE_CHECKING:
    from .graph import BindingTarget

# Operations whose derivative is zero almost everywhere (// %) or undefined at
# some points (abs min max). They are allowed; compile() reports where they sit.
NONDIFFERENTIABLE_OPS = frozenset({"//", "%", "abs", "min", "max"})


@dataclass(frozen=True)
class Source:
    """One graph node as compile() receives it from FormulaGraph."""
    key: str | BindingTarget          # parameter name or binding target
    formula: Formula | None
    error: FormulaError | None = None  # static error the graph already knows
    scale: float = 1.0                 # bindings: SI multiplier of the field unit


@dataclass(frozen=True)
class FormulaValues:
    """Output of one ``CompiledFormulas`` call; values are backend values."""
    parameters: dict[str, Any]
    bindings: dict[BindingTarget, Any]  # SI values


@dataclass(frozen=True)
class _Step:
    key: str | BindingTarget
    formula: Formula
    reads: tuple[str, ...]                                  # parameter names
    constants: dict[str, Any] = field(default_factory=dict)  # name -> backend constant
    scale: float = 1.0


class CompiledFormulas:
    """A frozen Formula Graph; call it as ``compiled({"w": w_tensor})``.

    Attributes:
        backend: the backend every call evaluates with.
        inputs: names of parameters a call may override, the free ones, in
            display order. A Study varies some of them.
        errors: nodes left out of the outputs, keyed by parameter name or
            binding target, with the reason (``upstream`` when a dependency was
            left out).
        nondifferentiable_ops: for each (free parameter, binding target) pair
            with such operations on some path between them, the set of
            ``NONDIFFERENTIABLE_OPS`` found; pairs without any are absent.
    """

    # Resolve names and record steps; ``parameters`` must be in topological order.
    def __init__(self, parameters: Sequence[Source], bindings: Sequence[Source],
                 backend: FormulaBackend) -> None:
        self.backend = backend
        self.errors: dict[str | BindingTarget, FormulaError] = {}
        names = {source.key for source in parameters}
        self._params: list[_Step] = []
        self._ready: set[str] = set()  # parameters already stepped, in topological order
        for source in parameters:
            step = self._step(source, names)
            if step is not None:
                self._params.append(step)
                self._ready.add(step.key)
        self._bindings = [step for source in bindings
                          if (step := self._step(source, names)) is not None]
        self.inputs = tuple(step.key for step in self._params if not step.reads)
        self.nondifferentiable_ops = self._find_ops()

    def __call__(self, inputs: Mapping[str, Any] | None = None) -> FormulaValues:
        """Evaluate every parameter and binding, overriding the parameters in ``inputs``.

        Parameters not in ``inputs`` are evaluated from their formulas, so a
        parameter derived from an input carries its gradient. Keys
        must be in ``self.inputs``. With the float backend a numeric failure
        raises ``FormulaError``; tensor backends return NaN instead.
        """
        inputs = inputs or {}
        rejected = tuple(name for name in inputs if name not in self.inputs)
        if rejected:
            raise FormulaError(ErrorCode.INVALID,
                               f"cannot override {', '.join(rejected)}: not a free parameter "
                               "of this compiled graph", names=rejected)
        values: dict[str, Any] = {}
        for step in self._params:
            values[step.key] = inputs[step.key] if step.key in inputs else self._run(step, values)
        bindings = {step.key: self._run(step, values) * step.scale for step in self._bindings}
        return FormulaValues(values, bindings)

    # Evaluate one step against the values computed so far.
    def _run(self, step: _Step, values: Mapping[str, Any]) -> Any:
        scope = dict(step.constants)
        scope.update((name, values[name]) for name in step.reads)
        return step.formula.evaluate(scope, self.backend)

    # Build a step, or record why the node is left out and return None.
    def _step(self, source: Source, names: set[str]) -> _Step | None:
        if source.error is not None or source.formula is None:
            self.errors[source.key] = source.error
            return None
        reads: list[str] = []
        constants: dict[str, Any] = {}
        for ref in source.formula.names:
            if ref.name in names:
                if ref.name in self._ready:
                    reads.append(ref.name)
                    continue
                self.errors[source.key] = FormulaError(
                    ErrorCode.UPSTREAM, f"'{ref.name}' has an error", ref.start, names=(ref.name,))
                return None
            if ref.name not in CONSTANTS:
                self.errors[source.key] = FormulaError(
                    ErrorCode.UNKNOWN_NAME, f"unknown name '{ref.name}'", ref.start,
                    names=(ref.name,))
                return None
            constants[ref.name] = self.backend.constant(CONSTANTS[ref.name].value)
        return _Step(source.key, source.formula, tuple(dict.fromkeys(reads)), constants,
                     source.scale)

    # Non-differentiable operations between each free parameter and each binding.
    def _find_ops(self) -> dict[tuple[str, BindingTarget], frozenset[str]]:
        ops = {s.key: s.formula.ops & NONDIFFERENTIABLE_OPS for s in self._params}
        upstream: dict[str, set[str]] = {}  # parameter -> every parameter it depends on
        for step in self._params:
            upstream[step.key] = set(step.reads).union(*(upstream[r] for r in step.reads))
        found: dict[tuple[str, BindingTarget], frozenset[str]] = {}
        for binding in self._bindings:
            above = set(binding.reads).union(*(upstream[r] for r in binding.reads))
            for name in self.inputs:
                if name not in above:
                    continue
                between = (p for p in above if p != name and name in upstream[p])
                hits = (binding.formula.ops & NONDIFFERENTIABLE_OPS).union(
                    *(ops[p] for p in between))
                if hits:
                    found[(name, binding.key)] = frozenset(hits)
        return found
