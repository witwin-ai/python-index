"""The one error type of the formula package and its stable codes.

Codes travel to the frontend in RPC replies and broadcasts, so they are stable
wire values: add new ones, never rename existing ones.
"""
from __future__ import annotations

from enum import StrEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .graph import Usages


class ErrorCode(StrEnum):
    SYNTAX = "syntax"                    # not a valid expression, or a wrong argument count
    FORBIDDEN = "forbidden"              # valid Python, but outside the formula whitelist
    TOO_LARGE = "too_large"              # source, tree or exponent over the limits in parser.py
    MATH = "math"                        # division by zero, domain error, overflow, NaN
    UNKNOWN_NAME = "unknown_name"        # a name that is neither a parameter nor a constant
    INVALID_NAME = "invalid_name"        # bad or duplicate parameter / constant name
    FORMULA_CYCLE = "formula_cycle"      # the edit would make parameters depend on themselves
    PARAMETER_IN_USE = "parameter_in_use"  # remove without force while something references it
    UPSTREAM = "upstream"                # a referenced parameter has an error
    UNIT = "unit"                        # the injected to_si() rejected the unit key
    NOT_FOUND = "not_found"              # unknown parameter id
    INVALID = "invalid"                  # malformed request, e.g. reorder ids that do not match
    FIELD_ANIMATED = "field_animated"    # bind a field that has animation keyframes
    NOT_FREE = "not_free"                # set a number on a parameter whose formula reads others


class FormulaError(Exception):
    """A rejected edit or a failed evaluation.

    ``offset`` is a character offset into the formula source when the problem
    has a position. ``names`` carries the parameter names involved (the cycle
    for ``formula_cycle``, the bad name for ``unknown_name`` / ``upstream``).
    ``usages`` is set only for ``parameter_in_use``.
    """

    # Builds the error; message is plain English for display.
    def __init__(
        self,
        code: ErrorCode,
        message: str,
        offset: int | None = None,
        *,
        names: tuple[str, ...] = (),
        usages: Usages | None = None,
    ) -> None:
        super().__init__(message)
        self.code = ErrorCode(code)
        self.message = message
        self.offset = offset
        self.names = tuple(names)
        self.usages = usages

    # JSON-ready form for RPC replies; usages are left to the caller, which knows entity names.
    def to_dict(self) -> dict[str, Any]:
        return {"code": str(self.code), "message": self.message,
                "offset": self.offset, "names": list(self.names)}

    # Two errors match when code, text and position match; used to detect state changes.
    def same_as(self, other: FormulaError | None) -> bool:
        return other is not None and (self.code, self.message, self.offset) == (
            other.code, other.message, other.offset)

    # Debug representation with the code first.
    def __repr__(self) -> str:
        return f"FormulaError({str(self.code)!r}, {self.message!r}, offset={self.offset})"
