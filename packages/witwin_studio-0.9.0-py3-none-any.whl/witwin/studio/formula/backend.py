"""Numeric backends for formula evaluation (plan §2.8).

The evaluator applies ``+ - * / // %`` and unary ``+ -`` with plain Python
operators, which work on floats and on tensors alike. Everything that differs
between number types goes through a ``FormulaBackend``: the function table,
how literals become values, ``**``, and the numeric check after each step.

``FLOAT_BACKEND`` is the editor's backend: ``recompute()`` uses it, and it
turns NaN, complex results and huge exponents into ``FormulaError``. Tensor
backends (``torch_backend.TorchBackend``) skip those checks, because raising
in the middle of an autograd graph helps nobody; the optimiser sees NaN instead.
"""
from __future__ import annotations

import math
from types import MappingProxyType
from typing import Any, Callable, Mapping, Protocol

from .constants import FUNCTIONS
from .errors import ErrorCode, FormulaError

MAX_EXPONENT = 1e4   # |b| in a ** b for the float backend; also checked on literals at parse time


class FormulaBackend(Protocol):
    """What the evaluator needs from a number type."""

    functions: Mapping[str, Callable[..., Any]]  # every name in constants.FUNCTIONS

    # Turn a float literal or constant into a backend value.
    def constant(self, value: float) -> Any: ...

    # Validate the result of one step; return it (possibly converted) or raise FormulaError.
    def check(self, value: Any, what: str, offset: int) -> Any: ...

    # ``base ** exponent``; separate because float ``**`` returns complex numbers.
    def power(self, base: Any, exponent: Any, offset: int) -> Any: ...


class FloatBackend:
    """Python float evaluation with strict checks."""

    functions: Mapping[str, Callable[..., Any]] = MappingProxyType(
        {name: f.fn for name, f in FUNCTIONS.items()})

    # Floats are their own backend values.
    def constant(self, value: float) -> float:
        return value

    # Results are always float; NaN never escapes, it would poison every downstream value.
    def check(self, value: Any, what: str, offset: int) -> float:
        if type(value) is complex:
            raise FormulaError(ErrorCode.MATH, f"'{what}': result is a complex number", offset)
        value = float(value)
        if math.isnan(value):
            raise FormulaError(ErrorCode.MATH, f"'{what}': result is not a number", offset)
        return value

    # math.pow raises for a negative base with a fractional exponent instead of going complex.
    def power(self, base: float, exponent: float, offset: int) -> float:
        if abs(exponent) > MAX_EXPONENT:
            raise FormulaError(ErrorCode.TOO_LARGE,
                               f"exponent is larger than {MAX_EXPONENT:g}", offset)
        return math.pow(base, exponent)


FLOAT_BACKEND = FloatBackend()
