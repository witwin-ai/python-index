"""Built-in formula constants and functions, and the plugin constant registry.

Constants are SI values: ``c`` is metres per second, because Studio stores
lengths in metres (plan §2.1). Functions use the numpy-style names users know
from solver scripts (``arcsin``, not ``asin``).

``register_formula_constant`` is a public plugin extension point (plan §2.6):
once plugins depend on it, it must not be removed or change meaning.
"""
from __future__ import annotations

import keyword
import math
import unicodedata
from dataclasses import dataclass
from types import MappingProxyType
from typing import Callable, Mapping

from .errors import ErrorCode, FormulaError


@dataclass(frozen=True)
class Constant:
    name: str
    value: float
    description: str = ""
    builtin: bool = False


@dataclass(frozen=True)
class Function:
    name: str
    fn: Callable[..., float]
    min_args: int
    max_args: int | None  # None: any number of arguments (min / max)
    description: str = ""


# min / max take positional floats, not an iterable, so wrap the builtins.
def _min(*args: float) -> float:
    return min(args)


# See _min.
def _max(*args: float) -> float:
    return max(args)


FUNCTIONS: Mapping[str, Function] = MappingProxyType({f.name: f for f in (
    Function("abs", abs, 1, 1, "Absolute value"),
    Function("log", math.log, 1, 1, "Natural logarithm"),
    Function("log10", math.log10, 1, 1, "Base-10 logarithm"),
    Function("exp", math.exp, 1, 1, "e raised to the power x"),
    Function("sqrt", math.sqrt, 1, 1, "Square root"),
    Function("sin", math.sin, 1, 1, "Sine, x in radians"),
    Function("cos", math.cos, 1, 1, "Cosine, x in radians"),
    Function("tan", math.tan, 1, 1, "Tangent, x in radians"),
    Function("arcsin", math.asin, 1, 1, "Inverse sine, result in radians"),
    Function("arccos", math.acos, 1, 1, "Inverse cosine, result in radians"),
    Function("arctan", math.atan, 1, 1, "Inverse tangent, result in radians"),
    Function("min", _min, 1, None, "Smallest argument"),
    Function("max", _max, 1, None, "Largest argument"),
)})

BUILTINS: tuple[Constant, ...] = (
    Constant("c", 299792458.0, "Speed of light in vacuum, m/s", builtin=True),
    Constant("pi", math.pi, "Ratio of a circle's circumference to its diameter", builtin=True),
    Constant("inf", math.inf, "Infinity", builtin=True),
)

_registry: dict[str, Constant] = {c.name: c for c in BUILTINS}

# Live read-only view; FormulaGraph resolves names against it at evaluation time.
CONSTANTS: Mapping[str, Constant] = MappingProxyType(_registry)


# Raise invalid_name unless ``name`` can appear as a bare name in a formula.
def check_identifier(name: str) -> None:
    if not name.isidentifier() or keyword.iskeyword(name):
        raise FormulaError(ErrorCode.INVALID_NAME, f"'{name}' is not a valid name",
                           names=(name,))
    # Python NFKC-normalises identifiers while parsing, so a name that changes
    # under NFKC could never be matched against the parsed formula.
    if unicodedata.normalize("NFKC", name) != name:
        raise FormulaError(ErrorCode.INVALID_NAME,
                           f"'{name}' is not in normalised (NFKC) form", names=(name,))
    if name in FUNCTIONS:
        raise FormulaError(ErrorCode.INVALID_NAME, f"'{name}' is a function name",
                           names=(name,))


def register_formula_constant(name: str, value: float, description: str = "") -> Constant:
    """Add a constant that every formula can use, for example ``eps0``.

    Registering a name again replaces the earlier plugin constant, so a plugin
    can reload. Built-in constants and function names cannot be replaced.
    A parameter with the same name shadows the constant in its scene.
    """
    check_identifier(name)
    existing = _registry.get(name)
    if existing is not None and existing.builtin:
        raise FormulaError(ErrorCode.INVALID_NAME, f"'{name}' is a built-in constant",
                           names=(name,))
    value = float(value)
    if math.isnan(value):
        raise FormulaError(ErrorCode.MATH, f"constant '{name}' is not a number", names=(name,))
    constant = Constant(name, value, description)
    _registry[name] = constant
    return constant


def unregister_formula_constant(name: str) -> None:
    """Remove a plugin constant, for plugin unload. Unknown names are ignored."""
    existing = _registry.get(name)
    if existing is not None and existing.builtin:
        raise FormulaError(ErrorCode.INVALID_NAME, f"'{name}' is a built-in constant",
                           names=(name,))
    _registry.pop(name, None)
