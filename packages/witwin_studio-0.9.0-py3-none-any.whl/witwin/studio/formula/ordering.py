"""Graph ordering helpers for FormulaGraph: topological order and cycle paths.

Both are iterative, so a chain of thousands of parameters cannot hit Python's
recursion limit.
"""
from __future__ import annotations

from collections import deque
from typing import Callable, Iterable, Mapping


# Kahn's algorithm over ``nodes``; nodes on or behind a cycle are left out.
def kahn(nodes: list[str], deps: Mapping[str, set[str]]) -> list[str]:
    indegree = {n: len(deps[n]) for n in nodes}
    users: dict[str, list[str]] = {n: [] for n in nodes}
    for n in nodes:
        for d in deps[n]:
            users[d].append(n)
    ready = deque(n for n in nodes if indegree[n] == 0)
    order: list[str] = []
    while ready:
        n = ready.popleft()
        order.append(n)
        for user in users[n]:
            indegree[user] -= 1
            if indegree[user] == 0:
                ready.append(user)
    return order


# Path ``start -> ... -> start`` along ``deps`` if one exists. Iterative, so long chains are safe.
def find_cycle(start: str, deps: Callable[[str], Iterable[str]]) -> list[str] | None:
    path = [start]
    stack = [iter(deps(start))]
    seen = {start}
    while stack:
        nxt = next(stack[-1], None)
        if nxt is None:
            stack.pop()
            path.pop()
        elif nxt == start:
            return path + [start]
        elif nxt not in seen:
            seen.add(nxt)
            path.append(nxt)
            stack.append(iter(deps(nxt)))
    return None
