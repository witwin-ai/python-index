"""The Formula Graph of one Scene: parameters, constants and field bindings (plan §2.2).

Nodes:

- Constants come from ``constants.CONSTANTS``; read-only, never saved.
- Parameters ``{id, name, expr, description}`` keep the user's order.
- Bindings tie one field component, ``BindingTarget(entity_id, "Comp.field",
  index)``, to a formula. Nothing can reference a binding, so bindings are
  always leaves.

An edge runs from a name to every formula that reads it. A name resolves to a
parameter first, then to a constant.

Rules this class keeps:

- Edits (``add_parameter``, ``update_parameter``, ``bind`` ...) validate first
  and raise ``FormulaError`` without changing anything. An accepted edit never
  creates a cycle. Data loaded with ``from_records`` may contain one (a
  hand-edited file); it loads and its members get ``formula_cycle`` errors.
- Edits only mark nodes dirty. ``recompute()`` evaluates the dirty nodes and,
  in topological order, only the nodes downstream of a node whose value or
  error changed. It returns the bindings whose SI value changed; the caller
  writes those numbers into the Scene (plan §3.3).
- A node that fails keeps its last good value and exposes the error through
  ``error()``. Nodes that read it get an ``upstream`` error and also keep their
  values; the rest of the graph is unaffected.
- Units: each field (entity + target) has one display unit key, shared by all
  vector components. A binding's formula result is a number in that unit;
  ``to_si(value, unit_key)``, injected in the constructor, converts it to the
  SI number stored in the component. The default is the identity, so the graph
  has no unit table of its own. Units without a binding are kept too: the graph
  owns all field side-metadata of the Scene.
- ``remove_parameter(force=True)`` unbinds every binding that reads the
  parameter (the field keeps its current number) and rewrites every parameter
  that reads it to the literal of its last good value. A reader without a good
  value keeps its formula and gets ``unknown_name``.
- ``compile(backend)`` (plan §2.8) freezes the graph into a reusable mapping
  from free-parameter values to binding SI values on a tensor backend; the
  editor path stays float-only. A parameter is free when its formula reads no
  other parameter (``2.5``, ``2 * pi``). Which free parameters a run varies,
  and in what range, is up to the Study that runs it (``witwin.studio.studies``);
  the graph keeps no design-variable state.
"""
from __future__ import annotations

import math
import secrets
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping, NamedTuple, Sequence

from .backend import FormulaBackend
from .compiled import CompiledFormulas, Source
from .constants import CONSTANTS, FUNCTIONS, Constant, check_identifier
from .errors import ErrorCode, FormulaError
from .ordering import find_cycle, kahn
from .parser import Formula, parse

# Lowercase Crockford base32, as in dev_docs/ID_DESIGN.md tier 2 ids.
_ID_ALPHABET = "0123456789abcdefghjkmnpqrstvwxyz"
PARAMETER_ID_PREFIX = "prm_"

ToSI = Callable[[float, str | None], float]


class BindingTarget(NamedTuple):
    entity_id: str
    target: str               # "Component.field"; Transform uses "Transform.position" etc.
    index: int | None = None  # vector component, None for a scalar field


@dataclass(frozen=True)
class Usages:
    """What reads a parameter."""
    bindings: tuple[BindingTarget, ...] = ()
    parameters: tuple[str, ...] = ()  # parameter ids

    # True when anything reads the parameter.
    def __bool__(self) -> bool:
        return bool(self.bindings or self.parameters)


@dataclass(frozen=True)
class ParameterInfo:
    id: str
    name: str
    expr: str
    description: str
    value: float | None        # last good value; None before the first good evaluation
    error: FormulaError | None
    free: bool = False         # reads no other parameter, so a Study may vary it


@dataclass(frozen=True)
class BindingInfo:
    target: BindingTarget
    expr: str
    unit: str | None
    value: float | None        # formula result, in ``unit``
    si_value: float | None     # the number the component stores
    error: FormulaError | None


@dataclass(frozen=True)
class Preview:
    """Result of ``evaluate_preview`` for the Equation Editor."""
    value: float | None
    si_value: float | None
    error: FormulaError | None
    references: tuple[str, ...]  # distinct names in source order


@dataclass(frozen=True)
class Records:
    """Disk form, plan §3.1: ``[[parameter]]`` rows and per-entity ``fields`` lists."""
    parameters: list[dict[str, Any]]
    fields: dict[str, list[dict[str, Any]]]  # entity id -> entries


@dataclass(eq=False)
class _Node:
    expr: str
    formula: Formula | None
    fault: FormulaError | None = None  # static problem found when expr / name was set
    value: float | None = None
    si_value: float | None = None      # bindings only
    error: FormulaError | None = None
    name: str = ""                     # parameters only
    description: str = ""              # parameters only
    named: bool = True                 # False: invalid or duplicate name, cannot be referenced

    # The names the formula reads.
    @property
    def refs(self) -> frozenset[str]:
        return self.formula.refs if self.formula is not None else frozenset()


# Parse leniently for loading: a broken formula becomes a node fault, not an exception.
def _loaded_node(expr: str) -> _Node:
    try:
        return _Node(expr, parse(expr))
    except FormulaError as exc:
        return _Node(expr, None, fault=exc)


# Identity unit conversion, used until a unit table is injected.
def _identity(value: float, unit: str | None) -> float:
    return value


class FormulaGraph:
    """Parameters, constants and field bindings of one Scene. See the module docstring."""

    # ``to_si(value, unit_key)`` converts a binding result to SI; it may raise KeyError / ValueError.
    def __init__(self, to_si: ToSI | None = None) -> None:
        self._to_si = to_si or _identity
        self._params: dict[str, _Node] = {}              # id -> node, in display order
        self._bindings: dict[BindingTarget, _Node] = {}
        self._units: dict[tuple[str, str], str] = {}     # (entity id, target) -> unit key
        self._sizes: dict[tuple[str, str], int] = {}     # vector length last loaded
        self._readers: dict[str, set] = {}               # name -> node keys reading it
        self._dirty: set = set()                         # node keys and changed names

    # ------------------------------------------------------------------ queries

    def parameters(self) -> list[ParameterInfo]:
        """All parameters in display order."""
        return [self._info(pid) for pid in self._params]

    def parameter(self, param_id: str) -> ParameterInfo:
        """One parameter; raises ``not_found``."""
        self._param(param_id)
        return self._info(param_id)

    def constants(self) -> list[Constant]:
        """The constants formulas can use (built-in and plugin)."""
        return list(CONSTANTS.values())

    def value(self, param_id: str) -> float | None:
        """Last good value of a parameter."""
        return self._param(param_id).value

    def error(self, node: str | BindingTarget) -> FormulaError | None:
        """Current error of a parameter (by id) or binding; None when it evaluated cleanly."""
        found = self._params.get(node) if type(node) is str else self._bindings.get(node)
        if found is None:
            raise FormulaError(ErrorCode.NOT_FOUND, f"no formula node {node!r}")
        return found.error

    def usages(self, param_id: str) -> Usages:
        """Bindings and parameters whose formula reads this parameter."""
        node = self._param(param_id)
        if not node.named:  # a loaded duplicate: readers of the name belong to the original
            return Usages()
        readers = self._readers.get(node.name, set())
        return Usages(
            bindings=tuple(t for t in self._bindings if t in readers),
            parameters=tuple(pid for pid in self._params if pid in readers and pid != param_id),
        )

    def bindings(self) -> list[BindingInfo]:
        """Every binding of the Scene, in binding order."""
        return [self._binding_info(t) for t in self._bindings]

    def bindings_for(self, entity_id: str) -> list[BindingInfo]:
        """Bindings of one entity, in binding order."""
        return [self._binding_info(t) for t in self._bindings if t.entity_id == entity_id]

    def unit(self, entity_id: str, target: str) -> str | None:
        """Display unit key of a field; None means SI."""
        return self._units.get((entity_id, target))

    def evaluate_preview(self, expr: str, unit: str | None = None,
                         exclude_param_id: str | None = None) -> Preview:
        """Evaluate ``expr`` against current values without changing the graph.

        With ``exclude_param_id``, also report the cycle that setting that
        parameter's formula to ``expr`` would create.
        """
        try:
            formula = parse(expr)
        except FormulaError as exc:
            return Preview(None, None, exc, ())
        references = tuple(dict.fromkeys(ref.name for ref in formula.names))
        try:
            if exclude_param_id is not None:
                self._check_formula(exclude_param_id, self._param(exclude_param_id).name, formula)
        except FormulaError as exc:
            return Preview(None, None, exc, references)
        value, error = self._evaluate(_Node(expr, formula), self._name_ids())
        if error is not None:
            return Preview(None, None, error, references)
        try:
            return Preview(value, self._convert(value, unit), None, references)
        except FormulaError as exc:
            return Preview(value, None, exc, references)

    # ------------------------------------------------------------- parameters

    def add_parameter(self, name: str | None, expr: str, description: str = "", *,
                      index: int | None = None, param_id: str | None = None) -> str:
        """Add a parameter and return its id; ``name=None`` picks ``var_1``, ``var_2`` ..."""
        if param_id is not None and param_id in self._params:
            raise FormulaError(ErrorCode.INVALID, f"parameter id '{param_id}' already exists")
        name = self._free_name() if name is None else name
        formula = parse(expr)
        pid = param_id or self._new_id()
        self._check_parameter(pid, name, formula)
        node = _Node(expr, formula, name=name, description=description)
        items = list(self._params.items())
        items.insert(len(items) if index is None else index, (pid, node))
        self._params = dict(items)
        self._attach(pid, node)
        self._dirty.update((pid, name))
        return pid

    def update_parameter(self, param_id: str, *, name: str | None = None,
                         expr: str | None = None, description: str | None = None) -> None:
        """Change a parameter. A rename rewrites every formula that reads the old name.

        ``None`` leaves a field as it is.
        """
        node = self._param(param_id)
        new_name = node.name if name is None else name
        formula = node.formula if expr is None else parse(expr)
        renamed = new_name != node.name or (name is not None and not node.named)
        if renamed or expr is not None:
            self._check_parameter(param_id, new_name, formula)
        if description is not None:
            node.description = description
        if expr is not None:
            self._detach(param_id, node)
            node.expr, node.formula, node.fault = expr, formula, None
            self._attach(param_id, node)
            self._dirty.add(param_id)
        if renamed:
            old, was_named = node.name, node.named
            node.name, node.named = new_name, True
            # A loaded duplicate never owned its old name: its readers belong to the original.
            for key in list(self._readers.get(old, ())) if was_named else ():
                if key != param_id:
                    self._rewrite(key, old, new_name)
            # The fault may have been the bad name; keep only an expression fault.
            node.fault = None if node.formula is not None else _loaded_node(node.expr).fault
            self._dirty.update((param_id, old, new_name))

    def remove_parameter(self, param_id: str, force: bool = False) -> Usages:
        """Remove a parameter and return what read it.

        Raises ``parameter_in_use`` with ``usages`` unless ``force``. With
        ``force`` the readers are unbound or frozen (module docstring).
        """
        usages = self.usages(param_id)
        node = self._params[param_id]
        if usages and not force:
            raise FormulaError(ErrorCode.PARAMETER_IN_USE,
                               f"'{node.name}' is used by {_count_text(usages)}",
                               names=(node.name,), usages=usages)
        for target in usages.bindings:
            self.unbind(target)
        for reader_id in usages.parameters:
            reader = self._params[reader_id]
            if reader.value is not None:
                self._set_expr(reader_id, reader, repr(reader.value))
        self._detach(param_id, node)
        del self._params[param_id]
        self._dirty.add(node.name)
        return usages

    def reorder(self, param_ids: Sequence[str]) -> None:
        """Set the display order; ``param_ids`` must list every parameter exactly once."""
        if sorted(param_ids) != sorted(self._params):
            raise FormulaError(ErrorCode.INVALID, "reorder must list every parameter once")
        self._params = {pid: self._params[pid] for pid in param_ids}

    # --------------------------------------------------------------- bindings

    def bind(self, target: BindingTarget, expr: str, unit: str | None) -> None:
        """Bind one field component to ``expr``; ``unit`` becomes the field's display unit."""
        formula = parse(expr)
        ids = self._name_ids()
        for ref in formula.names:
            if ref.name not in ids and ref.name not in CONSTANTS:
                raise FormulaError(ErrorCode.UNKNOWN_NAME, f"unknown name '{ref.name}'",
                                   ref.start, names=(ref.name,))
        self.unbind(target)
        node = _Node(expr, formula)
        self._bindings[target] = node
        self._attach(target, node)
        self._dirty.add(target)
        self.set_unit(target.entity_id, target.target, unit)

    def unbind(self, target: BindingTarget) -> None:
        """Remove a binding; the field keeps its number. Unbound targets are ignored."""
        node = self._bindings.pop(target, None)
        if node is not None:
            self._detach(target, node)

    def set_unit(self, entity_id: str, target: str, unit: str | None) -> None:
        """Set a field's display unit; bound components are re-evaluated in the new unit."""
        key = (entity_id, target)
        if self._units.get(key) == unit:
            return
        if unit is None:
            self._units.pop(key, None)
        else:
            self._units[key] = unit
        self._dirty.update(t for t in self._bindings if (t.entity_id, t.target) == key)

    def remove_entity(self, entity_id: str) -> None:
        """Drop all side-metadata of an entity."""
        self._drop_fields(lambda eid, target: eid == entity_id)

    def remove_component(self, entity_id: str, component: str) -> None:
        """Drop side-metadata of one component's fields (``Component.*``)."""
        prefix = component + "."
        self._drop_fields(lambda eid, target: eid == entity_id and target.startswith(prefix))

    # -------------------------------------------------------------- recompute

    def recompute(self, changed: Iterable[str | BindingTarget] = ()) -> list[tuple[BindingTarget, float]]:
        """Evaluate dirty nodes and their downstream; return bindings whose SI value changed.

        Edits made through this class are tracked automatically. ``changed``
        adds extra seeds: parameter ids, binding targets, or constant names
        (for example after a plugin re-registers a constant).
        """
        seeds = self._dirty | set(changed)
        self._dirty = set()
        ids = self._name_ids()
        changed_names = {s for s in seeds if type(s) is str and s not in self._params}
        order, cycles = self._order(ids)
        for pid in order:
            node = self._params[pid]
            if pid not in seeds and not node.refs & changed_names:
                continue
            before = (node.value, node.error)
            if pid in cycles:
                node.error = self._cycle_error(cycles[pid])
            else:
                self._apply(node, *self._evaluate(node, ids))
            if _state_changed(before, node) and node.named:
                changed_names.add(node.name)
        return self._recompute_bindings(seeds, changed_names, ids)

    def compile(self, backend: FormulaBackend) -> CompiledFormulas:
        """Freeze the graph into a reusable, differentiable evaluator (plan §2.8).

        The result maps ``{parameter name: value}`` overrides to parameter
        values and binding SI values on ``backend``; see ``CompiledFormulas``.
        It is a snapshot: later edits do not change it. Unit conversion is
        taken as a multiplier, ``to_si(1.0, unit)``, so it must be linear.
        Nodes with static errors (syntax, unknown names, cycles, bad units) are
        left out and listed in ``CompiledFormulas.errors``.
        """
        ids = self._name_ids()
        order, cycles = self._order(ids)
        params = []
        for pid in order:
            node = self._params[pid]
            if node.named:  # a loaded duplicate name cannot be addressed by name
                error = self._cycle_error(cycles[pid]) if pid in cycles else node.fault
                params.append(Source(node.name, node.formula, error))
        bindings = []
        for target, node in self._bindings.items():
            try:
                scale, error = self._convert(1.0, self.unit(target.entity_id, target.target)), None
            except FormulaError as exc:
                scale, error = 1.0, exc
            bindings.append(Source(target, node.formula, node.fault or error, scale=scale))
        return CompiledFormulas(params, bindings, backend)

    # ---------------------------------------------------------------- records

    def to_records(self) -> Records:
        """Disk form of parameters and field side-metadata."""
        parameters = [_parameter_record(pid, n) for pid, n in self._params.items()]
        entries: dict[str, dict[str, dict[str, Any]]] = {}
        for (eid, target), unit in self._units.items():
            entries.setdefault(eid, {}).setdefault(target, {"target": target})["unit"] = unit
        for t, node in self._bindings.items():
            entry = entries.setdefault(t.entity_id, {}).setdefault(t.target, {"target": t.target})
            if t.index is None:
                entry["expr"] = node.expr
                continue
            size = max(self._sizes.get((t.entity_id, t.target), 0), t.index + 1)
            exprs = entry["expr"] if type(entry.get("expr")) is list else [""] * size
            exprs.extend([""] * (size - len(exprs)))
            exprs[t.index] = node.expr
            entry["expr"] = exprs
        fields = {eid: list(by_target.values()) for eid, by_target in entries.items()}
        return Records(parameters, fields)

    @classmethod
    def from_records(cls, parameters: Iterable[Mapping[str, Any]],
                     fields: Mapping[str, Iterable[Mapping[str, Any]]], *,
                     to_si: ToSI | None = None) -> FormulaGraph:
        """Load the disk form. Call ``recompute()`` afterwards to evaluate.

        Formula problems (syntax, bad or duplicate names, cycles) load and show
        up as node errors. Malformed records (a field entry without a string
        ``target``) raise ``invalid``.
        """
        graph = cls(to_si)
        for record in parameters:
            graph._load_parameter(record)
        for entity_id, entries in fields.items():
            graph.load_fields(entity_id, entries)
        graph._dirty.update(graph._params)
        return graph

    def load_fields(self, entity_id: str, entries: Iterable[Mapping[str, Any]]) -> None:
        """Replace an entity's side-metadata with ``fields`` entries (lenient, like from_records).

        Also serves entity duplication: feed it another entity's entries from ``to_records``.
        """
        self.remove_entity(entity_id)
        for entry in entries:
            target = entry.get("target")
            if type(target) is not str:
                raise FormulaError(ErrorCode.INVALID, f"field entry without target: {entry!r}")
            if entry.get("unit") is not None:
                self._units[(entity_id, target)] = str(entry["unit"])
            expr = entry.get("expr")
            if type(expr) is str:
                exprs: list[tuple[int | None, str]] = [(None, expr)]
            elif expr is None:
                exprs = []
            else:
                self._sizes[(entity_id, target)] = len(expr)
                exprs = list(enumerate(expr))
            for index, text in exprs:
                if text:
                    key = BindingTarget(entity_id, target, index)
                    node = _loaded_node(str(text))
                    self._bindings[key] = node
                    self._attach(key, node)
                    self._dirty.add(key)

    # --------------------------------------------------------------- internals

    # Parameter node by id, or not_found.
    def _param(self, param_id: str) -> _Node:
        node = self._params.get(param_id)
        if node is None:
            raise FormulaError(ErrorCode.NOT_FOUND, f"no parameter with id '{param_id}'")
        return node

    # Public snapshot of a parameter.
    def _info(self, pid: str) -> ParameterInfo:
        n = self._params[pid]
        return ParameterInfo(pid, n.name, n.expr, n.description, n.value, n.error,
                             self._is_free(n.formula))

    # True when ``formula`` parses and reads only constants (no parameter shadows them).
    def _is_free(self, formula: Formula | None) -> bool:
        if formula is None:
            return False
        ids = self._name_ids()
        return all(r in CONSTANTS and r not in ids for r in formula.refs)

    # formula_cycle error for a cycle path of parameter ids.
    def _cycle_error(self, path: list[str]) -> FormulaError:
        names = tuple(self._params[p].name for p in path)
        return FormulaError(ErrorCode.FORMULA_CYCLE, f"formula cycle: {' -> '.join(names)}",
                            names=names)

    # Public snapshot of a binding.
    def _binding_info(self, t: BindingTarget) -> BindingInfo:
        n = self._bindings[t]
        return BindingInfo(t, n.expr, self.unit(t.entity_id, t.target), n.value, n.si_value, n.error)

    # Name -> parameter id for every referenceable parameter.
    def _name_ids(self) -> dict[str, str]:
        return {n.name: pid for pid, n in self._params.items() if n.named}

    # Register ``key`` as a reader of every name its formula uses.
    def _attach(self, key: Any, node: _Node) -> None:
        for name in node.refs:
            self._readers.setdefault(name, set()).add(key)

    # Undo _attach.
    def _detach(self, key: Any, node: _Node) -> None:
        for name in node.refs:
            readers = self._readers.get(name)
            if readers is not None:
                readers.discard(key)
                if not readers:
                    del self._readers[name]

    # Replace a node's formula without validation (callers already know it is safe).
    def _set_expr(self, key: Any, node: _Node, expr: str) -> None:
        self._detach(key, node)
        node.expr, node.formula, node.fault = expr, parse(expr), None
        self._attach(key, node)
        self._dirty.add(key)

    # Rename ``old`` to ``new`` inside the formula of parameter / binding ``key``.
    def _rewrite(self, key: Any, old: str, new: str) -> None:
        node = self._params[key] if type(key) is str else self._bindings[key]
        self._set_expr(key, node, node.formula.rename(old, new))

    # Validate a parameter's would-be name and formula; raise without mutating.
    def _check_parameter(self, pid: str, name: str, formula: Formula | None) -> None:
        check_identifier(name)
        if name in CONSTANTS:
            raise FormulaError(ErrorCode.INVALID_NAME, f"'{name}' is a constant", names=(name,))
        if self._name_ids().get(name, pid) != pid:
            raise FormulaError(ErrorCode.INVALID_NAME, f"a parameter named '{name}' already exists",
                               names=(name,))
        self._check_formula(pid, name, formula)

    # Raise unknown_name / formula_cycle if parameter ``pid`` named ``name`` had ``formula``.
    def _check_formula(self, pid: str, name: str, formula: Formula | None) -> None:
        ids = self._name_ids()
        current = self._params.get(pid)
        old = current.name if current is not None and current.named else None
        if old is not None:
            del ids[old]
        ids[name] = pid
        names = formula.names if formula is not None else ()
        for ref in names:
            if ref.name not in ids and ref.name not in CONSTANTS:
                raise FormulaError(ErrorCode.UNKNOWN_NAME, f"unknown name '{ref.name}'",
                                   ref.start, names=(ref.name,))

        # Dependencies in the would-be graph: the edited node reads ``formula``,
        # and after a rename every reader of the old name reads the new one.
        def deps(node_id: str) -> list[str]:
            if node_id == pid:
                refs = formula.refs if formula is not None else frozenset()
            else:
                refs = self._params[node_id].refs
                if old is not None and old != name:
                    refs = {name if r == old else r for r in refs}
            return [ids[r] for r in refs if r in ids]

        path = find_cycle(pid, deps)
        if path is not None:
            names = tuple(name if p == pid else self._params[p].name for p in path)
            raise FormulaError(ErrorCode.FORMULA_CYCLE, f"formula cycle: {' -> '.join(names)}",
                               names=names)

    # Topological order of all parameters, cycle members and their downstream last.
    def _order(self, ids: dict[str, str]) -> tuple[list[str], dict[str, list[str]]]:
        deps = {pid: {ids[r] for r in n.refs if r in ids} for pid, n in self._params.items()}
        order = kahn(list(self._params), deps)
        if len(order) == len(deps):
            return order, {}
        placed = set(order)
        rest = [pid for pid in self._params if pid not in placed]
        rest_set = set(rest)
        cycles: dict[str, list[str]] = {}
        for pid in rest:
            path = find_cycle(pid, lambda p: deps[p] & rest_set)
            if path is not None:
                cycles[pid] = path
        # Nodes that only read a cycle: order them among themselves after it.
        downstream = [pid for pid in rest if pid not in cycles]
        tail = kahn(downstream, {pid: deps[pid] - set(cycles) for pid in downstream})
        return order + list(cycles) + tail, cycles

    # Evaluate one node against current parameter values: (value, error).
    def _evaluate(self, node: _Node, ids: dict[str, str]) -> tuple[float | None, FormulaError | None]:
        if node.fault is not None:
            return None, node.fault
        scope: dict[str, float] = {}
        for ref in node.formula.names:
            pid = ids.get(ref.name)
            if pid is not None:
                source = self._params[pid]
                if source.error is not None or source.value is None:
                    return None, FormulaError(ErrorCode.UPSTREAM, f"'{ref.name}' has an error",
                                              ref.start, names=(ref.name,))
                scope[ref.name] = source.value
            elif ref.name in CONSTANTS:
                scope[ref.name] = CONSTANTS[ref.name].value
            else:
                return None, FormulaError(ErrorCode.UNKNOWN_NAME, f"unknown name '{ref.name}'",
                                          ref.start, names=(ref.name,))
        try:
            return node.formula.evaluate(scope), None
        except FormulaError as exc:
            return None, exc

    # Store an evaluation result; an error keeps the last good value.
    @staticmethod
    def _apply(node: _Node, value: float | None, error: FormulaError | None) -> None:
        node.error = error
        if error is None:
            node.value = value

    # Convert a binding result to SI through the injected to_si.
    def _convert(self, value: float, unit: str | None) -> float:
        try:
            si = float(self._to_si(value, unit))
        except (KeyError, ValueError) as exc:
            raise FormulaError(ErrorCode.UNIT, f"unknown unit '{unit}': {exc}") from None
        if math.isnan(si):
            raise FormulaError(ErrorCode.MATH, "unit conversion gave a non-number")
        return si

    # Evaluate the bindings reached by this recompute; return the changed SI values.
    def _recompute_bindings(self, seeds: set, changed_names: set[str],
                            ids: dict[str, str]) -> list[tuple[BindingTarget, float]]:
        todo = {s for s in seeds if type(s) is not str}
        for name in changed_names:
            todo.update(k for k in self._readers.get(name, ()) if type(k) is not str)
        changes: list[tuple[BindingTarget, float]] = []
        for target, node in self._bindings.items():
            if target not in todo:
                continue
            value, error = self._evaluate(node, ids)
            si = None
            if error is None:
                try:
                    si = self._convert(value, self.unit(target.entity_id, target.target))
                except FormulaError as exc:
                    error = exc
            self._apply(node, value, error)
            if si is not None and si != node.si_value:
                node.si_value = si
                changes.append((target, si))
        return changes

    # Load one [[parameter]] row; bad names and formulas become node faults.
    def _load_parameter(self, record: Mapping[str, Any]) -> None:
        pid = record.get("id")
        if type(pid) is not str or not pid or pid in self._params:
            pid = self._new_id()
        node = _loaded_node(str(record.get("expr", "")))
        node.name = str(record.get("name", ""))
        node.description = str(record.get("description", ""))
        try:
            check_identifier(node.name)
            if node.name in CONSTANTS or node.name in self._name_ids():
                raise FormulaError(ErrorCode.INVALID_NAME,
                                   f"'{node.name}' is a duplicate or constant name",
                                   names=(node.name,))
        except FormulaError as exc:
            node.fault, node.named = exc, False
        self._params[pid] = node
        self._attach(pid, node)

    # Remove bindings, units and sizes of every field matching ``match(entity_id, target)``.
    def _drop_fields(self, match: Callable[[str, str], bool]) -> None:
        for target in [t for t in self._bindings if match(t.entity_id, t.target)]:
            self.unbind(target)
        for store in (self._units, self._sizes):
            for key in [k for k in store if match(*k)]:
                del store[key]

    # Fresh unused parameter id.
    def _new_id(self) -> str:
        while True:
            pid = PARAMETER_ID_PREFIX + "".join(secrets.choice(_ID_ALPHABET) for _ in range(6))
            if pid not in self._params:
                return pid

    # First free ``var_<n>`` name.
    def _free_name(self) -> str:
        taken = set(self._name_ids()) | set(CONSTANTS) | set(FUNCTIONS)
        n = 1
        while f"var_{n}" in taken:
            n += 1
        return f"var_{n}"


# Disk row of one parameter.
def _parameter_record(pid: str, node: _Node) -> dict[str, Any]:
    return {"id": pid, "name": node.name, "expr": node.expr, "description": node.description}


# True when a node's value or error differs from ``before``.
def _state_changed(before: tuple[float | None, FormulaError | None], node: _Node) -> bool:
    value, error = before
    if value != node.value:
        return True
    if error is None or node.error is None:
        return (error is None) != (node.error is None)
    return not error.same_as(node.error)


# "2 bindings and 1 parameter".
def _count_text(usages: Usages) -> str:
    parts = []
    if usages.bindings:
        parts.append(f"{len(usages.bindings)} binding(s)")
    if usages.parameters:
        parts.append(f"{len(usages.parameters)} parameter(s)")
    return " and ".join(parts)
