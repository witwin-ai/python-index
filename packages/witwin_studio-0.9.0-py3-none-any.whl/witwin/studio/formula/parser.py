"""Parse and evaluate one formula (plan §2.5).

A formula is a single Python expression limited to a whitelist: numbers,
names, ``+ - * / ** // %``, unary ``+ -``, parentheses, and calls of the
functions in ``constants.FUNCTIONS`` with positional arguments. ``parse`` runs
``ast.parse`` and turns the whitelisted tree into nested closures; anything else
is rejected. Evaluation calls those closures and never uses ``eval()``, so a
formula cannot reach attributes, strings, imports or any other Python object.

Operators are plain Python operators, so the same closures run on floats and on
tensors; functions, literals, ``**`` and numeric checks come from a
``FormulaBackend`` (backend.py, plan §2.8). With the default float backend,
``7 // 2`` is ``3.0``, results are always ``float``, ``inf`` is a valid result
and NaN is always an error.
"""
from __future__ import annotations

import ast
import operator
import re
from dataclasses import dataclass, field
from functools import cached_property
from typing import Any, Callable, Mapping

from .backend import FLOAT_BACKEND, MAX_EXPONENT, FormulaBackend
from .constants import FUNCTIONS
from .errors import ErrorCode, FormulaError

# Limits that keep a hostile or broken formula from stalling the ProjectServer.
MAX_SOURCE = 1024    # characters
MAX_NODES = 256      # expression nodes in the syntax tree

Scope = Mapping[str, Any]
_Run = Callable[[Scope, FormulaBackend], Any]

_NEWLINE = re.compile(r"\r\n|\r|\n")

# The exceptions Python numbers raise for bad arithmetic (tensors do not raise).
_MATH_ERRORS = (ZeroDivisionError, OverflowError, ValueError)

# ``**`` is missing on purpose: it goes through FormulaBackend.power.
_BINOPS: dict[type, tuple[str, Callable[[Any, Any], Any]]] = {
    ast.Add: ("+", operator.add),
    ast.Sub: ("-", operator.sub),
    ast.Mult: ("*", operator.mul),
    ast.Div: ("/", operator.truediv),
    ast.FloorDiv: ("//", operator.floordiv),
    ast.Mod: ("%", operator.mod),
    ast.Pow: ("**", operator.pow),
}

_UNARYOPS: dict[type, Callable[[Any], Any]] = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}

# Friendlier wording for the rejected node kinds users are most likely to type.
_FORBIDDEN_WORDS = {
    "Attribute": "attribute access", "Subscript": "indexing", "Lambda": "lambda",
    "Compare": "comparisons", "BoolOp": "boolean operators", "NamedExpr": "':='",
    "IfExp": "conditional expressions", "JoinedStr": "f-strings", "Starred": "'*' arguments",
    "ListComp": "comprehensions", "SetComp": "comprehensions", "DictComp": "comprehensions",
    "GeneratorExp": "comprehensions", "List": "lists", "Tuple": "tuples", "Dict": "dicts",
    "Set": "sets", "Await": "await", "Yield": "yield", "YieldFrom": "yield",
    "Not": "'not'", "Invert": "'~'", "MatMult": "'@'", "BitAnd": "'&'", "BitOr": "'|'",
    "BitXor": "'^'", "LShift": "'<<'", "RShift": "'>>'",
}


@dataclass(frozen=True)
class NameRef:
    """One name in the source; ``start`` / ``end`` are character offsets."""
    name: str
    start: int
    end: int


@dataclass(frozen=True, eq=False)
class Formula:
    """A parsed formula. Build it with ``parse``."""
    src: str
    names: tuple[NameRef, ...]  # every referenced name in source order, repeats included
    ops: frozenset[str]         # operator symbols and function names used, e.g. {"//", "min"}
    _run: _Run = field(repr=False)

    # The distinct names the formula reads; function names are not included.
    @cached_property
    def refs(self) -> frozenset[str]:
        return frozenset(ref.name for ref in self.names)

    def evaluate(self, scope: Scope, backend: FormulaBackend = FLOAT_BACKEND) -> Any:
        """Evaluate with ``scope`` giving every name in ``refs``.

        With the default float backend the result is a ``float`` and numeric
        failures raise ``FormulaError`` (``math`` / ``too_large``). A name
        missing from ``scope`` raises ``unknown_name`` on every backend.
        """
        return backend.check(self._run(scope, backend), "result", 0)

    def rename(self, old: str, new: str) -> str:
        """Return the source with every ``old`` name replaced by ``new``.

        Replaces by source position instead of regenerating the source, so the
        user's spacing, parentheses and comments survive.
        """
        out = self.src
        for ref in sorted(self.names, key=lambda r: r.start, reverse=True):
            if ref.name == old:
                out = out[:ref.start] + new + out[ref.end:]
        return out


# Tokens for _explain_syntax: number, name, two-char operator, one-char
# operator, bracket or comma, any other single character.
_TOKEN = re.compile(
    r"(?P<num>(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)|(?P<name>[A-Za-z_][A-Za-z0-9_]*)"
    r"|(?P<op>\*\*|//|[-+*/%])|(?P<punct>[(),])|(?P<other>\S)")


def _explain_syntax(body: str) -> tuple[str, int] | None:
    """A short message and offset for a syntax error Python calls "invalid".

    Covers the common slips: two values with no operator between them, an
    operator with nothing after it, an operator where a value belongs, and a
    character formulas never use. Returns None when none of these fits, and
    the caller keeps Python's message.
    """
    tokens = [(m.lastgroup, m.group(), m.start()) for m in _TOKEN.finditer(body)]
    prev_kind, prev_text = None, None
    for kind, text, at in tokens:
        if kind == "other":
            return f"unexpected '{text}'", at
        ends_value = prev_kind in ("num", "name") or prev_text == ")"
        if kind in ("num", "name") or text == "(":
            # name( is a call; any other value next to a value lacks an operator.
            if ends_value and not (text == "(" and prev_kind == "name"):
                return f"missing operator before '{text}'", at
        elif kind == "op":
            after_op = prev_kind == "op" or prev_kind is None or prev_text in ("(", ",")
            if after_op and text not in "+-":
                return f"unexpected '{text}'", at
        elif text in "),":
            if prev_kind == "op":
                return f"missing value after '{prev_text}'", at - len(prev_text)
            if text == "," and prev_text in ("(", ","):
                return "unexpected ','", at
        prev_kind, prev_text = kind, text
    if prev_kind == "op":
        return f"missing value after '{prev_text}'", tokens[-1][2]
    return None


def parse(src: str) -> Formula:
    """Parse ``src`` into a ``Formula`` or raise ``FormulaError``."""
    if len(src) > MAX_SOURCE:
        raise FormulaError(ErrorCode.TOO_LARGE,
                           f"formula is longer than {MAX_SOURCE} characters", MAX_SOURCE)
    # ast.parse(mode="eval") rejects leading indentation, eval() does not;
    # strip it and shift every offset back by its length.
    body = src.lstrip(" \t")
    lead = len(src) - len(body)
    if not body.strip():
        raise FormulaError(ErrorCode.SYNTAX, "formula is empty", 0)
    compiler = _Compiler(body, lead)
    try:
        tree = ast.parse(body, mode="eval")
    except SyntaxError as exc:
        offset = compiler.char_offset(exc.lineno or 1, max((exc.offset or 1) - 1, 0), chars=True)
        message = exc.msg
        # Python says only "invalid syntax" (offset 0 for "2 *"); the editors
        # underline the offset, so name the token and point at it instead.
        if message.startswith("invalid"):
            found = _explain_syntax(body)
            if found is not None:
                message, offset = found[0], lead + found[1]
        raise FormulaError(ErrorCode.SYNTAX, message, min(offset, len(src))) from None
    except ValueError as exc:  # null bytes on Python 3.11
        raise FormulaError(ErrorCode.SYNTAX, str(exc), 0) from None
    except (RecursionError, MemoryError):
        raise FormulaError(ErrorCode.TOO_LARGE, "formula is nested too deeply", 0) from None
    run = compiler.build(tree.body)
    return Formula(src, tuple(compiler.names), frozenset(compiler.ops), run)


class _Compiler:
    """Checks one syntax tree against the whitelist and turns it into closures.

    Every closure takes ``(scope, backend)``, so one parse serves the float
    editor path and any tensor backend.
    """

    # ``body`` is the source after leading indentation, ``lead`` its length.
    def __init__(self, body: str, lead: int) -> None:
        self._body = body
        self._lead = lead
        self._line_starts = [0] + [m.end() for m in _NEWLINE.finditer(body)]
        self._count = 0
        self.names: list[NameRef] = []
        self.ops: set[str] = set()

    # Character offset into the original source of a (line, column) position.
    def char_offset(self, lineno: int, col: int, *, chars: bool = False) -> int:
        start = self._line_starts[min(lineno, len(self._line_starts)) - 1]
        if not chars:
            # ast columns count UTF-8 bytes, Python strings count characters.
            col = len(self._body[start:].encode("utf-8")[:col].decode("utf-8", "ignore"))
        return self._lead + start + col

    # Start offset of an AST node.
    def node_offset(self, node: ast.AST) -> int:
        return self.char_offset(node.lineno, node.col_offset)

    # Compile one expression node; the node count is checked before recursing deeper.
    def build(self, node: ast.expr) -> _Run:
        self._count += 1
        if self._count > MAX_NODES:
            raise FormulaError(ErrorCode.TOO_LARGE,
                               f"formula has more than {MAX_NODES} parts", self.node_offset(node))
        handler = _HANDLERS.get(type(node))
        if handler is None:
            raise self.forbidden(type(node).__name__, node)
        return handler(self, node)

    # Error for a node or operator kind outside the whitelist.
    def forbidden(self, kind: str, node: ast.AST) -> FormulaError:
        what = _FORBIDDEN_WORDS.get(kind, f"'{kind}' expressions")
        return FormulaError(ErrorCode.FORBIDDEN, f"{what} not allowed in formulas",
                            self.node_offset(node))

    # Numeric literal; bool, str, bytes, None, complex and Ellipsis are refused.
    def constant(self, node: ast.Constant) -> _Run:
        if type(node.value) not in (int, float):
            kind = {str: "strings", bytes: "bytes", bool: "booleans"}.get(
                type(node.value), f"'{node.value!r}'")
            raise FormulaError(ErrorCode.FORBIDDEN, f"{kind} not allowed in formulas",
                               self.node_offset(node))
        try:
            value = float(node.value)
        except OverflowError:
            raise FormulaError(ErrorCode.TOO_LARGE, "number is too large",
                               self.node_offset(node)) from None
        return lambda scope, backend: backend.constant(value)

    # Bare name; resolved from the scope at evaluation time.
    def name(self, node: ast.Name) -> _Run:
        start = self.node_offset(node)
        ref = NameRef(node.id, start, self.char_offset(node.end_lineno, node.end_col_offset))
        self.names.append(ref)

        # Look the name up in the evaluation scope.
        def run(scope: Scope, backend: FormulaBackend) -> Any:
            value = scope.get(ref.name)
            if value is None:
                raise FormulaError(ErrorCode.UNKNOWN_NAME, f"unknown name '{ref.name}'",
                                   start, names=(ref.name,))
            return value
        return run

    # Unary plus / minus.
    def unary(self, node: ast.UnaryOp) -> _Run:
        fn = _UNARYOPS.get(type(node.op))
        if fn is None:
            raise self.forbidden(type(node.op).__name__, node)
        operand = self.build(node.operand)
        return lambda scope, backend: fn(operand(scope, backend))

    # Binary arithmetic; a literal ``**`` exponent is range-checked here, at parse time.
    def binop(self, node: ast.BinOp) -> _Run:
        entry = _BINOPS.get(type(node.op))
        if entry is None:
            raise self.forbidden(type(node.op).__name__, node)
        symbol, fn = entry
        self.ops.add(symbol)
        offset = self.node_offset(node)
        power_at = self.node_offset(node.right) if symbol == "**" else None
        if power_at is not None:
            exponent = _literal(node.right)
            if exponent is not None and abs(exponent) > MAX_EXPONENT:
                raise FormulaError(ErrorCode.TOO_LARGE,
                                   f"exponent is larger than {MAX_EXPONENT:g}", power_at)
        left, right = self.build(node.left), self.build(node.right)

        # Apply the operator; Python number exceptions become FormulaError.
        def run(scope: Scope, backend: FormulaBackend) -> Any:
            a, b = left(scope, backend), right(scope, backend)
            try:
                value = fn(a, b) if power_at is None else backend.power(a, b, power_at)
            except _MATH_ERRORS as exc:
                raise FormulaError(ErrorCode.MATH, f"'{symbol}': {exc}", offset) from None
            return backend.check(value, symbol, offset)
        return run

    # Call of a whitelisted function with positional arguments only.
    def call(self, node: ast.Call) -> _Run:
        offset = self.node_offset(node)
        if type(node.func) is not ast.Name:
            raise FormulaError(ErrorCode.FORBIDDEN, "only named functions can be called", offset)
        func = FUNCTIONS.get(node.func.id)
        if func is None:
            raise FormulaError(ErrorCode.UNKNOWN_NAME, f"unknown function '{node.func.id}'",
                               offset, names=(node.func.id,))
        if node.keywords:
            raise FormulaError(ErrorCode.FORBIDDEN, "keyword arguments not allowed in formulas",
                               offset)
        count = len(node.args)
        if count < func.min_args or (func.max_args is not None and count > func.max_args):
            raise FormulaError(ErrorCode.SYNTAX, _arity_text(func.name, func.min_args,
                                                             func.max_args, count), offset)
        self.ops.add(func.name)
        args = [self.build(arg) for arg in node.args]

        # Evaluate the arguments, then the backend's implementation of the function.
        def run(scope: Scope, backend: FormulaBackend) -> Any:
            values = [arg(scope, backend) for arg in args]
            try:
                value = backend.functions[func.name](*values)
            except _MATH_ERRORS as exc:
                raise FormulaError(ErrorCode.MATH, f"{func.name}(): {exc}", offset) from None
            return backend.check(value, func.name, offset)
        return run


_HANDLERS: dict[type, Callable[[_Compiler, ast.expr], _Run]] = {
    ast.Constant: _Compiler.constant,
    ast.Name: _Compiler.name,
    ast.UnaryOp: _Compiler.unary,
    ast.BinOp: _Compiler.binop,
    ast.Call: _Compiler.call,
}


# The value of a literal exponent such as ``3`` or ``-1e5``, else None.
def _literal(node: ast.expr) -> float | None:
    sign = 1.0
    while type(node) is ast.UnaryOp and type(node.op) in _UNARYOPS:
        sign = -sign if type(node.op) is ast.USub else sign
        node = node.operand
    if type(node) is ast.Constant and type(node.value) in (int, float):
        return sign * node.value
    return None


# Message for a call with the wrong number of arguments.
def _arity_text(name: str, low: int, high: int | None, got: int) -> str:
    if high is None:
        return f"{name}() takes at least {low} argument(s), got {got}"
    return f"{name}() takes {low} argument(s), got {got}"
