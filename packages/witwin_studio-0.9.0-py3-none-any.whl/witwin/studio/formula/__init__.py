"""Formula Graph engine: parameters, formulas and field bindings (plan §2.2-§2.6).

Pure standard library. The ProjectServer imports this package, and user
scripts get the same semantics through ``witwin.studio``.
"""
from __future__ import annotations

from .backend import FLOAT_BACKEND, FloatBackend, FormulaBackend
from .compiled import NONDIFFERENTIABLE_OPS, CompiledFormulas, FormulaValues
from .constants import (
    BUILTINS,
    CONSTANTS,
    FUNCTIONS,
    Constant,
    Function,
    register_formula_constant,
    unregister_formula_constant,
)
from .errors import ErrorCode, FormulaError
from .graph import (
    BindingInfo,
    BindingTarget,
    FormulaGraph,
    ParameterInfo,
    Preview,
    Records,
    Usages,
)
from .parser import MAX_NODES, MAX_SOURCE, Formula, NameRef, parse
from .backend import MAX_EXPONENT

# TorchBackend lives in .torch_backend and is not imported here, so importing
# this package never needs torch.
__all__ = [
    "BUILTINS", "CONSTANTS", "FLOAT_BACKEND", "FUNCTIONS", "MAX_EXPONENT", "MAX_NODES",
    "MAX_SOURCE", "NONDIFFERENTIABLE_OPS", "BindingInfo", "BindingTarget", "CompiledFormulas",
    "Constant", "ErrorCode", "FloatBackend", "Formula", "FormulaBackend", "FormulaError",
    "FormulaGraph", "FormulaValues", "Function", "NameRef", "ParameterInfo", "Preview",
    "Records", "Usages", "parse", "register_formula_constant", "unregister_formula_constant",
]
