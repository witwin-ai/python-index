"""Torch backend for differentiable formula evaluation (plan §2.8).

Importing this module does not import torch; constructing ``TorchBackend``
does. ``witwin.studio`` must stay importable without torch
(tests/formula/test_backends.py checks that).

Literals and constants stay Python floats, so torch broadcasts them to the
dtype and device of the design-variable tensors instead of forcing float32 or
CPU. A function whose arguments are all Python floats (``sin(pi / 4)``) is
computed with ``math`` for the same reason. ``check`` does nothing: a NaN in
the middle of an autograd graph is the optimiser's business, and raising would
lose the graph.
"""
from __future__ import annotations

import functools
import math
from types import MappingProxyType
from typing import Any, Callable, Mapping

from .backend import FLOAT_BACKEND


class TorchBackend:
    """``FormulaBackend`` on torch tensors; pass it to ``FormulaGraph.compile``."""

    # Imports torch; raises ImportError when it is not installed.
    def __init__(self) -> None:
        import torch

        self._torch = torch
        self.functions: Mapping[str, Callable[..., Any]] = MappingProxyType({
            "abs": self._unary(torch.abs, abs),
            "log": self._unary(torch.log, math.log),
            "log10": self._unary(torch.log10, math.log10),
            "exp": self._unary(torch.exp, math.exp),
            "sqrt": self._unary(torch.sqrt, math.sqrt),
            "sin": self._unary(torch.sin, math.sin),
            "cos": self._unary(torch.cos, math.cos),
            "tan": self._unary(torch.tan, math.tan),
            "arcsin": self._unary(torch.asin, math.asin),
            "arccos": self._unary(torch.acos, math.acos),
            "arctan": self._unary(torch.atan, math.atan),
            "min": self._fold(torch.minimum, min),
            "max": self._fold(torch.maximum, max),
        })

    # Literals stay Python floats so torch picks dtype and device from the tensors.
    def constant(self, value: float) -> float:
        return value

    # No checks: keep the autograd graph intact.
    def check(self, value: Any, what: str, offset: int) -> Any:
        return value

    # Tensor power; two Python floats keep the float backend's strict rules.
    def power(self, base: Any, exponent: Any, offset: int) -> Any:
        if self._torch.is_tensor(base) or self._torch.is_tensor(exponent):
            return base ** exponent
        return FLOAT_BACKEND.power(base, exponent, offset)

    # One-argument function: torch for tensors, math for plain floats.
    def _unary(self, tensor_fn: Callable[[Any], Any],
               float_fn: Callable[[float], float]) -> Callable[[Any], Any]:
        is_tensor = self._torch.is_tensor
        return lambda x: tensor_fn(x) if is_tensor(x) else float_fn(x)

    # min / max over any number of arguments; floats are lifted to the first tensor's dtype.
    def _fold(self, tensor_fn: Callable[[Any, Any], Any],
              float_fn: Callable[..., float]) -> Callable[..., Any]:
        torch = self._torch

        # Reduce the arguments pairwise with the elementwise torch op.
        def fold(*args: Any) -> Any:
            tensors = [a for a in args if torch.is_tensor(a)]
            if not tensors:
                return float_fn(args)
            ref = tensors[0]
            lifted = [a if torch.is_tensor(a) else torch.as_tensor(a, dtype=ref.dtype,
                                                                      device=ref.device)
                      for a in args]
            return functools.reduce(tensor_fn, lifted)
        return fold
