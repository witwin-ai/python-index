"""Project facade: open a Project folder from code, without the ProjectServer."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Iterator, List, Optional, Sequence

from . import wtscene
from ._ids import unique_slug
from ._manifest import MANIFEST_NAME, read_project_table, read_witwin_project
from ._results import SCHEMA, ResultRecord, history_dir, next_version, read_history, text_plot, write_record
from ._scene import Scene
from .studies import StudyStore

SCENE_EXT = ".wtscene"
SCENES_DIR = "scenes"
# Used when witwin.toml names no main scene and no scene file exists yet; the
# ProjectServer creates the same id on first open (persistence.py).
DEFAULT_MAIN_SCENE_ID = "main"


@dataclass(frozen=True)
class SceneInfo:
    id: str
    name: str
    path: Path
    is_main: bool


class ResultStore:
    """The Results panel history (``.witwin/results/history``, format
    ``witwin.result.v1``, see ``dev_docs/witwin-result-v1.md``).

    ``record`` writes a new version that the Results panel lists the next time
    Studio opens the Project. While a ProjectServer serves the folder it owns
    the version numbering; headless solves attach to it instead of writing here.
    """

    def __init__(self, root: Path):
        self._root = root

    def list(self) -> List[ResultRecord]:
        """Every committed version, oldest first."""
        history = read_history((history_dir(self._root),))
        return [ResultRecord.from_dict(data) for data in history.values()]

    def get(self, version: int) -> ResultRecord:
        for record in self.list():
            if record.version == int(version):
                return record
        raise KeyError(version)

    def record(
        self,
        message: str,
        *,
        plots: Optional[List[Dict[str, Any]]] = None,
        text: Optional[str] = None,
        scene_id: Optional[str] = None,
        tag: Optional[str] = None,
        tag_color: Optional[str] = None,
        source: Optional[Dict[str, Any]] = None,
        views: Optional[Sequence[Dict[str, Any]]] = None,
        attach: Optional[bool] = None,
    ) -> ResultRecord:
        """Write one new version and return it.

        ``plots`` are Results-panel entries (``{"type": ..., "data": ...}``);
        ``text`` adds a markdown entry. ``source`` says what produced the
        Result (for a solve: solver id, run id, config, outputs) and is kept
        under the ``source`` key. ``views`` are ``witwin.studio.views`` views;
        their large arrays go to one blob under ``.witwin/results/blobs/``.

        While a ProjectServer serves the folder (``attach`` None or True) the
        version goes through it (``POST /v1/results``): it numbers the version
        and the open editor shows it at once. ``attach=False`` always writes
        the file; ``attach=True`` fails when no server runs.
        """
        entries = list(plots or [])
        if text:
            entries.append(text_plot(text))
        extra: Dict[str, Any] = {"schema": SCHEMA}
        if source:
            extra["source"] = dict(source)
        if views:
            from .views import pack

            extra["views"] = pack(views, self._root)
        server = None
        if attach is not False:
            from ._discovery import running_server

            server = running_server(self._root)
            if attach and server is None:
                raise RuntimeError(f"no running ProjectServer serves {self._root}")
        if server is not None:
            reply = _post_json(server, "/v1/results", {
                "message": message, "plots": entries, "scene_id": scene_id,
                "tag": tag, "tag_color": tag_color, "extra": extra,
            })
            return ResultRecord.from_dict(reply["record"])
        record = ResultRecord(
            version=next_version(self._root),
            message=message,
            plots=entries,
            timestamp=datetime.now().isoformat(),
            scene_id=scene_id,
            tag=tag,
            tag_color=tag_color if tag else None,
            extra=extra,
        )
        write_record(history_dir(self._root), record.to_dict())
        return record

    def __iter__(self) -> Iterator[ResultRecord]:
        return iter(self.list())

    def __len__(self) -> int:
        return len(self.list())


def _post_json(server: Any, path: str, body: Dict[str, Any], timeout: float = 30.0) -> Dict[str, Any]:
    import json
    import urllib.error
    import urllib.request

    request = urllib.request.Request(
        f"{server.url}{path}",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", **server.headers()},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"{server.url}{path}: HTTP {exc.code} {exc.read().decode('utf-8', 'replace')}") from exc


class Project:
    """A Project folder: ``witwin.toml``, ``scenes/``, ``studies/``, Results and the rest."""

    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        info = read_witwin_project(self.root)
        self.id: str = info.project_id
        self.name: str = info.name
        self.results = ResultStore(self.root)
        self.studies = StudyStore(self.root)

    @property
    def manifest_path(self) -> Path:
        return self.root / MANIFEST_NAME

    @property
    def scenes_dir(self) -> Path:
        return self.root / SCENES_DIR

    def _scene_index(self) -> Dict[str, Path]:
        # Same rule as the ProjectServer's scan: the file's own ``id`` wins over
        # its file name, files are visited in sorted path order, and the first
        # of two files claiming one id wins. Unreadable files are skipped.
        index: Dict[str, Path] = {}
        if not self.scenes_dir.is_dir():
            return index
        for path in sorted(self.scenes_dir.rglob(f"*{SCENE_EXT}")):
            try:
                scene_id = wtscene.loads(path.read_text(encoding="utf-8")).get("scene_id")
            except Exception:  # noqa: BLE001 - one malformed scene must not hide the rest
                continue
            if isinstance(scene_id, str) and scene_id and scene_id not in index:
                index[scene_id] = path
        return index

    @property
    def main_scene_id(self) -> str:
        """``[project].main_scene``, else the first scene on disk, else ``main``."""
        index = self._scene_index()
        pointer = str(read_project_table(self.root).get("main_scene") or "").strip()
        if pointer and pointer in index:
            return pointer
        if index:
            return next(iter(index))
        return pointer or DEFAULT_MAIN_SCENE_ID

    @property
    def scenes(self) -> List[SceneInfo]:
        main = self.main_scene_id
        out: List[SceneInfo] = []
        for scene_id, path in self._scene_index().items():
            try:
                name = wtscene.loads(path.read_text(encoding="utf-8")).get("name") or scene_id
            except Exception:  # noqa: BLE001 - the index already parsed it once
                name = scene_id
            out.append(SceneInfo(id=scene_id, name=str(name), path=path, is_main=scene_id == main))
        return out

    def scene(self, scene_id: Optional[str] = None) -> Scene:
        """Load a Scene by id (default: the main scene). KeyError if it has no file."""
        wanted = scene_id or self.main_scene_id
        path = self._scene_index().get(wanted)
        if path is None:
            raise KeyError(f"no scene with id {wanted!r} in {self.scenes_dir}")
        return Scene.load(path)

    def create_scene(self, name: str, *, id: Optional[str] = None, stage: str = "world") -> Scene:
        """A new, empty Scene at ``scenes/<id>.wtscene``. Nothing is written until ``save()``.

        ``stage`` is how Studio shows it: ``"world"`` or ``"bench"`` (``Scene.stage``).
        """
        index = self._scene_index()
        if id is not None:
            if id in index:
                raise ValueError(f"scene id already used: {id}")
            scene_id = id
        else:
            scene_id = unique_slug(name, index.keys(), fallback="scene")
        return Scene.new(scene_id, name, self.scenes_dir / f"{scene_id}{SCENE_EXT}", stage=stage)

    def solvers(self, *, plugin_paths: Sequence[Path] = ()) -> List[Any]:
        """The solvers this Project can run (``witwin.studio.solver.SolverSpec``)."""
        from .solver.client import list_solvers

        return list_solvers(self.root, plugin_paths=plugin_paths)

    def solve(
        self,
        solver_id: str,
        *,
        scene: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        record: bool = True,
        attach: Optional[bool] = None,
        plugin_paths: Sequence[Path] = (),
        on_progress: Optional[Callable[[float, Optional[str]], None]] = None,
        on_log: Optional[Callable[[str], None]] = None,
    ) -> Any:
        """Run a Plugin's solver on a scene of this Project and return its ``SolveRun``.

        The solve starts in the background; ``run.result()`` waits for it.
        ``scene`` is a scene id (default: the main scene). With ``record``,
        a successful solve writes a Result the Results panel lists.

        ``attach=None`` uses the ProjectServer serving this folder when
        ``.witwin/runtime/server.json`` says one is running, else runs the
        solver child here; ``True`` requires the server, ``False`` never uses
        it. Details: ``witwin.studio.solver.client``.
        """
        from .solver.client import start_solve

        return start_solve(
            self, solver_id, scene=scene, config=config, record=record, attach=attach,
            plugin_paths=plugin_paths, on_progress=on_progress, on_log=on_log,
        )

    def server(self) -> Any:
        """The running ProjectServer for this folder (``ServerRecord``), or None."""
        from ._discovery import running_server

        return running_server(self.root)

    def __repr__(self) -> str:
        return f"Project(name={self.name!r}, root={str(self.root)!r})"


def open_project(path: Path | str = ".") -> Project:
    """Open the Project at ``path``. Raises FileNotFoundError without ``witwin.toml``."""
    root = Path(path).resolve()
    if not (root / MANIFEST_NAME).is_file():
        raise FileNotFoundError(f"not a WiTwin Project (no {MANIFEST_NAME}): {root}")
    return Project(root)
