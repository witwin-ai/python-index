"""Gerber (RS-274X) and Excellon drill import: a small reader of our own, no dependency.

Supported Gerber subset (anything else is skipped with a warning):

- ``%FS`` with leading (L) or trailing (T) zero omission, absolute coordinates;
  ``%MO`` MM / IN (also the deprecated G70 / G71); coordinates with a decimal
  point are read as written.
- Apertures ``%AD``: standard C (circle), R (rectangle), O (obround),
  P (regular polygon), the optional hole parameter ignored; aperture macros
  ``%AM`` with primitives 1 (circle), 4 (outline), 5 (polygon), 20 (vector
  line), 21 (center line), variables ``$n``, arithmetic ``+ - x /`` and
  parentheses, exposure on/off and rotation.
- D01 (draw), D02 (move), D03 (flash), Dnn aperture select (also G54Dnn);
  G01 linear, G02 / G03 circular in G75 (multi-quadrant) and G74 (single
  quadrant) mode; G36 / G37 regions; ``%LPD`` / ``%LPC`` polarity.
- Strokes: a circular aperture draws a round-capped track; a rectangular one
  the swept rectangle (exact for straight lines); other apertures draw with
  a circle of the same size (warning).
- Ignored: attributes (TF/TA/TO/TD), comments (G04), IP/OF/SF/LN/IN.
- Not supported (warning): step and repeat (``%SR``), block apertures
  (``%AB``), incremental coordinates, mirroring/rotation/scaling (LM/LR/LS).

Excellon subset: header (M48 ... %), METRIC / INCH with optional LZ / TZ
and ``,000.000`` format, tool definitions ``TnC<diameter>``, tool select,
hits ``X..Y..`` (decimal points or implicit digits; default implicit format
3.3 mm or 2.4 in, TZ unless LZ is given), G85 slots (as a drill at each end
plus the slot as a non-plated cut, warning). Routing (G00/G01/M15/M16) is
not supported (warning).
"""
from __future__ import annotations

import math
import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

from ._imported import Imported
from ._layout import Layout
from ._stack import LayerStack

__all__ = ["GerberImage", "parse_excellon", "parse_gerber", "read_gerber"]

INCH_MM = 25.4
ARC_SEGMENTS = 64  # per full circle


def _read(source: Any) -> str:
    if hasattr(source, "read"):
        data = source.read()
        return data.decode("utf-8", "replace") if isinstance(data, bytes) else data
    with open(os.fspath(source), "r", encoding="utf-8", errors="replace") as fh:
        return fh.read()


# --------------------------------------------------------------------------- #
# Aperture macros
# --------------------------------------------------------------------------- #
_TOKEN = re.compile(r"\s*(\$\d+|\d*\.\d+|\d+\.?|[-+xX*/()])")


def _eval(expr: str, variables: Mapping[int, float]) -> float:
    """Evaluate a macro arithmetic expression (``x`` and ``X`` multiply)."""
    tokens = []
    pos = 0
    expr = expr.strip()
    while pos < len(expr):
        m = _TOKEN.match(expr, pos)
        if not m:
            raise ValueError(f"bad macro expression {expr!r}")
        tokens.append(m.group(1))
        pos = m.end()
    i = 0

    def peek() -> Optional[str]:
        return tokens[i] if i < len(tokens) else None

    def take() -> str:
        nonlocal i
        i += 1
        return tokens[i - 1]

    def atom() -> float:
        t = take()
        if t == "(":
            v = add()
            take()  # ")"
            return v
        if t in "+-":
            v = atom()
            return -v if t == "-" else v
        if t.startswith("$"):
            return float(variables.get(int(t[1:]), 0.0))
        return float(t)

    def mul() -> float:
        v = atom()
        while peek() in ("x", "X", "*", "/"):
            op = take()
            r = atom()
            v = v / r if op == "/" else v * r
        return v

    def add() -> float:
        v = mul()
        while peek() in ("+", "-"):
            op = take()
            r = mul()
            v = v + r if op == "+" else v - r
        return v

    return add()


def _rot(shape: Any, angle: float) -> Any:
    from shapely import affinity

    return affinity.rotate(shape, angle, origin=(0.0, 0.0)) if angle else shape


def _macro_shape(body: List[str], args: Sequence[float], warnings: List[str], name: str) -> Any:
    """Shapely shape of a macro instance at the origin, in file units."""
    from shapely.geometry import LineString, Point, Polygon, box

    variables: Dict[int, float] = {i + 1: float(v) for i, v in enumerate(args)}
    result = Polygon()
    for stmt in body:
        stmt = stmt.strip()
        if not stmt or stmt.startswith("0"):
            continue  # comment primitive
        if stmt.startswith("$"):
            var, expr = stmt.split("=", 1)
            variables[int(var[1:])] = _eval(expr, variables)
            continue
        fields = [f for f in stmt.split(",")]
        code = int(fields[0])
        vals = [_eval(f, variables) for f in fields[1:]]
        shape = None
        if code == 1:  # circle: exposure, diameter, cx, cy[, rotation]
            shape = Point(vals[2], vals[3]).buffer(vals[1] / 2.0, quad_segs=16)
            shape = _rot(shape, vals[4] if len(vals) > 4 else 0.0)
        elif code == 20:  # vector line: exposure, width, x1, y1, x2, y2, rotation
            line = LineString([(vals[2], vals[3]), (vals[4], vals[5])])
            shape = _rot(line.buffer(vals[1] / 2.0, cap_style="flat"), vals[6])
        elif code == 21:  # center line: exposure, width, height, cx, cy, rotation
            shape = _rot(box(vals[3] - vals[1] / 2, vals[4] - vals[2] / 2, vals[3] + vals[1] / 2,
                             vals[4] + vals[2] / 2), vals[5])
        elif code == 4:  # outline: exposure, n, x0, y0, ... xn, yn, rotation
            n = int(vals[1])
            pts = [(vals[2 + 2 * k], vals[3 + 2 * k]) for k in range(n + 1)]
            shape = _rot(Polygon(pts).buffer(0), vals[2 + 2 * (n + 1)])
        elif code == 5:  # polygon: exposure, vertices, cx, cy, diameter, rotation
            n = int(vals[1])
            r = vals[4] / 2.0
            pts = [(vals[2] + r * math.cos(2 * math.pi * k / n), vals[3] + r * math.sin(2 * math.pi * k / n))
                   for k in range(n)]
            shape = _rot(Polygon(pts), vals[5])
        else:
            warnings.append(f"aperture macro {name!r}: primitive {code} not supported, skipped")
            continue
        exposure = vals[0]
        result = result.union(shape) if exposure >= 0.5 else result.difference(shape)
    return result


# --------------------------------------------------------------------------- #
# Gerber
# --------------------------------------------------------------------------- #
@dataclass
class GerberImage:
    """One parsed Gerber file, in millimeters.

    ``geometry`` is the dark area (shapely); ``lines`` the stroke centerlines
    (LineStrings), which ``read_gerber`` uses to rebuild a board outline.
    """

    geometry: Any
    lines: List[Any] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


@dataclass
class _Aperture:
    kind: str  # C, R, O, P, macro
    params: Tuple[float, ...]
    shape: Any  # flash shape at the origin, mm


def _std_aperture(kind: str, params: Sequence[float]) -> Any:
    from shapely.geometry import Point, Polygon, box

    if kind == "C":
        return Point(0, 0).buffer(params[0] / 2.0, quad_segs=16)
    if kind == "R":
        return box(-params[0] / 2, -params[1] / 2, params[0] / 2, params[1] / 2)
    if kind == "O":
        w, h = params[0], params[1]
        from shapely.geometry import LineString

        if w >= h:
            return LineString([(-(w - h) / 2, 0), ((w - h) / 2, 0)]).buffer(h / 2, quad_segs=16) if w > h \
                else Point(0, 0).buffer(w / 2, quad_segs=16)
        return LineString([(0, -(h - w) / 2), (0, (h - w) / 2)]).buffer(w / 2, quad_segs=16)
    if kind == "P":
        d, n = params[0], int(params[1])
        rot = math.radians(params[2]) if len(params) > 2 else 0.0
        return Polygon([(d / 2 * math.cos(rot + 2 * math.pi * k / n), d / 2 * math.sin(rot + 2 * math.pi * k / n))
                        for k in range(n)])
    raise ValueError(kind)


def _arc_points(start: Tuple[float, float], end: Tuple[float, float], center: Tuple[float, float],
                clockwise: bool) -> List[Tuple[float, float]]:
    r = math.hypot(start[0] - center[0], start[1] - center[1])
    a0 = math.atan2(start[1] - center[1], start[0] - center[0])
    a1 = math.atan2(end[1] - center[1], end[0] - center[0])
    if clockwise:
        sweep = a1 - a0
        while sweep >= 0:
            sweep -= 2 * math.pi
    else:
        sweep = a1 - a0
        while sweep <= 0:
            sweep += 2 * math.pi
    if math.isclose(start[0], end[0], abs_tol=1e-9) and math.isclose(start[1], end[1], abs_tol=1e-9):
        sweep = -2 * math.pi if clockwise else 2 * math.pi
    n = max(2, int(math.ceil(abs(sweep) / (2 * math.pi) * ARC_SEGMENTS)))
    pts = [(center[0] + r * math.cos(a0 + sweep * k / n), center[1] + r * math.sin(a0 + sweep * k / n))
           for k in range(n + 1)]
    pts[-1] = end
    return pts


def _commands(text: str) -> Iterable[Tuple[bool, str]]:
    """(is_extended, command) pairs; an extended block yields each '*'-command inside it."""
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c in " \r\n\t":
            i += 1
            continue
        if c == "%":
            j = text.find("%", i + 1)
            if j < 0:
                break
            block = text[i + 1:j].replace("\r", "").replace("\n", "")
            if block.startswith("AM"):
                yield True, block  # a macro keeps its '*'-separated body together
            else:
                for part in block.split("*"):
                    if part:
                        yield True, part
            i = j + 1
        else:
            j = text.find("*", i)
            if j < 0:
                break
            yield False, text[i:j].replace("\r", "").replace("\n", "").strip()
            i = j + 1


def parse_gerber(source: Any) -> GerberImage:
    """Parse one RS-274X file (path or text stream); see the module docstring for the subset."""
    import shapely
    from shapely.geometry import LineString, Point, Polygon
    from shapely import affinity

    from ._shapes import clean

    text = _read(source)
    warnings: List[str] = []
    warned = set()

    def warn(msg: str) -> None:
        if msg not in warned:
            warned.add(msg)
            warnings.append(msg)

    fmt = (3, 6, 3, 6)  # x int, x dec, y int, y dec
    zeros = "L"
    unit = 1.0  # mm per file unit
    apertures: Dict[int, _Aperture] = {}
    macros: Dict[str, List[str]] = {}
    current: Optional[_Aperture] = None
    interp = "G01"
    multi_quadrant = True
    region = False
    contour: List[Tuple[float, float]] = []
    contours: List[List[Tuple[float, float]]] = []
    dark = True
    x = y = 0.0
    objects: List[Tuple[bool, Any]] = []
    lines: List[Any] = []
    op = "D02"

    def coord(raw: str, int_digits: int, dec_digits: int) -> float:
        if "." in raw:
            return float(raw) * unit
        sign = -1.0 if raw.startswith("-") else 1.0
        digits = raw.lstrip("+-")
        if zeros == "T":
            digits = digits.ljust(int_digits + dec_digits, "0")
        return sign * int(digits or "0") / 10 ** dec_digits * unit

    def flush_contour() -> None:
        nonlocal contour
        if len(contour) >= 3:
            contours.append(contour)
        contour = []

    def emit(shape: Any) -> None:
        objects.append((dark, shape))

    for extended, cmd in _commands(text):
        if not cmd:
            continue
        if extended:
            head = cmd[:2]
            if head == "FS":
                m = re.match(r"FS([LTD]?)([AI])X(\d)(\d)Y(\d)(\d)", cmd)
                if not m:
                    warn(f"unreadable format statement {cmd!r}")
                    continue
                zeros = m.group(1) or "L"
                if m.group(2) == "I":
                    warn("incremental coordinates are not supported; read as absolute")
                fmt = (int(m.group(3)), int(m.group(4)), int(m.group(5)), int(m.group(6)))
            elif head == "MO":
                unit = INCH_MM if cmd[2:4] == "IN" else 1.0
            elif head == "AD":
                m = re.match(r"ADD(\d+)([A-Za-z_.$][\w.$\-]*)(?:,(.*))?$", cmd)
                if not m:
                    warn(f"unreadable aperture {cmd!r}")
                    continue
                code, kind = int(m.group(1)), m.group(2)
                params = tuple(float(v) for v in m.group(3).split("X")) if m.group(3) else ()
                if kind in ("C", "R", "O", "P"):
                    shape = _std_aperture(kind, params)
                    if len(params) > (3 if kind == "P" else 2 if kind != "C" else 1):
                        warn("aperture holes are ignored")
                elif kind in macros:
                    shape = _macro_shape(macros[kind], params, warnings, kind)
                else:
                    warn(f"aperture macro {kind!r} is not defined; its flashes are skipped")
                    shape = Polygon()
                    kind = "macro"
                apertures[code] = _Aperture(kind if kind in ("C", "R", "O", "P") else "macro", params,
                                            affinity.scale(shape, unit, unit, origin=(0, 0)))
            elif head == "AM":
                parts = cmd.split("*")
                macros[parts[0][2:]] = [p for p in parts[1:] if p.strip()]
            elif head == "LP":
                dark = cmd[2:3] != "C"
            elif head == "SR":
                if re.match(r"SRX(\d+)Y(\d+)", cmd) and cmd != "SRX1Y1I0J0":
                    warn("step and repeat (%SR) is not supported; only the first copy is read")
            elif head == "AB":
                warn("block apertures (%AB) are not supported")
            elif head in ("LM", "LR", "LS"):
                warn(f"{head} (mirror/rotate/scale) is not supported; ignored")
            continue

        # Word command.
        if cmd.startswith("G04") or cmd.startswith("G4 "):
            continue
        if cmd in ("M02", "M00", "M01"):
            break
        for g in re.findall(r"G0*(\d+)", cmd):
            g = int(g)
            if g in (1, 2, 3):
                interp = f"G0{g}"
            elif g == 36:
                region, contour, contours = True, [], []
            elif g == 37:
                flush_contour()
                for ring in contours:
                    emit(clean(Polygon(ring)))
                region, contours = False, []
            elif g == 74:
                multi_quadrant = False
            elif g == 75:
                multi_quadrant = True
            elif g == 70:
                unit = INCH_MM
            elif g == 71:
                unit = 1.0
            elif g == 91:
                warn("incremental coordinates (G91) are not supported")
        values = dict(re.findall(r"([XYIJ])([+-]?[\d.]+)", cmd))
        d = re.search(r"D0*(\d+)", cmd)
        if d:
            code = int(d.group(1))
            if code >= 10:
                current = apertures.get(code)
                if current is None:
                    warn(f"aperture D{code} is used but not defined")
                continue
            op = f"D0{code}"
        elif not values:
            continue
        nx = coord(values["X"], fmt[0], fmt[1]) if "X" in values else x
        ny = coord(values["Y"], fmt[2], fmt[3]) if "Y" in values else y
        ci = coord(values["I"], fmt[0], fmt[1]) if "I" in values else 0.0
        cj = coord(values["J"], fmt[2], fmt[3]) if "J" in values else 0.0

        if op == "D02":
            if region:
                flush_contour()
                contour = [(nx, ny)]
        elif op == "D01":
            if interp == "G01":
                pts = [(x, y), (nx, ny)]
            else:
                cw = interp == "G02"
                if multi_quadrant:
                    center = (x + ci, y + cj)
                else:
                    best = None
                    for sx in (1, -1):
                        for sy in (1, -1):
                            c = (x + sx * abs(ci), y + sy * abs(cj))
                            r0 = math.hypot(x - c[0], y - c[1])
                            r1 = math.hypot(nx - c[0], ny - c[1])
                            p = _arc_points((x, y), (nx, ny), c, cw)
                            # A single-quadrant arc spans at most 90 degrees.
                            sweep_ok = len(p) - 1 <= ARC_SEGMENTS / 4 + 1
                            score = (0 if sweep_ok else 1, abs(r0 - r1))
                            if best is None or score < best[0]:
                                best = (score, c)
                    center = best[1]  # type: ignore[index]
                pts = _arc_points((x, y), (nx, ny), center, cw)
            if region:
                if not contour:
                    contour = [(x, y)]
                contour.extend(pts[1:])
            else:
                line = LineString(pts)
                if line.length > 0:
                    lines.append(line)
                if current is None:
                    warn("a draw without a selected aperture is skipped")
                elif current.kind == "C" or (current.kind == "R" and len(pts) == 2):
                    if current.kind == "C":
                        width = current.params[0] * unit
                        emit(line.buffer(width / 2.0, quad_segs=16) if line.length > 0
                             else Point(pts[0]).buffer(width / 2.0, quad_segs=16))
                    else:
                        a = affinity.translate(current.shape, *pts[0])
                        b = affinity.translate(current.shape, *pts[1])
                        emit(shapely.union_all([a, b]).convex_hull)
                else:
                    warn(f"draws with {current.kind} apertures are approximated with a round pen")
                    b = current.shape.bounds
                    width = max(b[2] - b[0], b[3] - b[1])
                    emit(line.buffer(width / 2.0, quad_segs=16))
        elif op == "D03":
            if current is None:
                warn("a flash without a selected aperture is skipped")
            elif not current.shape.is_empty:
                emit(affinity.translate(current.shape, nx, ny))
        x, y = nx, ny

    # Fold objects in order: consecutive dark shapes union, clear shapes subtract.
    result = Polygon()
    run: List[Any] = []
    run_dark = True
    for is_dark, shape in objects + [(None, None)]:
        if is_dark != run_dark or shape is None:
            if run:
                merged = shapely.union_all(run)
                result = result.union(merged) if run_dark else result.difference(merged)
            run, run_dark = [], bool(is_dark)
        if shape is not None:
            run.append(shape)
    return GerberImage(result, lines, warnings)


# --------------------------------------------------------------------------- #
# Excellon
# --------------------------------------------------------------------------- #
@dataclass
class Drill:
    """One drill hit in mm; ``end`` is set for a G85 slot."""

    position: Tuple[float, float]
    diameter: float
    end: Optional[Tuple[float, float]] = None


def parse_excellon(source: Any) -> Tuple[List[Drill], List[str]]:
    """Parse an Excellon drill file; returns (drills in mm, warnings)."""
    text = _read(source)
    warnings: List[str] = []
    unit = 1.0
    zeros = "TZ"
    fmt: Optional[Tuple[int, int]] = None
    tools: Dict[int, float] = {}
    tool: Optional[int] = None
    drills: List[Drill] = []
    x = y = 0.0
    in_header = False

    def coord(raw: str) -> float:
        if "." in raw:
            return float(raw) * unit
        sign = -1.0 if raw.startswith("-") else 1.0
        digits = raw.lstrip("+-")
        int_d, dec_d = fmt or ((3, 3) if unit == 1.0 else (2, 4))
        if zeros == "LZ":
            digits = digits.ljust(int_d + dec_d, "0")
        return sign * int(digits or "0") / 10 ** dec_d * unit

    for raw_line in text.splitlines():
        line = raw_line.split(";", 1)[0].strip()
        if not line:
            continue
        if line == "M48":
            in_header = True
            continue
        if line in ("%", "M95"):
            in_header = False
            continue
        if line.startswith(("METRIC", "INCH")):
            unit = 1.0 if line.startswith("METRIC") else INCH_MM
            for part in line.split(",")[1:]:
                if part in ("LZ", "TZ"):
                    zeros = part
                elif re.fullmatch(r"0+\.0+", part):
                    a, b = part.split(".")
                    fmt = (len(a), len(b))
            continue
        if line in ("M71",):
            unit = 1.0
            continue
        if line in ("M72",):
            unit = INCH_MM
            continue
        m = re.match(r"T(\d+)(?:[FSB][\d.]+)*C([\d.]+)", line)
        if m:
            tools[int(m.group(1))] = float(m.group(2)) * unit
            continue
        m = re.fullmatch(r"T(\d+)", line)
        if m and not in_header:
            tool = int(m.group(1))
            if tool != 0 and tool not in tools:
                warnings.append(f"tool T{tool} has no diameter; its hits are skipped")
            continue
        if line.startswith(("M30", "M00")):
            break
        if line.startswith(("G00", "G01", "M15", "M16", "M17")):
            if "routing is not supported" not in " ".join(warnings):
                warnings.append("routing is not supported; routed paths are skipped")
            continue
        if in_header:
            continue
        m = re.match(r"(?:X([+-]?[\d.]+))?(?:Y([+-]?[\d.]+))?(G85(?:X([+-]?[\d.]+))?(?:Y([+-]?[\d.]+))?)?$", line)
        if m and (m.group(1) or m.group(2)):
            x = coord(m.group(1)) if m.group(1) else x
            y = coord(m.group(2)) if m.group(2) else y
            if tool in tools:
                end = None
                if m.group(3):
                    ex = coord(m.group(4)) if m.group(4) else x
                    ey = coord(m.group(5)) if m.group(5) else y
                    end = (ex, ey)
                drills.append(Drill((x, y), tools[tool], end))  # type: ignore[index]
    return drills, warnings


# --------------------------------------------------------------------------- #
# Board
# --------------------------------------------------------------------------- #
def guess_board_stack(copper: Sequence[str], *, thickness: float, copper_thickness: float, eps_r: float,
                      tan_delta: float, unit: str = "mm") -> LayerStack:
    """Copper layers ``copper`` (top first) with equal FR4-like cores between them.

    One copper layer gets a single core of ``thickness`` under it.
    """
    names = list(copper)
    props = {"eps_r": eps_r, "tan_delta": tan_delta}
    if len(names) == 1:
        return LayerStack([("core", "dielectric", thickness, props), (names[0], "conductor", copper_thickness)],
                          unit=unit)
    core = (thickness - len(names) * copper_thickness) / (len(names) - 1)
    if core <= 0:
        raise ValueError("board thickness is too small for the copper layers")
    specs: List[Any] = []
    for i, name in enumerate(reversed(names)):
        if i:
            specs.append((f"core_{i}", "dielectric", core, props))
        specs.append((name, "conductor", copper_thickness))
    return LayerStack(specs, unit=unit)


def outline_from_lines(lines: Sequence[Any], warnings: List[str]) -> Any:
    """Board outline from stroke centerlines: the largest closed loop minus loops inside it."""
    import shapely
    from shapely.ops import polygonize

    if not lines:
        return None
    # Snap to 1 nm (lines are in mm) so ends computed separately still meet.
    merged = shapely.union_all([shapely.set_precision(line, 1e-6) for line in lines])
    polys = sorted(polygonize(merged), key=lambda p: -p.area)
    if not polys:
        warnings.append("the outline does not close; using the convex hull of its lines")
        return merged.convex_hull
    board = polys[0]
    # polygonize returns the board face and every face inside it (cutouts are
    # faces too); keep the outer boundary and cut faces that are separate loops.
    outer = shapely.geometry.Polygon(board.exterior)
    cutouts = [p for p in polys[1:] if outer.contains(p.representative_point())]
    inner_loops = [shapely.geometry.Polygon(p.exterior) for p in cutouts]
    if inner_loops:
        outer = outer.difference(shapely.union_all(inner_loops))
    return outer


def read_gerber(*, copper: Union[Mapping[str, Any], Sequence[Tuple[str, Any]]], drill: Any = None,
                npth_drill: Any = None, outline: Any = None, thickness: float = 1.6,
                copper_thickness: float = 0.035, eps_r: float = 4.4, tan_delta: float = 0.02) -> Imported:
    """Gerber copper layers + Excellon drills -> ``Imported`` (layout in mm).

    ``copper``: ``{layer name: gerber file}`` or ``[(name, file), ...]``,
    **top layer first**. ``drill``: plated-through Excellon file(s); each hit
    becomes a via from the top to the bottom copper layer (no pad: the pads
    are in the copper files). ``npth_drill``: non-plated holes, cut out of the
    board. ``outline``: the board-outline Gerber (Edge.Cuts / GKO); without
    it the outline is the bounding box. Stack guess: ``thickness`` board with
    ``copper_thickness`` copper and equal cores of ``eps_r``, ``tan_delta``
    (mm), see ``guess_board_stack``.
    """
    from shapely.geometry import LineString

    from ._shapes import circle

    items = list(copper.items()) if isinstance(copper, Mapping) else [tuple(i) for i in copper]
    if not items:
        raise ValueError("read_gerber needs at least one copper layer")
    warnings: List[str] = []
    lay = Layout(unit="mm")
    for name, source in items:
        image = parse_gerber(source)
        warnings.extend(f"{name}: {w}" for w in image.warnings)
        if image.geometry.is_empty:
            warnings.append(f"{name}: no copper")
        else:
            lay.add(name, image.geometry)
    if outline is not None:
        image = parse_gerber(outline)
        warnings.extend(f"outline: {w}" for w in image.warnings)
        board = outline_from_lines(image.lines, warnings)
        if board is not None:
            lay.outline = board
    top, bottom = items[0][0], items[-1][0]

    def drills_of(sources: Any) -> List[Drill]:
        if sources is None:
            return []
        out: List[Drill] = []
        for src in (sources if isinstance(sources, (list, tuple)) else [sources]):
            found, notes = parse_excellon(src)
            warnings.extend(f"drill: {w}" for w in notes)
            out.extend(found)
        return out

    for hole in drills_of(drill):
        if hole.end is not None:
            warnings.append("plated slots (G85) become a via at each end")
        for pos in [hole.position] + ([hole.end] if hole.end else []):
            if len(items) > 1:
                lay.via(pos, drill=hole.diameter, from_layer=top, to_layer=bottom)
    npth = drills_of(npth_drill)
    if npth:
        board = lay.outline
        for hole in npth:
            if hole.end is not None:
                cut = LineString([hole.position, hole.end]).buffer(hole.diameter / 2.0, quad_segs=8)
            else:
                cut = circle(hole.diameter / 2.0, center=hole.position, segments=32)
            board = board.difference(cut)
            for name, _ in items:
                lay.cut(name, cut)
        lay.outline = board
    if len(items) == 1 and drill is not None:
        warnings.append("one copper layer: drills are not turned into vias")
    stack = guess_board_stack([n for n, _ in items], thickness=thickness, copper_thickness=copper_thickness,
                              eps_r=eps_r, tan_delta=tan_delta)
    warnings.append(f"Gerber has no stack-up: guessed {thickness} mm board, {copper_thickness} mm copper, "
                    f"eps_r {eps_r}")
    return Imported(lay, stack, warnings)
