"""``Layer`` and ``LayerStack``: the vertical half of a 2.5D layout.

A stack is an ordered list of layers, bottom first. Each layer has a z range,
a kind and a material. Every length is stored in meters; the constructors take
a ``unit`` and convert once, so nothing downstream has to know which unit the
author typed.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, replace
from typing import Any, Dict, Iterable, Iterator, List, Mapping, Optional, Sequence, Tuple, Union

__all__ = ["KINDS", "Layer", "LayerStack", "length_factor"]

# dielectric: a slab over the board outline (drill holes cut out).
# conductor: copper drawn on the layer (traces, pads, zones).
# ground: like conductor, but an empty layer fills the whole board outline.
KINDS = ("dielectric", "conductor", "ground")

EPS0 = 8.8541878128e-12  # F/m


def length_factor(unit: str) -> float:
    """Meters per ``unit`` (any length key or label of ``witwin.studio.units``)."""
    from ..units import find_unit

    found = find_unit("length", unit) if isinstance(unit, str) else None
    if found is None:
        raise ValueError(f"unknown length unit {unit!r}; use one of m, mm, um, nm")
    return found.multiplier


@dataclass(frozen=True)
class Layer:
    """One layer of a ``LayerStack``. Lengths in meters.

    ``material`` is what ``Body`` accepts: a material name (``"PEC"``), a
    ``.wtmat`` path or a dict of Material fields. When it is None the stack
    builds one from ``eps_r``, ``sigma`` and ``tan_delta`` (``material_dict``).
    """

    name: str
    kind: str
    z_min: float
    thickness: float
    material: Union[str, Mapping[str, Any], None] = None
    eps_r: Optional[float] = None
    tan_delta: Optional[float] = None
    sigma: Optional[float] = None

    @property
    def z_max(self) -> float:
        return self.z_min + self.thickness

    @property
    def z_mid(self) -> float:
        return self.z_min + 0.5 * self.thickness

    @property
    def is_conductor(self) -> bool:
        return self.kind in ("conductor", "ground")

    def material_dict(self, frequency: Optional[float] = None) -> Union[str, Dict[str, Any], None]:
        """The ``material`` argument for this layer's ``Body``.

        An explicit ``material`` wins. Otherwise conductors without values are
        ``"PEC"`` and dielectrics get ``{"eps_r": eps_r, "sigma_e": sigma}``.
        ``tan_delta`` becomes an equivalent conductivity
        ``sigma = 2*pi*f*eps0*eps_r*tan_delta`` only when ``frequency`` (Hz)
        is known: a loss tangent alone has no frequency-independent form, and
        the sign of an imaginary permittivity differs between solvers.
        """
        if self.material is not None:
            return dict(self.material) if isinstance(self.material, Mapping) else self.material
        if self.is_conductor and self.eps_r is None:
            if self.sigma is None:
                return "PEC"
            return {"sigma_e": float(self.sigma)}
        out: Dict[str, Any] = {}
        if self.eps_r is not None:
            out["eps_r"] = float(self.eps_r)
        sigma = float(self.sigma or 0.0)
        if self.tan_delta and frequency:
            sigma += 2.0 * math.pi * float(frequency) * EPS0 * float(self.eps_r or 1.0) * float(self.tan_delta)
        if sigma or "eps_r" in out:
            out["sigma_e"] = sigma
        return out or None

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "kind": self.kind, "z_min": self.z_min, "thickness": self.thickness,
                "material": self.material, "eps_r": self.eps_r, "tan_delta": self.tan_delta, "sigma": self.sigma}


LayerSpec = Union[Layer, Mapping[str, Any], Tuple[Any, ...]]


class LayerStack:
    """Ordered layers, bottom first, each with a z range, kind and material.

        stack = LayerStack([
            ("bottom", "ground", 0.035),
            ("core", "dielectric", 1.6, {"eps_r": 4.4, "tan_delta": 0.02}),
            ("top", "conductor", 0.035),
        ], unit="mm", frequency=2.45e9)

    A layer is given as a ``Layer``, a dict with the ``Layer`` fields
    (``z_min`` optional, ``thickness`` in ``unit``) or a tuple
    ``(name, kind, thickness[, properties])`` where ``properties`` is a dict
    with ``material`` / ``eps_r`` / ``tan_delta`` / ``sigma``. Layers without
    ``z_min`` sit on top of the previous one, starting at ``z0``. All lengths
    are converted from ``unit`` to meters. ``frequency`` (Hz) turns loss
    tangents into conductivity, see ``Layer.material_dict``.
    """

    def __init__(self, layers: Iterable[LayerSpec], *, unit: str, z0: float = 0.0,
                 frequency: Optional[float] = None):
        factor = length_factor(unit)
        self.frequency = None if frequency is None else float(frequency)
        out: List[Layer] = []
        z = float(z0) * factor
        for spec in layers:
            layer = _layer_from_spec(spec, factor, z)
            out.append(layer)
            z = layer.z_max
        names = [layer.name for layer in out]
        if len(set(names)) != len(names):
            raise ValueError(f"layer names must be unique, got {names}")
        if not out:
            raise ValueError("a LayerStack needs at least one layer")
        self._layers = out

    # ------------------------------------------------------------------ #
    @classmethod
    def fr4(cls, *, substrate: float = 1.6, copper: float = 0.035, eps_r: float = 4.4,
            tan_delta: float = 0.02, unit: str = "mm", ground: bool = True,
            frequency: Optional[float] = None) -> "LayerStack":
        """A 2-layer FR4 board: ``bottom`` copper, ``core`` dielectric, ``top`` copper.

        Defaults: 1.6 mm core, 35 um (1 oz) copper, eps_r 4.4, tan_delta 0.02,
        all lengths in ``unit`` (mm). ``ground=True`` makes ``bottom`` a ground
        layer, which fills the board outline when nothing is drawn on it.
        """
        return cls([
            ("bottom", "ground" if ground else "conductor", copper),
            ("core", "dielectric", substrate, {"eps_r": eps_r, "tan_delta": tan_delta, "material": None}),
            ("top", "conductor", copper),
        ], unit=unit, frequency=frequency)

    # ------------------------------------------------------------------ #
    @property
    def layers(self) -> List[Layer]:
        return list(self._layers)

    @property
    def names(self) -> List[str]:
        return [layer.name for layer in self._layers]

    def __iter__(self) -> Iterator[Layer]:
        return iter(self._layers)

    def __len__(self) -> int:
        return len(self._layers)

    def __contains__(self, name: object) -> bool:
        return any(layer.name == name for layer in self._layers)

    def __getitem__(self, name: str) -> Layer:
        for layer in self._layers:
            if layer.name == name:
                return layer
        raise KeyError(f"no layer {name!r}; layers: {', '.join(self.names)}")

    def index(self, name: str) -> int:
        return self.names.index(self[name].name)

    @property
    def z_min(self) -> float:
        return min(layer.z_min for layer in self._layers)

    @property
    def z_max(self) -> float:
        return max(layer.z_max for layer in self._layers)

    @property
    def thickness(self) -> float:
        return self.z_max - self.z_min

    def conductors(self) -> List[Layer]:
        return [layer for layer in self._layers if layer.is_conductor]

    def dielectrics(self) -> List[Layer]:
        return [layer for layer in self._layers if layer.kind == "dielectric"]

    def between(self, a: str, b: str) -> List[Layer]:
        """Layers strictly between ``a`` and ``b`` in stack order."""
        i, j = sorted((self.index(a), self.index(b)))
        return self._layers[i + 1:j]

    def neighbors(self, name: str) -> Tuple[Optional[Layer], Optional[Layer]]:
        """(layer below, layer above) of ``name``; None at the ends."""
        i = self.index(name)
        below = self._layers[i - 1] if i > 0 else None
        above = self._layers[i + 1] if i + 1 < len(self._layers) else None
        return below, above

    def with_layer(self, name: str, **changes: Any) -> "LayerStack":
        """A copy with one layer's fields replaced (lengths in meters); z is not re-stacked."""
        new = LayerStack.__new__(LayerStack)
        new.frequency = self.frequency
        new._layers = [replace(layer, **changes) if layer.name == name else layer for layer in self._layers]
        return new

    def to_dict(self) -> Dict[str, Any]:
        return {"unit": "m", "frequency": self.frequency, "layers": [layer.to_dict() for layer in self._layers]}

    def summary(self) -> str:
        """One line per layer, top first, in millimeters."""
        lines = []
        for layer in reversed(self._layers):
            material = layer.material_dict(self.frequency)
            lines.append(f"{layer.name:<12} {layer.kind:<10} z {layer.z_min * 1e3:8.4f}..{layer.z_max * 1e3:8.4f} mm"
                         f"  t {layer.thickness * 1e3:.4g} mm  {material}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"LayerStack({', '.join(f'{l.name}:{l.kind}' for l in self._layers)})"


def _layer_from_spec(spec: LayerSpec, factor: float, z_default: float) -> Layer:
    if isinstance(spec, Layer):
        return spec
    if isinstance(spec, Mapping):
        data = dict(spec)
    elif isinstance(spec, Sequence) and not isinstance(spec, str) and 3 <= len(spec) <= 4:
        data = {"name": spec[0], "kind": spec[1], "thickness": spec[2]}
        if len(spec) == 4 and spec[3] is not None:
            if not isinstance(spec[3], Mapping):
                raise TypeError(f"layer properties must be a dict, got {spec[3]!r}")
            data.update(spec[3])
    else:
        raise TypeError(f"a layer is a Layer, a dict or (name, kind, thickness[, props]); got {spec!r}")
    unknown = set(data) - {"name", "kind", "thickness", "z_min", "material", "eps_r", "tan_delta", "sigma"}
    if unknown:
        raise ValueError(f"unknown layer fields {sorted(unknown)}")
    name = str(data.get("name") or "")
    if not name:
        raise ValueError("a layer needs a name")
    kind = data.get("kind")
    if kind not in KINDS:
        raise ValueError(f"layer {name!r}: kind must be one of {', '.join(KINDS)}; got {kind!r}")
    thickness = float(data["thickness"]) * factor
    if not thickness > 0 or not math.isfinite(thickness):
        raise ValueError(f"layer {name!r}: thickness must be positive, got {data['thickness']!r}")
    z_min = z_default if data.get("z_min") is None else float(data["z_min"]) * factor

    def number(key: str) -> Optional[float]:
        value = data.get(key)
        return None if value is None else float(value)

    material = data.get("material")
    if material is not None:
        from ..geometry import material_properties

        material_properties(material)  # refuse a bad material now
    return Layer(name, kind, z_min, thickness, material, number("eps_r"), number("tan_delta"), number("sigma"))
