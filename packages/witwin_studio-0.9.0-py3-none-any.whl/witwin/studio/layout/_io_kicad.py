"""``.kicad_pcb`` import with a small S-expression reader of our own (no dependency).

Read (KiCad 6 to 9 files; KiCad 5 ``module`` footprints and ``gr_arc`` with
``angle`` too):

- copper layers ``*.Cu`` in board order (F.Cu, In1.Cu, ..., B.Cu);
- tracks: ``segment`` and ``arc`` (round-capped, their width);
- ``via`` (through, blind and micro; drill and pad size, the two layers);
- ``zone`` fills: every ``filled_polygon``; a zone that was never filled
  uses its outline (warning). Keep-out / rule areas are skipped;
- footprint ``pad``: rect, roundrect, circle, oval, trapezoid (as its bounding
  rectangle, warning), custom (its anchor shape, warning); on the copper
  layers named in ``layers`` (``*.Cu`` = all); a plated drill becomes a via
  between the outer copper layers, a non-plated one a hole in the board;
- copper graphics, board-level (``gr_*``) and in footprints (``fp_*``):
  line, rect, circle, arc, poly;
- the board outline from ``Edge.Cuts`` graphics;
- the stack-up from ``(setup (stackup ...))`` when present (copper and
  dielectric layers with thickness, epsilon_r, loss_tangent); otherwise a
  guess from ``(general (thickness ...))``.

Not read: text, dimensions, silkscreen, solder mask and paste, net classes.
KiCad's y axis points down; it is flipped so the layout has y up, as seen
from the front.
"""
from __future__ import annotations

import math
import os
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

from ._imported import Imported
from ._layout import Layout
from ._stack import LayerStack

__all__ = ["parse_sexpr", "read_kicad_pcb"]

SExpr = Union[str, List["SExpr"]]
ARC_SEGMENTS = 64


def parse_sexpr(text: str) -> List[SExpr]:
    """Parse S-expressions into nested lists of strings (quotes removed, escapes resolved)."""
    stack: List[List[SExpr]] = [[]]
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c in " \t\r\n":
            i += 1
        elif c == "(":
            stack.append([])
            i += 1
        elif c == ")":
            if len(stack) == 1:
                raise ValueError(f"unbalanced ')' at offset {i}")
            done = stack.pop()
            stack[-1].append(done)
            i += 1
        elif c == '"':
            j = i + 1
            buf = []
            while j < n and text[j] != '"':
                if text[j] == "\\" and j + 1 < n:
                    j += 1
                    buf.append({"n": "\n", "t": "\t"}.get(text[j], text[j]))
                else:
                    buf.append(text[j])
                j += 1
            stack[-1].append("".join(buf))
            i = j + 1
        else:
            j = i
            while j < n and text[j] not in ' \t\r\n()"':
                j += 1
            stack[-1].append(text[i:j])
            i = j
    if len(stack) != 1:
        raise ValueError("unbalanced '(' in S-expression")
    return stack[0]


def _children(node: List[SExpr], name: str) -> List[List[SExpr]]:
    return [c for c in node[1:] if isinstance(c, list) and c and c[0] == name]


def _child(node: List[SExpr], name: str) -> Optional[List[SExpr]]:
    found = _children(node, name)
    return found[0] if found else None


def _nums(node: Optional[List[SExpr]], count: Optional[int] = None) -> List[float]:
    if node is None:
        return []
    out = []
    for v in node[1:]:
        if isinstance(v, str):
            try:
                out.append(float(v))
            except ValueError:
                continue
    return out[:count] if count else out


def _xy(node: Optional[List[SExpr]]) -> Optional[Tuple[float, float]]:
    vals = _nums(node, 2)
    return (vals[0], vals[1]) if len(vals) == 2 else None


def _layer_names(node: List[SExpr]) -> List[str]:
    names: List[str] = []
    for key in ("layer", "layers"):
        for item in _children(node, key):
            names.extend(v for v in item[1:] if isinstance(v, str))
    return names


def _copper_order(name: str) -> Tuple[int, int]:
    if name == "F.Cu":
        return (0, 0)
    if name == "B.Cu":
        return (2, 0)
    digits = "".join(ch for ch in name if ch.isdigit())
    return (1, int(digits or 0))


class _Frame:
    """A footprint placement: KiCad local coordinates -> layout coordinates (y up)."""

    def __init__(self, at: Sequence[float] = (0.0, 0.0, 0.0)):
        self.x, self.y = float(at[0]), float(at[1])
        self.angle = float(at[2]) if len(at) > 2 else 0.0

    def point(self, local: Tuple[float, float]) -> Tuple[float, float]:
        # Flip y first, then rotate CCW (KiCad angles are CCW as displayed).
        lx, ly = local[0], -local[1]
        a = math.radians(self.angle)
        return (self.x + lx * math.cos(a) - ly * math.sin(a), -self.y + lx * math.sin(a) + ly * math.cos(a))


_BOARD = _Frame()


def _arc3(a: Tuple[float, float], m: Tuple[float, float], b: Tuple[float, float]) -> List[Tuple[float, float]]:
    """Points along the circular arc from ``a`` through ``m`` to ``b``."""
    ax, ay = a
    bx, by = b
    mx, my = m
    d = 2 * (ax * (my - by) + mx * (by - ay) + bx * (ay - my))
    if abs(d) < 1e-12:
        return [a, b]
    ux = ((ax * ax + ay * ay) * (my - by) + (mx * mx + my * my) * (by - ay) + (bx * bx + by * by) * (ay - my)) / d
    uy = ((ax * ax + ay * ay) * (bx - mx) + (mx * mx + my * my) * (ax - bx) + (bx * bx + by * by) * (mx - ax)) / d
    r = math.hypot(ax - ux, ay - uy)
    a0 = math.atan2(ay - uy, ax - ux)
    am = math.atan2(my - uy, mx - ux)
    a1 = math.atan2(by - uy, bx - ux)

    def ccw(frm: float, to: float) -> float:
        s = to - frm
        while s < 0:
            s += 2 * math.pi
        return s

    sweep = ccw(a0, a1)
    if ccw(a0, am) > sweep:  # the mid point is on the other side: go clockwise
        sweep -= 2 * math.pi
    n = max(2, int(math.ceil(abs(sweep) / (2 * math.pi) * ARC_SEGMENTS)))
    pts = [(ux + r * math.cos(a0 + sweep * k / n), uy + r * math.sin(a0 + sweep * k / n)) for k in range(n + 1)]
    pts[0], pts[-1] = a, b
    return pts


def _arc_center(center: Tuple[float, float], start: Tuple[float, float], angle: float) -> List[Tuple[float, float]]:
    """KiCad 5 arc: center, start point and sweep in degrees (in layout space)."""
    r = math.hypot(start[0] - center[0], start[1] - center[1])
    a0 = math.atan2(start[1] - center[1], start[0] - center[0])
    sweep = math.radians(angle)
    n = max(2, int(math.ceil(abs(sweep) / (2 * math.pi) * ARC_SEGMENTS)))
    return [(center[0] + r * math.cos(a0 + sweep * k / n), center[1] + r * math.sin(a0 + sweep * k / n))
            for k in range(n + 1)]


def _graphic(node: List[SExpr], frame: _Frame, warnings: List[str]) -> Tuple[Optional[Any], Optional[Any]]:
    """(filled shape, centerline) of a gr_* / fp_* item in layout coordinates."""
    from shapely.geometry import LineString, Point, Polygon

    kind = str(node[0])[3:]
    width = 0.0
    stroke = _child(node, "stroke")
    if stroke is not None:
        width = (_nums(_child(stroke, "width"), 1) or [0.0])[0]
    else:
        width = (_nums(_child(node, "width"), 1) or [0.0])[0]
    fill_node = _child(node, "fill")
    filled = fill_node is not None and len(fill_node) > 1 and fill_node[1] in ("solid", "yes")
    start, end = _xy(_child(node, "start")), _xy(_child(node, "end"))
    line = None
    area = None
    if kind == "line" and start and end:
        line = LineString([frame.point(start), frame.point(end)])
    elif kind == "arc" and start and end:
        mid = _xy(_child(node, "mid"))
        if mid:
            line = LineString(_arc3(frame.point(start), frame.point(mid), frame.point(end)))
        else:  # KiCad 5: (start center) (end arc-start) (angle deg); y flipped -> angle sign flips
            angle = (_nums(_child(node, "angle"), 1) or [0.0])[0]
            line = LineString(_arc_center(frame.point(start), frame.point(end), -angle))
    elif kind == "rect" and start and end:
        corners = [start, (end[0], start[1]), end, (start[0], end[1])]
        ring = [frame.point(c) for c in corners]
        area = Polygon(ring) if filled else None
        line = LineString(ring + [ring[0]])
    elif kind == "circle":
        center = _xy(_child(node, "center")) or start
        if center and end:
            c = frame.point(center)
            r = math.hypot(end[0] - center[0], end[1] - center[1])
            disk = Point(c).buffer(r, quad_segs=16)
            area = disk if filled else None
            line = LineString(list(disk.exterior.coords))
    elif kind == "poly":
        pts = [frame.point(_xy(p)) for p in _children(_child(node, "pts") or ["pts"], "xy")]  # type: ignore[arg-type]
        if len(pts) >= 3:
            # A footprint/board polygon is filled unless (fill none) says otherwise.
            area = Polygon(pts) if (fill_node is None or filled) else None
            line = LineString(pts + [pts[0]])
    else:
        return None, None
    shape = area
    if line is not None and width > 0:
        stroke_shape = line.buffer(width / 2.0, quad_segs=8)
        shape = stroke_shape if shape is None else shape.union(stroke_shape)
    return shape, line


def _pad_shape(pad: List[SExpr], frame: _Frame, warnings: List[str]) -> Optional[Any]:
    from shapely import affinity
    from shapely.geometry import LineString, Point, box

    shape_kind = str(pad[3]) if len(pad) > 3 else "rect"
    at = _nums(_child(pad, "at"))
    size = _nums(_child(pad, "size"), 2)
    if len(at) < 2 or len(size) < 2:
        return None
    w, h = size
    if shape_kind == "circle":
        local = Point(0, 0).buffer(w / 2.0, quad_segs=16)
    elif shape_kind == "oval":
        if w >= h:
            local = LineString([(-(w - h) / 2, 0), ((w - h) / 2, 0)]).buffer(h / 2, quad_segs=16) if w > h \
                else Point(0, 0).buffer(w / 2, quad_segs=16)
        else:
            local = LineString([(0, -(h - w) / 2), (0, (h - w) / 2)]).buffer(w / 2, quad_segs=16)
    elif shape_kind == "roundrect":
        ratio = (_nums(_child(pad, "roundrect_rratio"), 1) or [0.25])[0]
        r = min(w, h) * ratio
        inner = box(-w / 2 + r, -h / 2 + r, w / 2 - r, h / 2 - r) if r > 0 else box(-w / 2, -h / 2, w / 2, h / 2)
        local = inner.buffer(r, quad_segs=8) if r > 0 else inner
    else:
        if shape_kind not in ("rect",):
            warnings.append(f"pad shape {shape_kind!r} read as its {w} x {h} rectangle")
        local = box(-w / 2, -h / 2, w / 2, h / 2)
    # Pad angle in the file is absolute (it includes the footprint's rotation).
    angle = at[2] if len(at) > 2 else 0.0
    shape = affinity.rotate(local, angle, origin=(0, 0))
    cx, cy = frame.point((at[0], at[1]))
    return affinity.translate(shape, cx, cy)


def read_kicad_pcb(path: Any, *, default_thickness: float = 1.6, default_copper: float = 0.035,
                   eps_r: float = 4.5, tan_delta: float = 0.02) -> Imported:
    """Read a ``.kicad_pcb`` board into a Layout (mm) and its stack-up.

    Without a ``stackup`` section the stack is guessed from the board
    thickness (``general``/``thickness`` or ``default_thickness``) with
    ``default_copper`` copper and cores of ``eps_r`` / ``tan_delta``; the
    same values fill in fields a stackup leaves out.
    """
    import shapely
    from shapely.geometry import LineString, Point

    from ._io_gerber import guess_board_stack, outline_from_lines
    from ._shapes import circle

    with open(os.fspath(path), "r", encoding="utf-8") as fh:
        tree = parse_sexpr(fh.read())
    board = next((n for n in tree if isinstance(n, list) and n and n[0] == "kicad_pcb"), None)
    if board is None:
        raise ValueError(f"{path} is not a kicad_pcb file")
    warnings: List[str] = []
    notes = set()

    def warn(msg: str) -> None:
        if msg not in notes:
            notes.add(msg)
            warnings.append(msg)

    copper = []
    layers_node = _child(board, "layers")
    for item in (layers_node or [])[1:]:
        if isinstance(item, list) and len(item) >= 2 and str(item[1]).endswith(".Cu"):
            copper.append(str(item[1]))
    if not copper:
        copper = ["F.Cu", "B.Cu"]
    copper.sort(key=_copper_order)

    def expand(names: Sequence[str]) -> List[str]:
        out: List[str] = []
        for n in names:
            if n in ("*.Cu", "F&B.Cu"):
                out.extend(copper if n == "*.Cu" else ["F.Cu", "B.Cu"])
            elif n in copper:
                out.append(n)
        return out

    lay = Layout(unit="mm")
    edge_lines: List[Any] = []
    edge_areas: List[Any] = []
    npth: List[Any] = []

    def add_graphic(node: List[SExpr], frame: _Frame) -> None:
        names = _layer_names(node)
        if not names:
            return
        if "Edge.Cuts" in names:
            area, line = _graphic(node, frame, warnings)
            if line is not None:
                edge_lines.append(line)
            return
        targets = expand(names)
        if not targets:
            return
        shape, _ = _graphic(node, frame, warnings)
        if shape is not None and not shape.is_empty:
            for name in targets:
                lay.add(name, shape)

    for node in board[1:]:
        if not isinstance(node, list) or not node:
            continue
        head = node[0]
        if head == "segment" or head == "arc":
            start, end = _xy(_child(node, "start")), _xy(_child(node, "end"))
            width = (_nums(_child(node, "width"), 1) or [0.0])[0]
            if not start or not end or width <= 0:
                continue
            if head == "arc":
                mid = _xy(_child(node, "mid"))
                pts = _arc3(_BOARD.point(start), _BOARD.point(mid), _BOARD.point(end)) if mid \
                    else [_BOARD.point(start), _BOARD.point(end)]
            else:
                pts = [_BOARD.point(start), _BOARD.point(end)]
            line = LineString(pts)
            shape = line.buffer(width / 2.0, quad_segs=8) if line.length else Point(pts[0]).buffer(width / 2.0)
            for name in expand(_layer_names(node)):
                lay.add(name, shape)
        elif head == "via":
            at = _xy(_child(node, "at"))
            size = (_nums(_child(node, "size"), 1) or [0.0])[0]
            drill = (_nums(_child(node, "drill"), 1) or [0.0])[0]
            names = expand(_layer_names(node))
            if not at or drill <= 0 or len(names) < 2:
                warn("a via without position, drill or two copper layers was skipped")
                continue
            names.sort(key=_copper_order)
            lay.via(_BOARD.point(at), drill=drill, pad=size if size >= drill else None,
                    from_layer=names[0], to_layer=names[-1])
        elif head == "zone":
            if _child(node, "keepout") is not None:
                warn("keep-out / rule-area zones were skipped")
                continue
            fills = _children(node, "filled_polygon")
            if fills:
                for fp in fills:
                    pts = [_BOARD.point(_xy(p)) for p in _children(_child(fp, "pts") or ["pts"], "xy")]  # type: ignore[arg-type]
                    names = expand(_layer_names(fp)) or expand(_layer_names(node))
                    if len(pts) >= 3:
                        from ._shapes import polygon

                        for name in names:
                            lay.add(name, polygon(pts))
            else:
                outline = _child(node, "polygon")
                pts = [_BOARD.point(_xy(p)) for p in _children(_child(outline, "pts") or ["pts"], "xy")] \
                    if outline else []  # type: ignore[arg-type]
                if len(pts) >= 3:
                    warn("a zone was never filled (run Fill All Zones in KiCad); its outline is used")
                    from ._shapes import polygon

                    for name in expand(_layer_names(node)):
                        lay.add(name, polygon(pts))
        elif head in ("footprint", "module"):
            frame = _Frame(_nums(_child(node, "at")) or (0.0, 0.0))
            for item in node[1:]:
                if not isinstance(item, list) or not item:
                    continue
                if item[0] == "pad":
                    pad_type = str(item[2]) if len(item) > 2 else ""
                    if len(item) > 3 and item[3] == "custom":
                        warn("custom pads are read as their anchor shape only")
                    shape = _pad_shape(item, frame, warnings)
                    names = expand(_layer_names(item))
                    if shape is not None:
                        for name in names:
                            lay.add(name, shape)
                    drill_node = _child(item, "drill")
                    if drill_node is not None and pad_type in ("thru_hole", "np_thru_hole"):
                        vals = _nums(drill_node)
                        if "oval" in drill_node:
                            warn("oval drills are read as round holes of their smaller size")
                            vals = [min(vals[:2])] if len(vals) >= 2 else vals
                        if not vals or vals[0] <= 0:
                            continue
                        at = _nums(_child(item, "at"))
                        center = frame.point((at[0], at[1]))
                        offset = _child(drill_node, "offset")
                        if offset is not None:
                            warn("drill offsets are ignored")
                        if pad_type == "np_thru_hole":
                            npth.append(circle(vals[0] / 2.0, center=center, segments=32))
                        elif len(copper) > 1:
                            lay.via(center, drill=vals[0], from_layer=copper[0], to_layer=copper[-1])
                elif str(item[0]).startswith("fp_"):
                    add_graphic(item, frame)
        elif str(head).startswith("gr_"):
            add_graphic(node, _BOARD)

    if edge_lines:
        outline = outline_from_lines(edge_lines, warnings)
        if outline is not None:
            lay.outline = outline
    else:
        warn("no Edge.Cuts outline: the board is the bounding box of the copper")
    if npth:
        holes = shapely.union_all(npth)
        lay.outline = lay.outline.difference(holes)
        for name in copper:
            lay.cut(name, holes)

    # Stack-up.
    general = _child(board, "general")
    board_thickness = (_nums(_child(general, "thickness"), 1) or [default_thickness])[0] if general else default_thickness
    setup = _child(board, "setup")
    stackup = _child(setup, "stackup") if setup else None
    stack = None
    if stackup is not None:
        specs: List[Any] = []
        for item in _children(stackup, "layer"):
            name = str(item[1])
            kind = str((_child(item, "type") or ["type", ""])[1]).lower()
            thickness = (_nums(_child(item, "thickness"), 1) or [0.0])[0]
            if kind == "copper" and name in copper:
                specs.append((name, "conductor", thickness or default_copper))
            elif kind in ("core", "prepreg") and thickness > 0:
                er = (_nums(_child(item, "epsilon_r"), 1) or [eps_r])[0]
                td = (_nums(_child(item, "loss_tangent"), 1) or [tan_delta])[0]
                props: Dict[str, Any] = {"eps_r": er, "tan_delta": td}
                specs.append((name.replace(" ", "_"), "dielectric", thickness, props))
                if len(_children(item, "addsublayer")) or "addsublayer" in item:
                    warn(f"dielectric {name!r} has sub-layers; only the first is read")
            elif kind:
                warn(f"stack-up layer {name!r} ({kind}) is not modeled")
        if [s[0] for s in specs if s[1] == "conductor"] == copper:
            stack = LayerStack(list(reversed(specs)), unit="mm")
        else:
            warn("the stack-up does not list every copper layer; guessing the stack")
    if stack is None:
        stack = guess_board_stack(copper, thickness=board_thickness, copper_thickness=default_copper,
                                  eps_r=eps_r, tan_delta=tan_delta)
        warn(f"no stack-up in the file: guessed {board_thickness} mm board, {default_copper} mm copper, "
             f"eps_r {eps_r}")
    return Imported(lay, stack, warnings)
