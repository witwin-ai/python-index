"""Top view of a ``Layout`` as PNG: numpy + Pillow, no GL.

The image is for an agent (or a person) to check a layout at a glance:
layer fills in fixed colors, drills dark, ports as labelled arrows, a legend
and a scale line. +y points up in the image, as in the layout.
"""
from __future__ import annotations

import io
import math
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence, Tuple, Union

if TYPE_CHECKING:  # pragma: no cover
    from ._layout import Layout
    from ._stack import LayerStack

__all__ = ["top_view"]

# allow-color: image palette for a rendered PNG, not UI chrome.
_PALETTE = [
    (214, 120, 40), (40, 120, 214), (60, 170, 90), (190, 60, 160), (200, 180, 40),
    (60, 180, 190), (150, 90, 50), (120, 120, 200),
]
_DIELECTRIC = (120, 150, 110)
_BACKGROUND = (250, 250, 250)
_INK = (20, 20, 20)
_DRILL = (40, 40, 40)
_PORT = (200, 20, 20)


def _mask(geom: Any, to_px, size: Tuple[int, int]):
    """8-bit coverage mask of a (multi)polygon; holes and islands-in-holes handled."""
    from PIL import Image, ImageDraw

    from ._extrude import polygons_of

    img = Image.new("L", size, 0)
    draw = ImageDraw.Draw(img)
    # Larger polygons first: an island inside another polygon's hole is drawn
    # after the hole is cleared.
    for poly in sorted(polygons_of(geom), key=lambda p: -p.area):
        draw.polygon([to_px(x, y) for x, y in poly.exterior.coords], fill=255)
        for hole in poly.interiors:
            draw.polygon([to_px(x, y) for x, y in hole.coords], fill=0)
    return img


def _nice_length(target: float) -> float:
    if target <= 0:
        return 0.0
    exp = math.floor(math.log10(target))
    for m in (5, 2, 1):
        if m * 10 ** exp <= target:
            return m * 10 ** exp
    return 10 ** exp


def _render(layout: "Layout", geoms: Dict[str, Any], kinds: Dict[str, str], size: int, labels: bool,
            title: Optional[str]) -> bytes:
    from PIL import Image, ImageDraw, ImageFont

    bounds = None
    for geom in geoms.values():
        if geom.is_empty:
            continue
        b = geom.bounds
        bounds = b if bounds is None else (min(bounds[0], b[0]), min(bounds[1], b[1]),
                                           max(bounds[2], b[2]), max(bounds[3], b[3]))
    if bounds is None:
        bounds = layout.bounds or (0.0, 0.0, 1.0, 1.0)
    x0, y0, x1, y1 = bounds
    w, h = max(x1 - x0, 1e-12), max(y1 - y0, 1e-12)
    margin = 24
    legend_h = (18 * (len(geoms) + 1) + 8) if labels else 0
    scale = (size - 2 * margin) / max(w, h)
    width = int(math.ceil(w * scale)) + 2 * margin
    height = int(math.ceil(h * scale)) + 2 * margin + legend_h

    def to_px(x: float, y: float) -> Tuple[float, float]:
        return (margin + (x - x0) * scale, margin + (y1 - y) * scale)

    canvas = Image.new("RGB", (width, height), _BACKGROUND)
    order = list(geoms)
    colors: Dict[str, Tuple[int, int, int]] = {}
    k = 0
    for name in order:
        if kinds.get(name) == "dielectric":
            colors[name] = _DIELECTRIC
        else:
            colors[name] = _PALETTE[k % len(_PALETTE)]
            k += 1
    for name in order:
        geom = geoms[name]
        if geom.is_empty:
            continue
        alpha = 70 if kinds.get(name) == "dielectric" else (230 if len(order) == 1 else 150)
        mask = _mask(geom, to_px, canvas.size).point(lambda v, a=alpha: v * a // 255)
        canvas.paste(Image.new("RGB", canvas.size, colors[name]), (0, 0), mask)

    draw = ImageDraw.Draw(canvas)
    from ._extrude import polygons_of

    # Opaque edges keep every layer readable where translucent fills overlap.
    for name in order:
        for poly in polygons_of(geoms[name]):
            for ring in [poly.exterior, *poly.interiors]:
                draw.line([to_px(x, y) for x, y in ring.coords], fill=colors[name], width=1)
    font = ImageFont.load_default()
    for via in layout.vias:
        cx, cy = to_px(*via.position)
        r = max(1.5, via.drill / 2.0 * scale)
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=_DRILL)
    if labels:
        for port in layout.ports.values():
            px, py = to_px(*port.point)
            draw.ellipse([px - 4, py - 4, px + 4, py + 4], outline=_PORT, width=2)
            if port.direction is not None:
                L = 22
                ex, ey = px + port.direction[0] * L, py - port.direction[1] * L
                draw.line([px, py, ex, ey], fill=_PORT, width=2)
            draw.text((px + 6, py + 4), port.name, fill=_PORT, font=font)
        # Legend and scale line under the drawing.
        ly = height - legend_h + 4
        for name in order:
            draw.rectangle([margin, ly + 2, margin + 12, ly + 12], fill=colors[name])
            draw.text((margin + 18, ly), f"{name} ({kinds.get(name, 'layer')})", fill=_INK, font=font)
            ly += 18
        bar = _nice_length(w / 4.0)
        bx = margin
        draw.line([bx, ly + 8, bx + bar * scale, ly + 8], fill=_INK, width=2)
        text = f"{bar:g} {layout.unit}" + (f"   {title}" if title else "")
        draw.text((bx + bar * scale + 8, ly + 2), text, fill=_INK, font=font)
    buf = io.BytesIO()
    canvas.save(buf, format="PNG")
    return buf.getvalue()


def top_view(layout: "Layout", target: Any = None, *, stack: Optional["LayerStack"] = None,
             layers: Optional[Sequence[str]] = None, size: int = 1024, per_layer: bool = False,
             labels: bool = True) -> Union[bytes, Dict[str, bytes]]:
    """Render ``layout`` seen from above as PNG.

    - ``stack`` given: layers are drawn as built (ground fills, via pads,
      drilled dielectrics), bottom first. Without it, only drawn shapes.
    - ``layers``: names to draw; default all.
    - ``per_layer=False``: one combined image. ``target`` is a file path, a
      writable binary file object, or None; returns the PNG bytes.
    - ``per_layer=True``: one image per layer. ``target`` is a directory
      (created if missing; files ``<layer>.png``) or None; returns
      ``{layer: png_bytes}``.
    - ``size``: pixels along the longer side of the drawing.
    """
    try:
        import PIL  # noqa: F401
    except ImportError as exc:
        raise ImportError("layout.top_view needs Pillow (pip install pillow)") from exc

    if stack is not None:
        resolved = layout.resolve(stack)
        geoms = {layer.name: resolved[layer.name] for layer in stack}
        kinds = {layer.name: layer.kind for layer in stack}
    else:
        geoms = {name: layout.shapes(name) for name in layout.layers}
        kinds = {}
    if layers is not None:
        missing = [n for n in layers if n not in geoms]
        if missing:
            raise KeyError(f"no layers {missing}; have {list(geoms)}")
        geoms = {n: geoms[n] for n in layers}
    geoms = {n: g for n, g in geoms.items() if not g.is_empty}

    if per_layer:
        out = {name: _render(layout, {name: geom}, kinds, size, labels, None) for name, geom in geoms.items()}
        if target is not None:
            folder = Path(target)
            folder.mkdir(parents=True, exist_ok=True)
            for name, data in out.items():
                safe = "".join(c if c.isalnum() or c in "-_." else "_" for c in name)
                (folder / f"{safe}.png").write_bytes(data)
        return out
    data = _render(layout, geoms, kinds, size, labels, None)
    if target is not None:
        if hasattr(target, "write"):
            target.write(data)
        else:
            Path(os.fspath(target)).write_bytes(data)
    return data
