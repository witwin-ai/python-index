"""2.5D layered layouts: PCB, microstrip, on-chip structures, metasurface cells.

    from witwin.studio import layout as L

    stack = L.LayerStack.fr4(substrate=1.6, copper=0.035, unit="mm", frequency=2.45e9)
    lay = L.Layout(unit="mm", outline=L.rect(80, 80))
    lay.add("top", L.rect(37.3, 28.8))                         # patch
    lay.add("top", L.path([(0, -14.4), (0, -40)], width=3.06)) # 50 ohm feed
    lay.port("feed", "top", (0, -40), direction=(0, -1), reference="bottom")
    bodies = lay.to_bodies(stack)       # ws.Body list, meters: slab, sheets, vias
    lay.top_view("layout.png", stack=stack)
    lay.add_to_scene(scene, stack, grid=0.5e-3)

Shapes are shapely polygons in the Layout's unit; the stack and every built
body are in meters. Thin conductors (below the grid step, or 100 um without a
grid) are built as ``fill="surface"`` sheets carrying their real thickness.

Importers return ``Imported(layout, stack, warnings)``: ``read_gds`` /
``read_oasis`` (gdstk), ``read_gerber`` (own RS-274X + Excellon reader),
``read_kicad_pcb`` (own S-expression reader) and ``read_dxf`` (ezdxf).
Exporters: ``write_gds`` and ``write_dxf``.

shapely is required (``pip install "witwin-studio[layout]"``); numpy,
Pillow, gdstk, ezdxf, mapbox_earcut and matplotlib (``text``) load only when
used. Importing this package loads none of them. Design:
``dev_docs/backend/LAYOUT_LIBRARY.md``.
"""
from __future__ import annotations

from ._imported import Imported
from ._io_dxf import read_dxf, write_dxf
from ._io_gds import read_gds, write_gds
from ._io_gerber import read_gerber
from ._io_kicad import read_kicad_pcb
from ._layout import DEFAULT_SURFACE_BELOW, LayerBody, Layout, Port, Via
from ._render import top_view
from ._shapes import arc_ring, array, boolean, circle, clean, mirror, move, offset, path, polygon, rect, rotate, text
from ._stack import KINDS, Layer, LayerStack


def read_oasis(path, **kwargs) -> Imported:
    """OASIS file -> ``Imported``; same keyword arguments as ``read_gds``."""
    return read_gds(path, oasis=True, **kwargs)


__all__ = [
    "DEFAULT_SURFACE_BELOW",
    "Imported",
    "KINDS",
    "Layer",
    "LayerBody",
    "LayerStack",
    "Layout",
    "Port",
    "Via",
    "arc_ring",
    "array",
    "boolean",
    "circle",
    "clean",
    "mirror",
    "move",
    "offset",
    "path",
    "polygon",
    "read_dxf",
    "read_gds",
    "read_gerber",
    "read_kicad_pcb",
    "read_oasis",
    "rect",
    "rotate",
    "text",
    "top_view",
    "write_dxf",
    "write_gds",
]
