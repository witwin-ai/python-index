"""2D layout primitives. Every function returns a shapely ``Polygon`` or ``MultiPolygon``.

Coordinates are in the unit of the ``Layout`` the shape is added to (the
functions themselves are unit-free). Angles are in degrees. Because the
results are plain shapely geometry, any shapely operation works on them too.

shapely is imported inside each function so ``import witwin.studio.layout``
stays light.
"""
from __future__ import annotations

import math
from typing import Any, Iterable, Optional, Sequence, Tuple, Union

__all__ = [
    "arc_ring", "array", "boolean", "circle", "clean", "mirror", "move", "offset", "path", "polygon",
    "rect", "rotate", "text",
]

Point2 = Tuple[float, float]

# Segments of a full circle. 64 keeps a 10 mm patch radius within 0.012 mm of
# the true circle; drills and pads usually pass ``segments`` explicitly.
DEFAULT_SEGMENTS = 64


def _quad_segs(segments: int) -> int:
    # shapely counts segments per quarter circle.
    return max(1, int(round(int(segments) / 4)))


def rect(width: float, height: float, *, center: Point2 = (0.0, 0.0)):
    """Axis-aligned rectangle of ``width`` x ``height`` centered on ``center``."""
    from shapely.geometry import box

    if not (width > 0 and height > 0):
        raise ValueError(f"rect needs a positive width and height, got {width!r} x {height!r}")
    cx, cy = (float(v) for v in center)
    return box(cx - width / 2.0, cy - height / 2.0, cx + width / 2.0, cy + height / 2.0)


def polygon(points: Sequence[Point2], holes: Iterable[Sequence[Point2]] = ()):
    """Polygon from its outline and optional holes; self-intersections are repaired."""
    from shapely.geometry import Polygon

    shape = Polygon([tuple(map(float, p)) for p in points], [[tuple(map(float, p)) for p in h] for h in holes])
    return clean(shape)


def circle(radius: float, *, center: Point2 = (0.0, 0.0), segments: int = DEFAULT_SEGMENTS):
    """Regular ``segments``-gon inscribed in a circle of ``radius``."""
    from shapely.geometry import Point

    if not radius > 0:
        raise ValueError(f"circle radius must be positive, got {radius!r}")
    return Point(float(center[0]), float(center[1])).buffer(float(radius), quad_segs=_quad_segs(segments))


def arc_ring(inner: float, outer: float, *, start: float = 0.0, end: float = 360.0,
             center: Point2 = (0.0, 0.0), segments: int = DEFAULT_SEGMENTS):
    """Annulus sector between radii ``inner`` and ``outer``, from ``start`` to ``end`` degrees (CCW).

    ``inner=0`` gives a pie slice; a full 360 degree sweep gives a ring.
    """
    from shapely.geometry import Polygon

    if not (0 <= inner < outer):
        raise ValueError(f"arc_ring needs 0 <= inner < outer, got {inner!r}, {outer!r}")
    sweep = float(end) - float(start)
    if sweep <= 0:
        raise ValueError(f"arc_ring needs end > start, got {start!r}..{end!r}")
    cx, cy = (float(v) for v in center)
    if sweep >= 360.0:
        ring = circle(outer, center=center, segments=segments)
        return ring.difference(circle(inner, center=center, segments=segments)) if inner > 0 else ring
    n = max(2, int(math.ceil(segments * sweep / 360.0)))
    angles = [math.radians(start + sweep * i / n) for i in range(n + 1)]
    outer_pts = [(cx + outer * math.cos(a), cy + outer * math.sin(a)) for a in angles]
    if inner > 0:
        inner_pts = [(cx + inner * math.cos(a), cy + inner * math.sin(a)) for a in reversed(angles)]
    else:
        inner_pts = [(cx, cy)]
    return clean(Polygon(outer_pts + inner_pts))


def path(points: Sequence[Point2], width: float, *, corner: str = "miter", end: str = "flat",
         segments: int = DEFAULT_SEGMENTS):
    """A trace of ``width`` along ``points``.

    ``corner``: ``"miter"`` (sharp bends, the usual microstrip corner before
    chamfering) or ``"round"``. ``end``: ``"flat"`` (the trace stops at the
    first and last point, as a microstrip port wants), ``"square"`` (extends
    by width/2) or ``"round"``.
    """
    from shapely.geometry import LineString

    if not width > 0:
        raise ValueError(f"path width must be positive, got {width!r}")
    joins = {"miter": "mitre", "round": "round", "bevel": "bevel"}
    caps = {"flat": "flat", "square": "square", "round": "round"}
    if corner not in joins:
        raise ValueError(f"corner must be one of miter, round, bevel; got {corner!r}")
    if end not in caps:
        raise ValueError(f"end must be one of flat, square, round; got {end!r}")
    pts = [tuple(map(float, p)) for p in points]
    if len(pts) < 2:
        raise ValueError("a path needs at least two points")
    # mitre_limit 10: a 90 degree bend is sqrt(2) and stays sharp; only very
    # acute bends (< ~11 degrees) get beveled instead of a long spike.
    return clean(LineString(pts).buffer(width / 2.0, quad_segs=_quad_segs(segments), cap_style=caps[end],
                                        join_style=joins[corner], mitre_limit=10.0))


def boolean(a: Any, b: Any, op: str = "union"):
    """``union`` / ``difference`` (a - b) / ``intersection`` / ``xor`` of two shapes."""
    ops = {"union": "union", "or": "union", "difference": "difference", "not": "difference", "sub": "difference",
           "intersection": "intersection", "and": "intersection", "xor": "symmetric_difference"}
    if op not in ops:
        raise ValueError(f"op must be union, difference, intersection or xor; got {op!r}")
    return clean(getattr(a, ops[op])(b))


def offset(shape: Any, distance: float, *, corner: str = "miter", segments: int = DEFAULT_SEGMENTS):
    """Grow (``distance`` > 0) or shrink (< 0) a shape: clearances, CPW gaps, slots."""
    joins = {"miter": "mitre", "round": "round", "bevel": "bevel"}
    if corner not in joins:
        raise ValueError(f"corner must be one of miter, round, bevel; got {corner!r}")
    return clean(shape.buffer(float(distance), quad_segs=_quad_segs(segments), join_style=joins[corner],
                              mitre_limit=10.0))


def move(shape: Any, dx: float = 0.0, dy: float = 0.0):
    """The shape translated by (dx, dy)."""
    from shapely import affinity

    return affinity.translate(shape, xoff=float(dx), yoff=float(dy))


def rotate(shape: Any, angle: float, *, origin: Union[str, Point2] = (0.0, 0.0)):
    """The shape rotated CCW by ``angle`` degrees about ``origin`` (a point or ``"center"``)."""
    from shapely import affinity

    return affinity.rotate(shape, float(angle), origin=origin if isinstance(origin, str) else tuple(origin))


def mirror(shape: Any, *, axis: str = "y", origin: Point2 = (0.0, 0.0)):
    """The shape mirrored across the vertical (``axis="y"``) or horizontal (``"x"``) line through ``origin``."""
    from shapely import affinity

    if axis not in ("x", "y"):
        raise ValueError("axis must be 'x' or 'y'")
    fx, fy = (-1.0, 1.0) if axis == "y" else (1.0, -1.0)
    return affinity.scale(shape, xfact=fx, yfact=fy, origin=(float(origin[0]), float(origin[1])))


def array(shape: Any, nx: int, ny: int = 1, pitch: Union[float, Sequence[float]] = 1.0, *,
          centered: bool = False):
    """``nx`` x ``ny`` copies of ``shape`` at ``pitch`` (one number or (px, py)), unioned.

    Copies start at the shape's own position and go +x, +y. ``centered=True``
    shifts the grid so its center is where the shape was.
    """
    from shapely.ops import unary_union

    nx, ny = int(nx), int(ny)
    if nx < 1 or ny < 1:
        raise ValueError("array needs nx >= 1 and ny >= 1")
    if isinstance(pitch, (int, float)):
        px = py = float(pitch)
    else:
        px, py = (float(v) for v in pitch)
    x0 = -(nx - 1) * px / 2.0 if centered else 0.0
    y0 = -(ny - 1) * py / 2.0 if centered else 0.0
    copies = [move(shape, x0 + i * px, y0 + j * py) for j in range(ny) for i in range(nx)]
    return clean(unary_union(copies))


def text(value: str, size: float, *, position: Point2 = (0.0, 0.0), font: Optional[str] = None):
    """Text outlines of height ``size`` (cap height of the font), lower-left at ``position``.

    Glyphs come from matplotlib's bundled DejaVu Sans (Bitstream Vera /
    DejaVu license, permissive); matplotlib is imported here only. Raises
    ``ImportError`` when matplotlib is missing. ``font`` is a font family
    name matplotlib can find.
    """
    try:
        from matplotlib.font_manager import FontProperties
        from matplotlib.textpath import TextPath
    except ImportError as exc:
        raise ImportError("layout.text needs matplotlib (its bundled DejaVu font supplies the glyphs)") from exc
    from shapely.geometry import Polygon
    from shapely.ops import unary_union

    if not size > 0:
        raise ValueError("text size must be positive")
    props = FontProperties(family=font or "DejaVu Sans")
    # TextPath(size=s): s is the em size; DejaVu's cap height is 0.729 em.
    tp = TextPath((0.0, 0.0), value, size=1.0, prop=props)
    rings = [ring for ring in tp.to_polygons(closed_only=True) if len(ring) >= 3]
    if not rings:
        raise ValueError(f"text {value!r} has no outlines")
    # Glyph contours nest (an "o" is an outer and an inner ring): even-odd fill.
    result = None
    for ring in rings:
        poly = Polygon(ring).buffer(0)
        result = poly if result is None else result.symmetric_difference(poly)
    scale = float(size) / 0.729
    from shapely import affinity

    result = affinity.scale(unary_union([result]), xfact=scale, yfact=scale, origin=(0.0, 0.0))
    return clean(move(result, float(position[0]), float(position[1])))


def clean(shape: Any):
    """Valid polygonal part of ``shape``: repairs self-intersections, drops lines and points.

    Returns a ``Polygon`` or ``MultiPolygon`` (possibly empty).
    """
    import shapely
    from shapely.geometry import GeometryCollection, MultiPolygon, Polygon

    if shape is None:
        return Polygon()
    if not shape.is_valid:
        shape = shapely.make_valid(shape)
    if isinstance(shape, (Polygon, MultiPolygon)):
        return shape
    if isinstance(shape, GeometryCollection) or hasattr(shape, "geoms"):
        polys = []
        for part in shape.geoms:
            part = clean(part)
            polys.extend(part.geoms if isinstance(part, MultiPolygon) else [part])
        polys = [p for p in polys if not p.is_empty]
        if not polys:
            return Polygon()
        return polys[0] if len(polys) == 1 else shapely.union_all(polys)
    return Polygon()
