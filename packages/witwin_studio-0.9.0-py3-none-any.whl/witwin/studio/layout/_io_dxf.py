"""DXF import and export through ezdxf (MIT license).

Import reads model space, expanding block references (INSERT). Per DXF
layer, closed curves (LWPOLYLINE / POLYLINE with the closed flag or equal
ends, CIRCLE, closed ELLIPSE and SPLINE) become polygons; open curves (LINE,
ARC, open polylines, open splines) are joined into loops where their ends
meet. All loops of a layer are combined even-odd, so a loop inside another
is a hole. Curves are flattened to a chord error of ``tolerance``. HATCH,
TEXT, DIMENSION and 3D entities are skipped (warning).

Units come from ``$INSUNITS`` (inch, foot, mm, cm, m, um, nm); unitless
files are read as millimeters (warning).
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Mapping, Optional

from ._imported import Imported
from ._layout import Layout
from ._stack import LayerStack

__all__ = ["read_dxf", "write_dxf"]

# $INSUNITS code -> millimeters per drawing unit.
_INSUNITS_MM = {1: 25.4, 2: 304.8, 4: 1.0, 5: 10.0, 6: 1000.0, 13: 1e-3, 12: 1e-6, 9: 0.0254, 14: 100.0}
# Layout unit -> $INSUNITS code.
_UNIT_CODE = {"mm": 4, "m": 6, "um": 13, "nm": 12}

_CURVES = {"LINE", "ARC", "CIRCLE", "LWPOLYLINE", "POLYLINE", "ELLIPSE", "SPLINE"}


def _ezdxf():
    try:
        import ezdxf
    except ImportError as exc:
        raise ImportError('DXF needs ezdxf: pip install "witwin-studio[layout]"') from exc
    return ezdxf


def _entities(container: Any, depth: int = 0):
    for e in container:
        if e.dxftype() == "INSERT" and depth < 8:
            yield from _entities(e.virtual_entities(), depth + 1)
        else:
            yield e


def read_dxf(path: Any, *, layer_map: Optional[Mapping[str, str]] = None, skip_unmapped: bool = False,
             tolerance: float = 0.01, thickness: float = 1.6, copper_thickness: float = 0.035,
             eps_r: float = 4.4, tan_delta: float = 0.02) -> Imported:
    """Read a DXF drawing into a Layout in millimeters.

    ``layer_map`` maps DXF layer names to layout layer names; other layers
    keep their DXF name unless ``skip_unmapped``. ``tolerance`` is the chord
    error for arcs and splines in mm. The stack is a guess: the layers (in
    first-seen order, top first) as copper on a board of ``thickness``, see
    ``_io_gerber.guess_board_stack``.
    """
    ezdxf = _ezdxf()
    import shapely
    from ezdxf import path as dxf_path
    from shapely.geometry import LineString, Polygon
    from shapely.ops import polygonize

    from ._shapes import clean

    doc = ezdxf.readfile(os.fspath(path))
    warnings: List[str] = []
    code = int(doc.header.get("$INSUNITS", 0) or 0)
    scale = _INSUNITS_MM.get(code)
    if scale is None:
        scale = 1.0
        warnings.append(f"$INSUNITS={code} is unitless or unknown; read as millimeters")
    tol = tolerance / scale  # in drawing units
    closed: Dict[str, List[Any]] = {}
    open_lines: Dict[str, List[Any]] = {}
    skipped: Dict[str, int] = {}
    order: List[str] = []
    for e in _entities(doc.modelspace()):
        kind = e.dxftype()
        if kind not in _CURVES:
            skipped[kind] = skipped.get(kind, 0) + 1
            continue
        src = e.dxf.layer
        name = (layer_map or {}).get(src)
        if name is None:
            if skip_unmapped:
                continue
            name = src
        try:
            p = dxf_path.make_path(e)
        except (TypeError, ValueError):
            skipped[kind] = skipped.get(kind, 0) + 1
            continue
        # Rounded to 1 pm so the ends of separate curves meet exactly (an arc's
        # computed end differs from the line it joins by ~1e-16).
        pts = [(round(float(v.x) * scale, 9), round(float(v.y) * scale, 9)) for v in p.flattening(tol)]
        if len(pts) < 2:
            continue
        is_closed = (kind == "CIRCLE" or bool(getattr(e, "closed", False))
                     or (kind == "POLYLINE" and e.is_closed)
                     or (len(pts) > 2 and abs(pts[0][0] - pts[-1][0]) < 1e-9 and abs(pts[0][1] - pts[-1][1]) < 1e-9))
        if name not in order:
            order.append(name)
        if is_closed and len(pts) >= 3:
            closed.setdefault(name, []).append(clean(Polygon(pts)))
        else:
            open_lines.setdefault(name, []).append(LineString(pts))
    for kind, count in sorted(skipped.items()):
        warnings.append(f"{count} {kind} entities skipped")

    lay = Layout(unit="mm")
    for name in order:
        loops = list(closed.get(name, []))
        lines = open_lines.get(name, [])
        if lines:
            faces = list(polygonize(shapely.union_all(lines)))
            if not faces:
                warnings.append(f"layer {name!r}: open curves do not close into loops; skipped")
            # polygonize returns nested faces with holes; even-odd on their outer rings.
            loops.extend(Polygon(f.exterior) for f in faces)
        geom = Polygon()
        for loop in loops:
            geom = geom.symmetric_difference(loop)
        geom = clean(geom)
        if not geom.is_empty:
            lay.add(name, geom)
    names = [n for n in order if n in lay.layers]
    if not names:
        raise ValueError(f"{path}: no closed shapes found")
    from ._io_gerber import guess_board_stack

    stack = guess_board_stack(names, thickness=thickness, copper_thickness=copper_thickness, eps_r=eps_r,
                              tan_delta=tan_delta)
    warnings.append(f"DXF has no stack-up: guessed {thickness} mm board with the layers {names} as copper, "
                    "top first")
    return Imported(lay, stack, warnings)


def write_dxf(layout: Layout, path: Any, *, stack: Optional[LayerStack] = None) -> None:
    """Write ``layout`` as DXF R2010: one DXF layer per layout layer, every ring a closed LWPOLYLINE.

    Holes are separate closed polylines, which ``read_dxf`` (and most CAM
    tools) read even-odd. With ``stack``, layers are written as built.
    """
    ezdxf = _ezdxf()
    from ._extrude import polygons_of

    doc = ezdxf.new("R2010")
    code = _UNIT_CODE.get(layout.unit)
    if code is not None:
        doc.header["$INSUNITS"] = code
    msp = doc.modelspace()
    for name, geom in layout.geometry_for_export(stack).items():
        if name not in doc.layers:
            doc.layers.add(name)
        for poly in polygons_of(geom):
            for ring in [poly.exterior, *poly.interiors]:
                msp.add_lwpolyline(list(ring.coords)[:-1], close=True, dxfattribs={"layer": name})
    doc.saveas(os.fspath(path))
