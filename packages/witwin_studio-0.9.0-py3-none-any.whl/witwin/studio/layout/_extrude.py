"""Polygons to triangle meshes: closed prisms and flat sheets.

The caps are triangulated from the ring vertices only (no Steiner points), so
every ring segment is an edge of exactly one cap triangle and one wall
triangle: each polygon becomes a closed 2-manifold shell, holes included.

Triangulation order of preference: shapely's constrained Delaunay
(``shapely.constrained_delaunay_triangles``, GEOS >= 3.10, well-shaped
triangles) and then mapbox_earcut. Each result is checked (every triangle
vertex is a ring vertex, areas add up); a failed check falls through to the
next method.
"""
from __future__ import annotations

from typing import Any, Dict, List, Tuple

__all__ = ["polygons_of", "prism", "sheet", "triangulate"]


def polygons_of(shape: Any) -> List[Any]:
    """The non-empty ``Polygon`` parts of a Polygon / MultiPolygon / collection."""
    from shapely.geometry import MultiPolygon, Polygon

    if shape is None or shape.is_empty:
        return []
    if isinstance(shape, Polygon):
        return [shape]
    if isinstance(shape, MultiPolygon):
        return [p for p in shape.geoms if not p.is_empty]
    out: List[Any] = []
    for part in getattr(shape, "geoms", ()):
        out.extend(polygons_of(part))
    return out


def _drop_collinear(ring: List[Tuple[float, float]], tol: float) -> List[Tuple[float, float]]:
    """Remove vertices that lie on the line through their neighbours.

    Each polygon is its own shell, so these points carry no topology; left in,
    they can make zero-area cap triangles that a voxelizer cannot see.
    """
    pts = list(ring)
    changed = True
    while changed and len(pts) > 3:
        changed = False
        for i in range(len(pts)):
            a, b, c = pts[i - 1], pts[i], pts[(i + 1) % len(pts)]
            cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
            if abs(cross) <= tol:
                del pts[i]
                changed = True
                break
    return pts


def _rings(poly: Any) -> List[List[Tuple[float, float]]]:
    """Exterior (CCW) then holes (CW), without the closing point, repeats or collinear points."""
    from shapely.geometry.polygon import orient

    poly = orient(poly, sign=1.0)
    x0, y0, x1, y1 = poly.bounds
    tol = 1e-12 * ((x1 - x0) ** 2 + (y1 - y0) ** 2)
    rings = []
    for ring in [poly.exterior, *poly.interiors]:
        coords = [(float(x), float(y)) for x, y in ring.coords[:-1]]
        dedup = [p for i, p in enumerate(coords) if p != coords[i - 1]] if len(coords) > 1 else coords
        dedup = _drop_collinear(dedup, tol)
        if len(dedup) >= 3:
            rings.append(dedup)
    return rings


def _signed_area(a, b, c) -> float:
    return 0.5 * ((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1]))


def _cdt(poly: Any, index: Dict[Tuple[float, float], int]):
    import shapely

    if not hasattr(shapely, "constrained_delaunay_triangles"):
        return None
    out = []
    for tri in polygons_of(shapely.constrained_delaunay_triangles(poly)):
        coords = [(float(x), float(y)) for x, y in tri.exterior.coords[:3]]
        try:
            out.append([index[c] for c in coords])
        except KeyError:  # GEOS added or moved a point: not usable for a closed shell
            return None
    return out


def _earcut(rings: List[List[Tuple[float, float]]], index: Dict[Tuple[float, float], int]):
    try:
        import mapbox_earcut
    except ImportError:
        return None
    import numpy as np

    flat = [p for ring in rings for p in ring]
    ends = np.cumsum([len(r) for r in rings]).astype(np.uint32)
    tris = mapbox_earcut.triangulate_float64(np.asarray(flat, dtype=np.float64), ends)
    return [[index[flat[i]] for i in tris[k:k + 3]] for k in range(0, len(tris), 3)]


def triangulate(poly: Any) -> Tuple[Any, Any, List[List[int]]]:
    """Triangulate one polygon (holes allowed) from its ring vertices.

    Returns ``(points, triangles, ring_indices)``: ``points`` (N, 2) float64,
    ``triangles`` (M, 3) int64 wound CCW (normal +z), and for each ring the
    point indices in ring order. Coincident ring vertices (a hole touching
    the outline) share one index.
    """
    import numpy as np

    rings = _rings(poly)
    if not rings:
        return np.zeros((0, 2)), np.zeros((0, 3), dtype=np.int64), []
    index: Dict[Tuple[float, float], int] = {}
    points: List[Tuple[float, float]] = []
    ring_indices: List[List[int]] = []
    for ring in rings:
        ids = []
        for p in ring:
            if p not in index:
                index[p] = len(points)
                points.append(p)
            ids.append(index[p])
        ring_indices.append(ids)
    tris = None
    from shapely.geometry import Polygon

    cleaned = Polygon(rings[0], rings[1:])
    target = float(cleaned.area)
    for method in (lambda: _cdt(cleaned, index), lambda: _earcut(rings, index)):
        candidate = method()
        if not candidate:
            continue
        area = sum(abs(_signed_area(points[a], points[b], points[c])) for a, b, c in candidate)
        if abs(area - target) <= 1e-6 * max(target, 1e-300):
            tris = candidate
            break
    if tris is None:
        raise RuntimeError("could not triangulate a layout polygon; install mapbox_earcut or shapely>=2.1 "
                           f"(polygon area {target:.6g}, {len(points)} vertices)")
    fixed = []
    for a, b, c in tris:
        # Both methods wind consistently; a zero-area triangle keeps its order
        # (dropping it would open the shell).
        s = _signed_area(points[a], points[b], points[c])
        fixed.append([a, c, b] if s < 0 else [a, b, c])
    return np.asarray(points, dtype=np.float64), np.asarray(fixed, dtype=np.int64).reshape(-1, 3), ring_indices


def prism(shape: Any, z0: float, z1: float) -> Tuple[Any, Any]:
    """Closed prism of every polygon in ``shape`` between ``z0`` and ``z1``; outward normals.

    Returns ``(vertices, faces)``. Each polygon is its own shell (no shared
    vertices between polygons), so two polygons touching at a corner stay
    2-manifold.
    """
    import numpy as np

    if not z1 > z0:
        raise ValueError(f"prism needs z1 > z0, got {z0!r}..{z1!r}")
    verts, faces, offset = [], [], 0
    for poly in polygons_of(shape):
        pts, tris, rings = triangulate(poly)
        n = len(pts)
        if n == 0 or len(tris) == 0:
            continue
        bottom = np.column_stack([pts, np.full(n, z0)])
        top = np.column_stack([pts, np.full(n, z1)])
        f = [tris[:, ::-1], tris + n]  # bottom faces -z, top faces +z
        for ids in rings:
            a = np.asarray(ids, dtype=np.int64)
            b = np.roll(a, -1)
            # Exterior CCW / holes CW: (a, b, b') faces away from the solid.
            f.append(np.column_stack([a, b, b + n]))
            f.append(np.column_stack([a, b + n, a + n]))
        verts.append(np.vstack([bottom, top]))
        faces.append(np.vstack(f) + offset)
        offset += 2 * n
    if not verts:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64)
    return np.vstack(verts), np.vstack(faces)


def sheet(shape: Any, z: float) -> Tuple[Any, Any]:
    """Flat triangulated sheet of ``shape`` at height ``z``, normals +z. Returns ``(vertices, faces)``."""
    import numpy as np

    verts, faces, offset = [], [], 0
    for poly in polygons_of(shape):
        pts, tris, _ = triangulate(poly)
        if len(tris) == 0:
            continue
        verts.append(np.column_stack([pts, np.full(len(pts), float(z))]))
        faces.append(tris + offset)
        offset += len(pts)
    if not verts:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64)
    return np.vstack(verts), np.vstack(faces)
