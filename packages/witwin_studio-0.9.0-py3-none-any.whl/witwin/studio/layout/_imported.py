"""``Imported``: what every layout importer returns."""
from __future__ import annotations

from typing import List, NamedTuple

from ._layout import Layout
from ._stack import LayerStack

__all__ = ["Imported"]


class Imported(NamedTuple):
    """The layout, a guessed stack, and notes on what was skipped or guessed.

        layout, stack, warnings = L.read_kicad_pcb("board.kicad_pcb")

    The stack is a guess whenever the file has no stack-up (GDS, Gerber,
    DXF); check ``warnings`` and replace it with the real one.
    """

    layout: Layout
    stack: LayerStack
    warnings: List[str]
