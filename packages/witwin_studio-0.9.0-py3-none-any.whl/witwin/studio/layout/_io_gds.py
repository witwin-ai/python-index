"""GDSII / OASIS import and GDSII export through gdstk (Boost Software License 1.0).

Import flattens the top cell (references and repetitions applied, paths
converted to polygons) and unions polygons per layer. GDS has no stack-up,
so the returned stack is a guess: one dielectric under each mapped layer.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Mapping, Optional, Tuple, Union

from ._imported import Imported
from ._layout import Layout
from ._stack import LayerStack

__all__ = ["read_gds", "write_gds"]

LayerKey = Union[int, Tuple[int, int]]


def _gdstk():
    try:
        import gdstk
    except ImportError as exc:
        raise ImportError('GDS/OASIS needs gdstk: pip install "witwin-studio[layout]"') from exc
    return gdstk


def _name_for(layer: int, datatype: int, layer_map: Optional[Mapping[Any, str]]) -> Optional[str]:
    if layer_map is None:
        return None
    if (layer, datatype) in layer_map:
        return layer_map[(layer, datatype)]
    if layer in layer_map:
        return layer_map[layer]
    return None


def read_gds(path: Any, *, layer_map: Optional[Mapping[LayerKey, str]] = None, cell: Optional[str] = None,
             skip_unmapped: bool = False, metal_thickness: float = 1.0, dielectric_thickness: float = 1.0,
             dielectric_eps_r: float = 3.9, oasis: bool = False) -> Imported:
    """Read a GDSII (or, with ``oasis=True``, OASIS) file into a Layout in micrometers.

    ``layer_map`` maps ``layer`` or ``(layer, datatype)`` to a layer name;
    unmapped layers are named ``"L<layer>D<datatype>"`` unless
    ``skip_unmapped``. ``cell`` picks the cell (default: the only top-level
    cell; several top cells are an error). The guessed stack puts, in
    increasing (layer, datatype) order, a dielectric of
    ``dielectric_thickness`` (eps_r ``dielectric_eps_r``) then the conductor
    of ``metal_thickness`` (both in um).
    """
    gdstk = _gdstk()
    path = os.fspath(path)
    lib = gdstk.read_oas(path) if oasis else gdstk.read_gds(path)
    warnings: List[str] = []
    if cell is not None:
        cells = [c for c in lib.cells if c.name == cell]
        if not cells:
            raise KeyError(f"no cell {cell!r} in {path}; cells: {[c.name for c in lib.cells]}")
        top = cells[0]
    else:
        tops = lib.top_level()
        if len(tops) != 1:
            raise ValueError(f"{path} has {len(tops)} top-level cells {[c.name for c in tops]}; pass cell=")
        top = tops[0]
    # Library unit is meters per user unit; the layout is in um.
    scale = float(lib.unit) / 1e-6
    from shapely.geometry import Polygon

    grouped: Dict[Tuple[int, int], List[Any]] = {}
    for poly in top.get_polygons(apply_repetitions=True, include_paths=True):
        pts = [(float(x) * scale, float(y) * scale) for x, y in poly.points]
        if len(pts) >= 3:
            grouped.setdefault((int(poly.layer), int(poly.datatype)), []).append(Polygon(pts))
    if not oasis and getattr(top, "labels", None):
        warnings.append(f"{len(top.labels)} text labels ignored")

    lay = Layout(unit="um")
    names: List[Tuple[Tuple[int, int], str]] = []
    for key in sorted(grouped):
        name = _name_for(key[0], key[1], layer_map)
        if name is None:
            if skip_unmapped:
                warnings.append(f"layer {key[0]}/{key[1]} skipped (not in layer_map)")
                continue
            name = f"L{key[0]}D{key[1]}"
        for shape in grouped[key]:
            lay.add(name, shape)
        if name not in [n for _, n in names]:
            names.append((key, name))
    if not names:
        raise ValueError(f"{path}: no polygons on any (mapped) layer")
    specs: List[Any] = []
    for i, (_, name) in enumerate(names):
        specs.append((f"dielectric_{i + 1}", "dielectric", dielectric_thickness, {"eps_r": dielectric_eps_r}))
        specs.append((name, "conductor", metal_thickness))
    stack = LayerStack(specs, unit="um")
    warnings.append("GDS/OASIS has no stack-up: the stack is a guess "
                    f"({metal_thickness} um metal on {dielectric_thickness} um eps_r {dielectric_eps_r} per layer)")
    return Imported(lay, stack, warnings)


def write_gds(layout: Layout, path: Any, *, layer_map: Optional[Mapping[str, LayerKey]] = None,
              cell: str = "TOP", stack: Optional[LayerStack] = None) -> Dict[str, Tuple[int, int]]:
    """Write ``layout`` to a GDSII file in the layout's unit (1 nm precision).

    ``layer_map`` maps layer names to ``layer`` or ``(layer, datatype)``;
    unmapped layers get the next free layer number from 1. With ``stack``,
    layers are written as built (ground fills, via pads, drilled
    dielectrics); without it, the drawn shapes. GDS polygons cannot have
    holes, so holes are cut in with keyhole slits (gdstk boolean). Returns
    the ``{name: (layer, datatype)}`` mapping used.
    """
    gdstk = _gdstk()
    from ._extrude import polygons_of

    geoms = layout.geometry_for_export(stack)
    used: Dict[str, Tuple[int, int]] = {}
    taken = set()
    for name, value in (layer_map or {}).items():
        key = (int(value), 0) if isinstance(value, int) else (int(value[0]), int(value[1]))
        used[name] = key
        taken.add(key[0])
    next_layer = 1
    for name in geoms:
        if name not in used:
            while next_layer in taken:
                next_layer += 1
            used[name] = (next_layer, 0)
            taken.add(next_layer)
    lib = gdstk.Library(unit=layout.factor, precision=1e-9)
    top = lib.new_cell(cell)
    for name, geom in geoms.items():
        layer, datatype = used[name]
        for poly in polygons_of(geom):
            outer = gdstk.Polygon(list(poly.exterior.coords)[:-1], layer=layer, datatype=datatype)
            holes = [gdstk.Polygon(list(r.coords)[:-1]) for r in poly.interiors]
            if holes:
                for piece in gdstk.boolean(outer, holes, "not", layer=layer, datatype=datatype):
                    top.add(piece)
            else:
                top.add(outer)
    lib.write_gds(os.fspath(path))
    return {name: used[name] for name in geoms}
