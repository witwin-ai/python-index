"""Unit tables shared by the editor, plugins and scripts.

Component properties always store SI numbers (lengths in metres). A unit only
changes how a number is shown and typed, so every table here converts to and
from SI by a single multiplier.

Each unit has two names:

* ``key`` is ASCII and is what gets saved and sent on the wire (``"um"``).
* ``label`` is what a person reads (``"μm"``).

Lookups accept either, so ``find_unit(LENGTH, "um")`` and
``find_unit(LENGTH, "μm")`` return the same unit. ``witwin_server.core.units``
re-exports this module for plugins.

Pure stdlib on purpose: ``witwin.studio`` must not pull in torch or numpy.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Optional, Tuple, Union

__all__ = [
    "ANGLE", "FREQUENCY", "LENGTH", "POWER", "QUANTITIES", "SAMPLE_RATE", "SLOPE", "TIME",
    "Quantity", "Unit",
    "as_unit", "find_unit", "from_si", "get_quantity", "key_to_si", "si_unit", "to_si",
]


@dataclass(frozen=True)
class Unit:
    """One display unit. ``value_si = value_in_unit * multiplier``."""

    key: str
    label: str
    multiplier: float

    def to_dict(self) -> dict:
        """The wire shape the frontend reads from widget config."""
        return {"key": self.key, "label": self.label, "multiplier": self.multiplier}


Quantity = Tuple[Unit, ...]

# Order is the order a unit dropdown shows. The SI unit (multiplier 1, see
# ``si_unit``) is the default when a field names a quantity but no default unit.
LENGTH: Quantity = (
    Unit("m", "m", 1.0),
    Unit("mm", "mm", 1e-3),
    Unit("um", "μm", 1e-6),
    Unit("nm", "nm", 1e-9),
)

FREQUENCY: Quantity = (
    Unit("Hz", "Hz", 1.0),
    Unit("kHz", "kHz", 1e3),
    Unit("MHz", "MHz", 1e6),
    Unit("GHz", "GHz", 1e9),
    Unit("THz", "THz", 1e12),
)

TIME: Quantity = (
    Unit("s", "s", 1.0),
    Unit("ms", "ms", 1e-3),
    Unit("us", "μs", 1e-6),
    Unit("ns", "ns", 1e-9),
    Unit("ps", "ps", 1e-12),
    Unit("fs", "fs", 1e-15),
)

# Angles are stored in radians (Transform.rotation already is).
ANGLE: Quantity = (
    Unit("deg", "deg", math.pi / 180.0),
    Unit("rad", "rad", 1.0),
)

# Linear units only. dBm is logarithmic, so it cannot be one multiplier; the
# Transmitter never offered it, so it is left out until a field needs it.
POWER: Quantity = (
    Unit("mW", "mW", 1e-3),
    Unit("W", "W", 1.0),
    Unit("kW", "kW", 1e3),
)

# FMCW chirp slope in Hz/s. Radar datasheets quote MHz/us, so a 60 MHz/us
# chirp is stored as 6.0e13.
SLOPE: Quantity = (
    Unit("Hz/s", "Hz/s", 1.0),
    Unit("MHz/us", "MHz/μs", 1e12),
    Unit("GHz/us", "GHz/μs", 1e15),
)

# ADC sample rate in samples per second. Kept apart from FREQUENCY so a
# field can offer ksps, the unit radar configs are written in.
SAMPLE_RATE: Quantity = (
    Unit("sps", "sps", 1.0),
    Unit("ksps", "ksps", 1e3),
    Unit("Msps", "Msps", 1e6),
)

QUANTITIES: Mapping[str, Quantity] = {
    "length": LENGTH,
    "frequency": FREQUENCY,
    "time": TIME,
    "angle": ANGLE,
    "power": POWER,
    "slope": SLOPE,
    "sample_rate": SAMPLE_RATE,
}

UnitLike = Union[Unit, Mapping[str, Any]]


def get_quantity(name: str) -> Quantity:
    """Return the unit table for a quantity name such as ``"length"``.

    Raises ``KeyError`` naming the known quantities, so a typo in a field
    declaration fails when the component class is defined.
    """
    try:
        return QUANTITIES[name]
    except KeyError:
        known = ", ".join(sorted(QUANTITIES))
        raise KeyError(f"unknown quantity {name!r}; known: {known}") from None


def as_unit(unit: UnitLike) -> Unit:
    """Turn a ``Unit`` or a unit dict into a ``Unit``.

    Older plugin unit lists only have ``label`` and ``multiplier``; their key
    falls back to the label so saved files keep using the same string.
    """
    if isinstance(unit, Unit):
        return unit
    label = str(unit["label"])
    key = unit.get("key") or label
    return Unit(str(key), label, float(unit["multiplier"]))


def _same_name(a: str, b: str) -> bool:
    # People type "µ" (U+00B5, micro sign) as often as "μ" (U+03BC, Greek mu);
    # treat them as the same letter.
    return a.replace("µ", "μ") == b.replace("µ", "μ")


def si_unit(units: Union[str, Iterable[UnitLike]]) -> Optional[Unit]:
    """Return the unit whose multiplier is 1, or ``None`` if the list has none."""
    table = get_quantity(units) if isinstance(units, str) else units
    for unit in (as_unit(u) for u in table):
        if unit.multiplier == 1:
            return unit
    return None


def find_unit(units: Union[str, Iterable[UnitLike]], name: str) -> Optional[Unit]:
    """Find a unit by key or label, or return ``None``.

    ``units`` is a quantity name (``"length"``) or a list of units. Keys win
    over labels when both could match.
    """
    table = [as_unit(u) for u in (get_quantity(units) if isinstance(units, str) else units)]
    for unit in table:
        if _same_name(unit.key, name):
            return unit
    for unit in table:
        if _same_name(unit.label, name):
            return unit
    return None


def to_si(value: float, unit: UnitLike) -> float:
    """Convert a number shown in ``unit`` to SI."""
    return value * as_unit(unit).multiplier


def key_to_si(value: float, key: Optional[str]) -> float:
    """Convert a number shown in the unit named ``key`` to SI; ``None`` means it is SI already.

    This is the converter the Formula Graph takes (``FormulaGraph(key_to_si)``):
    a binding only stores its field's unit key, not the field's unit table, so
    the key is looked up in every table in ``QUANTITIES``. Keys are unique
    across those tables. Raises ``KeyError`` for a key no table knows, which
    the graph reports as a ``unit`` error on that binding.
    """
    if key is None:
        return value
    for table in QUANTITIES.values():
        unit = find_unit(table, key)
        if unit is not None:
            return value * unit.multiplier
    raise KeyError(f"unknown unit key {key!r}")


def from_si(value: float, unit: UnitLike) -> float:
    """Convert an SI number to ``unit`` for display."""
    return value / as_unit(unit).multiplier
