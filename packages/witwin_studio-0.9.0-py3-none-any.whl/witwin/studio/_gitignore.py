"""Project ``.gitignore`` policy: the default file and the required patterns.

Part of the Project format (decision D11), so it lives in ``witwin.studio``:
the scaffold writer (``_scaffold``) and the ProjectServer's Git feature
(``witwin_server.plugins_builtin.git.ignore_policy`` re-exports this module) must
agree on what a Project ignores.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, List, Sequence, Tuple

# Runtime root: caches, AI DB, result history, plugin enable state, etc.
REQUIRED_IGNORE_PATTERNS: Tuple[str, ...] = (".witwin/",)

DEFAULT_GITIGNORE = """# --- WiTwin Studio: default project ignore (managed template) ---
# Runtime and system state (disposable; never share)
.witwin/

# OS junk
.DS_Store
Thumbs.db
desktop.ini

# Common tooling noise (defensive; projects may not use these)
__pycache__/
*.py[cod]
*$py.class
.pytest_cache/
.mypy_cache/
.ruff_cache/
node_modules/
dist/
build/
*.egg-info/
.venv/
venv/

# Editor swap / backup
*~
*.swp
*.swo
"""

_MANAGED_BLOCK_HEADER = "# --- WiTwin required (auto-added; safe to keep) ---"


def _normalize_pattern(pattern: str) -> str:
    return (pattern or "").strip().replace("\\", "/")


def _active_patterns(content: str) -> set[str]:
    """Return non-comment, non-blank pattern lines (exact string membership)."""
    active: set[str] = set()
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        active.add(_normalize_pattern(stripped))
    return active


def pattern_is_covered(active: set[str], pattern: str) -> bool:
    """True if *pattern* or a close equivalent is already listed."""
    p = _normalize_pattern(pattern)
    if not p:
        return True
    if p in active:
        return True
    # Accept both `.witwin/` and `.witwin` as covering each other for dirs.
    if p.endswith("/"):
        if p.rstrip("/") in active:
            return True
    else:
        if f"{p}/" in active:
            return True
    return False


def missing_required_patterns(
    content: str,
    required: Sequence[str] = REQUIRED_IGNORE_PATTERNS,
) -> List[str]:
    active = _active_patterns(content)
    return [p for p in required if not pattern_is_covered(active, p)]


def ensure_patterns(
    content: str,
    patterns: Iterable[str],
) -> Tuple[str, List[str], List[str]]:
    """Append missing patterns as a managed block.

    Returns ``(new_content, added, skipped)``. Never removes user lines.
    """
    text = content if content is not None else ""
    active = _active_patterns(text)
    to_add: List[str] = []
    skipped: List[str] = []
    for raw in patterns:
        p = _normalize_pattern(raw)
        if not p:
            continue
        if pattern_is_covered(active, p):
            skipped.append(p)
        else:
            to_add.append(p)
            active.add(p)

    if not to_add:
        return text, [], skipped

    block_lines = ["", _MANAGED_BLOCK_HEADER, *to_add, ""]
    # Ensure file ends with a newline before append when non-empty.
    if text and not text.endswith("\n"):
        text = text + "\n"
    text = text + "\n".join(block_lines)
    if not text.endswith("\n"):
        text = text + "\n"
    return text, to_add, skipped


def read_gitignore(root: Path) -> Tuple[str, bool]:
    """Return ``(content, present)`` for root ``.gitignore``."""
    path = Path(root) / ".gitignore"
    if not path.is_file():
        return "", False
    try:
        return path.read_text(encoding="utf-8"), True
    except OSError:
        return "", False


def write_gitignore(root: Path, content: str) -> None:
    path = Path(root) / ".gitignore"
    path.write_text(content if content.endswith("\n") else content + "\n", encoding="utf-8")


def write_default_gitignore_if_missing(root: Path) -> bool:
    """Write DEFAULT_GITIGNORE when missing. Returns True if written."""
    path = Path(root) / ".gitignore"
    if path.exists():
        return False
    write_gitignore(root, DEFAULT_GITIGNORE)
    return True


def ensure_required_on_disk(
    root: Path,
    required: Sequence[str] = REQUIRED_IGNORE_PATTERNS,
) -> Tuple[List[str], List[str]]:
    """Ensure required patterns exist on disk. Returns (added, skipped)."""
    content, present = read_gitignore(root)
    if not present:
        write_gitignore(root, DEFAULT_GITIGNORE)
        # Template already includes required patterns.
        return list(required), []
    new_content, added, skipped = ensure_patterns(content, required)
    if added:
        write_gitignore(root, new_content)
    return added, skipped


def is_forbidden_project_path(rel_path: str) -> bool:
    """True if a project-relative path is under runtime that must not be committed."""
    cleaned = (rel_path or "").replace("\\", "/").lstrip("/")
    if not cleaned:
        return False
    first = cleaned.split("/", 1)[0]
    return first == ".witwin"
