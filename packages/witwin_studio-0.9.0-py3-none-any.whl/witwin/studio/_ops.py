"""Scene operations shared by the Agent's ``scene.*`` Tools and ``witwin_agent``.

Internal: the public ``Scene.apply`` (design §3.5) is not frozen yet. Until it
is, the ProjectServer's scene Tools and the ``witwin_agent`` compatibility
module both use this module, so an Agent edit and a script's edit of a scene
file produce the same document, with the same units and checks.

``apply_ops`` takes the ``scene.batch`` Tool's operations (lengths in meters,
rotations Euler angles in DEGREES ``[x, y, z]`` as the Properties panel shows
them, ``parentId`` / ``objectId`` may name an earlier op's ``tempId``):

- ``create_object``: ``name``, ``meshType``, ``position``, ``rotation``,
  ``scale`` or the primitive's size (``size``, ``radius``, ``height``,
  ``tubeRadius``), ``material`` (``color``, ``metalness``, ``roughness``),
  ``parentId``.
- ``create_mesh``: ``name``, ``meshbinPath``, ``position``, ``rotation``,
  ``scale``, ``material``, ``fill``, ``role``, ``anchors``,
  ``surfaceThickness`` (meters), ``grid``, ``maxTriangles``, ``force``,
  ``parentId``.
- ``update_transform``: ``objectId``, ``position`` / ``rotation`` / ``scale``.
- ``set_component_field``: ``objectId``, ``component``, ``field``, ``value``.
- ``add_component``: ``objectId``, ``component``, ``fields``.
- ``delete_object``: ``objectId``.

The SDK's own ``Scene.add`` / ``Transform.rotation`` keep their quaternion
``(x, y, z, w)``: that is the file format. Only the op layer, which models and
Agent scripts write, speaks degrees; ``degrees_to_quat`` is the one conversion.
"""
from __future__ import annotations

import json
import math
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple

from ._scene import Entity, Scene, _euler_to_quat

EMPTY_MESH = "Empty"

# meshType values create_object accepts. "Custom" is an empty Mesh that
# imported or generated geometry fills later; "Empty" has no Mesh at all.
MESH_TYPES: Tuple[str, ...] = ("Cube", "Sphere", "Plane", "Cylinder", "Cone", "Torus", "Empty", "Custom")
PRIMITIVES = frozenset({"Cube", "Sphere", "Plane", "Cylinder", "Cone", "Torus"})

# Words models use for a primitive. Only unambiguous ones: "ring" could be a
# torus or a flat annulus, so it stays an error that lists the valid values.
_MESH_ALIASES = {
    "box": "Cube", "cuboid": "Cube", "block": "Cube", "brick": "Cube",
    "ball": "Sphere",
    "quad": "Plane",
    "donut": "Torus", "doughnut": "Torus",
    "group": "Empty", "folder": "Empty", "null": "Empty", "none": "Empty",
}

# Sizes of the ProjectServer's unit primitives (MeshComponent._create_*), in
# meters. A size argument becomes scale = wanted / unit.
_UNIT_RADIUS = 0.5          # Sphere, Cylinder, Cone
_UNIT_HEIGHT = 1.0          # Cylinder, Cone (along Y)
_UNIT_TORUS_MAJOR = 0.4     # centre-line radius, in the XY plane (axis Z)
_UNIT_TORUS_MINOR = 0.15    # tube radius

SIZE_KEYS = ("size", "radius", "height", "tubeRadius")
_SIZE_KEYS_BY_TYPE = {
    "Cube": ("size",),
    "Plane": ("size",),
    "Sphere": ("radius",),
    "Cylinder": ("radius", "height"),
    "Cone": ("radius", "height"),
    "Torus": ("radius", "tubeRadius"),
}
MATERIAL_KEYS = ("color", "metalness", "roughness")
TRANSFORM_FIELDS = ("position", "rotation", "scale")


class OpError(ValueError):
    """A refused operation. ``detail`` holds what a model needs to fix it (``valid``, ``next``)."""

    def __init__(self, message: str, detail: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.detail = detail or {}


# --------------------------------------------------------------------------- #
# Units
# --------------------------------------------------------------------------- #
def degrees_to_euler(xyz_degrees: Sequence[float]) -> List[float]:
    """Op rotation ``[x, y, z]`` degrees -> Transform.rotation field (``[z, x, y]`` radians, "ZXY").

    Models given the field's radians typed degrees into them, and an
    ``[x, y, z]`` list landed on the ``[z, x, y]`` slots, so ops use degrees.
    """
    values = [float(v) for v in xyz_degrees]
    if len(values) != 3:
        raise OpError("rotation needs [x, y, z] in degrees", {"got": list(xyz_degrees)})
    x, y, z = (math.radians(v) for v in values)
    return [z, x, y]


def euler_to_degrees(field_value: Sequence[float]) -> List[float]:
    """Transform.rotation field (``[z, x, y]`` radians) -> ``[x, y, z]`` degrees, rounded for reading."""
    z, x, y = (float(v) for v in list(field_value)[:3])
    return [round(math.degrees(v), 4) + 0.0 for v in (x, y, z)]


def degrees_to_quat(xyz_degrees: Sequence[float]) -> List[float]:
    """Op rotation ``[x, y, z]`` degrees -> quaternion ``(x, y, z, w)`` for ``Scene.add`` / ``add_mesh``."""
    return _euler_to_quat(degrees_to_euler(xyz_degrees))


def canonical_mesh_type(value: Any) -> str:
    """The canonical meshType for ``value`` (case-insensitive, with a few aliases).

    Before this check a typo such as "box" created an object with an empty
    Mesh that nobody could see.
    """
    if value is None:
        return "Custom"
    text = str(value).strip()
    for name in MESH_TYPES:
        if text.lower() == name.lower():
            return name
    alias = _MESH_ALIASES.get(text.lower())
    if alias is not None:
        return alias
    raise OpError(f"unknown meshType {value!r}", {
        "valid": list(MESH_TYPES),
        "next": "Use one of the valid meshTypes; for any other shape write geometry with a script.",
    })


def size_scale(mesh_type: str, args: Dict[str, Any]) -> Tuple[Optional[List[float]], List[str]]:
    """Scale that gives a primitive the size in ``args``, plus warnings.

    ``(None, [])`` when no size argument was given. Raises when a size argument
    does not fit the mesh type or is combined with ``scale``.
    """
    given = [key for key in SIZE_KEYS if args.get(key) is not None]
    if not given:
        return None, []
    allowed = _SIZE_KEYS_BY_TYPE.get(mesh_type, ())
    wrong = [key for key in given if key not in allowed]
    if wrong:
        raise OpError(f"{', '.join(wrong)} does not apply to meshType {mesh_type}",
                      {"valid": list(allowed), "next": "Pass the size parameters of this meshType, or use scale."})
    if args.get("scale") is not None:
        raise OpError("pass either size parameters or scale, not both",
                      {"next": "Drop scale; size, radius, height and tubeRadius are in meters."})
    warnings: List[str] = []
    if mesh_type == "Cube":
        return _lengths(args["size"], 3, "size"), warnings
    if mesh_type == "Plane":
        x, z = _lengths(args["size"], 2, "size")
        return [x, 1.0, z], warnings
    if mesh_type == "Sphere":
        d = float(args["radius"]) / _UNIT_RADIUS
        return [d, d, d], warnings
    if mesh_type in ("Cylinder", "Cone"):
        d = float(args.get("radius") or _UNIT_RADIUS) / _UNIT_RADIUS
        h = float(args.get("height") or _UNIT_HEIGHT) / _UNIT_HEIGHT
        return [d, h, d], warnings
    # Torus: scale cannot change the tube independently of the ring in the XY
    # plane. Keep the centre line and the tube's Z thickness exact; when the
    # ratio differs from the unit torus the tube is elliptical, and the caller
    # is told so instead of getting a silently wrong shape.
    major = float(args.get("radius") or _UNIT_TORUS_MAJOR)
    minor = float(args.get("tubeRadius") or major * _UNIT_TORUS_MINOR / _UNIT_TORUS_MAJOR)
    s_xy = major / _UNIT_TORUS_MAJOR
    s_z = minor / _UNIT_TORUS_MINOR
    radial = _UNIT_TORUS_MINOR * s_xy
    if abs(radial - minor) > 0.01 * minor:
        warnings.append(
            f"Torus scale keeps the ring radius {major:g} m and the tube thickness along Z "
            f"({2 * minor:g} m), but the tube's radial half-width is {radial:g} m, not {minor:g} m. "
            "For an exact torus with this ratio, write its mesh with a script."
        )
    return [s_xy, s_xy, s_z], warnings


def _lengths(value: Any, n: int, what: str) -> List[float]:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        values = [float(value)] * n
    elif isinstance(value, (list, tuple)) and len(value) == n:
        values = [float(v) for v in value]
    else:
        raise OpError(f"{what} needs {n} numbers in meters", {"got": value})
    if any(v <= 0 for v in values):
        raise OpError(f"{what} must be positive", {"got": value})
    return values


def coerce_color(value: Any) -> List[float]:
    """A color as RGBA floats 0..1. Accepts "#rrggbb[aa]", 0..1 lists, and 0..255 lists."""
    if isinstance(value, str) and value.strip()[:1] in ('[', '"'):
        # Models send the list or the hex string JSON-encoded once more
        # ('"[0.7, 0.7, 0.7, 1]"', '"\"#b8babf\""'); the decoded value is the color they meant.
        try:
            value = json.loads(value)
        except ValueError:
            pass
    if isinstance(value, str):
        match = re.match(r"^#?([0-9a-fA-F]{6})([0-9a-fA-F]{2})?$", value.strip())
        if match is None:
            raise OpError(f"invalid color {value!r}", {"expected": "[r, g, b, a] floats 0..1, or \"#rrggbb\""})
        digits = match.group(1) + (match.group(2) or "ff")
        return [int(digits[i:i + 2], 16) / 255 for i in range(0, 8, 2)]
    if isinstance(value, (list, tuple)) and len(value) in (3, 4) and all(
            isinstance(v, (int, float)) and not isinstance(v, bool) for v in value):
        channels = [float(v) for v in value]
        if any(v > 1.0 for v in channels):
            # 0..255 input: the old "make it red" -> [255, 0, 0] case turned objects black.
            channels = [v / 255 for v in channels]
        return channels if len(channels) == 4 else [*channels, 1.0]
    raise OpError(f"invalid color {value!r}", {"expected": "[r, g, b, a] floats 0..1, or \"#rrggbb\""})


def _vec3(value: Any, what: str) -> List[float]:
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise OpError(f"{what} needs [x, y, z]", {"got": value})
    return [float(v) for v in value]


# --------------------------------------------------------------------------- #
# Document edits
# --------------------------------------------------------------------------- #
def add_object(
    scene: Scene,
    *,
    name: str = "Object",
    mesh_type: str = "Custom",
    position: Optional[Sequence[float]] = None,
    scale: Optional[Sequence[float]] = None,
    parent: Optional[str] = None,
) -> Entity:
    """The entity the editor's "create object" makes, as a document entity.

    A mesh object gets ``Material`` and ``Mesh`` (with ``mesh_type``), an
    ``Empty`` gets neither, and the entity type follows the components
    (``builtin.mesh`` or ``builtin.group``), as in the ProjectServer. Component
    fields that are not set are left out; the ProjectServer fills their
    defaults when it loads the scene. KeyError if ``parent`` is not in the scene.
    """
    is_mesh = mesh_type != EMPTY_MESH
    entity = scene.add(name, type="builtin.mesh" if is_mesh else "builtin.group", parent=parent or None,
                       position=position, scale=scale)
    if is_mesh:
        entity.components.add("Material")
        entity.components.add("Mesh", mesh_type=mesh_type)
    return entity


def set_rotation_degrees(entity: Entity, xyz_degrees: Sequence[float]) -> None:
    """Rotate ``entity`` to op angles; stores the quaternion and the editor's Euler angles together."""
    entity.transform._set_euler(degrees_to_euler(xyz_degrees))


def read_mesh_op(op: Dict[str, Any]) -> Dict[str, Any]:
    """``Scene.add_mesh`` keyword arguments for a ``create_mesh`` op (reads its ``.meshbin``).

    The op's rotation is degrees; ``add_mesh`` takes a quaternion. The caller
    decides which ``meshbinPath`` values it trusts; the ProjectServer only
    takes files inside the running script's folder.
    """
    from . import meshbin
    from .geometry import MeshData

    path = op.get("meshbinPath")
    if not isinstance(path, str) or not path:
        raise OpError("create_mesh needs meshbinPath")
    with open(path, "rb") as f:
        decoded = meshbin.decode_mesh(f.read())
    mesh = MeshData(decoded.positions.astype("float64"), decoded.indices.astype("int64"),
                    None if decoded.normals is None else decoded.normals.astype("float64"))
    rotation = op.get("rotation")
    return {
        "mesh": mesh, "material": op.get("material"), "fill": op.get("fill"), "role": op.get("role"),
        "anchors": op.get("anchors"), "surface_thickness": op.get("surfaceThickness"),
        "unit": "m", "position": op.get("position"),
        "rotation": degrees_to_quat(rotation) if rotation is not None else None,
        "scale": op.get("scale"), "grid": op.get("grid"),
        "max_triangles": op.get("maxTriangles"), "force": bool(op.get("force")),
    }


class _Batch:
    def __init__(self, scene: Scene):
        self.scene = scene
        self.id_map: Dict[str, str] = {}
        self.created: List[Dict[str, Any]] = []
        self.changes: List[Dict[str, Any]] = []
        self.warnings: List[str] = []

    def ref(self, value: Any, what: str = "objectId") -> Optional[str]:
        if not value:
            return None
        object_id = self.id_map.get(value, value)
        if object_id not in self.scene.objects:
            raise OpError(f"{what} not found: {value}")
        return object_id

    def entity(self, op: Dict[str, Any]) -> Entity:
        object_id = self.ref(op.get("objectId"))
        if object_id is None:
            raise OpError("objectId is required")
        return self.scene.objects[object_id]

    def record(self, op: Dict[str, Any], entity: Entity) -> None:
        temp_id = op.get("tempId")
        if temp_id is not None:
            self.id_map[temp_id] = entity.id
        entry: Dict[str, Any] = {"tempId": temp_id, "objectId": entity.id, "name": entity.name}
        if entity.validation is not None:
            entry["validation"] = entity.validation.to_dict()
        self.created.append(entry)


def _create_object(batch: _Batch, op: Dict[str, Any]) -> None:
    mesh_type = canonical_mesh_type(op.get("meshType"))
    sized, warnings = size_scale(mesh_type, op)
    material = op.get("material") or {}
    if not isinstance(material, dict) or set(material) - set(MATERIAL_KEYS):
        raise OpError("create_object material takes color, metalness and roughness",
                      {"valid": list(MATERIAL_KEYS)})
    if material and mesh_type == EMPTY_MESH:
        raise OpError("an Empty object has no Material", {"next": "Use a mesh meshType, or drop material."})
    scale = sized or (_vec3(op["scale"], "scale") if op.get("scale") is not None else None)
    entity = add_object(batch.scene, name=op.get("name") or "Object", mesh_type=mesh_type,
                        position=_vec3(op["position"], "position") if op.get("position") is not None else None,
                        scale=scale, parent=batch.ref(op.get("parentId"), "parentId"))
    if op.get("rotation") is not None:
        set_rotation_degrees(entity, op["rotation"])
    for key, value in material.items():
        entity.components["Material"][key] = coerce_color(value) if key == "color" else value
    batch.warnings.extend(warnings)
    batch.record(op, entity)


def _create_mesh(batch: _Batch, op: Dict[str, Any]) -> None:
    kwargs = read_mesh_op(op)
    entity = batch.scene.add_mesh(op.get("name") or "Mesh", kwargs.pop("mesh"),
                                  parent=batch.ref(op.get("parentId"), "parentId"), **kwargs)
    if op.get("rotation") is not None:
        # Same rotation; this also stores the angles the editor shows.
        set_rotation_degrees(entity, op["rotation"])
    batch.record(op, entity)


def _set_transform(entity: Entity, key: str, value: Any) -> None:
    if key == "rotation":
        set_rotation_degrees(entity, _vec3(value, "rotation"))
    else:
        setattr(entity.transform, key, _vec3(value, key))


def _update_transform(batch: _Batch, op: Dict[str, Any]) -> Dict[str, Any]:
    entity = batch.entity(op)
    keys = [key for key in TRANSFORM_FIELDS if op.get(key) is not None]
    if not keys:
        raise OpError("update_transform needs position, rotation or scale")
    for key in keys:
        _set_transform(entity, key, op[key])
    return {"op": "update_transform", "ref": op["objectId"]}


def _set_component_field(batch: _Batch, op: Dict[str, Any]) -> Dict[str, Any]:
    entity = batch.entity(op)
    component, field, value = op.get("component"), op.get("field"), op.get("value")
    if not component or not field or "value" not in op:
        raise OpError("set_component_field needs component, field and value")
    if component == "Transform" and field in TRANSFORM_FIELDS:
        _set_transform(entity, field, value)
    else:
        if component not in entity.components:
            raise OpError(f"{entity.id} has no {component} component",
                          {"valid": sorted(entity.components), "next": "Add it first with an add_component op."})
        # Component classes live in the ProjectServer, so the SDK cannot check
        # field names or types; a color is the one value it normalizes.
        entity.components[component][field] = coerce_color(value) if field == "color" else value
    return {"op": "set_component_field", "ref": op["objectId"], "component": component, "field": field}


def _add_component(batch: _Batch, op: Dict[str, Any]) -> Dict[str, Any]:
    entity = batch.entity(op)
    component = op.get("component")
    if not component:
        raise OpError("add_component needs component")
    if component in entity.components:
        raise OpError(f"{entity.id} already has a {component} component",
                      {"next": "Change its fields with a set_component_field op."})
    entity.components.add(component, **(op.get("fields") or {}))
    return {"op": "add_component", "ref": op["objectId"], "component": component}


def _delete_object(batch: _Batch, op: Dict[str, Any]) -> Dict[str, Any]:
    entity = batch.entity(op)
    removed = set(batch.scene.remove(entity))
    batch.created = [item for item in batch.created if item["objectId"] not in removed]
    return {"op": "delete_object", "ref": op["objectId"]}


_APPLY = {
    "create_object": _create_object,
    "create_mesh": _create_mesh,
    "update_transform": _update_transform,
    "set_component_field": _set_component_field,
    "add_component": _add_component,
    "delete_object": _delete_object,
}
OPS: Tuple[str, ...] = tuple(_APPLY)


def apply_ops(scene: Scene, operations: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Apply ``scene.batch`` operations in order to a scene file. Raises ``OpError`` on the first bad op.

    The caller decides what a failure means: nothing is written until it calls
    ``scene.save()``, so dropping the Scene undoes every op.
    """
    batch = _Batch(scene)
    for index, op in enumerate(operations):
        kind = op.get("op")
        apply = _APPLY.get(kind)
        try:
            if apply is None:
                raise OpError(f"unsupported op {kind!r}", {"valid": list(OPS)})
            temp_id = op.get("tempId")
            if temp_id is not None and temp_id in batch.id_map:
                raise OpError(f"duplicate tempId {temp_id!r}")
            change = apply(batch, op)
        except OpError as exc:
            raise OpError(f"operation {index}: {exc}", exc.detail) from exc
        if change:
            batch.changes.append({"index": index, **change})
    result: Dict[str, Any] = {"count": len(batch.created), "idMap": batch.id_map, "objects": batch.created,
                              "changes": batch.changes}
    if batch.warnings:
        result["warnings"] = batch.warnings
    return result
