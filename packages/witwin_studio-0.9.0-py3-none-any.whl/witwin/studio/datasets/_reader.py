"""Reading a ``witwin.dataset.v1`` folder (``datasets.open``).

A split is read through a row index built from each shard's ``index`` and
``split`` arrays (``np.load`` of an ``.npz`` reads one array at a time, so
the fields are not read for that). Samples are read one shard at a time and
the last two shards stay in memory, so iterating in order reads each shard
once.
"""
from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping

from ._format import (
    FORMAT,
    INDEX_KEY,
    LFS_POINTER_PREFIX,
    SPLIT_KEY,
    VALUES_KEY,
    read_manifest,
)

_CACHED_SHARDS = 2


class DatasetError(Exception):
    """A dataset folder that cannot be read; ``code`` is stable.

    ``dataset_not_found`` (no manifest), ``invalid_dataset`` (another format
    or a broken shard), ``lfs_not_fetched`` (a shard is still a Git LFS
    pointer), ``split_not_found``, ``sample_not_found`` (``Dataset.sample``).
    """

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def open(path: str | Path, project: Any = None) -> "Dataset":  # noqa: A001 - mirrors builtins.open on purpose
    """Open the dataset in ``path``: a folder, relative to ``project`` (a Project or its root) or the cwd."""
    folder = Path(path)
    if not folder.is_absolute() and project is not None:
        folder = Path(project if isinstance(project, (str, Path)) else project.root) / folder
    return Dataset(folder)


class Dataset:
    """A dataset folder: its manifest, its splits and its samples in index order."""

    def __init__(self, folder: str | Path) -> None:
        self.folder = Path(folder)
        manifest = read_manifest(self.folder)
        if manifest is None:
            raise DatasetError("dataset_not_found", f"no dataset in {self.folder} (manifest.json is missing)")
        if manifest.get("format") != FORMAT:
            raise DatasetError("invalid_dataset", f"{self.folder} is {manifest.get('format')!r}, not {FORMAT}")
        self.manifest: dict[str, Any] = manifest
        self._shards: OrderedDict[int, dict[str, Any]] = OrderedDict()
        self._rows: list[tuple[int, int]] | None = None
        self._split_rows: dict[str, list[tuple[int, int]]] = {}

    @property
    def fields(self) -> dict[str, dict[str, Any]]:
        """Field name -> ``{"dtype", "shape"}`` of one sample."""
        return dict(self.manifest.get("fields") or {})

    @property
    def variables(self) -> list[str]:
        """Variable names, in the order of each sample's ``values``."""
        return list(self.manifest.get("variables") or [])

    @property
    def splits(self) -> dict[str, int]:
        """Split name -> samples in it."""
        return {name: int(n) for name, n in (self.manifest.get("split_counts") or {}).items()}

    def __len__(self) -> int:
        return int(self.manifest.get("samples") or 0)

    def __getitem__(self, i: int) -> dict[str, Any]:
        return self._sample(*self._all_rows()[i])

    def __iter__(self) -> Iterator[dict[str, Any]]:
        for shard, row in self._all_rows():
            yield self._sample(shard, row)

    def split(self, name: str) -> "DatasetSplit":
        """The samples of one split (``train``, ``val``, ...)."""
        if name not in (self.manifest.get("splits") or {}):
            raise DatasetError("split_not_found",
                               f"{self.folder} has no split {name!r}; it has {', '.join(self.splits)}")
        if name not in self._split_rows:
            self._split_rows[name] = [(shard, row) for shard, row, split in self._index() if split == name]
        return DatasetSplit(self, name, self._split_rows[name])

    def arrays(self, shard: int, names: Iterable[str] | None = None) -> dict[str, Any]:
        """The arrays of shard ``shard`` (fields plus ``index``, ``values``, ``split``).

        With ``names``, only those arrays are read (an ``.npz`` member is
        read on access), and the shard is not kept in the cache; a name the
        shard lacks is left out. Studio's viewer reads ``index``, ``split``
        and ``values`` this way without loading the fields.
        """
        if names is None:
            return self._load(shard)
        import numpy as np

        wanted = list(names)
        path = self._shard_path((self.manifest.get("shards") or [])[shard])
        with np.load(path, allow_pickle=False) as data:
            return {name: data[name] for name in wanted if name in data.files}

    def sample(self, index: int) -> dict[str, Any]:
        """The sample whose ``index`` is ``index`` (not its position; dropped samples leave gaps).

        Reads only the ``index`` arrays of the shards whose
        ``first_index``..``last_index`` range holds it, then that shard.
        Raises ``DatasetError("sample_not_found")`` when no shard has it.
        """
        import numpy as np

        for shard, entry in enumerate(self.manifest.get("shards") or []):
            first, last = entry.get("first_index"), entry.get("last_index")
            if first is not None and last is not None and not int(first) <= index <= int(last):
                continue
            rows = np.flatnonzero(self.arrays(shard, [INDEX_KEY])[INDEX_KEY] == index)
            if rows.size:
                return self._sample(shard, int(rows[0]))
        raise DatasetError("sample_not_found", f"{self.folder} has no sample {index}")

    def __repr__(self) -> str:
        return f"<Dataset {self.folder.name}: {len(self)} samples, splits {self.splits}>"

    # (shard, row) of every sample, in index order.
    def _all_rows(self) -> list[tuple[int, int]]:
        if self._rows is None:
            self._rows = [(shard, row) for shard, row, _ in self._index()]
        return self._rows

    # (shard, row, split) of every sample, sorted by sample index.
    def _index(self) -> list[tuple[int, int, str]]:
        import numpy as np

        found: list[tuple[int, int, int, str]] = []
        for shard, entry in enumerate(self.manifest.get("shards") or []):
            path = self._shard_path(entry)
            with np.load(path, allow_pickle=False) as data:
                indexes, splits = data[INDEX_KEY], data[SPLIT_KEY]
            found.extend((int(index), shard, row, str(split))
                         for row, (index, split) in enumerate(zip(indexes, splits)))
        found.sort()
        return [(shard, row, split) for _, shard, row, split in found]

    def _sample(self, shard: int, row: int) -> dict[str, Any]:
        arrays = self._load(shard)
        sample = {name: arrays[name][row] for name in arrays if name not in (INDEX_KEY, VALUES_KEY, SPLIT_KEY)}
        sample[INDEX_KEY] = int(arrays[INDEX_KEY][row])
        sample[SPLIT_KEY] = str(arrays[SPLIT_KEY][row])
        sample[VALUES_KEY] = dict(zip(self.variables, (float(v) for v in arrays[VALUES_KEY][row])))
        return sample

    def _load(self, shard: int) -> dict[str, Any]:
        import numpy as np

        if shard in self._shards:
            self._shards.move_to_end(shard)
            return self._shards[shard]
        entries = self.manifest.get("shards") or []
        path = self._shard_path(entries[shard])
        with np.load(path, allow_pickle=False) as data:
            arrays = {name: data[name] for name in data.files}
        self._shards[shard] = arrays
        while len(self._shards) > _CACHED_SHARDS:
            self._shards.popitem(last=False)
        return arrays

    def _shard_path(self, entry: Mapping[str, Any]) -> Path:
        path = self.folder / str(entry["file"])
        if not path.is_file():
            raise DatasetError("invalid_dataset", f"shard {path} is missing")
        with path.open("rb") as handle:
            head = handle.read(len(LFS_POINTER_PREFIX))
        if head == LFS_POINTER_PREFIX:
            raise DatasetError("lfs_not_fetched",
                               f"{path.name} is a Git LFS pointer; run "
                               f"git lfs pull --include \"{self.folder.as_posix()}/shards/**\"")
        return path


class DatasetSplit:
    """The samples of one split, in index order; ``torch()`` wraps it for a DataLoader."""

    def __init__(self, dataset: Dataset, name: str, rows: list[tuple[int, int]]) -> None:
        self.dataset = dataset
        self.name = name
        self._rows = rows

    def __len__(self) -> int:
        return len(self._rows)

    def __getitem__(self, i: int) -> dict[str, Any]:
        return self.dataset._sample(*self._rows[i])

    def __iter__(self) -> Iterator[dict[str, Any]]:
        for shard, row in self._rows:
            yield self.dataset._sample(shard, row)

    def torch(self) -> Any:
        """A ``torch.utils.data.Dataset`` of this split; numeric fields become tensors.

        Imports torch only here. ``values`` becomes a float64 tensor in
        ``Dataset.variables`` order; text fields and ``split`` stay strings.
        """
        import numpy as np
        import torch
        from torch.utils.data import Dataset as TorchDataset

        split = self
        names = split.dataset.variables

        class _Split(TorchDataset):  # type: ignore[misc]
            def __len__(self) -> int:
                return len(split)

            def __getitem__(self, i: int) -> dict[str, Any]:
                sample = split[i]
                out: dict[str, Any] = {}
                for key, value in sample.items():
                    if key == VALUES_KEY:
                        out[key] = torch.tensor([value[n] for n in names], dtype=torch.float64)
                    elif isinstance(value, np.ndarray) and value.dtype.kind in "biuf":
                        out[key] = torch.from_numpy(np.ascontiguousarray(value))
                    elif isinstance(value, np.generic) and value.dtype.kind in "biuf":
                        out[key] = torch.tensor(value.item())
                    else:
                        out[key] = value
                return out

        return _Split()

    def __repr__(self) -> str:
        return f"<DatasetSplit {self.name}: {len(self)} samples>"
