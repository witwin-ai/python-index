"""Datasets: the ``witwin.dataset.v1`` folders dataset Studies write.

    from witwin.studio import datasets

    ds = datasets.open("datasets/radar-scenes")
    train = ds.split("train")
    for sample in train:          # dict: field -> numpy array, plus index, split, values
        ...
    loader_ds = train.torch()     # imports torch only here

A dataset Study's Run writes the folder (``python -m witwin.studio.studies``;
``_writer``); real-hardware imports write the same format. The folder layout
is in ``_format``. This package imports numpy only when it reads or writes,
and torch only in ``DatasetSplit.torch``.
"""
from __future__ import annotations

from ._format import FORMAT, LFS_PATTERN, MANIFEST_FILE, split_for
from ._reader import Dataset, DatasetError, DatasetSplit, open

__all__ = ["FORMAT", "LFS_PATTERN", "MANIFEST_FILE", "Dataset", "DatasetError", "DatasetSplit",
           "open", "split_for"]
