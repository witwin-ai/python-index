"""The ``witwin.dataset.v1`` folder layout, shared by the writer and the reader.

    <dataset dir>/
      manifest.json      plain git: fields, counts, splits, source Study and Run
      shards/            Git LFS (``datasets/**/shards/**``)
        00000.npz        one array per field, first axis = samples of the shard,
        00001.npz        plus ``index`` (int64), ``values`` (float64, samples x
                         variables) and ``split`` (unicode)

A shard counts once ``os.replace`` has given it its final name and the
manifest lists it; a shard file the manifest does not list is a leftover of
a write that did not finish and is deleted on resume. Each sample's split
comes from its index alone (``split_for``), so resuming or adding samples
never moves an existing sample to another split.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Mapping

FORMAT = "witwin.dataset.v1"
MANIFEST_FILE = "manifest.json"
SHARD_DIR = "shards"
# The pattern .gitattributes routes to LFS; relative to the Project root.
LFS_PATTERN = "datasets/**/shards/**"


def lfs_pattern_for(folder: str) -> str:
    """The LFS pattern that covers the shards of ``folder`` (Project-relative posix path).

    ``LFS_PATTERN`` for a folder under ``datasets/``, so one line covers every
    such dataset; a folder elsewhere gets a line of its own.
    """
    folder = folder.strip("/")
    if folder.startswith("datasets/"):
        return LFS_PATTERN
    return f"{folder}/{SHARD_DIR}/**"

# Arrays every shard has besides the fields; a field may not use these names.
INDEX_KEY = "index"
VALUES_KEY = "values"
SPLIT_KEY = "split"
RESERVED_KEYS = frozenset({INDEX_KEY, VALUES_KEY, SPLIT_KEY})

# First bytes of a Git LFS pointer file (a shard that was not fetched).
LFS_POINTER_PREFIX = b"version https://git-lfs.github.com/spec/v1"


def shard_name(number: int) -> str:
    """``shards/00000.npz`` for shard 0, relative to the dataset folder."""
    return f"{SHARD_DIR}/{number:05d}.npz"


def split_for(index: int, splits: Mapping[str, float]) -> str:
    """The split of sample ``index``: a hash of the index placed on the cumulative fractions.

    Depends on the index only, not on the run's seed or the order samples
    finish in, so a resumed or longer run keeps every earlier sample's split.
    """
    digest = hashlib.sha256(str(int(index)).encode("ascii")).digest()
    u = int.from_bytes(digest[:7], "big") / float(1 << 56)
    total = 0.0
    names = list(splits)
    for name in names:
        total += float(splits[name])
        if u < total:
            return name
    return names[-1]


def read_manifest(folder: Path) -> dict[str, Any] | None:
    """The manifest of a dataset folder; None when it has none."""
    path = Path(folder) / MANIFEST_FILE
    if not path.is_file():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def write_manifest(folder: Path, manifest: Mapping[str, Any]) -> None:
    """Write ``manifest.json`` atomically, so a reader never sees half a file."""
    write_atomic(Path(folder) / MANIFEST_FILE,
                 (json.dumps(manifest, indent=2, sort_keys=False) + "\n").encode("utf-8"))


def write_atomic(path: Path, data: bytes) -> None:
    """Write ``data`` to a temporary file next to ``path``, then rename it into place."""
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise
