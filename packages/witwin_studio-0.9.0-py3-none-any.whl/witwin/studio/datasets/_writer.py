"""Writing a ``witwin.dataset.v1`` folder from a dataset Study's Run.

Two halves, so a process pool can export in parallel and one process still
owns the folder:

- ``SampleExport`` wraps the Study's ``export`` function. It runs wherever
  the point is evaluated (the Run's process, or a pool worker), gives the
  function ``ctx.rng``, and saves what it returns as one staged file
  ``<staging>/<index>.npz``. It returns loss 0: a dataset Run has no
  objective, and the driver only needs a number.
- ``DatasetWriter`` runs in the Run's process. ``collect(index)`` reads a
  staged sample into the buffer; a full buffer becomes the next shard. A
  staged file is deleted only after the manifest lists the shard holding its
  sample, so a crash loses no sample: resuming re-reads the staged files.
"""
from __future__ import annotations

import io
import logging
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ._format import (
    FORMAT,
    INDEX_KEY,
    RESERVED_KEYS,
    SHARD_DIR,
    SPLIT_KEY,
    VALUES_KEY,
    read_manifest,
    shard_name,
    split_for,
    write_atomic,
    write_manifest,
)

logger = logging.getLogger("witwin.studio")

# The metric a dropped sample (export returned None) records; the writer skips it.
DROPPED_METRIC = "dropped"
_VALUES_STAGED = "_values"


def _staged_file(staging: Path, index: int) -> Path:
    return staging / f"{int(index):09d}.npz"


def sample_arrays(out: Any) -> dict[str, Any]:
    """What ``export`` returned as ``{field: numpy array}``; raises ``TypeError`` / ``ValueError``.

    Values may be numbers, numpy arrays, nested lists, or tensors (moved to
    the CPU). Field names are Python names that do not start with ``_`` and
    are not ``index``, ``values`` or ``split``.
    """
    import numpy as np

    if not isinstance(out, Mapping) or not out:
        raise TypeError(f"export must return a non-empty dict of arrays, or None to drop the sample, "
                        f"not {type(out).__name__}")
    arrays: dict[str, Any] = {}
    for name, value in out.items():
        if not isinstance(name, str) or not name.isidentifier() or name.startswith("_") \
                or name in RESERVED_KEYS:
            raise ValueError(f"export field {name!r} must be a Python name that does not start with "
                             f"'_' and is not {', '.join(sorted(RESERVED_KEYS))}")
        if hasattr(value, "detach"):
            value = value.detach().cpu().numpy()
        array = np.asarray(value)
        if array.dtype == object:
            raise TypeError(f"export field {name!r} is not numeric or text")
        arrays[name] = array
    return arrays


class SampleExport:
    """The export function as an objective: stages each sample and returns loss 0.

    ``variables`` are the Study's variable names, in the order of the
    ``values`` array. ``ctx.rng`` is a numpy ``Generator`` seeded from the
    run's seed and the sample index, so a sample is the same however the
    points are spread over workers.
    """

    def __init__(self, fn: Callable[[Any], Any], staging: Path | str, seed: int,
                 variables: Sequence[str]) -> None:
        self.fn = fn
        self.staging = Path(staging)
        self.seed = int(seed)
        self.variables = list(variables)

    def __call__(self, ctx: Any) -> dict[str, float]:
        import numpy as np

        ctx.rng = np.random.default_rng([self.seed, int(ctx.step)])
        out = self.fn(ctx)
        if out is None:
            return {"loss": 0.0, DROPPED_METRIC: 1.0}
        arrays = sample_arrays(out)
        arrays[_VALUES_STAGED] = np.asarray([float(ctx.parameter(name)) for name in self.variables],
                                            dtype=np.float64)
        buffer = io.BytesIO()
        np.savez(buffer, **arrays)
        self.staging.mkdir(parents=True, exist_ok=True)
        write_atomic(_staged_file(self.staging, ctx.step), buffer.getvalue())
        return {"loss": 0.0}


class DatasetWriter:
    """Packs staged samples into shards of ``shard_size`` and keeps ``manifest.json`` current.

    ``resume`` False starts the folder over (shards, manifest and staged
    files are removed); True keeps the shards the manifest lists, removes
    unlisted ones and re-buffers staged samples no shard holds yet.
    ``source`` is stored in the manifest (study, run_id, scene, scene_sha256).
    """

    def __init__(self, folder: Path | str, staging: Path | str, *, shard_size: int,
                 splits: Mapping[str, float], variables: Sequence[str], seed: int,
                 source: Mapping[str, Any], resume: bool = False) -> None:
        self.folder = Path(folder)
        self.staging = Path(staging)
        self.shard_size = int(shard_size)
        self.splits = dict(splits)
        self.variables = list(variables)
        self.skipped = 0
        self._buffer: list[tuple[int, dict[str, Any]]] = []
        (self.folder / SHARD_DIR).mkdir(parents=True, exist_ok=True)
        self.staging.mkdir(parents=True, exist_ok=True)
        now = _now()
        previous = read_manifest(self.folder) if resume else None
        if previous is not None and previous.get("format") != FORMAT:
            previous = None
        if previous is None:
            self._clear()
            self.manifest: dict[str, Any] = {
                "format": FORMAT, **dict(source), "seed": int(seed), "variables": self.variables,
                "fields": {}, "splits": self.splits, "split_counts": {name: 0 for name in self.splits},
                "samples": 0, "skipped": 0, "shards": [], "complete": False,
                "created": now, "updated": now,
            }
            self._done: set[int] = set()
        else:
            self.manifest = previous
            self.manifest.update({**dict(source), "complete": False, "updated": now})
            self.skipped = int(previous.get("skipped") or 0)
            listed = {entry["file"] for entry in previous.get("shards", [])}
            for path in (self.folder / SHARD_DIR).glob("*.npz"):
                if f"{SHARD_DIR}/{path.name}" not in listed:
                    path.unlink(missing_ok=True)
            self._done = self._listed_indexes()
            for path in sorted(self.staging.glob("*.npz")):
                index = int(path.stem)
                if index in self._done:
                    path.unlink(missing_ok=True)
                else:
                    self.collect(index)
        write_manifest(self.folder, self.manifest)

    @property
    def samples(self) -> int:
        """Samples in written shards plus the ones buffered for the next shard."""
        return int(self.manifest["samples"]) + len(self._buffer)

    def collect(self, index: int) -> None:
        """Take the staged sample ``index`` into the buffer; writes a shard when it is full.

        A staged sample whose fields do not match the dataset's (another
        field set, shape or dtype kind) is skipped with a warning and counted
        in ``skipped``.
        """
        import numpy as np

        path = _staged_file(self.staging, index)
        if index in self._done or not path.is_file():
            return
        with np.load(path, allow_pickle=False) as data:
            arrays = {name: data[name] for name in data.files}
        problem = self._schema_problem(arrays)
        if problem is not None:
            logger.warning("dataset sample %d skipped: %s", index, problem)
            self.skipped += 1
            path.unlink(missing_ok=True)
            return
        self._buffer.append((int(index), arrays))
        if len(self._buffer) >= self.shard_size:
            self.flush()

    def flush(self) -> None:
        """Write the buffered samples as the next shard (fewer than ``shard_size`` is fine)."""
        import numpy as np

        if not self._buffer:
            return
        buffered, self._buffer = self._buffer, []
        buffered.sort(key=lambda item: item[0])
        indexes = [index for index, _ in buffered]
        splits = [split_for(index, self.splits) for index in indexes]
        fields = [name for name in buffered[0][1] if name != _VALUES_STAGED]
        arrays: dict[str, Any] = {name: np.stack([sample[name] for _, sample in buffered]) for name in fields}
        arrays[INDEX_KEY] = np.asarray(indexes, dtype=np.int64)
        arrays[VALUES_KEY] = np.stack([sample[_VALUES_STAGED] for _, sample in buffered]).astype(np.float64)
        arrays[SPLIT_KEY] = np.asarray(splits, dtype=str)
        number = len(self.manifest["shards"])
        name = shard_name(number)
        payload = io.BytesIO()
        np.savez(payload, **arrays)
        write_atomic(self.folder / name, payload.getvalue())
        counts = self.manifest["split_counts"]
        for split in splits:
            counts[split] = int(counts.get(split, 0)) + 1
        self.manifest["shards"].append({"file": name, "samples": len(indexes),
                                        "first_index": indexes[0], "last_index": indexes[-1]})
        self.manifest["samples"] = int(self.manifest["samples"]) + len(indexes)
        self.manifest["skipped"] = self.skipped
        self.manifest["updated"] = _now()
        write_manifest(self.folder, self.manifest)
        self._done.update(indexes)
        for index in indexes:
            _staged_file(self.staging, index).unlink(missing_ok=True)

    def close(self, complete: bool) -> dict[str, Any]:
        """Flush the last shard and mark the manifest ``complete``; returns the manifest."""
        self.flush()
        self.manifest["complete"] = bool(complete)
        self.manifest["skipped"] = self.skipped
        self.manifest["updated"] = _now()
        write_manifest(self.folder, self.manifest)
        return self.manifest

    # Remove what a fresh run replaces.
    def _clear(self) -> None:
        shutil.rmtree(self.folder / SHARD_DIR, ignore_errors=True)
        (self.folder / SHARD_DIR).mkdir(parents=True, exist_ok=True)
        for path in self.staging.glob("*.npz"):
            path.unlink(missing_ok=True)

    # Indexes held by the shards the manifest lists.
    def _listed_indexes(self) -> set[int]:
        import numpy as np

        done: set[int] = set()
        for entry in self.manifest.get("shards", []):
            with np.load(self.folder / entry["file"], allow_pickle=False) as data:
                done.update(int(i) for i in data[INDEX_KEY])
        return done

    # Why a sample does not fit the fields recorded so far; records them for the first sample.
    def _schema_problem(self, arrays: Mapping[str, Any]) -> str | None:
        import numpy as np

        schema = {name: {"dtype": str(a.dtype), "shape": list(a.shape)}
                  for name, a in arrays.items() if name != _VALUES_STAGED}
        fields = self.manifest["fields"]
        if not fields:
            self.manifest["fields"] = schema
            return None
        if set(schema) != set(fields):
            return f"fields {sorted(schema)} differ from the dataset's {sorted(fields)}"
        for name, spec in schema.items():
            if spec["shape"] != fields[name]["shape"]:
                return f"field {name!r} has shape {spec['shape']}, the dataset {fields[name]['shape']}"
            # Same kind (float, int, text) stacks; float32 next to float64 is widened.
            if np.dtype(spec["dtype"]).kind != np.dtype(fields[name]["dtype"]).kind:
                return f"field {name!r} has dtype {spec['dtype']}, the dataset {fields[name]['dtype']}"
        return None


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
