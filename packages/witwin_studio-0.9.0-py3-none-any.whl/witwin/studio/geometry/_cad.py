"""B-rep helpers for model results: topology counts, measurement queries, export, import.

Runs inside the model runner process (the Project interpreter), never in the
ProjectServer. build123d is imported only when a function needs it; every
function takes shapes in the model's unit and returns meters (SI).

Measurement queries (``measure``) are a small JSON language:

    {"op": "distance", "a": SEL, "b": SEL}   # shortest distance between two selections
    {"op": "bbox", "of": SEL}                # bounding box of a selection
    {"op": "area", "of": SEL} / {"op": "volume", "of": BODY}
    {"op": "holes", "of": BODY}              # diameters and counts of cylindrical holes
                                             # (concave cylinder faces; inside fillets count)
    {"op": "min_wall", "of": BODY}           # approximate minimum wall thickness

A selection SEL is a string:

    "<body>"            the whole body
    "<body>.<face>"     one face: top, bottom (largest / smallest center z of the
                        faces whose normal points +z / -z), +x, -x, +y, -y, +z, -z
                        (the outermost face whose normal points that way), or
                        face<N> (index in build123d's face order)
    "<body>@<anchor>"   an anchor point of a body; "@<anchor>" a loose model anchor
"""
from __future__ import annotations

import math
import re
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

__all__ = ["MeasureError", "export_shape", "import_shapes", "measure", "topology"]

_AXES = {"x": 0, "y": 1, "z": 2}
_FACE_SELECTOR = re.compile(r"^(top|bottom|[+-][xyz]|face\d+)$")
# Faces considered by min_wall; past this the pairwise search gets slow.
MAX_WALL_FACES = 400


class MeasureError(ValueError):
    """A measurement query is malformed or names something that does not exist."""


def _is_brep(shape: Any) -> bool:
    return shape is not None and hasattr(shape, "faces") and hasattr(shape, "wrapped")


def topology(shape: Any, multiplier: float) -> Optional[Dict[str, Any]]:
    """Exact B-rep counts and sizes of a build123d shape (meters), or None for a mesh."""
    if not _is_brep(shape):
        return None
    out: Dict[str, Any] = {
        "solids": len(shape.solids()), "faces": len(shape.faces()), "edges": len(shape.edges()),
    }
    try:
        out["volume"] = float(shape.volume) * multiplier ** 3
    except Exception:  # noqa: BLE001 - a sheet or wire has no volume
        out["volume"] = None
    try:
        out["area"] = float(shape.area) * multiplier ** 2
    except Exception:  # noqa: BLE001
        out["area"] = None
    return out


def _vec(v: Any) -> Tuple[float, float, float]:
    return float(v.X), float(v.Y), float(v.Z)


def _pick_face(shape: Any, selector: str) -> Any:
    faces = list(shape.faces())
    if not faces:
        raise MeasureError("the body has no faces")
    if selector.startswith("face"):
        index = int(selector[4:])
        if index >= len(faces):
            raise MeasureError(f"face{index} does not exist; the body has {len(faces)} faces")
        return faces[index]
    if selector in ("top", "bottom"):
        selector = "+z" if selector == "top" else "-z"
    sign = 1.0 if selector[0] == "+" else -1.0
    axis = _AXES[selector[1]]
    best, best_key = None, None
    for face in faces:
        center = face.center()
        try:
            normal = _vec(face.normal_at(center))
        except Exception:  # noqa: BLE001 - not a face normal can be taken of
            continue
        if normal[axis] * sign < 0.9:
            continue
        key = _vec(center)[axis] * sign
        if best_key is None or key > best_key:
            best, best_key = face, key
    if best is None:
        raise MeasureError(f"no face of the body has a normal along {selector}")
    return best


def _select(selection: Any, bodies: Mapping[str, Any], anchors: Mapping[str, Any]) -> Tuple[str, Any]:
    """('shape', shape) or ('point', (x, y, z)) in the model unit."""
    if not isinstance(selection, str) or not selection:
        raise MeasureError(f"a selection must be a string such as 'patch.top', got {selection!r}")
    if "@" in selection:
        body, _, name = selection.partition("@")
        table = anchors.get(body or None, {})
        if name not in table:
            raise MeasureError(f"no anchor {name!r} on {body or 'the model'}; known: {sorted(table)}")
        return "point", table[name]
    body, _, face = selection.partition(".")
    if body not in bodies:
        raise MeasureError(f"no body {body!r}; bodies: {sorted(bodies)}")
    shape = bodies[body]
    if not _is_brep(shape):
        raise MeasureError(f"body {body!r} is a mesh, not a B-rep; topology queries need build123d shapes")
    if not face:
        return "shape", shape
    if not _FACE_SELECTOR.match(face):
        raise MeasureError(f"unknown face selector {face!r}; use top, bottom, +x, -x, +y, -y, +z, -z or faceN")
    return "shape", _pick_face(shape, face)


def _as_shape(kind: str, value: Any) -> Any:
    if kind == "shape":
        return value
    from build123d import Vertex

    return Vertex(*value)


def _holes(shape: Any) -> List[Tuple[float, int]]:
    """``(diameter, count)`` of concave cylindrical faces (holes), largest first.

    A hole is counted once per axis line: OCC may split one bore into two
    half-cylinder faces. Concave fillets (inside corners) are concave
    cylinders too and are counted.
    """
    from build123d import GeomType

    found: List[Tuple[float, Tuple[float, ...], Tuple[float, ...]]] = []
    for face in shape.faces():
        if face.geom_type != GeomType.CYLINDER:
            continue
        center = face.center()
        normal = face.normal_at(center)
        axis = face.axis_of_rotation
        # Vector from the axis to the face point; a hole's outward normal points back at the axis.
        to_axis = axis.position - center
        to_axis = to_axis - axis.direction * to_axis.dot(axis.direction)
        if not (to_axis.length > 0 and normal.dot(to_axis) > 0):
            continue
        direction = axis.direction.normalized()
        if next(c for c in _vec(direction) if abs(c) > 1e-9) < 0:
            direction = -direction
        foot = axis.position - direction * axis.position.dot(direction)  # axis point nearest the origin
        diameter = 2.0 * float(face.radius)
        line = (_vec(direction), _vec(foot))
        if not any(abs(d - diameter) <= 1e-9 * max(1.0, d) and math.dist(line[0], dl) < 1e-6
                   and math.dist(line[1], fl) < 1e-6 * max(1.0, diameter) for d, dl, fl in found):
            found.append((diameter, *line))
    counts: List[Tuple[float, int]] = []
    for diameter, _, _ in sorted(found, key=lambda item: -item[0]):
        if counts and abs(counts[-1][0] - diameter) <= 1e-9 * max(1.0, diameter):
            counts[-1] = (counts[-1][0], counts[-1][1] + 1)
        else:
            counts.append((diameter, 1))
    return counts


def _min_wall(shape: Any) -> Optional[Dict[str, Any]]:
    """Smallest distance between two opposed, non-adjacent faces.

    Approximation, on purpose: a wall is two faces whose normals at their
    closest points point away from each other along the line joining them.
    Exact for slabs, tubes and boxes; a thin neck between curved faces that
    are not opposed at their closest points is missed.
    """
    faces = list(shape.faces())[:MAX_WALL_FACES]
    best: Optional[Dict[str, Any]] = None
    for i, fa in enumerate(faces):
        edges_a = {e.wrapped.__hash__() for e in fa.edges()}
        for j in range(i + 1, len(faces)):
            fb = faces[j]
            if edges_a & {e.wrapped.__hash__() for e in fb.edges()}:
                continue  # adjacent faces meet at an edge: distance 0, not a wall
            distance, pa, pb = fa.distance_to_with_closest_points(fb)
            if distance <= 0:
                continue
            try:
                na, nb = fa.normal_at(pa), fb.normal_at(pb)
            except Exception:  # noqa: BLE001
                continue
            gap = (pb - pa).normalized()
            # Material lies between the two faces when both normals point outward, away from each other.
            if na.dot(gap) < -0.9 and nb.dot(gap) > 0.9:
                if best is None or distance < best["value"]:
                    best = {"value": float(distance), "faces": [i, j], "at": [_vec(pa), _vec(pb)]}
    return best


def measure(queries: Sequence[Mapping[str, Any]], bodies: Mapping[str, Any],
            anchors: Mapping[Optional[str], Mapping[str, Sequence[float]]], multiplier: float) -> List[Dict[str, Any]]:
    """Run each query; lengths come back in meters (``value``) and the model unit (``value_model``).

    ``bodies``: body name -> build123d shape (model unit). ``anchors``: body
    name (None for loose anchors) -> {anchor name: point}. A failing query
    gives ``{"error": ...}`` and the others still run.
    """
    out: List[Dict[str, Any]] = []
    for query in queries:
        try:
            out.append(_measure_one(query, bodies, anchors, multiplier))
        except MeasureError as exc:
            out.append({"query": dict(query), "error": str(exc)})
    return out


def _measure_one(query: Mapping[str, Any], bodies: Mapping[str, Any], anchors: Any,
                 multiplier: float) -> Dict[str, Any]:
    op = query.get("op")
    result: Dict[str, Any] = {"query": dict(query)}
    if op == "distance":
        ka, a = _select(query.get("a"), bodies, anchors)
        kb, b = _select(query.get("b"), bodies, anchors)
        if ka == kb == "point":
            d = math.dist(a, b)
        else:
            d = float(_as_shape(ka, a).distance_to(_as_shape(kb, b)))
        result.update(value=d * multiplier, value_model=d, unit="m")
        return result
    of = query.get("of")
    if op == "bbox":
        kind, sel = _select(of, bodies, anchors)
        if kind == "point":
            raise MeasureError("bbox needs a body or a face, not an anchor")
        box = sel.bounding_box()
        lo, hi = _vec(box.min), _vec(box.max)
        result.update(min=[v * multiplier for v in lo], max=[v * multiplier for v in hi],
                      size=[(h - l) * multiplier for l, h in zip(lo, hi)], unit="m")
        return result
    if op in ("area", "volume"):
        kind, sel = _select(of, bodies, anchors)
        if kind == "point":
            raise MeasureError(f"{op} needs a body or a face, not an anchor")
        if op == "volume" and "." in str(of):
            raise MeasureError("volume needs a whole body, not a face")
        value = float(getattr(sel, op))
        power = 2 if op == "area" else 3
        result.update(value=value * multiplier ** power, value_model=value, unit=f"m^{power}")
        return result
    if op == "holes":
        kind, sel = _select(of, bodies, anchors)
        if kind == "point" or "." in str(of):
            raise MeasureError("holes needs a whole body")
        holes = _holes(sel)
        result.update(diameters=[d * multiplier for d, _ in holes], diameters_model=[d for d, _ in holes],
                      counts=[n for _, n in holes], unit="m")
        return result
    if op == "min_wall":
        kind, sel = _select(of, bodies, anchors)
        if kind == "point" or "." in str(of):
            raise MeasureError("min_wall needs a whole body")
        found = _min_wall(sel)
        if found is None:
            result.update(value=None, note="no pair of opposed faces found")
        else:
            result.update(value=found["value"] * multiplier, value_model=found["value"], unit="m",
                          faces=found["faces"], estimate="smallest gap between opposed, non-adjacent faces")
        return result
    raise MeasureError(f"unknown op {op!r}; use distance, bbox, area, volume, holes or min_wall")


def export_shape(shape: Any, path: str, fmt: str, unit: str) -> None:
    """Write a build123d shape as STEP (with its length unit) or BREP (unitless, in ``unit``)."""
    import build123d as bd

    if fmt == "step":
        # build123d's Unit has M, MM and MC (micrometre); STEP has no nanometre here.
        member = {"m": "M", "mm": "MM", "um": "MC"}.get(unit)
        if member is None or not hasattr(bd.Unit, member):
            raise ValueError(f"STEP export does not support unit {unit!r}; use m, mm or um in CONFIG")
        if not bd.export_step(shape, path, unit=getattr(bd.Unit, member)):
            raise RuntimeError("build123d.export_step failed")
    elif fmt == "brep":
        if not bd.export_brep(shape, path):
            raise RuntimeError("build123d.export_brep failed")
    else:
        raise ValueError(f"unknown B-rep format {fmt!r}")


def import_shapes(path: str) -> List[Tuple[str, Any]]:
    """Read a STEP, IGES or BREP file into named build123d solids (or the whole shape).

    STEP and IGES load in millimetres (Open CASCADE converts to mm); BREP
    carries no unit.
    """
    import build123d as bd

    lower = path.lower()
    if lower.endswith((".step", ".stp")):
        shape = bd.import_step(path)
    elif lower.endswith((".brep", ".brp")):
        shape = bd.import_brep(path)
    elif lower.endswith((".iges", ".igs")):
        from OCP.IFSelect import IFSelect_RetDone
        from OCP.IGESControl import IGESControl_Reader

        reader = IGESControl_Reader()
        if reader.ReadFile(path) != IFSelect_RetDone:
            raise ValueError(f"cannot read IGES file {path}")
        reader.TransferRoots()
        shape = bd.Compound(reader.OneShape())
    else:
        raise ValueError("geometry import reads .step/.stp, .iges/.igs and .brep files")
    solids = list(shape.solids())
    if len(solids) > 1:
        return [(f"solid{i}", s) for i, s in enumerate(solids)]
    return [("solid0" if solids else "shape", solids[0] if solids else shape)]
