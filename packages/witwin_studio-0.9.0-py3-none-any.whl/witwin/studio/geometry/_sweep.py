"""Swept and revolved solids in numpy: a closed 2D profile swept along a 3D path, an (r, z) profile revolved.

    import witwin.studio as ws
    from witwin.studio import geometry as g

    path = g.helix(radius=10, pitch=4, turns=5)             # (N, 3) points around the z axis
    wire = g.sweep(g.circle_profile(0.8), path)             # MeshData, closed and outward-wound
    ring = g.revolve([(8, -2), (12, -2), (12, 2), (8, 2)])  # a washer: (r, z) polygon about z
    return [ws.Body(wire, name="spring", material="Steel"), ws.Body(ring, name="washer")]

Lengths are in whatever unit the caller works in (in a model file,
``CONFIG["unit"]``). Angles are degrees. Paths and profiles are numpy arrays
or lists of points; every solid comes back as a watertight ``MeshData`` whose
triangles face outward, so ``geometry.check`` reports a volume.

Frames. ``sweep`` carries the profile along the path with rotation-minimizing
frames (the double-reflection method of Wang, Juttler, Zheng and Liu, ACM TOG
27(1), 2008): the profile does not spin around the path the way Frenet
frames do at inflection points, and a straight path keeps the profile's
orientation. At a sharp corner of a polyline the ring is a miter: it lies in
the bisecting plane and is stretched by ``1 / cos(half turn angle)`` so the
wall keeps its thickness. A closed path spreads the frame's leftover twist
evenly so the tube closes without a seam.

numpy only. This module imports numpy at import time; ``witwin.studio.geometry``
loads it on first use so ``import witwin.studio`` stays light.
"""
from __future__ import annotations

import math
from typing import Any, List, Optional, Sequence, Tuple

import numpy as np

from ._convert import MeshData

__all__ = ["arc", "circle_profile", "helix", "rect_profile", "revolve", "sweep"]

# A miter wider than 1 / cos(78 deg) ~ 4.8 times the profile means a corner of
# more than about 156 degrees; the tube would fold over itself there.
_MIN_MITER_COS = math.cos(math.radians(78))


# ------------------------------------------------------------------ profiles
def circle_profile(radius: float, segments: int = 16) -> np.ndarray:
    """A closed counter-clockwise ``segments``-gon of ``radius`` around (0, 0): a round wire's profile."""
    if not radius > 0:
        raise ValueError(f"circle_profile radius must be positive, got {radius!r}")
    if int(segments) < 3:
        raise ValueError(f"circle_profile needs at least 3 segments, got {segments!r}")
    t = np.linspace(0.0, 2.0 * math.pi, int(segments), endpoint=False)
    return np.c_[radius * np.cos(t), radius * np.sin(t)]


def rect_profile(width: float, height: float) -> np.ndarray:
    """A ``width`` x ``height`` rectangle centred on (0, 0), counter-clockwise: a strip or flat-wire profile.

    In ``sweep`` the first profile axis (``width``) runs along the frame's
    normal, the second (``height``) along its binormal.
    """
    if not (width > 0 and height > 0):
        raise ValueError(f"rect_profile needs a positive width and height, got {width!r} x {height!r}")
    w, h = width / 2.0, height / 2.0
    return np.array([[-w, -h], [w, -h], [w, h], [-w, h]], dtype=float)


# --------------------------------------------------------------------- paths
def helix(radius: float, pitch: float, turns: float, *, z0: float = 0.0, start_angle: float = 0.0,
          left: bool = False, segments_per_turn: int = 36, center: Sequence[float] = (0.0, 0.0)) -> np.ndarray:
    """Points of a helix around the z axis: ``(N, 3)``, from ``z0`` up to ``z0 + pitch * turns``.

    ``radius`` is to the wire centre line; ``pitch`` is the axial advance per
    turn; ``turns`` may be fractional (a QFH element is half a turn). A
    right-handed helix (default) turns counter-clockwise seen from +z as it
    rises; ``left=True`` turns clockwise. ``start_angle`` (degrees from +x)
    sets where it starts. A negative ``pitch`` winds downward.
    """
    if not radius > 0:
        raise ValueError(f"helix radius must be positive, got {radius!r}")
    if not turns > 0:
        raise ValueError(f"helix turns must be positive, got {turns!r}")
    if int(segments_per_turn) < 6:
        raise ValueError(f"segments_per_turn must be at least 6, got {segments_per_turn!r}")
    count = max(2, int(math.ceil(turns * int(segments_per_turn))) + 1)
    t = np.linspace(0.0, float(turns), count)
    sign = -1.0 if left else 1.0
    angle = math.radians(start_angle) + sign * 2.0 * math.pi * t
    cx, cy = float(center[0]), float(center[1])
    return np.c_[cx + radius * np.cos(angle), cy + radius * np.sin(angle), z0 + pitch * t]


_PLANES = {"xy": (0, 1, 2), "xz": (0, 2, 1), "yz": (1, 2, 0)}


def arc(radius: float, start_angle: float, end_angle: float, *, center: Sequence[float] = (0.0, 0.0, 0.0),
        plane: str = "xy", segments: Optional[int] = None) -> np.ndarray:
    """Points of a circular arc, ``(N, 3)``, from ``start_angle`` to ``end_angle`` (degrees).

    ``plane`` is ``"xy"`` (angles from +x towards +y), ``"xz"`` (from +x towards
    +z) or ``"yz"`` (from +y towards +z). ``end_angle < start_angle`` runs the
    other way; a 360 degree span gives a closed loop (first point repeated
    last), which ``sweep`` turns into a ring. ``segments`` defaults to one per
    10 degrees.
    """
    if not radius > 0:
        raise ValueError(f"arc radius must be positive, got {radius!r}")
    if plane not in _PLANES:
        raise ValueError(f"arc plane must be one of {sorted(_PLANES)}, got {plane!r}")
    span = float(end_angle) - float(start_angle)
    if span == 0:
        raise ValueError("arc start_angle and end_angle are equal")
    n = int(segments) if segments is not None else max(2, int(math.ceil(abs(span) / 10.0)))
    t = np.radians(np.linspace(float(start_angle), float(end_angle), n + 1))
    a, b, c = _PLANES[plane]
    out = np.zeros((len(t), 3))
    out[:, a] = radius * np.cos(t)
    out[:, b] = radius * np.sin(t)
    return out + np.asarray(center, dtype=float)


# --------------------------------------------------------------------- sweep
def _unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v, axis=-1, keepdims=True)
    return v / np.where(n > 0, n, 1.0)


def _profile(profile: Any) -> np.ndarray:
    """The profile as a counter-clockwise ``(M, 2)`` array (a repeated first point is dropped)."""
    p = np.asarray(profile, dtype=float)
    if p.ndim != 2 or p.shape[1] != 2 or len(p) < 3:
        raise ValueError(f"a profile is an (M, 2) array of at least 3 points, got shape {p.shape}")
    if np.allclose(p[0], p[-1]):
        p = p[:-1]
    if not np.all(np.isfinite(p)):
        raise ValueError("profile contains NaN or infinity")
    x, y = p[:, 0], p[:, 1]
    area = 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(np.roll(x, -1), y))
    if abs(area) <= 1e-12 * float(np.ptp(p, axis=0).max()) ** 2:
        raise ValueError("the profile has no area")
    return p if area > 0 else p[::-1].copy()


def triangulate_polygon(polygon: Any) -> np.ndarray:
    """Ear-clipping triangulation of a simple counter-clockwise polygon; ``(M - 2, 3)`` vertex indices.

    O(M^2): meant for profiles of tens of points (a cap), not for large outlines.
    """
    p = np.asarray(polygon, dtype=float)
    idx = list(range(len(p)))
    tris: List[Tuple[int, int, int]] = []
    scale = float(np.ptp(p, axis=0).max()) or 1.0
    eps = 1e-12 * scale * scale

    def inside(q, a, b, c):
        d1 = (b[0] - a[0]) * (q[1] - a[1]) - (b[1] - a[1]) * (q[0] - a[0])
        d2 = (c[0] - b[0]) * (q[1] - b[1]) - (c[1] - b[1]) * (q[0] - b[0])
        d3 = (a[0] - c[0]) * (q[1] - c[1]) - (a[1] - c[1]) * (q[0] - c[0])
        return d1 >= -eps and d2 >= -eps and d3 >= -eps

    while len(idx) > 3:
        n = len(idx)
        for j in range(n):
            i0, i1, i2 = idx[j - 1], idx[j], idx[(j + 1) % n]
            a, b, c = p[i0], p[i1], p[i2]
            if (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]) <= eps:
                continue  # reflex or flat corner: not an ear
            if any(inside(p[k], a, b, c) for k in idx if k not in (i0, i1, i2)):
                continue
            tris.append((i0, i1, i2))
            idx.pop(j)
            break
        else:
            raise ValueError("the profile is not a simple polygon (its edges cross)")
    tris.append((idx[0], idx[1], idx[2]))
    return np.array(tris, dtype=np.int64)


def _clean_path(path: Any, closed: Optional[bool]) -> Tuple[np.ndarray, bool]:
    p = np.asarray(path, dtype=float)
    if p.ndim != 2 or p.shape[1] != 3 or len(p) < 2:
        raise ValueError(f"a path is an (N, 3) array of at least 2 points, got shape {np.shape(path)}")
    if not np.all(np.isfinite(p)):
        raise ValueError("path contains NaN or infinity")
    scale = max(float(np.ptp(p, axis=0).max()), 1e-300)
    # Consecutive duplicates come from joining paths with np.vstack; drop them.
    keep = np.r_[True, np.linalg.norm(np.diff(p, axis=0), axis=1) > 1e-9 * scale]
    p = p[keep]
    ends_meet = len(p) > 3 and np.linalg.norm(p[0] - p[-1]) <= 1e-6 * scale
    if closed is None:
        closed = ends_meet
    if closed and ends_meet:
        p = p[:-1]
    if len(p) < (3 if closed else 2):
        raise ValueError("the path has too few distinct points")
    return p, bool(closed)


def _rotate_frames(r: np.ndarray, s: np.ndarray, angle: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    c, si = np.cos(angle)[:, None], np.sin(angle)[:, None]
    return c * r + si * s, -si * r + c * s


def _frames(p: np.ndarray, closed: bool, normal: Optional[Sequence[float]]):
    """Tangents, rotation-minimizing normals and binormals, and the miter stretch at each path point."""
    n = len(p)
    seg = _unit(np.roll(p, -1, axis=0) - p)  # seg[i]: direction from point i to i + 1 (wraps when closed)
    if closed:
        incoming, outgoing = np.roll(seg, 1, axis=0), seg
    else:
        seg = seg[:-1]
        incoming = np.vstack([seg[:1], seg])
        outgoing = np.vstack([seg, seg[-1:]])
    summed = incoming + outgoing
    if np.any(np.linalg.norm(summed, axis=1) < 1e-9):
        raise ValueError("the path doubles back on itself (a 180 degree turn)")
    t = _unit(summed)
    miter_cos = np.einsum("ij,ij->i", t, outgoing)
    if np.any(miter_cos < _MIN_MITER_COS):
        raise ValueError("the path has a corner sharper than about 156 degrees; round it with more points")
    bend = outgoing - incoming
    bend_len = np.linalg.norm(bend, axis=1)
    bend = np.where(bend_len[:, None] > 1e-9, bend / np.where(bend_len > 0, bend_len, 1.0)[:, None], 0.0)

    # First normal: the hint, else +z (radial-free for a helix about z), else +x.
    hint = np.asarray(normal if normal is not None else (0.0, 0.0, 1.0), dtype=float)
    r0 = hint - np.dot(hint, t[0]) * t[0]
    if np.linalg.norm(r0) < 1e-6 * max(np.linalg.norm(hint), 1e-300):
        if normal is not None:
            raise ValueError("normal is parallel to the path's start direction")
        hint = np.array([1.0, 0.0, 0.0]) if abs(t[0][0]) < 0.9 else np.array([0.0, 1.0, 0.0])
        r0 = hint - np.dot(hint, t[0]) * t[0]
    r = np.empty_like(p)
    r[0] = r0 / np.linalg.norm(r0)

    def reflect(x0, x1, ri, ti, t1):
        v1 = x1 - x0
        c1 = float(np.dot(v1, v1))
        r_l = ri - (2.0 / c1) * np.dot(v1, ri) * v1
        t_l = ti - (2.0 / c1) * np.dot(v1, ti) * v1
        v2 = t1 - t_l
        c2 = float(np.dot(v2, v2))
        out = r_l if c2 < 1e-30 else r_l - (2.0 / c2) * np.dot(v2, r_l) * v2
        out = out - np.dot(out, t1) * t1  # drop rounding drift out of the normal plane
        return out / np.linalg.norm(out)

    for i in range(n - 1):
        r[i + 1] = reflect(p[i], p[i + 1], r[i], t[i], t[i + 1])
    s = np.cross(t, r)
    if closed:
        # Carried once around, the normal comes back turned by the loop's
        # holonomy angle; spread the correction so the last ring meets the first.
        back = reflect(p[-1], p[0], r[-1], t[-1], t[0])
        angle = math.atan2(float(np.dot(np.cross(back, r[0]), t[0])), float(np.dot(back, r[0])))
        r, s = _rotate_frames(r, s, angle * np.arange(n) / n)
    return t, r, s, 1.0 / miter_cos, bend


def sweep(profile: Any, path: Any, *, closed: Optional[bool] = None, normal: Optional[Sequence[float]] = None,
          twist: float = 0.0) -> MeshData:
    """Sweep a closed 2D ``profile`` along a 3D ``path``; returns a watertight ``MeshData``.

    ``profile``: ``(M, 2)`` points of a simple polygon (``circle_profile``,
    ``rect_profile`` or your own), in the plane across the path: the first
    coordinate runs along the frame normal, the second along the binormal.
    ``path``: ``(N, 3)`` points (``helix``, ``arc``, a polyline, or several
    joined with ``np.vstack``; repeated joint points are dropped). An open
    path gets flat end caps; a path whose last point equals its first (or
    ``closed=True``) makes a ring with no caps. ``normal`` is the frame normal
    at the start (default: +z made perpendicular to the path, else +x).
    ``twist`` turns the profile by that many degrees from start to end,
    evenly along the length (a closed path needs a multiple of 360 for the
    profile to meet itself).

    Sample the path finely enough for its curvature (``helix`` uses 36 points
    per turn). A sharp polyline corner gets a mitered ring; the profile must be
    narrower than the corner's radius of turn on the inside, else the tube
    folds over itself (not checked).
    """
    prof = _profile(profile)
    p, closed = _clean_path(path, closed)
    t, r, s, stretch, bend = _frames(p, closed, normal)
    n, m = len(p), len(prof)
    if twist:
        length = np.r_[0.0, np.cumsum(np.linalg.norm(np.diff(p, axis=0), axis=1))]
        total = length[-1] + (np.linalg.norm(p[0] - p[-1]) if closed else 0.0)
        r, s = _rotate_frames(r, s, math.radians(twist) * length / total)

    offsets = prof[None, :, 0:1] * r[:, None, :] + prof[None, :, 1:2] * s[:, None, :]  # (n, m, 3)
    along = np.einsum("nmk,nk->nm", offsets, bend)
    offsets = offsets + ((stretch - 1.0)[:, None] * along)[:, :, None] * bend[:, None, :]
    vertices = (p[:, None, :] + offsets).reshape(-1, 3)

    rings = n if closed else n - 1
    i = np.arange(rings)[:, None]
    k = np.arange(m)[None, :]
    a, a1 = i * m + k, i * m + (k + 1) % m
    b, b1 = ((i + 1) % n) * m + k, ((i + 1) % n) * m + (k + 1) % m
    # Profile counter-clockwise seen from +t, frames right-handed (r x s = t):
    # these quads face outward.
    faces = [np.stack([a, a1, b1], -1).reshape(-1, 3), np.stack([a, b1, b], -1).reshape(-1, 3)]
    if not closed:
        cap = triangulate_polygon(prof)
        faces += [cap[:, ::-1], cap + (n - 1) * m]
    return _outward(vertices, np.vstack(faces))


# ------------------------------------------------------------------- revolve
def revolve(profile: Any, *, segments: int = 64) -> MeshData:
    """Revolve a closed ``(r, z)`` polygon a full turn about the z axis; returns a watertight ``MeshData``.

    ``r`` must be >= 0. Points on the axis (``r == 0``) become single pole
    vertices, so a profile that touches the axis gives a solid without a hole
    (a ball: a half circle from ``(0, -R)`` to ``(0, R)``); one that stays off
    it gives a ring (a bearing race, a washer). ``segments`` is the number of
    samples around the axis.
    """
    prof = np.asarray(profile, dtype=float)
    if prof.ndim != 2 or prof.shape[1] != 2 or len(prof) < 3:
        raise ValueError(f"a revolve profile is a (K, 2) array of (r, z) points, got shape {prof.shape}")
    if np.allclose(prof[0], prof[-1]):
        prof = prof[:-1]
    if np.any(prof[:, 0] < 0):
        raise ValueError("revolve profile radii must be >= 0 (the axis is r = 0)")
    seg = int(segments)
    if seg < 3:
        raise ValueError(f"revolve needs at least 3 segments, got {segments!r}")
    scale = float(np.ptp(prof, axis=0).max()) or 1.0
    on_axis = prof[:, 0] <= 1e-12 * scale
    theta = np.linspace(0.0, 2.0 * math.pi, seg, endpoint=False)
    index = np.empty((len(prof), seg), dtype=np.int64)
    vertices: List[np.ndarray] = []
    count = 0
    for kk, (radius, z) in enumerate(prof):
        if on_axis[kk]:
            vertices.append(np.array([[0.0, 0.0, z]]))
            index[kk] = count
            count += 1
        else:
            vertices.append(np.c_[radius * np.cos(theta), radius * np.sin(theta), np.full(seg, z)])
            index[kk] = count + np.arange(seg)
            count += seg
    faces = []
    for kk in range(len(prof)):
        k1 = (kk + 1) % len(prof)
        if on_axis[kk] and on_axis[k1]:
            continue  # an edge along the axis sweeps no area
        for j in range(seg):
            j1 = (j + 1) % seg
            a, a1, b, b1 = index[kk, j], index[kk, j1], index[k1, j], index[k1, j1]
            # Each quad is (a, b, b1) + (a, b1, a1); next to a pole (a == a1 or
            # b == b1) one of the two collapses and is left out.
            if not on_axis[k1]:
                faces.append((a, b, b1))
            if not on_axis[kk]:
                faces.append((a, b1, a1))
    # Which way the profile runs decides the winding; _outward fixes it.
    return _outward(np.vstack(vertices), np.array(faces, dtype=np.int64))


def _outward(vertices: np.ndarray, faces: np.ndarray) -> MeshData:
    """``MeshData`` with the faces flipped when the enclosed signed volume is negative (inside out)."""
    a, b, c = vertices[faces[:, 0]], vertices[faces[:, 1]], vertices[faces[:, 2]]
    if float(np.einsum("ij,ij->i", a, np.cross(b, c)).sum()) < 0:
        faces = faces[:, ::-1]
    return MeshData(np.ascontiguousarray(vertices, dtype=np.float64), np.ascontiguousarray(faces, dtype=np.int64))
