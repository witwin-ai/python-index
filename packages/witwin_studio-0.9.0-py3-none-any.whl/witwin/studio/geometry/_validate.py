"""Mesh statistics and the modeling rules of plan §4.7 (ERROR blocks, WARN informs).

numpy only; nothing here needs trimesh. Two families of checks:

- per body: empty, triangle cap, open (non-watertight) solid, zero volume,
  feature size against the grid step, degenerate triangles, loose vertices,
  inconsistent winding, inside-out solids, size far off the declared unit,
  missing material, conductor sheet without a thickness, outside the
  simulation domain;
- between bodies: overlapping conductors, overlapping dielectrics, port
  anchors that are not on a conductor.

Approximations (each one stated in its message too):

- Feature size is a slab-thickness estimate, ``2 * volume / area`` for a
  closed body (exact for a thin plate; for a round wire it gives the radius,
  half the diameter, so it errs toward reporting), capped by the smallest
  bounding-box extent. Open bodies use the smallest extent.
- Overlaps compare world-space bounding boxes, not the triangles, so touching
  or interleaved bodies (a helix around a rod) can be reported though they do
  not intersect. Because of that, overlaps are warnings, not errors.
- A port anchor counts as "on a conductor" when it lies inside a conductor's
  bounding box grown by 1 % of its diagonal.
- Self-intersection is not checked.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

__all__ = [
    "DEFAULT_MAX_TRIANGLES", "BodyInput", "BodyStats", "GeometryValidationError", "Issue",
    "ValidationReport", "mesh_stats", "validate", "validate_inputs",
]

ERROR = "error"
WARNING = "warning"

# A single mesh larger than this is refused (plan §4.2: "e.g. 2 million").
DEFAULT_MAX_TRIANGLES = 2_000_000
# Sizes in the declared unit outside this range usually mean the wrong unit
# (mm numbers written with unit="m" make a 60 m patch).
_SIZE_RANGE = (1e-3, 1e3)


@dataclass
class Issue:
    """One finding. ``severity`` is ``"error"`` or ``"warning"``; ``code`` is stable for tools."""

    severity: str
    code: str
    message: str
    body: Optional[str] = None
    object_id: Optional[str] = None
    detail: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        out = {"severity": self.severity, "code": self.code, "message": self.message}
        if self.body is not None:
            out["body"] = self.body
        if self.object_id is not None:
            out["object_id"] = self.object_id
        if self.detail:
            out["detail"] = self.detail
        return out


@dataclass
class BodyStats:
    """Statistics of one body. Lengths in meters (SI), in world space."""

    name: str
    object_id: Optional[str]
    triangle_count: int
    vertex_count: int
    bounds_min: List[float]
    bounds_max: List[float]
    size: List[float]
    area: float
    volume: Optional[float]  # None when the mesh is not closed
    watertight: bool
    boundary_edge_count: int
    non_manifold_edge_count: int
    degenerate_face_count: int
    loose_vertex_count: int
    inconsistent_winding_edge_count: int
    feature_size: Optional[float]
    role: str = "other"
    fill: str = "solid"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ValidationReport:
    """Bodies checked plus the issues found. ``ok`` is True when there is no error."""

    bodies: List[BodyStats] = field(default_factory=list)
    issues: List[Issue] = field(default_factory=list)
    grid_step: Optional[float] = None
    max_triangles: int = DEFAULT_MAX_TRIANGLES

    @property
    def errors(self) -> List[Issue]:
        return [i for i in self.issues if i.severity == ERROR]

    @property
    def warnings(self) -> List[Issue]:
        return [i for i in self.issues if i.severity == WARNING]

    @property
    def ok(self) -> bool:
        return not self.errors

    def extend(self, other: "ValidationReport") -> None:
        self.bodies.extend(other.bodies)
        self.issues.extend(other.issues)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "error_count": len(self.errors),
            "warning_count": len(self.warnings),
            "grid_step": self.grid_step,
            "max_triangles": self.max_triangles,
            "issues": [i.to_dict() for i in self.issues],
            "bodies": [b.to_dict() for b in self.bodies],
        }

    def summary(self) -> str:
        """One line per issue, errors first, for exception messages and logs."""
        lines = [f"{len(self.bodies)} body(ies): {len(self.errors)} error(s), {len(self.warnings)} warning(s)"]
        for issue in self.errors + self.warnings:
            where = f" [{issue.body}]" if issue.body else ""
            lines.append(f"  {issue.severity.upper()} {issue.code}{where}: {issue.message}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"ValidationReport(ok={self.ok}, errors={len(self.errors)}, warnings={len(self.warnings)})"


class GeometryValidationError(ValueError):
    """A mesh write was refused because validation found errors.

    ``report`` holds every finding. Pass ``force=True`` to write anyway.
    """

    def __init__(self, report: ValidationReport):
        self.report = report
        super().__init__("geometry validation failed; pass force=True to write anyway\n" + report.summary())


@dataclass
class BodyInput:
    """What the validator needs about one body; vertices in world space, meters."""

    name: str
    vertices: Any
    faces: Any
    role: str = "other"
    fill: str = "solid"
    has_material: bool = True
    anchors: Sequence[Any] = ()  # Anchor objects, points in world space, meters
    object_id: Optional[str] = None
    # Meters per unit the caller declared, for the size check; None skips it
    # (a stored scene does not record which unit its author used).
    unit_multiplier: Optional[float] = 1.0
    # Real thickness of a fill="surface" sheet in meters; None or 0: not given.
    surface_thickness: Optional[float] = None


GridLike = Union[None, float, int, Sequence[float], Mapping[str, Any]]


def _grid(grid: GridLike) -> Tuple[Optional[float], int]:
    """(step in meters, subpixel samples) from a number, 3 numbers or a dict."""
    if grid is None:
        return None, 1
    subpixel = 1
    if isinstance(grid, Mapping):
        subpixel = int(grid.get("subpixel_samples") or grid.get("subpixelSamples") or 1)
        grid = grid.get("step")
        if grid is None:
            return None, subpixel
    if isinstance(grid, (int, float)) and not isinstance(grid, bool):
        step = float(grid)
    else:
        # Per-axis steps: the finest one decides what a body can resolve.
        step = min(float(v) for v in grid)  # type: ignore[union-attr]
    if not step > 0:
        raise ValueError(f"grid step must be positive, got {grid!r}")
    return step, subpixel


def mesh_stats(vertices: Any, faces: Any) -> Dict[str, Any]:
    """Statistics of one triangle mesh, in its own units.

    Keys: ``triangle_count``, ``vertex_count``, ``bounds_min``, ``bounds_max``,
    ``size``, ``area``, ``volume`` (None unless closed), ``signed_volume``,
    ``watertight``, ``boundary_edge_count``, ``non_manifold_edge_count``,
    ``degenerate_face_count``, ``loose_vertex_count``,
    ``inconsistent_winding_edge_count``, ``feature_size``.
    """
    import numpy as np

    v = np.asarray(vertices, dtype=np.float64).reshape(-1, 3)
    f = np.asarray(faces, dtype=np.int64).reshape(-1, 3)
    n_v, n_f = len(v), len(f)
    if n_v:
        lo, hi = v.min(axis=0), v.max(axis=0)
    else:
        lo = hi = np.zeros(3)
    size = hi - lo
    diagonal = float(np.linalg.norm(size))
    out: Dict[str, Any] = {
        "triangle_count": n_f, "vertex_count": n_v,
        "bounds_min": lo.tolist(), "bounds_max": hi.tolist(), "size": size.tolist(),
    }
    if n_f == 0:
        out.update(area=0.0, volume=None, signed_volume=0.0, watertight=False, boundary_edge_count=0,
                   non_manifold_edge_count=0, degenerate_face_count=0, loose_vertex_count=n_v,
                   inconsistent_winding_edge_count=0, feature_size=None)
        return out

    a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
    cross = np.cross(b - a, c - a)
    areas = 0.5 * np.linalg.norm(cross, axis=1)
    # A triangle is degenerate when it repeats an index or its area is below
    # (1e-6 of the diagonal)^2: a sliver that a voxelizer cannot see.
    repeated = (f[:, 0] == f[:, 1]) | (f[:, 1] == f[:, 2]) | (f[:, 0] == f[:, 2])
    degenerate = repeated | (areas <= (1e-6 * diagonal) ** 2)

    # Undirected edges keyed as lo * N + hi; an edge of a closed 2-manifold is
    # used by exactly two triangles.
    e_from = f[:, [0, 1, 2]].reshape(-1)
    e_to = f[:, [1, 2, 0]].reshape(-1)
    valid = e_from != e_to
    e_from, e_to = e_from[valid], e_to[valid]
    lo_i, hi_i = np.minimum(e_from, e_to), np.maximum(e_from, e_to)
    _, counts = np.unique(lo_i * n_v + hi_i, return_counts=True)
    boundary = int(np.count_nonzero(counts == 1))
    non_manifold = int(np.count_nonzero(counts > 2))
    # Consistent winding: each directed edge appears once; a repeat means two
    # neighbours disagree on which side is outside.
    _, directed_counts = np.unique(e_from * n_v + e_to, return_counts=True)
    inconsistent = int(np.count_nonzero(directed_counts > 1))

    watertight = boundary == 0 and non_manifold == 0
    signed_volume = float(np.einsum("ij,ij->i", a, np.cross(b, c)).sum() / 6.0)
    area = float(areas.sum())
    volume = abs(signed_volume) if watertight else None
    smallest_extent = float(size.min())
    if volume is not None and area > 0:
        feature = min(2.0 * volume / area, smallest_extent) if smallest_extent > 0 else 2.0 * volume / area
    else:
        feature = smallest_extent
    loose = n_v - int(np.unique(f).size)
    out.update(area=area, volume=volume, signed_volume=signed_volume, watertight=watertight,
               boundary_edge_count=boundary, non_manifold_edge_count=non_manifold,
               degenerate_face_count=int(np.count_nonzero(degenerate)), loose_vertex_count=loose,
               inconsistent_winding_edge_count=inconsistent, feature_size=float(feature))
    return out


def _overlap(a: BodyStats, b: BodyStats) -> float:
    """Volume of the intersection of two bounding boxes (0 when they only touch)."""
    extent = 1.0
    for i in range(3):
        lo = max(a.bounds_min[i], b.bounds_min[i])
        hi = min(a.bounds_max[i], b.bounds_max[i])
        if hi <= lo:
            return 0.0
        extent *= hi - lo
    return extent


def _check_body(body: BodyInput, stats: Dict[str, Any], step: Optional[float], subpixel: int,
                max_triangles: int, domain: Optional[Tuple[Sequence[float], Sequence[float]]]) -> List[Issue]:
    issues: List[Issue] = []

    def add(severity: str, code: str, message: str, **detail: Any) -> None:
        issues.append(Issue(severity, code, message, body.name, body.object_id, detail))

    n_f = stats["triangle_count"]
    if n_f == 0:
        add(ERROR, "empty_mesh", "the mesh has no triangles")
        return issues
    if n_f > max_triangles:
        add(ERROR, "too_many_triangles",
            f"{n_f} triangles is over the limit of {max_triangles}; decimate the mesh or coarsen its "
            "tessellation tolerance", triangle_count=n_f, limit=max_triangles)
    solid = body.fill != "surface"
    if solid and not stats["watertight"]:
        add(ERROR, "not_watertight",
            f"the mesh is not closed ({stats['boundary_edge_count']} open edges, "
            f"{stats['non_manifold_edge_count']} non-manifold edges); close it, or pass fill=\"surface\" "
            "for a sheet", boundary_edge_count=stats["boundary_edge_count"],
            non_manifold_edge_count=stats["non_manifold_edge_count"])
    diagonal = sum(s * s for s in stats["size"]) ** 0.5
    if solid and stats["volume"] is not None and stats["volume"] <= 1e-9 * diagonal ** 3:
        add(ERROR, "zero_volume", "the closed mesh encloses no volume", volume=stats["volume"])
    if solid and stats["watertight"] and stats["inconsistent_winding_edge_count"] == 0 \
            and stats["signed_volume"] < 0:
        add(WARNING, "inverted_normals", "the triangles face inward (negative signed volume); flip the winding")
    if stats["inconsistent_winding_edge_count"]:
        add(WARNING, "inconsistent_winding",
            f"{stats['inconsistent_winding_edge_count']} edges join triangles wound in opposite directions",
            edge_count=stats["inconsistent_winding_edge_count"])

    feature = stats["feature_size"]
    if step is not None and solid and feature is not None:
        approx = ("feature size is estimated as 2*volume/area (slab thickness; a round wire reports its "
                  "radius), capped by the smallest bounding-box extent")
        detail = {"feature_size": feature, "grid_step": step, "estimate": approx}
        if feature < 0.5 * step:
            severity = WARNING if subpixel > 1 else ERROR
            add(severity, "feature_below_grid",
                f"smallest feature ~{feature:.4g} m is under half the grid step {step:.4g} m; refine the grid, "
                "use fill=\"surface\" for thin sheets, or enable subpixel sampling", **detail)
        elif feature < 2.0 * step:
            add(WARNING, "feature_near_grid",
                f"smallest feature ~{feature:.4g} m spans fewer than two grid steps ({step:.4g} m)", **detail)

    if body.unit_multiplier:
        largest = max(stats["size"]) / body.unit_multiplier
        if largest > _SIZE_RANGE[1] or (0 < largest < _SIZE_RANGE[0]):
            add(WARNING, "suspicious_size",
                f"largest extent is {largest:.4g} in the declared unit; check the unit argument",
                largest_extent_in_unit=largest)
    if not body.has_material:
        add(WARNING, "no_material", "no material is set")
    if body.fill == "surface" and body.role == "conductor" and not body.surface_thickness:
        # A warning, not an error: a zero-thickness PEC sheet is a valid model,
        # but a real trace or plane (35 um copper) loses its thickness and
        # conductor loss when the solver does not know it.
        add(WARNING, "no_surface_thickness",
            "conductor sheet (fill=\"surface\") has no surface_thickness; the solver treats it as "
            "infinitely thin. Pass surface_thickness in meters (e.g. 35e-6 for 1 oz copper)")
    if stats["degenerate_face_count"]:
        add(WARNING, "degenerate_faces", f"{stats['degenerate_face_count']} zero-area triangles",
            count=stats["degenerate_face_count"])
    if stats["loose_vertex_count"]:
        add(WARNING, "loose_vertices", f"{stats['loose_vertex_count']} vertices belong to no triangle",
            count=stats["loose_vertex_count"])
    if domain is not None:
        d_lo, d_hi = domain
        outside = any(stats["bounds_min"][i] < float(d_lo[i]) or stats["bounds_max"][i] > float(d_hi[i])
                      for i in range(3))
        if outside:
            add(ERROR, "outside_domain", "the body extends outside the simulation domain",
                domain_min=[float(x) for x in d_lo], domain_max=[float(x) for x in d_hi])
    return issues


def validate_inputs(bodies: Sequence[BodyInput], *, grid: GridLike = None,
                    max_triangles: Optional[int] = None,
                    domain: Optional[Tuple[Sequence[float], Sequence[float]]] = None) -> ValidationReport:
    """Check bodies already in world space (meters) and return the report."""
    step, subpixel = _grid(grid)
    limit = DEFAULT_MAX_TRIANGLES if max_triangles is None else int(max_triangles)
    report = ValidationReport(grid_step=step, max_triangles=limit)
    for body in bodies:
        stats = mesh_stats(body.vertices, body.faces)
        report.issues.extend(_check_body(body, stats, step, subpixel, limit, domain))
        report.bodies.append(BodyStats(
            name=body.name, object_id=body.object_id,
            triangle_count=stats["triangle_count"], vertex_count=stats["vertex_count"],
            bounds_min=stats["bounds_min"], bounds_max=stats["bounds_max"], size=stats["size"],
            area=stats["area"], volume=stats["volume"], watertight=stats["watertight"],
            boundary_edge_count=stats["boundary_edge_count"],
            non_manifold_edge_count=stats["non_manifold_edge_count"],
            degenerate_face_count=stats["degenerate_face_count"], loose_vertex_count=stats["loose_vertex_count"],
            inconsistent_winding_edge_count=stats["inconsistent_winding_edge_count"],
            feature_size=stats["feature_size"], role=body.role, fill=body.fill))

    # Pairwise checks on bounding boxes (see the module docstring).
    pairs = list(zip(bodies, report.bodies))
    for i, (body_a, a) in enumerate(pairs):
        for body_b, b in pairs[i + 1:]:
            if a.triangle_count == 0 or b.triangle_count == 0 or _overlap(a, b) <= 0:
                continue
            if a.role == b.role == "conductor":
                code, what = "conductor_overlap", "conductors"
            elif a.role == b.role == "dielectric":
                code, what = "dielectric_overlap", "dielectrics"
            else:
                continue
            report.issues.append(Issue(
                WARNING, code,
                f"{what} '{a.name}' and '{b.name}' have overlapping bounding boxes; if they intersect, "
                f"{'they short' if what == 'conductors' else 'the solver priority decides which wins'} "
                "(bounding-box test, not an exact intersection)",
                a.name, a.object_id, {"other": b.name, "other_object_id": b.object_id}))
    conductors = [s for s in report.bodies if s.role == "conductor" and s.triangle_count]
    for body in bodies:
        for item in body.anchors:
            if getattr(item, "kind", None) != "port":
                continue
            point = item.point
            on = False
            for s in conductors:
                pad = 0.01 * sum(x * x for x in s.size) ** 0.5
                if all(s.bounds_min[k] - pad <= point[k] <= s.bounds_max[k] + pad for k in range(3)):
                    on = True
                    break
            if not on:
                report.issues.append(Issue(
                    WARNING, "port_off_conductor",
                    f"port anchor '{item.name}' is not on any conductor (bounding-box test)",
                    body.name, body.object_id, {"anchor": item.name, "point": list(point)}))
    return report


def validate(bodies: Iterable[Any], *, grid: GridLike = None, max_triangles: Optional[int] = None,
             domain: Optional[Tuple[Sequence[float], Sequence[float]]] = None,
             unit: str = "m") -> ValidationReport:
    """Check meshes before writing them; returns a ``ValidationReport``.

    ``bodies`` are ``ws.Body`` objects or anything ``to_mesh`` accepts (taken
    as role "other", fill "solid", no material). Coordinates are in ``unit``.
    ``grid`` is the solver grid step in meters: a number, three per-axis
    steps, or ``{"step": 0.5e-3, "subpixel_samples": 4}``. ``domain`` is
    ``(min_xyz, max_xyz)`` in meters.
    """
    from ..units import find_unit
    from ._body import Body
    from ._convert import to_mesh

    found = find_unit("length", unit)
    if found is None:
        raise ValueError(f"unknown length unit {unit!r}")
    factor = found.multiplier
    inputs = []
    for index, item in enumerate(bodies):
        body = item if isinstance(item, Body) else Body(to_mesh(item))
        inputs.append(BodyInput(
            name=body.name or f"body{index}", vertices=body.mesh.vertices * factor, faces=body.mesh.faces,
            role=body.role or "other", fill=body.fill or "solid", has_material=body.material is not None,
            anchors=[a.scaled(factor) for a in body.anchors], unit_multiplier=factor,
            surface_thickness=body.surface_thickness))
    return validate_inputs(inputs, grid=grid, max_triangles=max_triangles, domain=domain)
