"""Up axis: the one conversion between a Z-up author frame and the Y-up Scene frame.

The Scene, the viewport, the render views (``top`` looks down -Y) and the
placement Tools (``scene.mate`` face ``top`` = +Y) treat **+Y as up**. CAD and
EM geometry is authored **+Z up**: build123d extrudes along +Z, layout stacks
put layers along z, Maxwell's cylinders default to ``axis="z"``. A body
declares which frame it was built in with ``up``:

- ``"y"``: already in the Scene frame; nothing changes.
- ``"z"``: rotated once, where it enters the Scene, by -90 degrees about X:
  ``(x, y, z) -> (x, z, -y)``. Author +Z becomes Scene +Y (a board lies flat,
  its top face is ``top``), author +Y becomes Scene -Z (``back``), X stays.

The rotation is proper (determinant +1), so triangle winding and outward
normals survive it. Vertices, normals, anchor points and anchor normals all go
through the functions below; nothing else in the SDK or the server rotates
geometry for the up axis. Model checks (``geometry.check``,
``geometry.measure``) stay in the author frame on purpose: an assertion such
as ``patch.bbox.min.z >= 1.6`` reads the way the model was written.
"""
from __future__ import annotations

from typing import Any, Optional

__all__ = ["SCENE_UP", "UP_AXES", "check_up", "from_scene", "to_scene"]

SCENE_UP = "y"
UP_AXES = ("y", "z")


def check_up(up: Any, what: str = "up") -> str:
    """``up`` as ``"y"`` or ``"z"``; anything else raises ``ValueError``."""
    if isinstance(up, str) and up.lower() in UP_AXES:
        return up.lower()
    raise ValueError(f"{what} must be 'y' (Scene frame) or 'z' (CAD / EM frame), got {up!r}")


def _rotate(points: Any, up: Optional[str], inverse: bool) -> Any:
    if up is None or check_up(up) == SCENE_UP:
        return points
    if isinstance(points, tuple) and len(points) == 3 and not hasattr(points[0], "__len__"):
        x, y, z = (float(v) for v in points)
        return (x, -z, y) if inverse else (x, z, -y)
    import numpy as np

    pts = np.asarray(points)
    out = np.empty_like(pts)
    out[..., 0] = pts[..., 0]
    if inverse:   # Scene -> author: (x, y, z) -> (x, -z, y)
        out[..., 1] = -pts[..., 2]
        out[..., 2] = pts[..., 1]
    else:         # author -> Scene: (x, y, z) -> (x, z, -y)
        out[..., 1] = pts[..., 2]
        out[..., 2] = -pts[..., 1]
    return out


def to_scene(points: Any, up: Optional[str]) -> Any:
    """Points or directions in an author frame with ``up`` -> the Scene frame.

    ``points`` is an (..., 3) array (a new array is returned) or one
    ``(x, y, z)`` tuple (a tuple is returned). ``up`` None or ``"y"`` returns
    the input unchanged.
    """
    return _rotate(points, up, inverse=False)


def from_scene(points: Any, up: Optional[str]) -> Any:
    """The inverse of ``to_scene``: Scene frame -> an author frame with ``up``."""
    return _rotate(points, up, inverse=True)


def mesh_to_scene(mesh: Any, up: Optional[str]) -> Any:
    """A ``MeshData`` with vertices and normals in the Scene frame (a copy unless ``up`` is y)."""
    if up is None or check_up(up) == SCENE_UP:
        return mesh
    from ._convert import MeshData

    return MeshData(to_scene(mesh.vertices, up), mesh.faces.copy(),
                    None if mesh.normals is None else to_scene(mesh.normals, up))


def mesh_between(mesh: Any, source: Optional[str], target: Optional[str]) -> Any:
    """A ``MeshData`` moved from the ``source`` up frame into the ``target`` one."""
    if (source or SCENE_UP) == (target or SCENE_UP):
        return mesh
    from ._convert import MeshData

    vertices = from_scene(to_scene(mesh.vertices, source), target)
    normals = None if mesh.normals is None else from_scene(to_scene(mesh.normals, source), target)
    return MeshData(vertices, mesh.faces.copy(), normals)


def anchor_to_scene(anchor: Any, up: Optional[str], *, source: Optional[str] = None) -> Any:
    """An ``Anchor`` (point and normal) moved into the Scene frame, or into ``up``'s frame from ``source``.

    With only ``up``: author frame ``up`` -> Scene. With ``source``: frame
    ``source`` -> frame ``up`` (used when a model returns a body built in
    another up frame than its own).
    """
    from ._body import Anchor

    if source is None:
        convert = lambda v: to_scene(v, up)  # noqa: E731
    else:
        convert = lambda v: from_scene(to_scene(v, source), up)  # noqa: E731
    point = convert(tuple(anchor.point))
    normal = None if anchor.normal is None else convert(tuple(anchor.normal))
    return Anchor(anchor.name, point, normal, anchor.kind)


def handle_dict_to_scene(entry: Any, up: Optional[str]) -> Any:
    """A handle dict (``Handle.to_dict`` plus ``si_scale``) with ``point`` and ``axis`` in the Scene frame.

    ``axis`` is a direction, and the rotation is proper, so it stays a unit
    vector and the drag sign is unchanged.
    """
    moved = dict(entry)
    moved["point"] = list(to_scene(tuple(entry["point"]), up))
    moved["axis"] = list(to_scene(tuple(entry["axis"]), up))
    return moved
