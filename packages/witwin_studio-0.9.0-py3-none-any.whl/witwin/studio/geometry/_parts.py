"""Standard mechanical parts as numpy meshes: ISO metric hex bolts and nuts, involute spur gears, ball bearings.

    import witwin.studio as ws
    from witwin.studio import geometry as g

    CONFIG = {"unit": "mm", "up": "z"}

    def build(ctx):
        bolt = g.hex_bolt("M10", 40)                 # head underside on z = 0, shank up +z
        nut = g.hex_nut("M10", z0=20)                # screwed on: lower face 20 mm up
        gears = g.gear_pair(2, 20, 40, face_width=10, bore=10)
        return [bolt, nut, *gears, *g.ball_bearing("6204", position=(0, 0, 60))]

Every function works in millimetres (the standards' tables are in mm), Z up,
and returns ``ws.Body`` objects with a watertight mesh, a ``name`` and
``material="Steel"`` (role ``"other"``); pass ``material=`` / ``role=`` to
change them, ``position=`` to move a part. Use them in a model file with
``CONFIG = {"unit": "mm", "up": "z"}``.

Sources. Thread: ISO 68-1 basic profile (60 degree flanks, crest flat P/8)
with the external root at d3 = d - 1.22687 P (ISO 965-1) and the internal
crest at D1 = d - 1.08253 P; coarse pitches from ISO 261/262. Bolt head s and
k: ISO 4017 / 4014 nominal. Nut s and m: ISO 4032 (m maximum). Gears: ISO 53
basic rack (addendum 1 m, dedendum 1.25 m), involute flanks, no root fillet.
Bearings: ISO 15 boundary dimensions; ball count and size are typical catalog
values (SKF / NSK), which vary a little between makers.
"""
from __future__ import annotations

import math
import re
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Union

import numpy as np

from ._body import Body
from ._convert import MeshData
from ._sweep import _outward, revolve

__all__ = [
    "ball_bearing", "bearing_size", "gear_pair", "hex_bolt", "hex_nut", "iso_metric", "spur_gear",
]

MaterialLike = Union[str, Mapping[str, Any], None]
STEEL = "Steel"

# d: (coarse pitch P, width across flats s, head height k (ISO 4017), nut height m (ISO 4032 max)), all mm.
_ISO_METRIC: Dict[float, Tuple[float, float, float, float]] = {
    1.6: (0.35, 3.2, 1.1, 1.3), 2: (0.4, 4.0, 1.4, 1.6), 2.5: (0.45, 5.0, 1.7, 2.0),
    3: (0.5, 5.5, 2.0, 2.4), 4: (0.7, 7.0, 2.8, 3.2), 5: (0.8, 8.0, 3.5, 4.7),
    6: (1.0, 10.0, 4.0, 5.2), 8: (1.25, 13.0, 5.3, 6.8), 10: (1.5, 16.0, 6.4, 8.4),
    12: (1.75, 18.0, 7.5, 10.8), 14: (2.0, 21.0, 8.8, 12.8), 16: (2.0, 24.0, 10.0, 14.8),
    18: (2.5, 27.0, 11.5, 15.8), 20: (2.5, 30.0, 12.5, 18.0), 22: (2.5, 34.0, 14.0, 19.4),
    24: (3.0, 36.0, 15.0, 21.5), 27: (3.0, 41.0, 17.0, 23.8), 30: (3.5, 46.0, 18.7, 25.6),
    33: (3.5, 50.0, 21.0, 28.7), 36: (4.0, 55.0, 22.5, 31.0), 39: (4.0, 60.0, 25.0, 33.4),
    42: (4.5, 65.0, 26.0, 34.0), 45: (4.5, 70.0, 28.0, 36.0), 48: (5.0, 75.0, 30.0, 38.0),
    52: (5.0, 80.0, 33.0, 42.0), 56: (5.5, 85.0, 35.0, 45.0), 60: (5.5, 90.0, 38.0, 48.0),
    64: (6.0, 95.0, 40.0, 51.0),
}
_SQRT3 = math.sqrt(3.0)


def iso_metric(size: Union[str, float]) -> Dict[str, float]:
    """ISO metric coarse thread and hex dimensions for ``size`` (``"M10"``, ``10``), in mm.

    Keys: ``d`` (nominal), ``pitch`` (ISO 261 coarse), ``s`` (width across
    flats), ``e`` (across corners, s / cos 30), ``k`` (bolt head height,
    ISO 4017), ``m`` (nut height, ISO 4032), ``d3`` (external minor diameter,
    ISO 965-1), ``D1`` (internal minor diameter), ``d2`` (pitch diameter).
    Sizes M1.6 to M64.
    """
    text = str(size).strip().upper()
    match = re.fullmatch(r"M?\s*(\d+(?:\.\d+)?)", text)
    d = float(match.group(1)) if match else None
    if d is None or d not in _ISO_METRIC:
        known = ", ".join(f"M{k:g}" for k in _ISO_METRIC)
        raise ValueError(f"no ISO metric size {size!r}; known: {known}")
    pitch, s, k, m = _ISO_METRIC[d]
    return {"d": d, "pitch": pitch, "s": s, "e": s / math.cos(math.radians(30)), "k": k, "m": m,
            "d3": d - 1.226869 * pitch, "D1": d - 1.082532 * pitch, "d2": d - 0.649519 * pitch}


# --------------------------------------------------------------- ring lofts
def _loft(zs: Sequence[float], radii: np.ndarray, theta: np.ndarray, closed: bool) -> MeshData:
    """A surface through rings ``(z_j, r_j(theta))`` around the z axis.

    ``closed=False``: a solid capped with a fan at the first and last ring.
    ``closed=True``: the ring list is a loop (up the outside, down the
    inside), which makes a solid with a hole along the axis.
    """
    n, m = len(theta), len(zs)
    z = np.repeat(np.asarray(zs, dtype=float), n)
    r = np.asarray(radii, dtype=float).reshape(-1)
    t = np.tile(theta, m)
    vertices = np.c_[r * np.cos(t), r * np.sin(t), z]
    j = np.arange(m if closed else m - 1)[:, None]
    i = np.arange(n)[None, :]
    a, a1 = j * n + i, j * n + (i + 1) % n
    b, b1 = ((j + 1) % m) * n + i, ((j + 1) % m) * n + (i + 1) % n
    faces = [np.stack([a, a1, b1], -1).reshape(-1, 3), np.stack([a, b1, b], -1).reshape(-1, 3)]
    if not closed:
        c0, c1 = m * n, m * n + 1
        vertices = np.vstack([vertices, [[0.0, 0.0, zs[0]], [0.0, 0.0, zs[-1]]]])
        ring = np.arange(n)
        faces.append(np.c_[np.full(n, c0), (ring + 1) % n, ring])
        faces.append(np.c_[np.full(n, c1), (m - 1) * n + ring, (m - 1) * n + (ring + 1) % n])
    return _outward(vertices, np.vstack(faces))


def _thread_depth(z: float, theta: np.ndarray, pitch: float, max_depth: float) -> np.ndarray:
    """Radial depth below the major diameter of a right-hand ISO 68-1 thread at height ``z``.

    ``u`` is the position within one pitch along the helix through angle
    ``theta``; the crest flat (P/8) is centred on u = 0, and the 60 degree
    flanks fall sqrt(3) mm per mm of axial distance until ``max_depth``.
    """
    u = ((z - pitch * theta / (2.0 * math.pi)) / pitch) % 1.0
    off_crest = np.minimum(u, 1.0 - u) - 1.0 / 16.0
    return np.clip(off_crest * _SQRT3 * pitch, 0.0, max_depth)


def _hexagon(theta: np.ndarray, s: float) -> np.ndarray:
    """Radius of a hexagon with width across flats ``s`` whose flats face +y and -y."""
    rel = theta % (math.pi / 3.0) - math.pi / 6.0
    return s / 2.0 / np.cos(rel)


def _chamfered_hex(theta: np.ndarray, s: float, dist: float) -> np.ndarray:
    """The hexagon cut by a 30 degree chamfer cone ``dist`` mm from the chamfered face.

    The cone meets the face on a circle of 0.95 s (ISO 4032 bearing face dw >= 0.9 s).
    """
    return np.minimum(_hexagon(theta, s), 0.475 * s + dist * _SQRT3)


def _chamfer_height(s: float) -> float:
    """How far the 30 degree chamfer of ``_chamfered_hex`` reaches before the corners are whole."""
    return (s / math.sqrt(3.0) - 0.475 * s) / _SQRT3


def _segments(segments: int) -> np.ndarray:
    # A multiple of 6 puts a sample on every hexagon corner; otherwise the
    # across-corners size would be short.
    n = max(12, int(round(int(segments) / 6.0)) * 6)
    return np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)


def _moved(mesh: MeshData, position: Optional[Sequence[float]]) -> MeshData:
    if position is None:
        return mesh
    offset = np.asarray(position, dtype=float).reshape(3)
    return MeshData(mesh.vertices + offset, mesh.faces)


# --------------------------------------------------------------- fasteners
def hex_bolt(size: Union[str, float] = "M10", length: float = 40.0, *, threaded: bool = True,
             thread_length: Optional[float] = None, segments: int = 72, rows_per_pitch: int = 12,
             name: str = "bolt", material: MaterialLike = STEEL, role: str = "other",
             position: Optional[Sequence[float]] = None) -> Body:
    """ISO 4017 / 4014 hex head bolt with a modelled helical thread; returns a ``Body``.

    Frame (mm, Z up): the axis is the z axis, the head's underside is on
    z = 0 with the head below it (z = -k .. 0), and the shank runs up to
    z = ``length``. Two flats face +y and -y. The head has a 30 degree
    chamfer on its top; the tip a 45 degree chamfer to below the thread root.

    ``size``: ``"M10"`` or ``10`` (M1.6 to M64, coarse pitch). ``threaded``:
    False gives a plain shank of diameter d (fast, few triangles).
    ``thread_length``: threaded length from the tip (ISO 4014 b); None
    threads up to the head (ISO 4017). The thread is right-handed with the
    ISO 68-1 profile. ``segments`` (samples around the axis, rounded to a
    multiple of 6) and ``rows_per_pitch`` (rings per pitch) set the mesh
    size: about ``2 * segments * rows_per_pitch * length / pitch`` triangles
    (M10 x 40: 46 000).
    """
    iso = iso_metric(size)
    d, pitch, s, k = iso["d"], iso["pitch"], iso["s"], iso["k"]
    if not length > 0:
        raise ValueError(f"bolt length must be positive, got {length!r}")
    theta = _segments(segments)
    rows = max(4, int(rows_per_pitch))
    r_major, depth = d / 2.0, (d - iso["d3"]) / 2.0
    r_tip = iso["d3"] / 2.0 - 0.1 * pitch  # the 45 degree point chamfer starts just under the root
    chamfer = _chamfer_height(s)
    zs: List[float] = list(-k + np.linspace(0.0, chamfer, 7)) + [0.0]
    radii: List[np.ndarray] = [_chamfered_hex(theta, s, z + k) for z in zs[:-1]] + [_hexagon(theta, s)]

    plain = np.full(len(theta), r_major)
    if threaded:
        z_thread = 0.0 if thread_length is None else max(0.0, length - float(thread_length))
        # Below z_thread the shank is plain; one ring just under it keeps the run-out short.
        shank = [0.0, z_thread - pitch / rows] if z_thread > pitch / rows else []
        steps = int(math.ceil((length - z_thread) / (pitch / rows)))
        shank += list(np.linspace(z_thread, length, steps + 1))
    else:
        z_thread = math.inf
        shank = [0.0, length - (r_major - r_tip), length]
    for z in shank:
        r = plain if z < z_thread - 1e-9 else r_major - _thread_depth(z, theta, pitch, depth)
        zs.append(z)
        radii.append(np.minimum(r, r_tip + (length - z)))
    mesh = _loft(zs, np.array(radii), theta, closed=False)
    return Body(_moved(mesh, position), name=name, material=material, role=role)


def hex_nut(size: Union[str, float] = "M10", *, z0: float = 0.0, threaded: bool = True,
            clearance: Optional[float] = None, segments: int = 72, rows_per_pitch: int = 12,
            name: str = "nut", material: MaterialLike = STEEL, role: str = "other",
            position: Optional[Sequence[float]] = None) -> Body:
    """ISO 4032 hex nut, double chamfered, with a modelled internal thread; returns a ``Body``.

    Frame (mm, Z up): axis along z, lower face at ``z0``, upper face at
    ``z0 + m``; two flats face +y and -y, like ``hex_bolt``. The thread's
    phase is fixed to the absolute z, so a nut at any ``z0`` fits a
    ``hex_bolt`` of the same size on the same axis: screw it along the bolt
    with ``z0``, not with ``position`` (``position`` is applied last and
    moves the thread with it). ``clearance`` (mm, default 0.05 P) is the
    radial play to the bolt's thread so the two do not touch. Both faces have
    a 90 degree countersink to 1.08 d (ISO 4032 da max).
    ``threaded=False`` gives a plain bore of diameter d.
    """
    iso = iso_metric(size)
    d, pitch, s, m = iso["d"], iso["pitch"], iso["s"], iso["m"]
    theta = _segments(segments)
    rows = max(4, int(rows_per_pitch))
    z1 = z0 + m
    chamfer = _chamfer_height(s)
    outer_z = list(z0 + np.linspace(0.0, chamfer, 7)) + list(z1 - np.linspace(chamfer, 0.0, 7))
    radii = [_chamfered_hex(theta, s, min(z - z0, z1 - z)) for z in outer_z]
    clear = 0.05 * pitch if clearance is None else float(clearance)
    r_minor, r_sink = iso["D1"] / 2.0, 0.54 * d
    depth = (d - iso["D1"]) / 2.0 + clear  # the internal crest stays at D1 whatever the play
    steps = int(math.ceil(m / (pitch / rows))) if threaded else 1
    inner_z = list(np.linspace(z1, z0, steps + 1))
    if not threaded:
        sink = r_sink - d / 2.0
        inner_z = [z1, z1 - sink, z0 + sink, z0]
    for z in inner_z:
        if threaded:
            bore = d / 2.0 + clear - _thread_depth(z, theta, pitch, depth)
            bore = np.maximum(bore, r_minor)
        else:
            bore = np.full(len(theta), d / 2.0)
        radii.append(np.maximum(bore, r_sink - min(z - z0, z1 - z)))
    mesh = _loft(outer_z + inner_z, np.array(radii), theta, closed=True)
    return Body(_moved(mesh, position), name=name, material=material, role=role)


# -------------------------------------------------------------------- gears
def _involute(a: float) -> float:
    return math.tan(a) - a


def _gear_outline(module: float, teeth: int, pressure_angle: float, addendum: float, dedendum: float,
                  backlash: float, flank_points: int) -> Tuple[np.ndarray, np.ndarray]:
    """``(points, polar angles)`` of a spur gear outline, counter-clockwise, tooth 0 centred on +x.

    The angles never decrease along the outline (equal only along a radial
    flank), which ``_zip`` relies on.
    """
    alpha = math.radians(pressure_angle)
    rp = module * teeth / 2.0
    ra, rf, rb = rp + addendum * module, rp - dedendum * module, rp * math.cos(alpha)
    if rf <= 0:
        raise ValueError(f"{teeth} teeth are too few for dedendum {dedendum} m (root radius {rf:g} mm)")
    # Half the tooth's angular thickness at the pitch circle, then along the involute.
    psi = (math.pi * module / 2.0 - backlash) / (2.0 * rp)
    radii = np.linspace(max(rb, rf), ra, max(3, int(flank_points)))
    half = psi + _involute(alpha) - np.array([_involute(math.acos(min(1.0, rb / r))) for r in radii])
    keep = half > 1e-3 * psi
    if not keep.all():  # pointed teeth: stop the flank where the two sides meet
        radii, half = radii[keep], half[keep]
    if rf < rb:  # radial flank below the base circle (no undercut is modelled)
        radii, half = np.r_[rf, radii], np.r_[half[0], half]
    pitch_angle = 2.0 * math.pi / teeth
    gap = pitch_angle - 2.0 * half[0]
    if gap <= 0:
        raise ValueError("the teeth overlap at the root; check backlash and the tooth count")
    tip = np.linspace(-half[-1], half[-1], 5)[1:-1]
    root = np.linspace(half[0], half[0] + gap, 6)[1:-1]
    angle_one = np.r_[-half, tip, half[::-1], root]
    radius_one = np.r_[radii, np.full(len(tip), radii[-1]), radii[::-1], np.full(len(root), rf)]
    angle = (angle_one[None, :] + pitch_angle * np.arange(teeth)[:, None]).reshape(-1)
    radius = np.tile(radius_one, teeth)
    return np.c_[radius * np.cos(angle), radius * np.sin(angle)], angle


def _zip(outer_angle: np.ndarray, inner_angle: np.ndarray, n: int, m: int) -> List[Tuple[str, int, int]]:
    """Triangles of the band between two closed curves that are star-shaped about the origin.

    Both lists of polar angles increase and span one turn; the curves are
    walked together, always advancing the one whose next point comes first.
    Returns ``(kind, i, j)``: kind ``"o"`` is (outer i, outer i+1, inner j),
    ``"i"`` is (outer i, inner j+1, inner j); indices wrap at ``n`` and ``m``.
    """
    out_a = np.r_[outer_angle, outer_angle[0] + 2.0 * math.pi]
    in_a = np.r_[inner_angle, inner_angle[0] + 2.0 * math.pi]
    i = j = 0
    tris = []
    while i < n or j < m:
        if j >= m or (i < n and out_a[i + 1] <= in_a[j + 1]):
            tris.append(("o", i, j))
            i += 1
        else:
            tris.append(("i", i, j))
            j += 1
    return tris


def _extrude_star(outline: np.ndarray, outline_angle: np.ndarray, hole_radius: float, zs: np.ndarray,
                  turns: np.ndarray, hole_segments: int) -> MeshData:
    """Extrude a star-shaped outline through layers ``zs``, layer ``l`` turned by ``turns[l]`` radians.

    ``hole_radius > 0`` leaves a round hole (a bore). Otherwise a small inner
    polygon is fanned from the centre, which keeps the triangles off radial
    outline edges; that case takes exactly two layers (a straight prism).
    """
    n = len(outline)
    m = int(hole_segments)
    a0 = outline_angle[0]
    inner_angle = a0 + 2.0 * math.pi * (np.arange(m) + 0.5) / m
    r_in = hole_radius if hole_radius > 0 else 0.4 * float(np.linalg.norm(outline, axis=1).min())
    inner = np.c_[r_in * np.cos(inner_angle), r_in * np.sin(inner_angle)]
    layers = len(zs)
    per = n + m
    verts = []
    for z, turn in zip(zs, turns):
        c, s = math.cos(turn), math.sin(turn)
        ring = np.vstack([outline, inner]) @ np.array([[c, s], [-s, c]])
        verts.append(np.c_[ring, np.full(per, z)])
    vertices = np.vstack(verts)
    faces: List[Tuple[int, int, int]] = []
    band = _zip(outline_angle, inner_angle, n, m)

    def cap(base: int, up: bool) -> None:
        for kind, i, j in band:
            o0, o1 = base + i % n, base + (i + 1) % n
            q0, q1 = base + n + j % m, base + n + (j + 1) % m
            tri = (o0, o1, q0) if kind == "o" else (o0, q1, q0)
            faces.append(tri if up else tri[::-1])

    cap(0, False)
    cap((layers - 1) * per, True)
    for layer in range(layers - 1):
        a, b = layer * per, (layer + 1) * per
        for i in range(n):  # outline walls face outward
            i1 = (i + 1) % n
            faces += [(a + i, a + i1, b + i1), (a + i, b + i1, b + i)]
        for j in range(m):
            j1 = (j + 1) % m
            if hole_radius > 0:  # bore walls face the axis
                faces += [(a + n + j, b + n + j1, a + n + j1), (a + n + j, b + n + j, b + n + j1)]
    if hole_radius <= 0:  # close the inner polygon with fans at both ends
        centre = len(vertices)
        vertices = np.vstack([vertices, [[0.0, 0.0, zs[0]], [0.0, 0.0, zs[-1]]]])
        for j in range(m):
            j1 = (j + 1) % m
            faces.append((centre, n + j1, n + j))
            top = (layers - 1) * per + n
            faces.append((centre + 1, top + j, top + j1))
    return _outward(vertices, np.array(faces, dtype=np.int64))


def spur_gear(module: float, teeth: int, *, face_width: float = 10.0, bore: float = 0.0,
              pressure_angle: float = 20.0, helix_angle: float = 0.0, rotation: float = 0.0,
              backlash: float = 0.0, addendum: float = 1.0, dedendum: float = 1.25, flank_points: int = 10,
              layers: Optional[int] = None, name: str = "gear", material: MaterialLike = STEEL,
              role: str = "other", position: Optional[Sequence[float]] = None) -> Body:
    """Involute spur (or helical) gear; returns a ``Body``.

    Frame (mm, Z up): axis along z, faces at z = -face_width/2 and
    +face_width/2, centred on the origin (``position`` moves it). Tooth 0 is
    centred on +x, turned by ``rotation`` degrees counter-clockwise.

    Sizes (ISO 53 basic rack with ``addendum`` = 1 and ``dedendum`` = 1.25):
    pitch diameter m z, tip diameter m (z + 2), root diameter m (z - 2.5),
    base diameter m z cos(pressure_angle). ``bore`` is the shaft hole
    diameter (0: solid). ``backlash`` (mm) thins each tooth at the pitch
    circle. ``helix_angle`` (degrees, at the pitch circle) twists the teeth
    into a helical gear, right-handed when positive; it needs a bore.
    Flanks are exact involutes from the base circle, radial below it; no
    root fillet or undercut. ``flank_points`` sets the samples per flank;
    ``layers`` the slices along z of a helical gear (default: one per 2
    degrees of twist).
    """
    z = int(teeth)
    if z < 6:
        raise ValueError(f"a gear needs at least 6 teeth, got {teeth!r}")
    if not (module > 0 and face_width > 0):
        raise ValueError("module and face_width must be positive")
    outline, angle = _gear_outline(module, z, pressure_angle, addendum, dedendum, backlash, flank_points)
    rf = module * (z / 2.0 - dedendum)
    if bore >= 2.0 * rf * 0.95:
        raise ValueError(f"bore {bore:g} mm leaves no material under the root circle ({2 * rf:g} mm)")
    rp = module * z / 2.0
    twist_total = face_width * math.tan(math.radians(helix_angle)) / rp
    if helix_angle and bore <= 0:
        raise ValueError("a helical gear needs a bore (bore > 0)")
    if bore <= 0:
        layers = 2  # a solid gear is a straight prism; _extrude_star fills it from the centre
    elif layers is None:
        layers = 2 if not helix_angle else max(2, int(math.ceil(abs(math.degrees(twist_total)) / 2.0)) + 1)
    zs = np.linspace(-face_width / 2.0, face_width / 2.0, layers)
    turns = math.radians(rotation) + twist_total * (zs - zs[0]) / face_width
    hole_segments = max(24, min(128, 4 * z)) if bore > 0 else 24
    mesh = _extrude_star(outline, angle, bore / 2.0, zs, turns, hole_segments)
    return Body(_moved(mesh, position), name=name, material=material, role=role)


def gear_pair(module: float, teeth_1: int, teeth_2: int, *, face_width: float = 10.0, bore: float = 0.0,
              pressure_angle: float = 20.0, backlash: float = 0.0, names: Sequence[str] = ("gear_1", "gear_2"),
              material: MaterialLike = STEEL, flank_points: int = 10) -> List[Body]:
    """Two meshing spur gears: gear 1 on the origin, gear 2 on +x at the centre distance m (z1 + z2) / 2.

    Gear 1 has a tooth on +x; gear 2 is turned so a gap faces it on the line
    between the centres. Same frame and parameters as ``spur_gear``.
    """
    distance = module * (int(teeth_1) + int(teeth_2)) / 2.0
    common = dict(face_width=face_width, bore=bore, pressure_angle=pressure_angle, backlash=backlash,
                  material=material, flank_points=flank_points)
    first = spur_gear(module, teeth_1, name=names[0], **common)
    # A gap of gear 2 at its polar angle 180 degrees: half a tooth pitch off a tooth.
    turn = 180.0 + 180.0 / int(teeth_2)
    second = spur_gear(module, teeth_2, rotation=turn, name=names[1], position=(distance, 0.0, 0.0), **common)
    return [first, second]


# ----------------------------------------------------------------- bearings
# Boundary dimensions (ISO 15) d, D, B and typical ball count and diameter (mm).
_BEARINGS: Dict[str, Tuple[float, float, float, int, float]] = {
    "6000": (10, 26, 8, 7, 4.762), "6001": (12, 28, 8, 8, 4.762), "6002": (15, 32, 9, 9, 4.762),
    "6003": (17, 35, 10, 10, 4.762), "6004": (20, 42, 12, 9, 6.35), "6005": (25, 47, 12, 10, 6.35),
    "6006": (30, 55, 13, 11, 7.144), "6007": (35, 62, 14, 11, 7.938), "6008": (40, 68, 15, 12, 7.938),
    "6009": (45, 75, 16, 12, 8.731), "6010": (50, 80, 16, 13, 8.731),
    "6200": (10, 30, 9, 7, 4.762), "6201": (12, 32, 10, 7, 5.953), "6202": (15, 35, 11, 8, 5.953),
    "6203": (17, 40, 12, 8, 6.747), "6204": (20, 47, 14, 8, 7.938), "6205": (25, 52, 15, 9, 7.938),
    "6206": (30, 62, 16, 9, 9.525), "6207": (35, 72, 17, 9, 11.112), "6208": (40, 80, 18, 9, 12.7),
    "6209": (45, 85, 19, 10, 12.7), "6210": (50, 90, 20, 10, 12.7),
    "6300": (10, 35, 11, 7, 6.35), "6301": (12, 37, 12, 7, 6.747), "6302": (15, 42, 13, 7, 7.144),
    "6303": (17, 47, 14, 7, 7.938), "6304": (20, 52, 15, 7, 9.525), "6305": (25, 62, 17, 7, 11.509),
    "6306": (30, 72, 19, 8, 12.303), "6307": (35, 80, 21, 8, 13.494), "6308": (40, 90, 23, 8, 15.081),
    "6309": (45, 100, 25, 8, 17.462), "6310": (50, 110, 27, 8, 19.05),
}
# Inch and metric ball sizes bearings use, for the estimate when only d / D / B are given.
_BALL_SIZES = (3.175, 3.969, 4.762, 5.556, 5.953, 6.35, 6.747, 7.144, 7.938, 8.731, 9.525, 10.319, 11.112,
               11.906, 12.7, 13.494, 14.288, 15.081, 15.875, 17.462, 19.05, 20.638, 22.225, 23.812, 25.4)


def bearing_size(designation: Union[str, int, None] = None, *, d: Optional[float] = None,
                 D: Optional[float] = None, B: Optional[float] = None, balls: Optional[int] = None,
                 ball_diameter: Optional[float] = None) -> Dict[str, Any]:
    """Dimensions of a deep-groove ball bearing in mm: ``d``, ``D``, ``B``, ``balls``, ``ball_diameter``, ``pitch_diameter``.

    ``designation`` is a 60xx, 62xx or 63xx number from 6000 to 6310
    (``"6204"`` = 20 x 47 x 14). Explicit ``d`` / ``D`` / ``B`` / ``balls`` /
    ``ball_diameter`` override it; without a designation the balls are
    estimated: the standard ball size nearest 0.3 (D - d), as many as fill
    about 62 % of the pitch circle (what a Conrad-assembled bearing holds).
    """
    if designation is not None:
        key = str(designation).strip()
        if key not in _BEARINGS:
            raise ValueError(f"unknown bearing {designation!r}; known: {', '.join(sorted(_BEARINGS))}")
        bd, bD, bB, bn, bw = _BEARINGS[key]
        d, D, B = (bd if d is None else d), (bD if D is None else D), (bB if B is None else B)
        if ball_diameter is None and balls is None and (d, D) == (bd, bD):
            balls, ball_diameter = bn, bw
    if d is None or D is None or B is None:
        raise ValueError("give a designation such as '6204', or d, D and B")
    d, D, B = float(d), float(D), float(B)
    if not (0 < d < D and B > 0):
        raise ValueError(f"need 0 < d < D and B > 0, got d={d:g}, D={D:g}, B={B:g}")
    pitch_diameter = (d + D) / 2.0
    if ball_diameter is None:
        ball_diameter = min(_BALL_SIZES, key=lambda size: abs(size - 0.3 * (D - d)))
    ball_diameter = float(ball_diameter)
    if balls is None:
        balls = max(3, int(0.62 * math.pi * pitch_diameter / ball_diameter))
    balls = int(balls)
    if math.pi * pitch_diameter / balls <= ball_diameter * 1.02:
        raise ValueError(f"{balls} balls of {ball_diameter:g} mm do not fit on a {pitch_diameter:g} mm pitch circle")
    if ball_diameter >= 0.45 * (D - d):
        raise ValueError(f"ball {ball_diameter:g} mm is too large for rings {d:g} x {D:g} mm")
    return {"d": d, "D": D, "B": B, "balls": balls, "ball_diameter": ball_diameter,
            "pitch_diameter": pitch_diameter}


def _cage(rp: float, ball_radius: float, balls: int, half_width: float, height: float, gap: float,
          segments: int) -> MeshData:
    """A window cage: a band around the pitch circle with one rectangular pocket per ball.

    The band spans radii ``rp +- half_width`` and z ``+-height/2``; each pocket
    goes through the band and clears its ball by ``gap`` everywhere. The mesh is
    the boundary of the solid cells of a (r, theta, z) grid with one radial
    cell, three z cells (rail, pocket row, rail) and theta cells whose edges
    fall on the pocket sides, so it is closed without a boolean.
    """
    r_in, r_out = rp - half_width, rp + half_width
    # Widest angle the ball covers anywhere in the band (law of cosines), plus the gap at the inner face.
    radii = np.linspace(r_in, r_out, 9)
    cos_a = np.clip((radii ** 2 + rp ** 2 - ball_radius ** 2) / (2.0 * radii * rp), -1.0, 1.0)
    pocket = float(np.arccos(cos_a).max()) + gap / r_in
    pitch = 2.0 * math.pi / balls
    if pitch - 2.0 * pocket < 0.02 * pitch:
        raise ValueError(f"{balls} balls leave no room for cage bars between them; pass cage=False")
    window_cells = max(2, int(math.ceil(segments * 2 * pocket / (2 * math.pi))))
    bar_cells = max(1, int(math.ceil(segments * (pitch - 2 * pocket) / (2 * math.pi))))
    theta: List[float] = []
    for k in range(balls):
        c = k * pitch
        theta += list(np.linspace(c - pocket, c + pocket, window_cells + 1)[:-1])
        theta += list(np.linspace(c + pocket, c + pitch - pocket, bar_cells + 1)[:-1])
    theta_arr = np.array(theta)
    n = len(theta_arr)
    in_window = np.zeros(n, dtype=bool)
    for k in range(balls):
        in_window[k * (window_cells + bar_cells):k * (window_cells + bar_cells) + window_cells] = True
    z_pocket = ball_radius + gap
    if height <= 2.0 * z_pocket:
        raise ValueError(f"a cage {height:g} mm tall cannot hold {2 * ball_radius:g} mm balls; pass cage=False")
    zs = np.array([-height / 2.0, -z_pocket, z_pocket, height / 2.0])
    rs = np.array([r_in, r_out])
    solid = np.ones((n, 3), dtype=bool)  # [theta cell, z cell]
    solid[in_window, 1] = False

    index: Dict[Tuple[int, int, int], int] = {}
    verts: List[Tuple[float, float, float]] = []

    def vid(ir: int, jt: int, kz: int) -> int:
        key = (ir, jt % n, kz)
        if key not in index:
            index[key] = len(verts)
            t = theta_arr[key[1]]
            verts.append((rs[ir] * math.cos(t), rs[ir] * math.sin(t), zs[kz]))
        return index[key]

    def filled(jt: int, kz: int) -> bool:
        return 0 <= kz < 3 and bool(solid[jt % n, kz])

    faces: List[Tuple[int, int, int]] = []
    # (r, theta, z) is right-handed like (x, y, z): a face listed with corners
    # in (b, c) order looks along +a, as in a Cartesian cell grid.
    for jt in range(n):
        for kz in range(3):
            if not solid[jt, kz]:
                continue
            cell = (0, jt, kz)
            for a in range(3):
                b, c = (a + 1) % 3, (a + 2) % 3
                for side in (0, 1):
                    if a == 1 and filled(jt + (1 if side else -1), kz):
                        continue
                    if a == 2 and filled(jt, kz + (1 if side else -1)):
                        continue
                    corners = []
                    for db, dc in ((0, 0), (1, 0), (1, 1), (0, 1)):
                        key = list(cell)
                        key[a] += side
                        key[b] += db
                        key[c] += dc
                        corners.append(vid(*key))
                    q = corners if side else corners[::-1]
                    faces += [(q[0], q[1], q[2]), (q[0], q[2], q[3])]
    return _outward(np.array(verts, dtype=float), np.array(faces, dtype=np.int64))


def ball_bearing(designation: Union[str, int, None] = "6204", *, d: Optional[float] = None,
                 D: Optional[float] = None, B: Optional[float] = None, balls: Optional[int] = None,
                 ball_diameter: Optional[float] = None, cage: bool = True, segments: int = 96,
                 ball_segments: int = 24, prefix: str = "", material: MaterialLike = STEEL, role: str = "other",
                 position: Optional[Sequence[float]] = None) -> List[Body]:
    """Deep-groove ball bearing: ``[inner_ring, outer_ring, cage, ball_1, ..., ball_n]`` as ``Body`` objects.

    Frame (mm, Z up): axis along z, centred on the origin, ring faces at
    z = -B/2 and +B/2; ball 1 sits on +x. Dimensions from ``bearing_size``
    (``"6204"``: d 20, D 47, B 14, eight 7.938 mm balls). Each ring has a
    circular raceway groove of radius 0.52 ball diameters on the pitch circle
    and shoulders at 0.4 ball diameters from it; the balls touch neither ring.
    The ``cage`` (``cage=False`` leaves it out) is a band 0.3 ball diameters
    thick on the pitch circle, as tall as the ball plus 0.3 ball diameters,
    with one rectangular pocket per ball; it clears the balls and both rings.
    ``prefix`` is put before every body name (``"b1_"`` gives
    ``b1_inner_ring``) to place several bearings in one model.
    """
    size = bearing_size(designation, d=d, D=D, B=B, balls=balls, ball_diameter=ball_diameter)
    d, D, B, dw = size["d"], size["D"], size["B"], size["ball_diameter"]
    rp, rg = size["pitch_diameter"] / 2.0, 0.52 * dw
    shoulder_in, shoulder_out = rp - 0.4 * dw, rp + 0.4 * dw
    if shoulder_in <= d / 2.0 + 0.05 * (D - d) or shoulder_out >= D / 2.0 - 0.05 * (D - d):
        raise ValueError(f"balls of {dw:g} mm leave the rings too thin for {d:g} x {D:g} mm")
    arc_points = max(9, int(segments) // 6)

    def groove(shoulder: float, side: float) -> np.ndarray:
        # The groove's arc from z < 0 to z > 0 through its deepest point; side -1 cuts the inner ring.
        reach = math.acos(abs(rp - shoulder) / rg)
        phi = np.linspace(-reach, reach, arc_points)
        return np.c_[rp + side * rg * np.cos(phi), rg * np.sin(phi)]

    h = B / 2.0
    inner = np.vstack([[(d / 2.0, -h), (shoulder_in, -h)], groove(shoulder_in, -1.0),
                       [(shoulder_in, h), (d / 2.0, h)]])
    outer = np.vstack([[(shoulder_out, -h), (D / 2.0, -h), (D / 2.0, h), (shoulder_out, h)],
                       groove(shoulder_out, 1.0)[::-1]])
    seg = max(24, int(segments))
    bodies = [Body(_moved(revolve(inner, segments=seg), position), name=f"{prefix}inner_ring",
                   material=material, role=role),
              Body(_moved(revolve(outer, segments=seg), position), name=f"{prefix}outer_ring",
                   material=material, role=role)]
    if cage:
        gap = 0.03 * dw  # pocket play around each ball
        mesh = _cage(rp, dw / 2.0, size["balls"], 0.15 * dw, min(1.3 * dw, B - 0.1 * dw), gap,
                     max(24, int(segments)))
        bodies.append(Body(_moved(mesh, position), name=f"{prefix}cage", material=material, role=role))
    lat = np.linspace(-math.pi / 2.0, math.pi / 2.0, max(4, int(ball_segments) // 2) + 1)
    ball = revolve(np.c_[dw / 2.0 * np.cos(lat), dw / 2.0 * np.sin(lat)], segments=max(8, int(ball_segments)))
    base = np.zeros(3) if position is None else np.asarray(position, dtype=float).reshape(3)
    for index in range(size["balls"]):
        a = 2.0 * math.pi * index / size["balls"]
        centre = base + (rp * math.cos(a), rp * math.sin(a), 0.0)
        bodies.append(Body(MeshData(ball.vertices + centre, ball.faces.copy()), name=f"{prefix}ball_{index + 1}",
                           material=material, role=role))
    return bodies
