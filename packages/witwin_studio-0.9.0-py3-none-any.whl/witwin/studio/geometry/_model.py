"""Model files: ``models/<name>.py`` with ``CONFIG``, ``PARAMS`` and ``build(ctx)``.

    # models/plate.py
    import witwin.studio as ws
    from build123d import Box

    CONFIG = {"unit": "mm", "tolerance": 0.01}
    PARAMS = {
        "w": ws.param(40, unit="mm", min=1, description="Plate width"),
        "h": ws.param(1.6, unit="mm"),
        "er": ws.param(4.4, description="Relative permittivity"),
    }

    def build(ctx):
        p = ctx.params                      # lengths in CONFIG["unit"] (mm here)
        return ws.Body(Box(p.w, p.w, p.h), name="substrate", material={"eps_r": p.er})

    if __name__ == "__main__":
        ws.preview(build)                   # python models/plate.py

Units. ``CONFIG["unit"]`` is the model's length unit (default ``"m"``). The
geometry ``build`` returns is in that unit; it is scaled to meters once, at
the boundary (``ModelOutput.si_bodies``). ``ctx.params`` holds each parameter
in the unit the model works in: a length parameter in ``CONFIG["unit"]``
whatever unit it was declared in, any other quantity (``GHz``, ``deg``) in its
own declared unit, a parameter without a unit as given. Studio stores the
values in SI, like every component field, so they can be bound to the Formula
Graph.

Up axis. ``CONFIG["up"]`` is ``"z"`` (default: CAD and EM geometry, build123d
extrusions and layout stacks go up along +Z) or ``"y"`` (the Scene frame).
``build`` and everything about the model's own result (``geometry.check``,
``geometry.measure``, the manifest's statistics) stay in that frame; the
geometry is turned into the Y-up Scene frame once, where it is placed or
drawn (``geometry._frame``).

Design formulas. A model may also declare ``DESIGN_SPEC`` (a dict of
``ws.param``: the target specification, such as ``f0`` in Hz) and
``design(spec) -> dict``: parameter values, in each parameter's declared
unit, computed from a spec given in ``DESIGN_SPEC`` units. Missing spec
keys take their ``DESIGN_SPEC`` defaults. ``Model.design_values`` runs it;
explicit parameter overrides win over its result.

Handles. ``build`` may also return ``ws.handle(param, point=, axis=,
scale=)`` next to its bodies: a point the user drags in the viewport along
``axis`` to change ``param`` by ``scale`` per model unit of drag
(``_body.Handle``). Handles are in the model's frame and unit like loose
anchors; ``ModelOutput.si_handles`` gives them in meters.

This module runs a model in the current process. ``_runner`` runs it in a
subprocess of the Project interpreter, which is how Studio runs it.
Design: ``dev_docs/backend/SCRIPT_GEOMETRY.md``.
"""
from __future__ import annotations

import keyword
import math
import runpy
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterator, List, Mapping, Optional, Sequence, Tuple

from ..units import QUANTITIES, Unit, find_unit
from ._body import Anchor, Body, Handle
from ._convert import MeshData, model_tolerances
from ._frame import anchor_to_scene, check_up, mesh_between, mesh_to_scene

__all__ = [
    "Model", "ModelContext", "ModelError", "ModelOutput", "Param", "ParamValues", "load_model",
    "model_from_namespace", "param", "preview", "set_preview_renderer",
]

DEFAULT_UNIT = "m"
# Model files are authored Z up (CAD / EM); see geometry._frame.
DEFAULT_UP = "z"


class ModelError(ValueError):
    """A model file breaks the contract (bad CONFIG, PARAMS, build or override)."""


def _unit_of(key: str) -> Tuple[str, Unit]:
    """(quantity name, Unit) for a unit key or label such as ``"mm"`` or ``"GHz"``."""
    for quantity, table in QUANTITIES.items():
        found = find_unit(table, key)
        if found is not None:
            return quantity, found
    known = ", ".join(u.key for table in QUANTITIES.values() for u in table)
    raise ModelError(f"unknown unit {key!r}; known: {known}")


def _real(value: Any, what: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ModelError(f"{what} must be a number, got {value!r}")
    out = float(value)
    if not math.isfinite(out):
        raise ModelError(f"{what} must be finite, got {value!r}")
    return out


@dataclass(frozen=True)
class Param:
    """One model parameter: a default value in ``unit`` plus optional bounds.

    ``unit`` is a unit key of ``witwin.studio.units`` (``"mm"``, ``"GHz"``,
    ``"deg"``) or None for a plain number. ``min`` / ``max`` are in ``unit``.
    ``integer`` hands the model ``int(round(value))``; the stored field stays
    a decimal so it can be bound to a formula.
    """

    value: float
    unit: Optional[str] = None
    min: Optional[float] = None
    max: Optional[float] = None
    description: str = ""
    integer: bool = False

    @property
    def quantity(self) -> Optional[str]:
        return None if self.unit is None else _unit_of(self.unit)[0]

    @property
    def multiplier(self) -> float:
        """SI value of 1 ``unit`` (1.0 without a unit)."""
        return 1.0 if self.unit is None else _unit_of(self.unit)[1].multiplier

    def to_si(self, value: float) -> float:
        return float(value) * self.multiplier

    def from_si(self, value: float) -> float:
        return float(value) / self.multiplier

    def check(self, value: float, name: str) -> None:
        """Refuse a value (in ``unit``) outside ``[min, max]``."""
        # A relative slack absorbs the float32 round trip of stored fields.
        slack = 1e-6 * max(1.0, abs(value))
        # Name the unit: a design spec in GHz given 5e9 (Hz) should say so.
        unit = f" {self.unit}" if self.unit else ""
        if self.min is not None and value < self.min - slack:
            raise ModelError(f"{name} = {value:g}{unit} is below its min {self.min:g}{unit}")
        if self.max is not None and value > self.max + slack:
            raise ModelError(f"{name} = {value:g}{unit} is above its max {self.max:g}{unit}")

    def schema(self, name: str) -> Dict[str, Any]:
        """The parameter as data: what Studio stores and shows (``si_*`` in SI units)."""
        m = self.multiplier
        return {
            "name": name, "value": self.value, "unit": self.unit, "quantity": self.quantity,
            "min": self.min, "max": self.max, "description": self.description, "integer": self.integer,
            "si_value": self.value * m,
            "si_min": None if self.min is None else self.min * m,
            "si_max": None if self.max is None else self.max * m,
        }

    @classmethod
    def from_schema(cls, data: Mapping[str, Any]) -> "Param":
        return cls(float(data["value"]), data.get("unit"), data.get("min"), data.get("max"),
                   str(data.get("description") or ""), bool(data.get("integer")))


def param(value: float, *, unit: Optional[str] = None, min: Optional[float] = None,
          max: Optional[float] = None, description: str = "", integer: bool = False) -> Param:
    """Declare a model parameter for ``PARAMS``.

        PARAMS = {"W": ws.param(37.3, unit="mm", min=10, max=60, description="Patch width")}

    In Studio each parameter becomes a numeric field of the ScriptGeometry
    component (stored in SI, shown in ``unit``) that can be bound to a
    formula; changing it regenerates the geometry.
    """
    value = _real(value, "param value")
    if unit is not None:
        if not isinstance(unit, str):
            raise ModelError(f"unit must be a unit key such as 'mm', got {unit!r}")
        unit = _unit_of(unit)[1].key
    low = None if min is None else _real(min, "min")
    high = None if max is None else _real(max, "max")
    if low is not None and high is not None and low > high:
        raise ModelError(f"min {low:g} is above max {high:g}")
    out = Param(value, unit, low, high, str(description or ""), bool(integer))
    out.check(value, "default value")
    return out


class ParamValues(Mapping[str, Any]):
    """``ctx.params``: read as ``p.W`` or ``p["W"]``."""

    def __init__(self, values: Mapping[str, Any]):
        self._values = dict(values)

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        try:
            return self._values[name]
        except KeyError:
            raise AttributeError(f"no parameter {name!r}; PARAMS declares {sorted(self._values)}") from None

    def __getitem__(self, name: str) -> Any:
        return self._values[name]

    def __iter__(self) -> Iterator[str]:
        return iter(self._values)

    def __len__(self) -> int:
        return len(self._values)

    def __repr__(self) -> str:
        return f"ParamValues({self._values!r})"


@dataclass
class ModelContext:
    """What ``build(ctx)`` receives."""

    params: ParamValues
    config: Dict[str, Any]
    unit: str
    tolerance: Optional[float]
    angular_tolerance: Optional[float]
    path: Optional[Path] = None


@dataclass
class Model:
    """A loaded model file."""

    path: Optional[Path]
    config: Dict[str, Any]
    params: Dict[str, Param]
    build: Callable[[ModelContext], Any]
    unit: str = DEFAULT_UNIT
    up: str = DEFAULT_UP
    design_spec: Dict[str, Param] = field(default_factory=dict)
    design: Optional[Callable[["ParamValues"], Any]] = None
    summary: str = ""

    @property
    def multiplier(self) -> float:
        """Meters per model unit."""
        return _unit_of(self.unit)[1].multiplier

    @property
    def tolerance(self) -> Optional[float]:
        value = self.config.get("tolerance")
        return None if value is None else float(value)

    @property
    def angular_tolerance(self) -> Optional[float]:
        value = self.config.get("angular_tolerance")
        return None if value is None else float(value)

    def schema(self) -> List[Dict[str, Any]]:
        return [p.schema(name) for name, p in self.params.items()]

    def design_schema(self) -> List[Dict[str, Any]]:
        return [p.schema(name) for name, p in self.design_spec.items()]

    def describe(self) -> Dict[str, Any]:
        """What a generator listing shows: summary, unit, up axis, parameters and design spec."""
        return {"summary": self.summary, "unit": self.unit, "up": self.up, "params": self.schema(),
                "design_spec": self.design_schema(), "has_design": self.design is not None}

    def design_values(self, spec: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
        """Run ``design(spec)``; returns parameter overrides in each parameter's declared unit.

        ``spec`` values are in ``DESIGN_SPEC`` units; missing keys take the
        ``DESIGN_SPEC`` defaults and unknown keys raise ``ModelError``. Values
        are checked against ``DESIGN_SPEC`` bounds. The result must be a dict
        of known parameter names to numbers (``resolve`` checks their bounds).
        """
        if self.design is None:
            raise ModelError("this model has no design(spec) function")
        values: Dict[str, Any] = {name: p.value for name, p in self.design_spec.items()}
        for name, value in (spec or {}).items():
            if name not in self.design_spec:
                raise ModelError(f"unknown design spec key {name!r}; DESIGN_SPEC declares "
                                 f"{sorted(self.design_spec)}")
            number = _real(value, f"design spec {name}")
            self.design_spec[name].check(number, f"design spec {name}")
            values[name] = number
        result = self.design(ParamValues(values))
        if not isinstance(result, Mapping):
            raise ModelError(f"design(spec) must return a dict of parameter values, got {type(result).__name__}")
        out: Dict[str, Any] = {}
        for name, value in result.items():
            if name not in self.params:
                raise ModelError(f"design(spec) returned unknown parameter {name!r}; PARAMS declares "
                                 f"{sorted(self.params)}")
            out[str(name)] = _tidy(_real(value, f"design(spec)[{name!r}]"))
        return out

    def resolve(self, overrides: Optional[Mapping[str, Any]] = None,
                si_overrides: Optional[Mapping[str, Any]] = None,
                *, strict: bool = True) -> Tuple[Dict[str, Any], Dict[str, float]]:
        """``(ctx values, SI values)`` from the defaults plus overrides.

        ``overrides`` are in each parameter's declared unit; ``si_overrides``
        in SI (what Studio stores). Values outside ``[min, max]`` raise
        ``ModelError``; so do unknown names unless ``strict`` is False (Studio
        passes the values of the last run, and the model may have dropped a
        parameter since).
        """
        si = {name: p.to_si(p.value) for name, p in self.params.items()}
        for source, in_si in ((overrides, False), (si_overrides, True)):
            for name, value in (source or {}).items():
                if name not in self.params:
                    if not strict:
                        continue
                    raise ModelError(f"unknown parameter {name!r}; PARAMS declares {sorted(self.params)}")
                p = self.params[name]
                number = _real(value, f"parameter {name}")
                si[name] = number if in_si else p.to_si(number)
        values: Dict[str, Any] = {}
        model_m = self.multiplier
        for name, p in self.params.items():
            p.check(p.from_si(si[name]), name)
            if p.quantity == "length":
                value: Any = si[name] / model_m
            else:
                value = p.from_si(si[name])
            values[name] = int(round(value)) if p.integer else _tidy(value)
        return values, si

    def run(self, values: Mapping[str, Any]) -> "ModelOutput":
        """Call ``build`` with ``values`` (from ``resolve``) and collect what it returned."""
        ctx = ModelContext(ParamValues(values), dict(self.config), self.unit, self.tolerance,
                           self.angular_tolerance, self.path)
        with model_tolerances(self.tolerance, self.angular_tolerance):
            result = self.build(ctx)
            output = collect_output(result, self.unit, self.multiplier, up=self.up)
        unknown = sorted({h.param for h in output.handles} - set(self.params))
        if unknown:
            raise ModelError(f"handles drive unknown parameters {unknown}; PARAMS declares {sorted(self.params)}")
        return output


def _tidy(value: float) -> float:
    """Drop float32 noise: 37.29999923706055 -> 37.3 (fields store float32)."""
    if value == 0 or not math.isfinite(value):
        return value
    return float(f"{value:.7g}")


def model_from_namespace(namespace: Mapping[str, Any], path: Optional[Path] = None) -> Model:
    """Check a model module's globals and return the ``Model``."""
    build = namespace.get("build")
    if not callable(build):
        raise ModelError("a model file must define build(ctx)")
    config = namespace.get("CONFIG") or {}
    if not isinstance(config, Mapping):
        raise ModelError("CONFIG must be a dict")
    config = dict(config)
    unit = config.get("unit", DEFAULT_UNIT)
    if not isinstance(unit, str):
        raise ModelError(f"CONFIG['unit'] must be a length unit key, got {unit!r}")
    quantity, found = _unit_of(unit)
    if quantity != "length":
        raise ModelError(f"CONFIG['unit'] must be a length unit (m, mm, um, nm), got {unit!r}")
    for key in ("tolerance", "angular_tolerance"):
        if config.get(key) is not None and not _real(config[key], f"CONFIG[{key!r}]") > 0:
            raise ModelError(f"CONFIG[{key!r}] must be positive")
    try:
        up = check_up(config.get("up", DEFAULT_UP), "CONFIG['up']")
    except ValueError as exc:
        raise ModelError(str(exc)) from None
    params = _param_table(namespace.get("PARAMS"), "PARAMS")
    design_spec = _param_table(namespace.get("DESIGN_SPEC"), "DESIGN_SPEC")
    design = namespace.get("design")
    if design is not None and not callable(design):
        raise ModelError("design must be a function design(spec) -> dict of parameter values")
    if design is not None and not design_spec:
        raise ModelError("design(spec) needs DESIGN_SPEC: the spec keys with their units and defaults")
    doc = namespace.get("__doc__") or ""
    summary = next((line.strip() for line in str(doc).strip().splitlines() if line.strip()), "")
    return Model(path, config, params, build, found.key, up, design_spec, design, summary)


def _param_table(raw: Any, what: str) -> Dict[str, Param]:
    raw = raw or {}
    if not isinstance(raw, Mapping):
        raise ModelError(f"{what} must be a dict of name -> ws.param(...)")
    out: Dict[str, Param] = {}
    for name, value in raw.items():
        if not isinstance(name, str) or not name.isidentifier() or keyword.iskeyword(name):
            raise ModelError(f"{what} name {name!r} is not a Python identifier")
        out[name] = value if isinstance(value, Param) else param(value)
    return out


def load_model(path: Any) -> Model:
    """Execute a model file (its ``__main__`` block does not run) and return the ``Model``."""
    path = Path(path).resolve()
    if not path.is_file():
        raise ModelError(f"model file not found: {path}")
    folder = str(path.parent)
    added = folder not in sys.path
    if added:
        sys.path.insert(0, folder)  # sibling helpers import as with `python models/x.py`
    try:
        namespace = runpy.run_path(str(path), run_name="__witwin_model__")
    finally:
        if added and folder in sys.path:
            sys.path.remove(folder)
    return model_from_namespace(namespace, path)


# --------------------------------------------------------------------- output
@dataclass
class ModelOutput:
    """What ``build`` returned, as bodies plus loose anchors, in the model unit."""

    bodies: List[Body]
    anchors: List[Anchor]
    unit: str
    multiplier: float  # meters per model unit
    names: List[str] = field(default_factory=list)
    up: str = DEFAULT_UP  # the model's frame; the bodies are in it
    handles: List[Handle] = field(default_factory=list)  # model frame and unit, like loose anchors

    def si_mesh(self, index: int) -> MeshData:
        """Body ``index`` in meters, still in the model's frame."""
        return self.bodies[index].mesh.scaled(self.multiplier)

    def scene_mesh(self, index: int) -> MeshData:
        """Body ``index`` in meters, turned into the Y-up Scene frame."""
        return mesh_to_scene(self.si_mesh(index), self.up)

    def si_anchors(self, index: Optional[int] = None) -> List[Anchor]:
        """Anchors of one body (or the loose ones, ``index=None``) in meters."""
        source = self.anchors if index is None else self.bodies[index].anchors
        return [a.scaled(self.multiplier) for a in source]

    def si_handles(self, params: Mapping[str, Param]) -> List[Dict[str, Any]]:
        """Handle dicts in meters, still in the model's frame, each with ``si_scale``.

        ``si_scale`` is how much the parameter's stored SI value changes per
        meter of drag, so the editor needs no unit table. A length parameter
        is in the model unit inside ``build``, so it moves ``scale`` meters
        per meter; any other parameter moves ``scale`` of its declared unit
        per model unit of drag.
        """
        out = []
        for h in self.handles:
            p = params[h.param]
            entry = h.scaled(self.multiplier).to_dict()
            entry["si_scale"] = h.scale if p.quantity == "length" else h.scale * p.multiplier / self.multiplier
            out.append(entry)
        return out

    def validate(self, grid: Any = None, max_triangles: Optional[int] = None):
        from ._validate import validate

        named = []
        for name, body in zip(self.names, self.bodies):
            body.name = name
            named.append(body)
        return validate(named, grid=grid, max_triangles=max_triangles, unit=self.unit)


def _is_mesh_tuple(value: Any) -> bool:
    return isinstance(value, tuple) and len(value) in (2, 3) and hasattr(value[0], "shape")


def collect_output(result: Any, unit: str, multiplier: float, up: str = DEFAULT_UP) -> ModelOutput:
    """Bodies and anchors from ``build``'s return value.

    Accepted: one object, a list or tuple of objects, a generator, or a dict
    ``{name: object}``. An object is a ``ws.Body``, a ``ws.anchor`` (a loose
    anchor of the whole model), a ``ws.handle`` (a viewport drag handle for a
    parameter) or anything ``to_mesh`` accepts (becomes a Body named
    ``body<i>``). Repeated handle names get ``_2``, ``_3``. Body names are made unique with ``_2``, ``_3``.
    A body with its own ``unit`` (a layout ``LayerBody`` is in meters) is
    rescaled into the model unit; one with its own ``up`` (a ``LayerBody`` is
    ``"z"``) is turned into the model's frame ``up``.
    """
    if result is None:
        raise ModelError("build(ctx) returned None; return a ws.Body, a shape, or a list of them")
    if isinstance(result, Mapping) and not ("vertices" in result and "faces" in result):
        items: List[Tuple[Optional[str], Any]] = [(str(k), v) for k, v in result.items()]
    elif isinstance(result, (list, tuple)) and not _is_mesh_tuple(result):
        items = [(None, v) for v in result]
    elif hasattr(result, "__next__"):
        items = [(None, v) for v in result]
    else:
        items = [(None, result)]
    bodies: List[Body] = []
    anchors: List[Anchor] = []
    handles: List[Handle] = []
    names: List[str] = []
    for key, item in items:
        if isinstance(item, Anchor):
            anchors.append(item)
            continue
        if isinstance(item, Handle):
            handles.append(item)
            continue
        body = item if isinstance(item, Body) else Body(item)
        if body.unit is not None and body.unit != unit:
            body = _in_model_unit(body, unit, multiplier)
        if body.up is not None and body.up != up:
            body = _in_model_frame(body, up)
        base = body.name or key or f"body{len(bodies)}"
        name, n = base, 2
        while name in names:
            name, n = f"{base}_{n}", n + 1
        bodies.append(body)
        names.append(name)
    if not bodies:
        raise ModelError("build(ctx) returned no geometry")
    loose = [a.name for a in anchors]
    if len(set(loose)) != len(loose):
        raise ModelError(f"anchor names must be unique, got {loose}")
    taken: List[str] = []
    for index, h in enumerate(handles):
        base = h.name or h.param
        name, n = base, 2
        while name in taken:
            name, n = f"{base}_{n}", n + 1
        taken.append(name)
        if name != h.name:
            handles[index] = Handle(h.param, h.point, h.axis, h.scale, name)
    return ModelOutput(bodies, anchors, unit, multiplier, names, up, handles)


def _in_model_unit(body: Body, unit: str, multiplier: float) -> Body:
    """A copy of ``body`` with mesh and anchors in the model unit; ``body`` is not changed."""
    import copy

    factor = _unit_of(body.unit)[1].multiplier / multiplier
    out = copy.copy(body)
    out.mesh = body.mesh.scaled(factor)
    out.anchors = [a.scaled(factor) for a in body.anchors]
    out.unit = unit
    # A B-rep stays in its own unit; drop it rather than export or measure it at the wrong scale.
    out.shape = None
    return out


def _in_model_frame(body: Body, up: str) -> Body:
    """A copy of ``body`` turned from its own up frame into the model's ``up``."""
    import copy

    out = copy.copy(body)
    out.mesh = mesh_between(body.mesh, body.up, up)
    out.anchors = [anchor_to_scene(a, up, source=body.up) for a in body.anchors]
    out.up = up
    out.shape = None  # a B-rep stays in its own frame; do not measure or export it turned
    return out


# -------------------------------------------------------------------- preview
PreviewRenderer = Callable[[Model, ModelOutput], Any]


def preview_folder(model_path: Optional[Path]) -> Path:
    """Where ``preview`` writes its picture: the Project's ``.witwin/cache/renders``, else a temp folder.

    The Project is the nearest folder above the model file that has
    ``witwin.toml``; a model outside any Project goes to
    ``<temp>/witwin-preview``.
    """
    if model_path is not None:
        for folder in Path(model_path).resolve().parents:
            if (folder / "witwin.toml").is_file():
                return folder / ".witwin" / "cache" / "renders"
    import tempfile

    return Path(tempfile.gettempdir()) / "witwin-preview"


def render_preview(model: Model, output: ModelOutput) -> Path:
    """The default preview renderer: a contact sheet of the bodies, written as a PNG; returns its path.

    Same picture as the Agent Tool ``geometry.render`` (``_render.py``,
    numpy only). One file per model, ``preview-<file stem>.png``, overwritten
    on every run so ``python models/x.py`` does not fill the folder.
    """
    from ._body import material_properties
    from ._render import body_color, render_meshes

    meshes = []
    for index, body in enumerate(output.bodies):
        mesh = output.scene_mesh(index)  # drawn as it will sit in the Scene
        material = material_properties(body.material) if body.material is not None else None
        meshes.append((mesh.vertices, mesh.faces, body_color(material, body.role)))
    png, _, _ = render_meshes(meshes, overlay=True)
    stem = model.path.stem if model.path is not None else "model"
    target = preview_folder(model.path) / f"preview-{stem}.png"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(png)
    return target


_PREVIEW_RENDERER: Optional[PreviewRenderer] = render_preview


def set_preview_renderer(renderer: Optional[PreviewRenderer]) -> None:
    """Install the function ``preview`` calls to draw the bodies; None turns drawing off.

    The default is ``render_preview`` (a PNG under ``.witwin/cache/renders``).
    Its return value becomes ``PreviewResult.image``.
    """
    global _PREVIEW_RENDERER
    _PREVIEW_RENDERER = renderer


@dataclass
class PreviewResult:
    model: Model
    output: ModelOutput
    report: Any
    values: Dict[str, Any]
    image: Any = None


def _fmt(values: Sequence[float]) -> str:
    return "(" + ", ".join(f"{v:.4g}" for v in values) + ")"


def preview(build: Callable[[ModelContext], Any], *, params: Optional[Mapping[str, Any]] = None,
            grid: Any = None, quiet: bool = False, design: Optional[Mapping[str, Any]] = None) -> PreviewResult:
    """Run the model ``build`` belongs to, print statistics and checks, return them.

    For the ``if __name__ == "__main__":`` block of a model file, so
    ``python models/x.py`` works outside Studio. ``params`` override
    defaults in their declared units; ``design`` is a spec for the model's
    ``design(spec)``, applied before ``params``. The model's ``PARAMS``,
    ``CONFIG``, ``DESIGN_SPEC`` and ``design`` are read from ``build``'s
    module. The picture shows the bodies in the Y-up Scene frame. The bodies are drawn by the installed
    preview renderer (default ``render_preview``: a PNG whose path is printed
    and returned as ``image``); a drawing error is printed, not raised.
    """
    namespace = getattr(build, "__globals__", {})
    path = namespace.get("__file__")
    model = model_from_namespace({**namespace, "build": build}, Path(path) if path else None)
    overrides = model.design_values(design) if design is not None else {}
    overrides.update(params or {})
    values, _ = model.resolve(overrides)
    output = model.run(values)
    report = output.validate(grid=grid if grid is not None else model.config.get("grid"))
    image, render_error = None, None
    if _PREVIEW_RENDERER is not None:
        try:
            image = _PREVIEW_RENDERER(model, output)
        except Exception as exc:  # noqa: BLE001 - the statistics are still worth printing
            render_error = f"{type(exc).__name__}: {exc}"
    if not quiet:
        u = model.unit
        print(f"model {path or build.__name__}: {len(output.bodies)} body(ies), unit {u}")
        for name, value in values.items():
            p = model.params[name]
            shown = p.unit if p.quantity != "length" else u
            print(f"  param {name} = {value:g}{' ' + shown if shown else ''}")
        for stats in report.bodies:
            size = [s / model.multiplier for s in stats.size]
            volume = "open" if stats.volume is None else f"{stats.volume / model.multiplier ** 3:.6g} {u}^3"
            print(f"  body {stats.name}: {stats.triangle_count} triangles, size {_fmt(size)} {u}, "
                  f"volume {volume}, watertight {stats.watertight}")
        print("  " + report.summary().replace("\n", "\n  "))
        if render_error is not None:
            print(f"  (preview not drawn: {render_error})")
        elif isinstance(image, Path):
            print(f"  preview: {image}")
        elif image is None:
            print("  (no preview renderer installed; statistics only)")
    return PreviewResult(model, output, report, values, image)
