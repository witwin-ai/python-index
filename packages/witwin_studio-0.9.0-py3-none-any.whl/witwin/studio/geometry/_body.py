"""``Body``, ``Anchor`` and ``Handle``: a mesh plus what a solver and the editor need to know about it.

The metadata is stored on the entity as two components, both plain data in
the ``.wtscene`` file:

- ``Material``: the material name or EM values (``material_properties``);
- ``GeometryBody``: ``role``, ``fill``, ``surface_thickness`` and the anchors
  as JSON (``body_properties``). The ProjectServer registers the same component
  (``core/components/geometry_body.py``); keep the property names in step.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

from ._convert import MeshData, _cad_shape, to_mesh
from ._frame import check_up

__all__ = [
    "Anchor", "Body", "FILLS", "Handle", "ROLES", "anchor", "body_properties", "handle", "material_properties",
    "parse_anchors",
]

# ``fill`` maps onto Maxwell's ``fill_mode``: "solid" voxelizes the inside of
# a closed mesh, "surface" treats the triangles as a thin sheet.
FILLS = ("solid", "surface")
ROLES = ("conductor", "dielectric", "port", "other")

Vec3 = Tuple[float, float, float]


def _vec3(value: Sequence[float], what: str) -> Vec3:
    out = tuple(float(v) for v in value)
    if len(out) != 3 or not all(math.isfinite(v) for v in out):
        raise ValueError(f"{what} needs 3 finite numbers, got {value!r}")
    return out  # type: ignore[return-value]


@dataclass(frozen=True)
class Anchor:
    """A named point on a body, for placing, measuring and feeding.

    ``point`` and ``normal`` are in the body's own (mesh) coordinates and in
    the same unit as its vertices. ``kind`` is free text; the validator reads
    ``"port"`` (a feed point that must sit on a conductor). Other common kinds:
    ``"point"``, ``"face"``, ``"axis"``.
    """

    name: str
    point: Vec3
    normal: Optional[Vec3] = None
    kind: str = "point"

    def scaled(self, factor: float) -> "Anchor":
        point = tuple(v * factor for v in self.point)
        return Anchor(self.name, point, self.normal, self.kind)  # type: ignore[arg-type]

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"name": self.name, "point": list(self.point), "kind": self.kind}
        if self.normal is not None:
            out["normal"] = list(self.normal)
        return out

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Anchor":
        return anchor(str(data["name"]), point=data["point"], normal=data.get("normal"),
                      kind=str(data.get("kind") or "point"))


def anchor(name: str, *, point: Sequence[float], normal: Optional[Sequence[float]] = None,
           kind: str = "point") -> Anchor:
    """Make an ``Anchor``. ``normal`` is normalized; a zero normal is refused."""
    if not isinstance(name, str) or not name.strip():
        raise ValueError("an anchor needs a non-empty name")
    unit_normal = None
    if normal is not None:
        n = _vec3(normal, "normal")
        length = math.sqrt(sum(c * c for c in n))
        if length == 0:
            raise ValueError("an anchor normal cannot be zero")
        unit_normal = tuple(c / length for c in n)
    if not isinstance(kind, str) or not kind:
        raise ValueError("kind must be a non-empty string")
    return Anchor(name, _vec3(point, "point"), unit_normal, kind)  # type: ignore[arg-type]


@dataclass(frozen=True)
class Handle:
    """A point the user drags in the viewport to change one model parameter.

    ``point`` and ``axis`` are in the model's frame and unit, like loose
    anchors. Dragging the point by ``d`` (model units) along ``axis`` changes
    ``param`` by ``d * scale``, in the unit ``ctx.params`` gives it (a length
    in ``CONFIG["unit"]``, anything else in its declared unit). ``scale=2``
    suits a size centered on the origin: the edge moves by ``d``, the width
    by ``2 d``. ``axis`` is normalized; ``scale`` may be negative.
    """

    param: str
    point: Vec3
    axis: Vec3
    scale: float = 1.0
    name: str = ""

    def scaled(self, factor: float) -> "Handle":
        point = tuple(v * factor for v in self.point)
        return Handle(self.param, point, self.axis, self.scale, self.name)  # type: ignore[arg-type]

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name or self.param, "param": self.param, "point": list(self.point),
                "axis": list(self.axis), "scale": self.scale}


def handle(param: str, *, point: Sequence[float], axis: Sequence[float], scale: float = 1.0,
           name: Optional[str] = None) -> Handle:
    """Make a ``Handle`` for ``build`` to return next to its bodies.

        return [body, ws.handle("W", point=(p.W / 2, 0, p.h), axis=(1, 0, 0), scale=2)]

    ``name`` defaults to ``param``; repeated names get ``_2``, ``_3``.
    """
    if not isinstance(param, str) or not param.strip():
        raise ValueError("a handle needs the name of the parameter it drives")
    a = _vec3(axis, "axis")
    length = math.sqrt(sum(c * c for c in a))
    if length == 0:
        raise ValueError("a handle axis cannot be zero")
    if isinstance(scale, bool) or not isinstance(scale, (int, float)) or not math.isfinite(scale) or scale == 0:
        raise ValueError(f"handle scale must be a finite non-zero number, got {scale!r}")
    return Handle(param, _vec3(point, "point"), tuple(c / length for c in a), float(scale),  # type: ignore[arg-type]
                  str(name or param))


AnchorLike = Union[Anchor, Mapping[str, Any]]


def parse_anchors(anchors: Optional[Iterable[AnchorLike]]) -> List[Anchor]:
    """Anchors from ``Anchor`` objects or dicts; names must be unique."""
    out: List[Anchor] = []
    for item in anchors or ():
        out.append(item if isinstance(item, Anchor) else Anchor.from_dict(item))
    names = [a.name for a in out]
    if len(set(names)) != len(names):
        raise ValueError(f"anchor names must be unique, got {names}")
    return out


def _check_choice(value: Optional[str], allowed: Sequence[str], what: str) -> Optional[str]:
    if value is not None and value not in allowed:
        raise ValueError(f"{what} must be one of {', '.join(allowed)}; got {value!r}")
    return value


def surface_thickness_value(value: Any) -> Optional[float]:
    """``surface_thickness`` in meters, or None when not given (None or 0).

    A negative, non-finite or non-numeric value is refused. 0 means "not
    given" because that is how ``GeometryBody.surface_thickness`` stores it.
    """
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"surface_thickness must be a number of meters, not {type(value).__name__}")
    value = float(value)
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"surface_thickness must be a finite length >= 0 in meters, got {value!r}")
    return value or None


class Body:
    """A mesh with its material, fill mode, role, anchors and sheet thickness.

        ws.Body(mesh, name="patch", material="PEC", fill="surface", role="conductor",
                surface_thickness=35e-6,
                anchors=[ws.anchor("feed", point=(0, -5, 0), kind="port")])

    ``mesh`` is anything ``witwin.studio.geometry.to_mesh`` accepts; it is
    converted at once, so a bad input fails here. CAD shapes are tessellated
    with ``tolerance`` (chord error, in the shape's unit; default 1e-3 of its
    bounding-box diagonal) and ``angular_tolerance`` (radians, default 0.1).
    ``material`` is a name (``"PEC"``, ``"FR4"``, an ITU name such as
    ``"Concrete"``), a ``.wtmat`` path, or a dict of Material fields such as
    ``{"eps_r": 4.4, "sigma_e": 0.0}``. ``surface_thickness`` is the real
    thickness of a ``fill="surface"`` sheet (35 um copper drawn as one face),
    for Maxwell's ``surface_thickness``. It is always in meters, whatever unit
    the vertices use; None means not given. ``up`` is the frame the mesh and
    anchors were built in: ``"z"`` (CAD / EM, Z up), ``"y"`` (the Scene
    frame), or None for the caller's frame (``Scene.add_mesh(up=...)``, the
    model's ``CONFIG["up"]``). See ``geometry._frame``.
    """

    # Length unit of ``mesh`` and ``anchors`` when the body fixes its own;
    # None means "the caller's unit". A model's build() may return bodies in
    # another unit (layout ``LayerBody`` is "m"); the model rescales them.
    unit: Optional[str] = None
    # Up axis of ``mesh`` and ``anchors`` when the body fixes its own; None
    # means "the caller's frame". Layout ``LayerBody`` is "z".
    up: Optional[str] = None

    def __init__(self, mesh: Any, *, name: Optional[str] = None,
                 material: Union[str, Mapping[str, Any], None] = None,
                 fill: str = "solid", role: str = "other",
                 anchors: Optional[Iterable[AnchorLike]] = None,
                 tolerance: Optional[float] = None, angular_tolerance: Optional[float] = None,
                 surface_thickness: Optional[float] = None, up: Optional[str] = None):
        if up is not None:
            self.up = check_up(up)
        elif isinstance(mesh, Body) and mesh.up is not None:
            self.up = mesh.up
        self.mesh: MeshData = to_mesh(mesh, tolerance=tolerance, angular_tolerance=angular_tolerance)
        # The exact B-rep behind a build123d / CadQuery input, kept for STEP
        # export and topology queries (geometry.export / geometry.measure);
        # None for meshes.
        self.shape: Any = _cad_shape(mesh.shape if isinstance(mesh, Body) else mesh)
        self.name = name
        material_properties(material)  # refuse a bad material now, not at write time
        self.material = material
        self.fill = _check_choice(fill, FILLS, "fill")
        self.role = _check_choice(role, ROLES, "role")
        self.anchors: List[Anchor] = parse_anchors(anchors)
        self.surface_thickness: Optional[float] = surface_thickness_value(surface_thickness)

    def __repr__(self) -> str:
        thickness = f", surface_thickness={self.surface_thickness:.4g}" if self.surface_thickness else ""
        up = f", up={self.up!r}" if self.up else ""
        return (f"Body(name={self.name!r}, {self.mesh.triangle_count} triangles, material={self.material!r}, "
                f"fill={self.fill!r}, role={self.role!r}{thickness}{up}, anchors={[a.name for a in self.anchors]})")


def material_properties(material: Union[str, Mapping[str, Any], None]) -> Dict[str, Any]:
    """The ``Material`` component properties for a ``material`` argument.

    A string is a material name (``material_name``) or, ending in
    ``.wtmat``, a material file (``asset``). A dict gives Material fields
    directly; ``name`` is accepted for ``material_name``, and ``eps_r`` may be
    a real or complex number (stored as ``[real, imag]``). Values must be
    numbers, strings, booleans or lists of them, as the scene file stores them.
    """
    if material is None:
        return {}
    if isinstance(material, str):
        if not material.strip():
            raise ValueError("material name cannot be empty")
        return {"asset": material} if material.endswith(".wtmat") else {"material_name": material}
    if not isinstance(material, Mapping):
        raise TypeError(f"material must be a name or a dict of Material fields, not {type(material).__name__}")
    out: Dict[str, Any] = {}
    for key, value in material.items():
        key = "material_name" if key == "name" else str(key)
        if key == "eps_r":
            if isinstance(value, complex):
                value = [value.real, value.imag]
            elif isinstance(value, (int, float)) and not isinstance(value, bool):
                value = [float(value), 0.0]
        if isinstance(value, tuple):
            value = list(value)
        out[key] = value
    return out


def body_properties(role: Optional[str], fill: Optional[str], anchors: Sequence[Anchor],
                    surface_thickness: Optional[float] = None) -> Dict[str, Any]:
    """The ``GeometryBody`` component properties.

    ``surface_thickness`` (meters) is written only when given, so updating an
    existing component with these properties keeps its stored thickness.
    """
    out: Dict[str, Any] = {
        "role": _check_choice(role, ROLES, "role") or "other",
        "fill": _check_choice(fill, FILLS, "fill") or "solid",
        "anchors_json": json.dumps([a.to_dict() for a in anchors]) if anchors else "",
    }
    thickness = surface_thickness_value(surface_thickness)
    if thickness is not None:
        out["surface_thickness"] = thickness
    return out


def anchors_from_properties(properties: Mapping[str, Any]) -> List[Anchor]:
    """Anchors stored in ``GeometryBody.anchors_json`` (empty or bad JSON: none)."""
    raw = properties.get("anchors_json") or ""
    try:
        return parse_anchors(json.loads(raw)) if raw else []
    except (ValueError, KeyError, TypeError):
        return []
