"""Involute spur gear (or helical gear), optionally with a meshing second gear and shafts.

Geometry (Z up, mm): gear axis along z, faces at z = -face_width/2 and
+face_width/2, centred on the origin; tooth 0 centred on +x. Sizes follow the
ISO 53 basic rack: pitch diameter m z, tip diameter m (z + 2), root diameter
m (z - 2.5), base diameter m z cos(pressure angle). Flanks are exact
involutes; no root fillet.

With ``mate_teeth`` > 0 a second gear ``gear_2`` sits on +x at the centre
distance m (z1 + z2) / 2, turned so a gap faces gear 1's tooth on the line
between the centres (zero backlash unless ``backlash`` > 0); gear 1 is then
named ``gear_1``. With ``shaft_length`` > 0 each gear gets a shaft of the bore
diameter (``shaft`` / ``shaft_1``, ``shaft_2``), centred on the gear.

Bodies: ``gear`` (or ``gear_1``, ``gear_2``) and the shafts.
Anchors: ``axis_top`` (0, 0, face_width/2, normal +z).
"""
import math

import witwin.studio as ws
from witwin.studio import geometry as g

CONFIG = {"unit": "mm", "up": "z"}

PARAMS = {
    "module": ws.param(2, unit="mm", min=0.05, max=50, description="module m (pitch diameter / teeth)"),
    "teeth": ws.param(20, integer=True, min=6, max=400, description="number of teeth z"),
    "pressure_angle": ws.param(20, unit="deg", min=10, max=35, description="pressure angle"),
    "face_width": ws.param(10, unit="mm", min=0.1, max=2000, description="face width (along z)"),
    "bore": ws.param(0, unit="mm", min=0, max=2000, description="bore diameter; 0 = solid"),
    "helix_angle": ws.param(0, unit="deg", min=-45, max=45, description="helix angle; 0 = spur (needs a bore if not 0)"),
    "backlash": ws.param(0, unit="mm", min=0, max=5, description="tooth thinning at the pitch circle"),
    "mate_teeth": ws.param(0, integer=True, min=0, max=400, description="teeth of a meshing gear on +x; 0 = none"),
    "shaft_length": ws.param(0, unit="mm", min=0, max=5000, description="shaft through each bore; 0 = none"),
    "flank_points": ws.param(10, integer=True, min=3, max=60, description="samples per tooth flank"),
}


def _shaft(diameter, length, x, name):
    r, h = diameter / 2, length / 2
    mesh = g.revolve([(0, -h), (r, -h), (r, h), (0, h)], segments=48)
    return ws.Body((mesh.vertices + (x, 0, 0), mesh.faces), name=name, material="Steel")


def build(ctx):
    p = ctx.params
    common = dict(face_width=p.face_width, bore=p.bore, pressure_angle=p.pressure_angle,
                  backlash=p.backlash, flank_points=p.flank_points)
    if p.mate_teeth:
        if p.helix_angle:
            raise ValueError("mate_teeth makes a spur pair; set helix_angle to 0")
        bodies = g.gear_pair(p.module, p.teeth, p.mate_teeth, **common)
        distance = p.module * (p.teeth + p.mate_teeth) / 2
        shafts = [(0.0, "shaft_1"), (distance, "shaft_2")]
    else:
        bodies = [g.spur_gear(p.module, p.teeth, helix_angle=p.helix_angle, **common)]
        shafts = [(0.0, "shaft")]
    if p.shaft_length > 0:
        if p.bore <= 0:
            raise ValueError("shaft_length needs a bore (the shaft diameter)")
        bodies += [_shaft(p.bore, p.shaft_length, x, name) for x, name in shafts]
    return bodies + [ws.anchor("axis_top", point=(0, 0, p.face_width / 2), normal=(0, 0, 1))]


if __name__ == "__main__":
    ws.preview(build)
