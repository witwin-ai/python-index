"""ISO 4017 hex head bolt with a modelled helical ISO metric thread, optionally with an ISO 4032 nut screwed on.

Geometry (Z up, mm): the bolt axis is the z axis; the underside of the head
is on z = 0 with the head below it (z = -k .. 0) and the shank pointing up to
z = length. Two flats of the head (and of the nut) face +y and -y. Sizes M1.6
to M64 with the ISO 261 coarse pitch (M6: 1.0, M10: 1.5); head s and k from
ISO 4017, nut s and m from ISO 4032; thread profile ISO 68-1 (60 degree
flanks, external root at d3 = d - 1.22687 P).

Bodies: ``bolt``; with ``nut_z`` > 0 also ``nut``, its lower face at z = nut_z
(clamping a plate of that thickness), its internal thread in phase with the
bolt's.

Anchors: ``head_top`` (z = -k, normal -z), ``tip`` (z = length, normal +z),
and ``nut_top`` when there is a nut.
"""
import witwin.studio as ws
from witwin.studio import geometry as g

CONFIG = {"unit": "mm", "up": "z"}

PARAMS = {
    "d": ws.param(10, unit="mm", min=1.6, max=64, description="nominal diameter: 10 for M10 (ISO sizes M1.6..M64)"),
    "length": ws.param(40, unit="mm", min=2, max=600, description="nominal length l, head underside to tip"),
    "thread_length": ws.param(0, unit="mm", min=0, max=600,
                              description="threaded length b from the tip (ISO 4014); 0 = up to the head (ISO 4017)"),
    "threaded": ws.param(1, integer=True, min=0, max=1, description="1 helical thread, 0 plain shank (few triangles)"),
    "nut_z": ws.param(0, unit="mm", min=0, max=600, description="nut's lower face above the head underside; 0 = no nut"),
    "segments": ws.param(72, integer=True, min=24, max=360, description="samples around the axis (multiple of 6)"),
    "rows_per_pitch": ws.param(12, integer=True, min=4, max=48, description="thread rings per pitch"),
}


def build(ctx):
    p = ctx.params
    size = round(p.d, 1)
    iso = g.iso_metric(size)
    mesh = dict(segments=p.segments, rows_per_pitch=p.rows_per_pitch, threaded=bool(p.threaded))
    bolt = g.hex_bolt(size, p.length, thread_length=p.thread_length or None, **mesh)
    bolt.anchors = [ws.anchor("head_top", point=(0, 0, -iso["k"]), normal=(0, 0, -1)),
                    ws.anchor("tip", point=(0, 0, p.length), normal=(0, 0, 1))]
    out = [bolt]
    if p.nut_z > 0:
        nut = g.hex_nut(size, z0=p.nut_z, **mesh)
        nut.anchors = [ws.anchor("nut_top", point=(0, 0, p.nut_z + iso["m"]), normal=(0, 0, 1))]
        out.append(nut)
    return out


if __name__ == "__main__":
    ws.preview(build)
