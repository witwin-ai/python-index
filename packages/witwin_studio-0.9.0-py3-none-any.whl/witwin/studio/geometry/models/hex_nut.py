"""ISO 4032 hex nut with a modelled internal ISO metric thread, double chamfered, countersunk both sides.

Geometry (Z up, mm): axis along z, lower face on z = z0, upper face at
z0 + m (M10: m = 8.4); two flats face +y and -y. Width across flats s and
height m from ISO 4032 (M10: s 16, m 8.4; M6: s 10, m 5.2). The thread's
phase is tied to the absolute z, so this nut fits the ``hex_bolt``
generator's bolt of the same size on the same axis at any z0.

Bodies: ``nut``. Anchors: ``bottom`` (z0, normal -z) and ``top`` (z0 + m, +z).
"""
import witwin.studio as ws
from witwin.studio import geometry as g

CONFIG = {"unit": "mm", "up": "z"}

PARAMS = {
    "d": ws.param(10, unit="mm", min=1.6, max=64, description="nominal diameter: 10 for M10 (ISO sizes M1.6..M64)"),
    "z0": ws.param(0, unit="mm", min=-1000, max=1000, description="height of the lower face"),
    "threaded": ws.param(1, integer=True, min=0, max=1, description="1 internal thread, 0 plain bore of diameter d"),
    "play": ws.param(0.05, min=0, max=0.3, description="radial play to a bolt's thread, in pitches"),
    "segments": ws.param(72, integer=True, min=24, max=360, description="samples around the axis (multiple of 6)"),
    "rows_per_pitch": ws.param(12, integer=True, min=4, max=48, description="thread rings per pitch"),
}


def build(ctx):
    p = ctx.params
    size = round(p.d, 1)
    iso = g.iso_metric(size)
    m = iso["m"]
    nut = g.hex_nut(size, z0=p.z0, threaded=bool(p.threaded), clearance=p.play * iso["pitch"], segments=p.segments,
                    rows_per_pitch=p.rows_per_pitch)
    nut.anchors = [ws.anchor("bottom", point=(0, 0, p.z0), normal=(0, 0, -1)),
                   ws.anchor("top", point=(0, 0, p.z0 + m), normal=(0, 0, 1))]
    return nut


if __name__ == "__main__":
    ws.preview(build)
