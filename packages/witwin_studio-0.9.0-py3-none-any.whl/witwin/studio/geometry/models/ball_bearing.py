"""Deep-groove ball bearing by designation (6000-6010, 6200-6210, 6300-6310) or by d, D, B, with a cage.

Geometry (Z up, mm): axis along z, centred on the origin, ring faces at
z = -B/2 and +B/2; ball 1 on +x. Boundary dimensions from ISO 15
(6204: d 20, D 47, B 14); ball count and size are typical catalog values
(6204: eight 7.938 mm balls). Raceway grooves of radius 0.52 ball diameters
on the pitch circle (d + D) / 2; the balls touch neither ring. The cage is a
band on the pitch circle with one pocket per ball, clear of balls and rings,
lower than the rings (6204: 10.3 mm of 14).

Bodies: ``inner_ring``, ``outer_ring``, ``cage`` (unless ``cage`` = 0),
``ball_1`` .. ``ball_n`` (6204: 11 bodies).
Anchors: ``top`` (0, 0, B/2, normal +z) and ``bottom`` (0, 0, -B/2, normal -z).
"""
import witwin.studio as ws
from witwin.studio import geometry as g

CONFIG = {"unit": "mm", "up": "z"}

PARAMS = {
    "designation": ws.param(6204, integer=True, min=6000, max=6310,
                            description="bearing number: 6000-6010, 6200-6210, 6300-6310"),
    "d": ws.param(0, unit="mm", min=0, max=2000, description="bore; 0 = from the designation"),
    "D": ws.param(0, unit="mm", min=0, max=3000, description="outside diameter; 0 = from the designation"),
    "B": ws.param(0, unit="mm", min=0, max=1000, description="width; 0 = from the designation"),
    "balls": ws.param(0, integer=True, min=0, max=200, description="ball count; 0 = catalog value or estimate"),
    "ball_d": ws.param(0, unit="mm", min=0, max=500, description="ball diameter; 0 = catalog value or estimate"),
    "cage": ws.param(1, integer=True, min=0, max=1, description="1 window cage between the balls, 0 none"),
    "segments": ws.param(96, integer=True, min=24, max=720, description="samples around the axis"),
    "ball_segments": ws.param(24, integer=True, min=8, max=96, description="samples around each ball"),
}


def build(ctx):
    p = ctx.params
    explicit = {key: value or None for key, value in
                (("d", p.d), ("D", p.D), ("B", p.B), ("balls", p.balls), ("ball_diameter", p.ball_d))}
    designation = None if all(explicit[k] for k in ("d", "D", "B")) else str(p.designation)
    bodies = g.ball_bearing(designation, cage=bool(p.cage), segments=p.segments, ball_segments=p.ball_segments,
                            **explicit)
    width = g.bearing_size(designation, **explicit)["B"]
    return bodies + [ws.anchor("top", point=(0, 0, width / 2), normal=(0, 0, 1)),
                     ws.anchor("bottom", point=(0, 0, -width / 2), normal=(0, 0, -1))]


if __name__ == "__main__":
    ws.preview(build)
