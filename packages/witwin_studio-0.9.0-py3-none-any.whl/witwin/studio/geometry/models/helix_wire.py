"""A round wire swept along a helix: a coil spring, a helical antenna's wire, an inductor coil.

Geometry (Z up, mm): the helix winds around the z axis from z = z0 up to
z0 + pitch * turns, starting on +x (``start_angle`` turns the start point);
right-handed (counter-clockwise seen from +z as it rises) unless
``left`` = 1. ``radius`` is to the wire's centre line, so the outside
diameter is 2 radius + wire_d. The wire is a ``sides``-gon swept with
rotation-minimizing frames and capped flat at both ends.

``conductor`` = 1 makes the wire PEC with role conductor (an antenna);
0 makes it Steel (a spring).

Bodies: ``wire``. Anchors: ``start`` and ``end`` (the centre line's end
points, normals along the wire, outward), loose ``axis_bottom`` (0, 0, z0).
"""
import math

import witwin.studio as ws
from witwin.studio import geometry as g

CONFIG = {"unit": "mm", "up": "z"}

PARAMS = {
    "radius": ws.param(10, unit="mm", min=0.01, max=1e5, description="helix radius to the wire centre line"),
    "pitch": ws.param(5, unit="mm", min=0.01, max=1e5, description="axial advance per turn"),
    "turns": ws.param(5, min=0.05, max=500, description="number of turns (fractions allowed: 0.5 is half a turn)"),
    "wire_d": ws.param(1, unit="mm", min=0.001, max=1e4, description="wire diameter"),
    "z0": ws.param(0, unit="mm", min=-1e5, max=1e5, description="height of the helix start"),
    "start_angle": ws.param(0, unit="deg", min=-360, max=360, description="angle of the start point from +x"),
    "left": ws.param(0, integer=True, min=0, max=1, description="1 left-handed, 0 right-handed"),
    "conductor": ws.param(0, integer=True, min=0, max=1, description="1 PEC conductor (antenna), 0 Steel (spring)"),
    "segments_per_turn": ws.param(48, integer=True, min=8, max=720, description="path samples per turn"),
    "sides": ws.param(12, integer=True, min=3, max=64, description="polygon sides of the wire section"),
}


def build(ctx):
    p = ctx.params
    if p.wire_d >= min(2 * p.radius, p.pitch):
        raise ValueError(f"wire_d {p.wire_d:g} must be below the pitch {p.pitch:g} and the coil diameter "
                         f"{2 * p.radius:g} or the turns would intersect")
    path = g.helix(p.radius, p.pitch, p.turns, z0=p.z0, start_angle=p.start_angle, left=bool(p.left),
                   segments_per_turn=p.segments_per_turn)
    mesh = g.sweep(g.circle_profile(p.wire_d / 2, p.sides), path)
    head, tail = path[1] - path[0], path[-1] - path[-2]
    material = dict(material="PEC", role="conductor") if p.conductor else dict(material="Steel")
    wire = ws.Body(mesh, name="wire", anchors=[
        ws.anchor("start", point=tuple(path[0]), normal=tuple(-head / math.hypot(*head))),
        ws.anchor("end", point=tuple(path[-1]), normal=tuple(tail / math.hypot(*tail))),
    ], **material)
    return [wire, ws.anchor("axis_bottom", point=(0, 0, p.z0), normal=(0, 0, -1))]


if __name__ == "__main__":
    ws.preview(build)
