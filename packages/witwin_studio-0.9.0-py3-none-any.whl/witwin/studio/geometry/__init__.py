"""Geometry from Python into Scenes: converters, ``Body``, anchors, handles and checks.

    import witwin.studio as ws

    body = ws.Body(trimesh_mesh, material="PEC", role="conductor")
    report = ws.geometry.validate([body], grid=0.5e-3)   # ERROR / WARN findings
    scene.add_mesh("helix", body, unit="mm")              # validates, then writes

``to_mesh`` / ``to_parts`` accept numpy ``(vertices, faces)``, trimesh,
manifold3d, build123d and CadQuery objects; each library is only touched when
you pass one of its objects. Importing this package does not import numpy.
Model files (``models/<name>.py`` with ``CONFIG``, ``PARAMS`` and
``build(ctx)``) load with ``load_model`` and run in a subprocess of the
Project interpreter with ``run_model`` / ``run_cached``; ``preview`` draws one
to a PNG with the headless renderer (``render_preview``).

Swept solids and standard parts (numpy; loaded on first use, mm, Z up):
``sweep`` a 2D profile along a path (``helix``, ``arc``, a polyline),
``revolve`` an (r, z) profile, ``hex_bolt`` / ``hex_nut`` (ISO metric, real
thread), ``spur_gear`` / ``gear_pair`` (involute), ``ball_bearing``
(60xx/62xx/63xx). ``builtin_models`` lists the model files built on them,
which Studio offers as generators without a Plugin.
Design: ``dev_docs/backend/PYTHON_MESH_GEOMETRY.md``, ``dev_docs/backend/SCRIPT_GEOMETRY.md``.
"""
from __future__ import annotations

from typing import Any

from ._body import FILLS, ROLES, Anchor, Body, Handle, anchor, body_properties, handle, material_properties
from ._builtin import builtin_models
from ._convert import MeshData, to_mesh, to_parts
from ._model import (
    Model,
    ModelContext,
    ModelError,
    ModelOutput,
    Param,
    ParamValues,
    load_model,
    param,
    preview,
    render_preview,
    set_preview_renderer,
)
from ._runner import ModelApprovals, ModelCache, ModelRun, cache_key, library_versions, run_cached, run_model, source_hash
from ._validate import (
    DEFAULT_MAX_TRIANGLES,
    BodyStats,
    GeometryValidationError,
    Issue,
    ValidationReport,
    mesh_stats,
    validate,
)

# numpy-backed helpers, imported on first attribute access so that
# ``import witwin.studio`` does not load numpy (tests/test_import_weight.py).
_LAZY = {
    "arc": "_sweep", "circle_profile": "_sweep", "helix": "_sweep", "rect_profile": "_sweep",
    "revolve": "_sweep", "sweep": "_sweep",
    "ball_bearing": "_parts", "bearing_size": "_parts", "gear_pair": "_parts", "hex_bolt": "_parts",
    "hex_nut": "_parts", "iso_metric": "_parts", "spur_gear": "_parts",
}


def __getattr__(name: str) -> Any:
    module = _LAZY.get(name)
    if module is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    import importlib

    value = getattr(importlib.import_module(f"{__name__}.{module}"), name)
    globals()[name] = value
    return value


__all__ = [
    "Anchor",
    "Body",
    "BodyStats",
    "DEFAULT_MAX_TRIANGLES",
    "FILLS",
    "GeometryValidationError",
    "Handle",
    "Issue",
    "MeshData",
    "Model",
    "ModelApprovals",
    "ModelCache",
    "ModelContext",
    "ModelError",
    "ModelOutput",
    "ModelRun",
    "Param",
    "ParamValues",
    "ROLES",
    "ValidationReport",
    "anchor",
    "arc",
    "ball_bearing",
    "bearing_size",
    "body_properties",
    "builtin_models",
    "cache_key",
    "circle_profile",
    "gear_pair",
    "handle",
    "helix",
    "hex_bolt",
    "hex_nut",
    "iso_metric",
    "library_versions",
    "load_model",
    "material_properties",
    "mesh_stats",
    "param",
    "preview",
    "rect_profile",
    "render_preview",
    "revolve",
    "run_cached",
    "run_model",
    "set_preview_renderer",
    "source_hash",
    "spur_gear",
    "sweep",
    "to_mesh",
    "to_parts",
    "validate",
]
