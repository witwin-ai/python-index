"""The model files ``witwin-studio`` ships: generators that need no Plugin.

They live in ``geometry/models/`` next to this module and are ordinary model
files (``CONFIG``, ``PARAMS``, ``build``) built on ``_parts`` and ``_sweep``.
``builtin_models()`` lists them in the form of a Plugin's
``[[contributes.models]]`` entries, paths relative to ``BUILTIN_ROOT``; the
ProjectServer registers them as generators under the id ``witwin.studio``
(``features/script_geometry/generators.py``) next to the Plugin ones. Outside
Studio, load one with ``load_model(BUILTIN_ROOT / entry["path"])``.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Tuple

__all__ = ["BUILTIN_ID", "BUILTIN_LIBRARY", "BUILTIN_ROOT", "builtin_models"]

BUILTIN_ID = "witwin.studio"
BUILTIN_ROOT = Path(__file__).resolve().parent
# Code the built-in models call: part of their digest, so changing it regenerates them.
BUILTIN_LIBRARY: Tuple[str, ...] = ("_parts.py", "_sweep.py")

_MODELS: Tuple[Dict[str, Any], ...] = (
    {"id": "witwin.studio.mech.hex_bolt", "path": "models/hex_bolt.py", "title": "ISO hex bolt (threaded) + nut",
     "category": "Mechanical", "icon": "wrench",
     "tags": ["bolt", "screw", "fastener", "thread", "nut", "iso 4017", "iso 4032", "metric"]},
    {"id": "witwin.studio.mech.hex_nut", "path": "models/hex_nut.py", "title": "ISO hex nut (threaded)",
     "category": "Mechanical", "icon": "hexagon", "tags": ["nut", "fastener", "thread", "iso 4032", "metric"]},
    {"id": "witwin.studio.mech.spur_gear", "path": "models/spur_gear.py", "title": "Involute spur gear (or pair)",
     "category": "Mechanical", "icon": "cog", "tags": ["gear", "spur", "helical", "involute", "pinion", "pair"]},
    {"id": "witwin.studio.mech.ball_bearing", "path": "models/ball_bearing.py", "title": "Deep-groove ball bearing",
     "category": "Mechanical", "icon": "circle-dot", "tags": ["bearing", "ball", "6204", "60xx", "62xx", "63xx"]},
    {"id": "witwin.studio.sweep.helix_wire", "path": "models/helix_wire.py",
     "title": "Helical wire (spring, helix antenna)", "category": "Wires & sweeps", "icon": "spline",
     "tags": ["helix", "helical", "spring", "coil", "wire", "sweep", "antenna"]},
)


def builtin_models() -> List[Dict[str, Any]]:
    """The built-in model files as ``[[contributes.models]]`` entries (copies; paths relative to ``BUILTIN_ROOT``)."""
    return [dict(entry, tags=list(entry["tags"])) for entry in _MODELS]
