"""Run a model file in a subprocess of the Project interpreter.

The parent (``run_model``, called by the ProjectServer or any script) writes
a request JSON and starts

    <python> -I -c <bootstrap> <sdk path> <sys.path entries> <request.json>

The child (``main``) loads the model, calls ``build(ctx)``, scales every body
to meters and writes into the run folder:

- ``body_<i>.meshbin``: the triangles (WTB1 ``mesh``, meters, float32);
- ``body_<i>.brep``: the exact shape, model unit, when the body is a
  build123d B-rep (STEP export, topology queries);
- ``manifest.json``: parameters, the design spec, the model's ``up`` axis,
  bodies (material, role, fill, anchors, statistics, B-rep topology), loose
  anchors, drag handles, the validation report, library versions and, when the model
  failed, the error with its line.

Meshes, anchors and statistics in the manifest are in meters and in the
model's own frame (``CONFIG["up"]``, default ``"z"``). Whoever places or draws
them turns them into the Y-up Scene frame with ``ModelRun.scene_mesh`` /
``scene_anchors`` (``geometry._frame``).

Meshes never travel through stdout. The child gets the parent's ``witwin``
SDK first on ``sys.path`` (copied out of ``site-packages`` when installed), so
the manifest it writes is the format this module reads; numpy, build123d and
other libraries come from the Project interpreter. A timeout or a cancel kills
the child; OCCT sometimes hangs in booleans and fillets, which is why the
model never runs in the ProjectServer.

Results are cached by ``cache_key`` (source text + parameters in SI + library
versions) under a cache folder, normally ``<project>/.witwin/cache/geometry/``.
"""
from __future__ import annotations

import atexit
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

__all__ = [
    "DEFAULT_TIMEOUT", "ModelApprovals", "ModelCache", "ModelRun", "PROTOCOL", "cache_key",
    "library_versions", "main", "run_cached", "run_model", "source_hash",
]

# 2: the manifest carries "up" (model frame), "design_spec" and "summary".
# 3: and "handles" (viewport drag handles; older cache entries have none, so they rerun).
PROTOCOL = 3
DEFAULT_TIMEOUT = 120.0
RUNNER_ENV = "WITWIN_MODEL_RUNNER"
MANIFEST = "manifest.json"
# Distributions whose version changes what a model produces; part of the cache key.
GEOMETRY_DISTRIBUTIONS = (
    "build123d", "cadquery", "cadquery-ocp", "cadquery-ocp-novtk", "trimesh", "manifold3d",
    "numpy", "shapely", "gdstk", "scipy", "witwin-studio",
)
# Keep this much of the child's stdout / stderr in the result.
_OUTPUT_TAIL = 20_000

_BOOTSTRAP = (
    "import os, sys\n"
    "sdk, front, request = sys.argv[1], sys.argv[2], sys.argv[3]\n"
    "sys.path[:0] = [sdk] + [p for p in front.split(os.pathsep) if p]\n"
    "from witwin.studio.geometry._runner import main\n"
    "sys.exit(main(request))\n"
)


def source_hash(text: str) -> str:
    """``sha256:<hex>`` of a model's source text (what an approval is recorded for)."""
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()


def cache_key(source_text: str, si_params: Mapping[str, float], versions: Mapping[str, Optional[str]],
              extra: Any = None) -> str:
    """Folder name of a cached run: hash of source, SI parameters (7 digits), versions and ``extra``."""
    payload = {
        "protocol": PROTOCOL,
        "source": hashlib.sha256(source_text.encode("utf-8")).hexdigest(),
        # Fields store float32: 7 significant digits keep a value read back
        # from a field on the same key as the value written into it.
        "params": {k: float(f"{float(v):.7g}") for k, v in sorted(si_params.items())},
        "versions": dict(sorted(versions.items())),
        "extra": extra,
    }
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
    return "g" + digest[:31]


# ------------------------------------------------------------------ the child
def _jsonable(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return repr(value)


def _versions() -> Dict[str, Optional[str]]:
    from importlib import metadata

    out: Dict[str, Optional[str]] = {}
    for name in GEOMETRY_DISTRIBUTIONS:
        try:
            out[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            out[name] = None
    return out


def _missing_module(exc: BaseException) -> Optional[str]:
    """The top-level module a ModuleNotFoundError names, or None.

    Falls back to the message because a re-raised copy loses ``name``:
    trimesh raises ``ModuleNotFoundError(*args)`` when its manifold engine is
    missing, so ``exc.name`` is None there.
    """
    if not isinstance(exc, ModuleNotFoundError):
        return None
    if exc.name:
        return exc.name
    found = re.search(r"No module named '([^']+)'", str(exc))
    return found.group(1) if found else None


def _error_info(exc: BaseException, model_path: Optional[str]) -> Dict[str, Any]:
    """The error and the model line it came from (the last traceback frame in the model file)."""
    info: Dict[str, Any] = {"type": type(exc).__name__, "message": str(exc)}
    target = os.path.normcase(os.path.abspath(model_path)) if model_path else None
    if isinstance(exc, SyntaxError) and exc.filename and target \
            and os.path.normcase(os.path.abspath(exc.filename)) == target:
        info.update(line=exc.lineno, code=(exc.text or "").rstrip())
    elif target:
        for frame in reversed(traceback.extract_tb(exc.__traceback__)):
            if os.path.normcase(os.path.abspath(frame.filename)) == target:
                info.update(line=frame.lineno, code=frame.line or "")
                break
    text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    info["traceback"] = text[-4000:]
    missing = _missing_module(exc)
    if missing:
        info["missing_module"] = missing
        info["hint"] = (f"the Project interpreter has no module {missing!r}; install it in the Project "
                        f"environment (for build123d: `uv add build123d` or `pip install build123d`)")
    return info


def _surface_thickness(body: Any) -> Optional[float]:
    value = getattr(body, "surface_thickness", None)
    return float(value) if value else None


def _write_body(out: Path, index: int, output: Any, report_stats: Any, want_brep: bool) -> Dict[str, Any]:
    from ..meshbin import encode_mesh
    from ._body import material_properties
    from ._cad import topology
    import numpy as np

    body = output.bodies[index]
    mesh = output.si_mesh(index)
    name = f"body_{index}.meshbin"
    (out / name).write_bytes(encode_mesh(np.asarray(mesh.vertices, dtype=np.float32),
                                         np.asarray(mesh.faces, dtype=np.uint32)))
    entry: Dict[str, Any] = {
        "name": output.names[index], "file": name,
        "material": _jsonable(material_properties(body.material)) if body.material is not None else None,
        "role": body.role, "fill": body.fill,
        "anchors": [a.to_dict() for a in output.si_anchors(index)],
        # Meters; a layout sheet's real copper thickness (GeometryBody.surface_thickness).
        "surface_thickness": _surface_thickness(body),
        "stats": report_stats.to_dict() if report_stats is not None else None,
        "brep": None, "topology": None,
    }
    if body.shape is not None:
        try:
            entry["topology"] = topology(body.shape, output.multiplier)
        except Exception as exc:  # noqa: BLE001 - topology is extra information
            entry["topology_error"] = str(exc)
        if want_brep and hasattr(body.shape, "wrapped"):
            try:
                from ._cad import export_shape

                export_shape(body.shape, str(out / f"body_{index}.brep"), "brep", output.unit)
                entry["brep"] = f"body_{index}.brep"
            except Exception as exc:  # noqa: BLE001 - STEP export reports it later
                entry["brep_error"] = str(exc)
    return entry


def _build(req: Mapping[str, Any], out: Path, manifest: Dict[str, Any]) -> None:
    from ._model import load_model

    model = load_model(req["model"])
    manifest.update(unit=model.unit, up=model.up, config=_jsonable(model.config), params=model.schema(),
                    design_spec=model.design_schema(), has_design=model.design is not None,
                    summary=model.summary)
    overrides: Dict[str, Any] = {}
    if req.get("design") is not None:
        # design(spec) first; explicit parameter overrides win over its result.
        overrides = model.design_values(req.get("design"))
        manifest["design_values"] = dict(overrides)
    if req.get("mode") == "describe":
        return
    overrides.update(req.get("params") or {})
    values, si = model.resolve(overrides, req.get("si_params"), strict=req.get("strict", True))
    manifest.update(values=values, si_values=si)
    started = time.perf_counter()
    output = model.run(values)
    manifest["build_seconds"] = round(time.perf_counter() - started, 4)
    grid = req.get("grid") if req.get("grid") is not None else model.config.get("grid")
    report = output.validate(grid=grid, max_triangles=req.get("max_triangles"))
    stats = {s.name: s for s in report.bodies}
    manifest["bodies"] = [_write_body(out, i, output, stats.get(output.names[i]), req.get("brep", True))
                          for i in range(len(output.bodies))]
    manifest["anchors"] = [a.to_dict() for a in output.si_anchors()]
    manifest["handles"] = output.si_handles(model.params)
    manifest["validation"] = report.to_dict()
    mode = req.get("mode", "build")
    if mode == "measure":
        from ._cad import measure

        shapes = {name: body.shape for name, body in zip(output.names, output.bodies)}
        anchors: Dict[Optional[str], Dict[str, Any]] = {
            name: {a.name: a.point for a in body.anchors} for name, body in zip(output.names, output.bodies)}
        anchors[None] = {a.name: a.point for a in output.anchors}
        anchors[""] = anchors[None]
        manifest["measurements"] = measure(req.get("queries") or [], shapes, anchors, output.multiplier)
    elif mode == "export":
        from ._cad import export_shape

        spec = req.get("export") or {}
        wanted = spec.get("bodies") or output.names
        shapes = [b.shape for n, b in zip(output.names, output.bodies) if n in wanted]
        if not shapes or any(s is None or not hasattr(s, "wrapped") for s in shapes):
            raise ValueError("STEP/BREP export needs bodies built with build123d (B-rep); mesh bodies "
                             "can be exported as STL or GLB")
        if len(shapes) == 1:
            shape = shapes[0]
        else:
            from build123d import Compound

            shape = Compound(children=shapes)
        export_shape(shape, spec["path"], spec["format"], model.unit)
        manifest["export"] = {"path": spec["path"], "format": spec["format"], "unit": model.unit,
                              "bodies": list(wanted)}


def _import(req: Mapping[str, Any], out: Path, manifest: Dict[str, Any]) -> None:
    from ._body import Body
    from ._cad import import_shapes
    from ._model import _unit_of, collect_output

    unit = req.get("unit") or "mm"
    up = req.get("up") or "z"
    multiplier = _unit_of(unit)[1].multiplier
    parts = import_shapes(req["file"])
    output = collect_output({name: Body(shape, name=name, tolerance=req.get("tolerance"))
                             for name, shape in parts}, unit, multiplier, up=up)
    report = output.validate(grid=req.get("grid"))
    stats = {s.name: s for s in report.bodies}
    manifest.update(unit=unit, up=up, params=[], values={}, si_values={})
    manifest["bodies"] = [_write_body(out, i, output, stats.get(output.names[i]), False)
                          for i in range(len(output.bodies))]
    manifest["anchors"] = []
    manifest["validation"] = report.to_dict()


def main(request_path: str) -> int:
    """Child entry point: run one request and write ``manifest.json`` (exit 0 unless the runner broke)."""
    req = json.loads(Path(request_path).read_text(encoding="utf-8"))
    out = Path(req["out"])
    out.mkdir(parents=True, exist_ok=True)
    manifest: Dict[str, Any] = {"protocol": PROTOCOL, "mode": req.get("mode", "build"), "ok": False,
                                "model": req.get("display_path") or req.get("model")}
    try:
        if req.get("mode") == "import":
            _import(req, out, manifest)
        else:
            _build(req, out, manifest)
        manifest["ok"] = True
    except BaseException as exc:  # noqa: BLE001 - every model failure goes into the manifest
        manifest["error"] = _error_info(exc, req.get("model"))
        if isinstance(exc, KeyboardInterrupt):
            raise
    try:
        manifest["versions"] = _versions()
    except Exception:  # noqa: BLE001
        manifest["versions"] = {}
    (out / MANIFEST).write_text(json.dumps(manifest, indent=1, default=repr), encoding="utf-8")
    return 0


# ----------------------------------------------------------------- the parent
_SDK_COPY: Optional[str] = None
_SDK_LOCK = threading.Lock()


def _sdk_path() -> str:
    """A ``sys.path`` entry holding this ``witwin`` package and nothing else of the server's environment.

    A source checkout (``sdk/src``) is used as is. An installed SDK sits in
    ``site-packages`` next to the ProjectServer's own libraries, which must
    not leak into the Project interpreter, so ``witwin/studio`` is copied
    once per process into a temporary folder.
    """
    global _SDK_COPY
    studio = Path(__file__).resolve().parents[1]
    root = studio.parents[1]
    if root.name not in ("site-packages", "dist-packages"):
        return str(root)
    with _SDK_LOCK:
        if _SDK_COPY is None:
            base = Path(tempfile.mkdtemp(prefix="witwin-sdk-"))
            shutil.copytree(studio, base / "witwin" / "studio",
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            atexit.register(shutil.rmtree, base, True)
            _SDK_COPY = str(base)
        return _SDK_COPY


_VERSIONS: Dict[str, Dict[str, Optional[str]]] = {}
_PROBE = (
    "import json\nfrom importlib import metadata\nout = {}\n"
    "for n in %r:\n"
    "    try: out[n] = metadata.version(n)\n"
    "    except metadata.PackageNotFoundError: out[n] = None\n"
    "print(json.dumps(out))\n"
)


def library_versions(python: Optional[str] = None, *, refresh: bool = False) -> Dict[str, Optional[str]]:
    """Versions of the geometry libraries in ``python``'s environment (cached per interpreter).

    ``witwin-studio`` is reported as this SDK's version, because the child
    runs this SDK whatever the environment has installed.
    """
    from .. import __version__

    exe = python or sys.executable
    if refresh or exe not in _VERSIONS:
        names = tuple(n for n in GEOMETRY_DISTRIBUTIONS if n != "witwin-studio")
        try:
            done = subprocess.run([exe, "-I", "-c", _PROBE % (names,)], capture_output=True, text=True,
                                  timeout=60)
            versions = json.loads(done.stdout.strip().splitlines()[-1]) if done.returncode == 0 else {}
        except (OSError, subprocess.SubprocessError, ValueError, IndexError):
            versions = {}
        _VERSIONS[exe] = versions
    return {**_VERSIONS[exe], "witwin-studio": __version__}


@dataclass
class ModelRun:
    """One run of a model (or an import): the manifest plus how the process ended."""

    folder: Path
    manifest: Dict[str, Any] = field(default_factory=dict)
    stdout: str = ""
    stderr: str = ""
    returncode: Optional[int] = None
    timed_out: bool = False
    cancelled: bool = False
    elapsed: float = 0.0
    cached: bool = False
    key: Optional[str] = None

    @property
    def ok(self) -> bool:
        """The model ran and returned geometry (validation may still have errors)."""
        return bool(self.manifest.get("ok")) and not self.timed_out and not self.cancelled

    @property
    def error(self) -> Optional[Dict[str, Any]]:
        if self.timed_out:
            return {"type": "Timeout", "message": "the model did not finish in time and was stopped"}
        if self.cancelled:
            return {"type": "Cancelled", "message": "the run was cancelled"}
        if self.manifest.get("error"):
            return self.manifest["error"]
        if not self.manifest:
            tail = self.stderr.strip().splitlines()[-5:]
            return {"type": "RunnerError", "message": "the model runner wrote no manifest "
                    f"(exit code {self.returncode})", "stderr": "\n".join(tail)}
        return None

    @property
    def bodies(self) -> List[Dict[str, Any]]:
        return list(self.manifest.get("bodies") or [])

    @property
    def params(self) -> List[Dict[str, Any]]:
        return list(self.manifest.get("params") or [])

    @property
    def validation(self) -> Dict[str, Any]:
        return dict(self.manifest.get("validation") or {})

    @property
    def up(self) -> str:
        """The frame the manifest's meshes and anchors are in (the model's ``CONFIG["up"]``)."""
        return str(self.manifest.get("up") or "z")

    def body_path(self, index: int, kind: str = "file") -> Optional[Path]:
        name = self.bodies[index].get(kind)
        return None if not name else self.folder / name

    def mesh(self, index: int):
        """``(vertices float32 (N, 3) meters, faces uint32 (M, 3))`` of body ``index``."""
        import numpy as np

        from ..meshbin import decode_mesh

        decoded = decode_mesh(self.body_path(index).read_bytes())
        return (np.asarray(decoded.positions, dtype=np.float32).reshape(-1, 3),
                np.asarray(decoded.indices, dtype=np.uint32).reshape(-1, 3))

    def scene_mesh(self, index: int):
        """``mesh(index)`` turned into the Y-up Scene frame (what is placed and drawn)."""
        import numpy as np

        from ._frame import to_scene

        vertices, faces = self.mesh(index)
        return np.asarray(to_scene(vertices, self.up), dtype=np.float32), faces

    def scene_anchors(self, index: Optional[int] = None) -> List[Dict[str, Any]]:
        """Anchor dicts of body ``index`` (or the loose ones) in the Scene frame, meters."""
        from ._frame import to_scene

        source = self.manifest.get("anchors") if index is None else self.bodies[index].get("anchors")
        out = []
        for item in source or []:
            moved = dict(item)
            moved["point"] = list(to_scene(tuple(item["point"]), self.up))
            if item.get("normal") is not None:
                moved["normal"] = list(to_scene(tuple(item["normal"]), self.up))
            out.append(moved)
        return out

    def scene_handles(self) -> List[Dict[str, Any]]:
        """Handle dicts in the Scene frame, meters, each with ``si_scale`` (see ``ModelOutput.si_handles``)."""
        from ._frame import handle_dict_to_scene

        return [handle_dict_to_scene(item, self.up) for item in self.manifest.get("handles") or []]

    def summary(self) -> Dict[str, Any]:
        """JSON-ready result for tools: no vertex data."""
        out: Dict[str, Any] = {
            "ok": self.ok, "model": self.manifest.get("model"), "unit": self.manifest.get("unit"),
            "up": self.manifest.get("up"),
            "params": self.params, "values": self.manifest.get("values"), "cached": self.cached,
            "bodies": [{k: v for k, v in b.items() if k not in ("file", "brep")} for b in self.bodies],
            "anchors": self.manifest.get("anchors") or [],
        }
        if self.validation:
            out["validation"] = {k: v for k, v in self.validation.items() if k != "bodies"}
        if self.error:
            out["error"] = self.error
        for key in ("design_values", "measurements", "export", "build_seconds"):
            if key in self.manifest:
                out[key] = self.manifest[key]
        if self.stdout.strip():
            out["stdout"] = self.stdout[-4000:]
        if self.stderr.strip() and not self.ok:
            out["stderr"] = self.stderr[-4000:]
        return out


def _read_tail(path: Path) -> str:
    try:
        data = path.read_bytes()
    except OSError:
        return ""
    return data[-_OUTPUT_TAIL:].decode("utf-8", "replace")


def run_model(model: Any = None, *, params: Optional[Mapping[str, Any]] = None,
              si_params: Optional[Mapping[str, Any]] = None, mode: str = "build",
              project_root: Any = None, python: Optional[str] = None, timeout: float = DEFAULT_TIMEOUT,
              cancel: Any = None, out_dir: Any = None, grid: Any = None,
              queries: Optional[Sequence[Mapping[str, Any]]] = None, export: Optional[Mapping[str, Any]] = None,
              source_text: Optional[str] = None, import_file: Any = None, import_unit: Optional[str] = None,
              brep: bool = True, strict: bool = True, env: Optional[Mapping[str, str]] = None,
              design: Optional[Mapping[str, Any]] = None, import_up: Optional[str] = None) -> ModelRun:
    """Run a model file (or import a CAD file) in a child process; blocks until it ends.

    - ``model``: path of the model file. ``source_text`` runs that text
      instead, as if it were the file (``geometry.diff`` uses it for older
      revisions); the file's folder stays importable.
    - ``params`` override defaults in each parameter's declared unit;
      ``si_params`` in SI (what Studio stores).
    - ``mode``: ``build``, ``describe`` (load the model and report its
      parameters, design spec and up axis; ``build`` is not called),
      ``measure`` (with ``queries``), ``export`` (with ``export =
      {"format": "step"|"brep", "path": ...}``) or ``import``
      (``import_file``, ``import_unit``, ``import_up``: the file's up axis,
      default ``"z"``).
    - ``design``: a spec for the model's ``design(spec)`` (``DESIGN_SPEC``
      units); its result is applied first and ``params`` override it.
    - ``python``: the interpreter (default: this one). ``cancel``: an object
      with ``is_set()``; when it turns true the child is killed.
    - ``out_dir``: where the run writes its files (default: a new temporary
      folder the caller owns).
    """
    started = time.monotonic()
    folder = Path(out_dir) if out_dir is not None else Path(tempfile.mkdtemp(prefix="witwin-model-"))
    folder.mkdir(parents=True, exist_ok=True)
    root = Path(project_root).resolve() if project_root is not None else None
    request: Dict[str, Any] = {"mode": mode, "out": str(folder), "grid": grid, "brep": brep, "strict": strict}
    front: List[str] = []
    if mode == "import":
        request.update(file=str(Path(import_file).resolve()), unit=import_unit, up=import_up)
    else:
        path = Path(model).resolve()
        request["display_path"] = (path.relative_to(root).as_posix()
                                   if root is not None and path.is_relative_to(root) else str(path))
        if source_text is not None:
            src_dir = folder / "_source"
            src_dir.mkdir(exist_ok=True)
            target = src_dir / path.name
            target.write_text(source_text, encoding="utf-8")
            request["model"] = str(target)
        else:
            request["model"] = str(path)
        front.append(str(path.parent))
        request.update(params=dict(params or {}), si_params=dict(si_params or {}),
                       queries=list(queries or []), export=dict(export or {}) or None,
                       design=None if design is None else dict(design))
    if root is not None and str(root) not in front:
        front.append(str(root))
    request_path = folder / "request.json"
    request_path.write_text(json.dumps(request), encoding="utf-8")

    child_env = dict(os.environ if env is None else env)
    child_env[RUNNER_ENV] = "1"
    child_env.setdefault("PYTHONIOENCODING", "utf-8")
    run = ModelRun(folder)
    out_path, err_path = folder / "stdout.txt", folder / "stderr.txt"
    with open(out_path, "wb") as out_f, open(err_path, "wb") as err_f:
        try:
            proc = subprocess.Popen(
                [python or sys.executable, "-I", "-c", _BOOTSTRAP, _sdk_path(), os.pathsep.join(front),
                 str(request_path)],
                cwd=str(root) if root is not None else None, env=child_env, stdout=out_f, stderr=err_f)
        except OSError as exc:
            run.manifest = {"ok": False, "error": {"type": "LaunchError",
                                                   "message": f"cannot start {python or sys.executable}: {exc}"}}
            return run
        deadline = started + float(timeout)
        while proc.poll() is None:
            if cancel is not None and cancel.is_set():
                run.cancelled = True
                break
            if time.monotonic() > deadline:
                run.timed_out = True
                break
            time.sleep(0.02)
        if proc.poll() is None:
            proc.kill()
            proc.wait()
        run.returncode = proc.returncode
    run.stdout, run.stderr = _read_tail(out_path), _read_tail(err_path)
    manifest_path = folder / MANIFEST
    if manifest_path.is_file() and not (run.timed_out or run.cancelled):
        try:
            run.manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except ValueError:
            run.manifest = {}
    run.elapsed = time.monotonic() - started
    return run


# ---------------------------------------------------------------------- cache
class ModelCache:
    """Finished runs by ``cache_key``: ``<root>/<key>/manifest.json`` plus the body files.

    Writes go to a fresh ``tmp-*`` folder that is renamed into place, so a
    reader never sees half a result. Only successful ``build`` runs are kept;
    the oldest entries past ``max_entries`` are removed.
    """

    def __init__(self, root: Any, max_entries: int = 64):
        self.root = Path(root)
        self.max_entries = max_entries

    def folder(self, key: str) -> Path:
        return self.root / key

    def scratch(self) -> Path:
        """A new folder for a run that may become a cache entry."""
        path = self.root / f"tmp-{uuid.uuid4().hex[:12]}"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def get(self, key: str) -> Optional[ModelRun]:
        folder = self.folder(key)
        manifest = folder / MANIFEST
        if not manifest.is_file():
            return None
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        if not data.get("ok") or data.get("protocol") != PROTOCOL:
            return None
        if any(not (folder / b.get("file", "")).is_file() for b in data.get("bodies") or []):
            return None
        try:
            os.utime(manifest)  # most recently used survives pruning
        except OSError:
            pass
        return ModelRun(folder, data, returncode=0, cached=True, key=key)

    def put(self, key: str, run: ModelRun) -> ModelRun:
        """Move a successful run's folder into the cache; returns the run at its new place."""
        if not run.ok or run.manifest.get("mode", "build") != "build":
            return run
        target = self.folder(key)
        if target.exists():
            shutil.rmtree(run.folder, ignore_errors=True)
            cached = self.get(key)
            return cached or run
        try:
            os.replace(run.folder, target)
        except OSError:
            return run
        run.folder, run.key = target, key
        self._prune()
        return run

    def _prune(self) -> None:
        entries = [p for p in self.root.iterdir() if p.is_dir() and not p.name.startswith("tmp-")]
        if len(entries) <= self.max_entries:
            return
        entries.sort(key=lambda p: (p / MANIFEST).stat().st_mtime if (p / MANIFEST).exists() else 0)
        for stale in entries[:len(entries) - self.max_entries]:
            shutil.rmtree(stale, ignore_errors=True)


# ------------------------------------------------------------------ approvals
class ModelApprovals:
    """Which model source texts the user approved to run without asking again.

    Stored per Project in ``<project>/.witwin/model-approvals.json``, keyed by
    ``source_hash``: ``{"version": 1, "approved": {"sha256:...": {"path", "at"}}}``.
    Editing a model file changes its hash, so the next regeneration needs a
    new approval. Only the model file's own text is covered, not modules it
    imports.
    """

    FILE = "model-approvals.json"

    def __init__(self, project_root: Any):
        self.path = Path(project_root) / ".witwin" / self.FILE
        self._lock = threading.Lock()

    def _read(self) -> Dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {"version": 1, "approved": {}}
        if not isinstance(data, dict) or not isinstance(data.get("approved"), dict):
            return {"version": 1, "approved": {}}
        return data

    def is_approved(self, digest: str) -> bool:
        with self._lock:
            return digest in self._read()["approved"]

    def approve(self, digest: str, path: str = "") -> None:
        with self._lock:
            data = self._read()
            data["approved"][digest] = {"path": path, "at": datetime.now().isoformat(timespec="seconds")}
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
            os.replace(tmp, self.path)

    def revoke(self, digest: str) -> bool:
        with self._lock:
            data = self._read()
            if data["approved"].pop(digest, None) is None:
                return False
            self.path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            return True

    def approved(self) -> Iterable[str]:
        with self._lock:
            return list(self._read()["approved"])


def run_cached(model: Any, *, cache: ModelCache, python: Optional[str] = None,
               params: Optional[Mapping[str, Any]] = None, si_params: Optional[Mapping[str, Any]] = None,
               grid: Any = None, design: Optional[Mapping[str, Any]] = None, salt: Any = None,
               **kwargs: Any) -> ModelRun:
    """``run_model`` in build mode, reusing ``cache`` when source, parameters and libraries match.

    The key covers the parameters as given (``params`` and ``si_params``
    separately), so the same values spelled differently miss the cache once.
    ``salt`` is any JSON-able value that also changes what the model
    produces but is not in its text, such as the hash of helper modules
    next to a Plugin's model file.
    """
    path = Path(model).resolve()
    text = path.read_text(encoding="utf-8")
    key = cache_key(text, dict(si_params or {}), library_versions(python),
                    extra={"params": _jsonable(dict(params or {})), "grid": _jsonable(grid),
                           "design": _jsonable(design), "salt": _jsonable(salt)})
    hit = cache.get(key)
    if hit is not None:
        return hit
    run = run_model(path, params=params, si_params=si_params, python=python, grid=grid, design=design,
                    out_dir=cache.scratch(), **kwargs)
    run.key = key
    if run.ok:
        return cache.put(key, run)
    return run
