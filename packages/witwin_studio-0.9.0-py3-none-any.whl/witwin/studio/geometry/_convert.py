"""Turn the geometry objects of common Python libraries into triangle arrays.

Accepted inputs (``to_parts`` / ``to_mesh``):

- ``MeshData``, a ``Body`` (its mesh), ``(vertices, faces)`` or
  ``(vertices, faces, normals)``, a mapping with ``vertices`` and ``faces``;
- ``trimesh.Trimesh``; ``trimesh.Scene`` (one part per scene-graph node, with
  the node's transform applied);
- ``manifold3d.Manifold`` and ``manifold3d.Mesh``;
- build123d shapes and builders (``BuildPart`` and friends, through ``.part``
  / ``.sketch`` / ``.line``) and CadQuery shapes and ``Workplane`` objects,
  tessellated with ``tolerance`` / ``angular_tolerance``;
- any other object with ``vertices`` and ``faces`` attributes.

Every library is detected by duck typing, never imported here, so a missing
library costs nothing. numpy is imported inside the functions: this module is
imported by ``witwin.studio``, which must load without numpy.
"""
from __future__ import annotations

import contextlib
import contextvars
from dataclasses import dataclass
from typing import Any, Iterator, List, Optional, Tuple

__all__ = ["MeshData", "to_mesh", "to_parts"]

# Relative chord tolerance for CAD tessellation when none is given: 1e-3 of
# the shape's bounding-box diagonal. Fine enough that a 1 mm wire in a 100 mm
# part gets ~0.1 mm chords, coarse enough to stay well under the triangle cap.
DEFAULT_RELATIVE_TOLERANCE = 1e-3
DEFAULT_ANGULAR_TOLERANCE = 0.1  # radians, build123d's and CadQuery's own default

# Tolerances a model file sets in CONFIG ("tolerance", "angular_tolerance"),
# in the model's unit. The model runner sets them around build(ctx), so a
# ws.Body made without its own tolerance uses the model's. None: the defaults
# above.
_MODEL_TOLERANCES: contextvars.ContextVar[Tuple[Optional[float], Optional[float]]] = contextvars.ContextVar(
    "witwin_model_tolerances", default=(None, None))


@contextlib.contextmanager
def model_tolerances(tolerance: Optional[float], angular_tolerance: Optional[float]) -> Iterator[None]:
    """CAD tessellation tolerances for conversions inside the block (model runner)."""
    token = _MODEL_TOLERANCES.set((tolerance, angular_tolerance))
    try:
        yield
    finally:
        _MODEL_TOLERANCES.reset(token)


@dataclass
class MeshData:
    """One triangle mesh: ``vertices`` float64 (N, 3), ``faces`` int64 (M, 3).

    ``normals`` is an optional (N, 3) per-vertex array. Coordinates are in
    whatever unit the caller works in; ``Scene.add_mesh(unit=...)`` converts.
    """

    vertices: Any
    faces: Any
    normals: Any = None

    @property
    def triangle_count(self) -> int:
        return int(len(self.faces))

    @property
    def vertex_count(self) -> int:
        return int(len(self.vertices))

    def scaled(self, factor: float) -> "MeshData":
        """A copy with vertices multiplied by ``factor`` (normals unchanged)."""
        return MeshData(self.vertices * float(factor), self.faces.copy(),
                        None if self.normals is None else self.normals.copy())

    def __repr__(self) -> str:
        return f"MeshData(vertices={self.vertex_count}, triangles={self.triangle_count})"


def _arrays(vertices: Any, faces: Any, normals: Any = None) -> MeshData:
    import numpy as np

    v = np.asarray(vertices, dtype=np.float64)
    f = np.asarray(faces)
    if v.ndim != 2 or v.shape[1] != 3:
        raise ValueError(f"vertices must be an (N, 3) array, got shape {v.shape}")
    if f.size == 0:
        f = f.reshape(0, 3)
    if f.ndim != 2 or f.shape[1] != 3:
        raise ValueError(f"faces must be an (M, 3) array of vertex indices, got shape {f.shape}")
    if not np.issubdtype(f.dtype, np.integer):
        if not np.all(np.mod(f, 1) == 0):
            raise ValueError("faces must hold integer vertex indices")
    f = f.astype(np.int64)
    if f.size and (f.min() < 0 or f.max() >= len(v)):
        raise ValueError(f"faces index vertices outside 0..{len(v) - 1}")
    if not np.all(np.isfinite(v)):
        raise ValueError("vertices contain NaN or infinity")
    n = None
    if normals is not None:
        n = np.asarray(normals, dtype=np.float64)
        if n.shape != v.shape:
            raise ValueError(f"normals must match vertices {v.shape}, got {n.shape}")
    return MeshData(v, f, n)


def _module(obj: Any) -> str:
    return type(obj).__module__.split(".")[0]


def _is_trimesh_scene(obj: Any) -> bool:
    return _module(obj) == "trimesh" and hasattr(obj, "graph") and hasattr(obj, "geometry")


def _is_manifold(obj: Any) -> bool:
    return _module(obj) == "manifold3d" and hasattr(obj, "to_mesh")


def _is_manifold_mesh(obj: Any) -> bool:
    return _module(obj) == "manifold3d" and hasattr(obj, "vert_properties") and hasattr(obj, "tri_verts")


def _cad_shape(obj: Any) -> Any:
    """The tessellatable shape behind a build123d / CadQuery object, or None."""
    module = _module(obj)
    if module not in ("build123d", "cadquery", "OCP"):
        return None
    if hasattr(obj, "tessellate"):
        return obj
    if module == "build123d":
        # Builders (BuildPart, BuildSketch, BuildLine) keep their result here.
        for attr in ("part", "sketch", "line"):
            inner = getattr(obj, attr, None)
            if inner is not None:
                return _cad_shape(inner)
        if isinstance(obj, (list, tuple)):  # a ShapeList
            from build123d import Compound  # the caller already uses build123d

            return Compound(children=list(obj))
    if hasattr(obj, "toCompound"):  # a CadQuery Workplane: fuse its stack
        return obj.toCompound()
    return None


def _vec3(value: Any) -> Tuple[float, float, float]:
    for name in ("to_tuple", "toTuple"):
        method = getattr(value, name, None)
        if callable(method):
            x, y, z = method()
            return float(x), float(y), float(z)
    if hasattr(value, "X"):
        return float(value.X), float(value.Y), float(value.Z)
    x, y, z = value
    return float(x), float(y), float(z)


def _cad_diagonal(shape: Any) -> Optional[float]:
    try:
        box = shape.bounding_box()  # build123d
        return float(box.diagonal)
    except Exception:  # noqa: BLE001 - try the CadQuery spelling next
        pass
    try:
        return float(shape.BoundingBox().DiagonalLength)  # CadQuery
    except Exception:  # noqa: BLE001 - unknown shape kind: caller falls back
        return None


def merge_vertices(mesh: MeshData, tolerance: float) -> MeshData:
    """Weld vertices closer than ``tolerance`` (snapped to a grid of that size).

    CAD tessellators emit each B-rep face with its own vertices, so a closed
    solid comes out as patches whose shared edges are duplicated. Welding
    restores the shared edges; without it every solid reads as open.
    """
    import numpy as np

    if mesh.vertex_count == 0 or tolerance <= 0:
        return mesh
    keys = np.round(mesh.vertices / tolerance).astype(np.int64)
    _, first, inverse = np.unique(keys, axis=0, return_index=True, return_inverse=True)
    inverse = inverse.reshape(-1)
    faces = inverse[mesh.faces]
    # Faces that collapsed to an edge or a point after welding are slivers
    # below the tessellation tolerance; drop them.
    keep = (faces[:, 0] != faces[:, 1]) & (faces[:, 1] != faces[:, 2]) & (faces[:, 0] != faces[:, 2])
    return MeshData(mesh.vertices[first], faces[keep], None)


def _tessellate(shape: Any, tolerance: Optional[float], angular_tolerance: Optional[float]) -> MeshData:
    import numpy as np

    diagonal = _cad_diagonal(shape)
    model_tolerance, model_angular = _MODEL_TOLERANCES.get()
    if tolerance is None:
        tolerance = model_tolerance
    if tolerance is None:
        tolerance = (diagonal or 1.0) * DEFAULT_RELATIVE_TOLERANCE
    if angular_tolerance is None:
        angular_tolerance = model_angular
    if angular_tolerance is None:
        angular_tolerance = DEFAULT_ANGULAR_TOLERANCE
    # Positional arguments: build123d names the second one angular_tolerance,
    # CadQuery angularTolerance.
    verts, tris = shape.tessellate(float(tolerance), float(angular_tolerance))
    vertices = np.array([_vec3(v) for v in verts], dtype=np.float64).reshape(-1, 3)
    faces = np.array([tuple(t) for t in tris], dtype=np.int64).reshape(-1, 3)
    mesh = _arrays(vertices, faces)
    # Weld well below the chord tolerance so distinct features never merge.
    return merge_vertices(mesh, max((diagonal or 1.0) * 1e-9, float(tolerance) * 1e-3))


def to_parts(obj: Any, *, tolerance: Optional[float] = None,
             angular_tolerance: Optional[float] = None) -> List[Tuple[Optional[str], MeshData]]:
    """Convert ``obj`` to a list of ``(part_name, MeshData)``.

    Most inputs give one part with name None. A ``trimesh.Scene`` gives one
    part per scene-graph node, named after the node. ``TypeError`` names the
    accepted inputs when ``obj`` is none of them.
    """
    from ._body import Body  # local import: _body imports this module

    if isinstance(obj, Body):
        return [(None, obj.mesh)]
    if isinstance(obj, MeshData):
        return [(None, _arrays(obj.vertices, obj.faces, obj.normals))]
    if isinstance(obj, tuple) and len(obj) in (2, 3):
        return [(None, _arrays(*obj))]
    if isinstance(obj, dict) and "vertices" in obj and "faces" in obj:
        return [(None, _arrays(obj["vertices"], obj["faces"], obj.get("normals")))]
    if _is_trimesh_scene(obj):
        parts = []
        for node in obj.graph.nodes_geometry:
            transform, geometry_name = obj.graph[node]
            geometry = obj.geometry[geometry_name]
            if not hasattr(geometry, "faces"):
                continue  # a Path or PointCloud node: no triangles
            moved = geometry.copy()
            moved.apply_transform(transform)
            parts.append((str(node), _arrays(moved.vertices, moved.faces)))
        if not parts:
            raise ValueError("the trimesh.Scene holds no triangle meshes")
        return parts
    if _is_manifold(obj):
        return to_parts(obj.to_mesh())
    if _is_manifold_mesh(obj):
        import numpy as np

        props = np.asarray(obj.vert_properties, dtype=np.float64)
        return [(None, _arrays(props[:, :3], np.asarray(obj.tri_verts)))]
    shape = _cad_shape(obj)
    if shape is not None:
        return [(None, _tessellate(shape, tolerance, angular_tolerance))]
    if hasattr(obj, "vertices") and hasattr(obj, "faces"):
        # trimesh.Trimesh and look-alikes. Vertex normals are not taken:
        # trimesh smooths them across hard edges, which shades boxes wrongly;
        # the viewport computes its own.
        return [(None, _arrays(obj.vertices, obj.faces))]
    raise TypeError(
        f"cannot make a mesh from {type(obj).__module__}.{type(obj).__name__}; pass (vertices, faces) "
        "arrays, a trimesh.Trimesh/Scene, a manifold3d.Manifold, a build123d or CadQuery shape, or ws.Body")


def to_mesh(obj: Any, *, tolerance: Optional[float] = None,
            angular_tolerance: Optional[float] = None) -> MeshData:
    """Convert ``obj`` to one ``MeshData``; several parts are concatenated."""
    import numpy as np

    parts = to_parts(obj, tolerance=tolerance, angular_tolerance=angular_tolerance)
    if len(parts) == 1:
        return parts[0][1]
    vertices, faces, offset = [], [], 0
    for _, part in parts:
        vertices.append(part.vertices)
        faces.append(part.faces + offset)
        offset += part.vertex_count
    return MeshData(np.concatenate(vertices), np.concatenate(faces), None)
