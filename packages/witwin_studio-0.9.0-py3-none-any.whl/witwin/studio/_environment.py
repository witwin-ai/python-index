"""The Python interpreter a Project's code runs with (decision D11.9).

One resolver for every place that starts Project code: headless solves
(``witwin.studio.solver``), the ProjectServer's Scripts, Runs and
``${project:python}`` solver children (``witwin_server.plugins.environment``
re-exports these functions). Order:

1. ``WITWIN_PROJECT_PYTHON``: an interpreter the user chose;
2. ``<project>/.venv``;
3. the calling interpreter (``sys.executable``), which keeps legacy Projects
   without an environment working.

On a hosted ProjectServer (``WITWIN_HOSTED=1``, set by the hosted Control
for every worker) only step 3 applies: a ``.venv`` or interpreter path inside
the Project is a file the user wrote, so starting it would run their code on a
machine other users share.

Resolved on every call, never cached: a ``uv sync`` that creates ``.venv``
takes effect on the next launch.

``run_sys_path`` gives the ``sys.path`` entries such a launch puts in front of
the interpreter's own, so a Script or Run imports like ``python scripts/x.py``
typed in the Project root.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import List, Optional

PROJECT_PYTHON_ENV = "WITWIN_PROJECT_PYTHON"
PROJECT_DIR_ENV = "WITWIN_PROJECT_DIR"
PROJECT_VENV_DIRNAME = ".venv"
HOSTED_ENV = "WITWIN_HOSTED"


def hosted() -> bool:
    """True on a ProjectServer that shares its machine with other users' Projects."""
    return os.environ.get(HOSTED_ENV, "").strip().lower() in {"1", "true", "yes", "on"}


def venv_interpreter(prefix: Path) -> Path:
    """The interpreter path inside a virtual environment folder."""
    if os.name == "nt":
        return Path(prefix) / "Scripts" / "python.exe"
    return Path(prefix) / "bin" / "python"


def project_venv(project_dir: Path) -> Optional[Path]:
    """``<project>/.venv`` when it holds an interpreter.

    ``pyvenv.cfg`` is not required: Script and Run launches have always used
    any ``.venv`` interpreter, and every launcher must agree on it.
    """
    prefix = Path(project_dir) / PROJECT_VENV_DIRNAME
    return prefix if venv_interpreter(prefix).is_file() else None


def project_venv_python(project_dir: Path) -> Optional[Path]:
    """``<project>/.venv``'s interpreter, or None when there is none."""
    venv = project_venv(project_dir)
    return venv_interpreter(venv) if venv is not None else None


def default_project_dir() -> Path:
    """``WITWIN_PROJECT_DIR`` (set by the ProjectServer), else the current folder."""
    return Path(os.environ.get(PROJECT_DIR_ENV) or ".")


def project_python(project_dir: Optional[Path] = None) -> str:
    """The interpreter that runs this Project's code (see the module docstring)."""
    if hosted():
        return sys.executable
    explicit = os.environ.get(PROJECT_PYTHON_ENV, "").strip()
    if explicit and Path(explicit).is_file():
        return str(Path(explicit))
    venv = project_venv_python(Path(project_dir) if project_dir is not None else default_project_dir())
    return str(venv) if venv is not None else sys.executable


def run_sys_path(project_root: Path, script: Path) -> List[str]:
    """``sys.path`` entries a Script or Run gets in front of its own.

    Runs use ``python -I``, which leaves the script's folder off ``sys.path``.
    ``python scripts/x.py`` typed in the Project root puts that folder first;
    the run does the same and adds the Project root after it, so a script can
    import sibling helpers and ``src/<name>`` alike.
    """
    out: List[str] = []
    for entry in (Path(script).resolve().parent, Path(project_root).resolve()):
        if str(entry) not in out:
            out.append(str(entry))
    return out
