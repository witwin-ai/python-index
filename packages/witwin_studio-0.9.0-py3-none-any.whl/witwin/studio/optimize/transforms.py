"""Generic transforms of tensor design variables (plan §5.4): density filter and tanh projection.

These are the two steps density-based topology optimization puts between the
raw design field and the physics, written as plain torch operations so the
gradient flows through them. They know nothing about any solver.

- ``density_filter(x, radius)``: each cell becomes the weighted mean of the
  cells within ``radius`` (in cells), weights ``radius - distance`` (a cone).
  Near the border only cells inside the array count, so a constant field
  stays constant. 1 to 3 dimensions. ``radius <= 1`` changes nothing.
- ``tanh_projection(x, beta, eta)``: pushes values in [0, 1] towards 0 or 1
  around the threshold ``eta``; ``beta`` sets how sharp (``beta -> 0`` is the
  identity, large ``beta`` a step). 0 maps to 0 and 1 to 1 for every ``beta``.

A Study declares them per tensor as an ordered list (``tensors.<id>.transforms``,
see ``_tensors``); ``TransformChain`` applies that list. The chain works on the
tensor scaled to [0, 1] by its ``lower`` / ``upper`` and scales the result
back, so a projection threshold ``eta = 0.5`` means "half way between the
bounds" whatever the units.

Beta continuation: a projection with ``every = N > 0`` multiplies ``beta`` by
``factor`` (default 2) at steps ``N + 1``, ``2N + 1``, ... up to ``beta_max``.
The current ``beta`` is state of the run: it is in each step's record and in
the checkpoint, and a resumed run continues from it.
"""
from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

__all__ = ["DensityFilter", "TanhProjection", "TransformChain", "density_filter", "tanh_projection"]


def density_filter(x: Any, radius: float) -> Any:
    """Cone-kernel filter of a 1-3 D tensor; ``radius`` in cells. See the module doc."""
    return DensityFilter(radius)(x)


def tanh_projection(x: Any, beta: float, eta: float = 0.5) -> Any:
    """``(tanh(beta*eta) + tanh(beta*(x - eta))) / (tanh(beta*eta) + tanh(beta*(1 - eta)))``."""
    import torch

    beta = float(beta)
    num = math.tanh(beta * eta) + torch.tanh(beta * (x - eta))
    return num / (math.tanh(beta * eta) + math.tanh(beta * (1.0 - eta)))


class DensityFilter:
    """``density_filter`` with its kernel and border weights cached per shape."""

    def __init__(self, radius: float) -> None:
        self.radius = float(radius)
        self.reach = max(0, math.ceil(self.radius) - 1)  # cells with radius - distance > 0
        self._cache: dict[tuple[Any, ...], tuple[Any, Any]] = {}

    def __call__(self, x: Any) -> Any:
        if self.reach == 0:
            return x
        import torch.nn.functional as F

        dims = x.dim()
        if not 1 <= dims <= 3:
            raise ValueError(f"the density filter takes 1 to 3 dimensions, not {dims}")
        kernel, weight = self._weights(tuple(x.shape), x.dtype, x.device)
        conv = (F.conv1d, F.conv2d, F.conv3d)[dims - 1]
        out = conv(x.reshape(1, 1, *x.shape), kernel, padding=self.reach)
        return out.reshape(x.shape) / weight

    # The cone kernel and, per cell, the sum of the kernel weights that fall inside the array.
    def _weights(self, shape: tuple[int, ...], dtype: Any, device: Any) -> tuple[Any, Any]:
        key = (shape, dtype, device)
        if key not in self._cache:
            import torch
            import torch.nn.functional as F

            dims, reach = len(shape), self.reach
            axis = torch.arange(-reach, reach + 1, dtype=dtype, device=device)
            grids = torch.meshgrid(*([axis] * dims), indexing="ij")
            distance = torch.sqrt(sum(g * g for g in grids))
            kernel = torch.clamp(self.radius - distance, min=0.0).reshape(1, 1, *([2 * reach + 1] * dims))
            conv = (F.conv1d, F.conv2d, F.conv3d)[dims - 1]
            ones = torch.ones(1, 1, *shape, dtype=dtype, device=device)
            weight = conv(ones, kernel, padding=reach).reshape(shape)
            self._cache[key] = (kernel, weight)
        return self._cache[key]


class TanhProjection:
    """``tanh_projection`` with beta continuation (``advance``)."""

    def __init__(self, beta: float = 1.0, eta: float = 0.5, beta_max: float | None = None,
                 every: int = 0, factor: float = 2.0) -> None:
        self.beta = float(beta)
        self.eta = float(eta)
        self.beta_max = float(beta if beta_max is None else beta_max)
        self.every = int(every)
        self.factor = float(factor)

    def __call__(self, x: Any) -> Any:
        return tanh_projection(x, self.beta, self.eta)

    def advance(self, step: int) -> None:
        """Called once before step ``step`` (from 1) is evaluated; raises beta on schedule."""
        if self.every > 0 and step > 1 and (step - 1) % self.every == 0:
            self.beta = min(self.beta * self.factor, self.beta_max)


class TransformChain:
    """The ordered transforms of one tensor, from its record entries (``_tensors.check_tensor``)."""

    def __init__(self, specs: Sequence[Mapping[str, Any]], lower: float = 0.0, upper: float = 1.0) -> None:
        self.lower = float(lower)
        self.upper = float(upper)
        self.steps: list[DensityFilter | TanhProjection] = []
        for spec in specs:
            if spec["kind"] == "filter":
                self.steps.append(DensityFilter(spec["radius"]))
            else:
                self.steps.append(TanhProjection(spec.get("beta", 1.0), spec.get("eta", 0.5),
                                                 spec.get("beta_max"), spec.get("every", 0),
                                                 spec.get("factor", 2.0)))

    def __bool__(self) -> bool:
        return bool(self.steps)

    def __call__(self, x: Any) -> Any:
        if not self.steps:
            return x
        span = self.upper - self.lower
        u = (x - self.lower) / span
        for step in self.steps:
            u = step(u)
        return self.lower + span * u

    @property
    def beta(self) -> float | None:
        """The last projection's current beta; None without a projection."""
        projections = [s for s in self.steps if isinstance(s, TanhProjection)]
        return projections[-1].beta if projections else None

    def advance(self, step: int) -> None:
        for item in self.steps:
            if isinstance(item, TanhProjection):
                item.advance(step)

    # Every projection's beta, for the checkpoint.
    def state_dict(self) -> list[float]:
        return [s.beta for s in self.steps if isinstance(s, TanhProjection)]

    def load_state_dict(self, betas: Sequence[float]) -> None:
        projections = [s for s in self.steps if isinstance(s, TanhProjection)]
        for projection, beta in zip(projections, betas):
            projection.beta = float(beta)
