"""The gradient method's design variables: optimizer leaves, physical values, bounds (plan §5.3-5.5).

``DesignVariables`` holds one torch leaf per scalar design variable and one
per tensor design variable, and maps them to the physical values the
objective sees. Three bound modes:

- ``clamp``: the leaf is the physical value; ``clamp_`` puts it back into
  ``[lower, upper]`` after each optimizer step (projected gradient).
- ``sigmoid``: a variable with both bounds is ``lower + (upper - lower) *
  sigmoid(z)`` with an unbounded leaf ``z``, so the optimizer (L-BFGS in
  particular) never meets a bound and its curvature history stays valid.
  The bound itself is only reached in the limit; a start value on a bound is
  moved 1e-6 of the range inside it, where the gradient through the sigmoid
  is tiny, so start inside the range. A variable with one bound or none is
  used as it is and clamped like ``clamp``.
- ``box`` (MMA): the leaf is the physical value and every variable has both
  bounds; MMA reads and writes all of them as one vector in [0, 1]^n
  (``unit_vector`` / ``set_unit_vector``).

Tensors then go through their transforms (``transforms.TransformChain``)
before the objective sees them (``transformed``).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from ..studies._errors import ErrorCode, StudyError, invalid
from ._space import DesignSpace
from ._tensors import design_tensor_path, load_array
from .transforms import TransformChain

CLAMP = "clamp"
SIGMOID = "sigmoid"
BOX = "box"
# Start values on a bound move this fraction of the range inside it under ``sigmoid``.
_SIGMOID_EDGE = 1e-6


class DesignVariables:
    """Leaves and physical values of one gradient run's scalars and tensors."""

    def __init__(self, torch: Any, space: DesignSpace, specs: Mapping[str, Mapping[str, Any]],
                 start: Mapping[str, Any], mode: str) -> None:
        self._torch = torch
        self.space = space
        self.specs = {key: dict(spec) for key, spec in specs.items()}
        self.mode = mode
        # key -> (lower, upper); keys are "s:<name>" for scalars, "t:<id>" for tensors.
        self._bounds: dict[str, tuple[float | None, float | None]] = {}
        self._leaves: dict[str, Any] = {}
        for v in space.variables:
            self._add(f"s:{v.name}", torch.tensor(float(v.value), dtype=torch.float64), v.lower, v.upper)
        for tensor_id, spec in self.specs.items():
            self._add(f"t:{tensor_id}", start[tensor_id], spec["lower"], spec["upper"])
        self.chains = {tensor_id: TransformChain(spec.get("transforms", ()), spec["lower"], spec["upper"])
                       for tensor_id, spec in self.specs.items()}

    def _add(self, key: str, value: Any, lower: float | None, upper: float | None) -> None:
        self._bounds[key] = (lower, upper)
        value = value.detach().to(self._torch.float64).clone()
        if lower is not None or upper is not None:
            value = value.clamp(min=lower, max=upper)
        self._leaves[key] = self._raw(key, value).requires_grad_(True)

    # ---------------------------------------------------------------- views
    def leaves(self) -> list[Any]:
        """The tensors the optimizer steps, scalars first, in a fixed order."""
        return list(self._leaves.values())

    @property
    def keys(self) -> list[str]:
        return list(self._leaves)

    def scalars(self) -> dict[str, Any]:
        """Scalar name -> physical value (a 0-d tensor with gradient)."""
        return {key[2:]: self._physical(key) for key in self._leaves if key.startswith("s:")}

    def tensors(self) -> dict[str, Any]:
        """Tensor id -> physical value before transforms."""
        return {key[2:]: self._physical(key) for key in self._leaves if key.startswith("t:")}

    def transformed(self) -> dict[str, Any]:
        """Tensor id -> what the objective sees: the physical value through its transforms."""
        return {tensor_id: self.chains[tensor_id](value) for tensor_id, value in self.tensors().items()}

    def values(self) -> dict[str, float]:
        """Scalar name -> physical value as a float."""
        with self._torch.no_grad():
            return {name: float(value.item()) for name, value in self.scalars().items()}

    def tensor_arrays(self) -> dict[str, Any]:
        """Tensor id -> detached copy of the physical value before transforms."""
        with self._torch.no_grad():
            return {tensor_id: value.detach().clone() for tensor_id, value in self.tensors().items()}

    def grad_norm(self) -> float:
        """Norm of the gradient on the physical values, from the leaves' ``.grad``.

        Under ``sigmoid`` a leaf's gradient is ``dL/dz = dL/dx * dx/dz``; it is
        divided back by ``dx/dz``, so the number means the same in every mode.
        Where ``dx/dz`` underflows to 0 (far on a bound) that element counts 0.
        """
        torch = self._torch
        total = 0.0
        with torch.no_grad():
            for key, leaf in self._leaves.items():
                grad = leaf.grad
                if grad is None:
                    continue
                if self._squashed(key):
                    lower, upper = self._bounds[key]
                    s = torch.sigmoid(leaf)
                    slope = (upper - lower) * s * (1.0 - s)
                    grad = torch.where(slope > 0, grad / torch.where(slope > 0, slope, 1.0), 0.0)
                total += float((grad * grad).sum())
        return total ** 0.5

    def betas(self) -> dict[str, float]:
        """Tensor id -> its last projection's current beta (tensors with a projection only)."""
        return {tensor_id: chain.beta for tensor_id, chain in self.chains.items() if chain.beta is not None}

    def advance(self, step: int) -> None:
        """Beta continuation of every projection, before step ``step`` is evaluated."""
        for chain in self.chains.values():
            chain.advance(step)

    # ---------------------------------------------------------------- updates
    def clamp_(self) -> None:
        """Put clamped variables back into their bounds (every mode but sigmoid's bounded ones)."""
        with self._torch.no_grad():
            for key, leaf in self._leaves.items():
                lower, upper = self._bounds[key]
                if (lower is None and upper is None) or self._squashed(key):
                    continue
                leaf.clamp_(min=lower, max=upper)

    def unit_vector(self) -> Any:
        """``box`` mode: every variable scaled to [0, 1] by its bounds, as one flat vector."""
        torch = self._torch
        with torch.no_grad():
            parts = []
            for key, leaf in self._leaves.items():
                lower, upper = self._bounds[key]
                parts.append(((leaf - lower) / (upper - lower)).reshape(-1))
            return torch.cat(parts) if parts else torch.zeros(0, dtype=torch.float64)

    def set_unit_vector(self, u: Any) -> None:
        """``box`` mode: the inverse of ``unit_vector``."""
        offset = 0
        with self._torch.no_grad():
            for key, leaf in self._leaves.items():
                lower, upper = self._bounds[key]
                n = leaf.numel()
                leaf.copy_((lower + (upper - lower) * u[offset:offset + n]).reshape(leaf.shape))
                offset += n

    def unit_spans(self) -> Any:
        """``box`` mode: d(physical)/d(unit) per element, to turn gradients into unit coordinates."""
        torch = self._torch
        parts = [torch.full((leaf.numel(),), float(self._bounds[key][1] - self._bounds[key][0]),
                            dtype=torch.float64) for key, leaf in self._leaves.items()]
        return torch.cat(parts) if parts else torch.zeros(0, dtype=torch.float64)

    def unbounded(self) -> list[str]:
        """Names of variables without both bounds (MMA refuses them)."""
        return [key[2:] for key, (lower, upper) in self._bounds.items() if lower is None or upper is None]

    # ---------------------------------------------------------------- checkpoint
    def raw_state(self) -> dict[str, Any]:
        """key -> detached copy of each leaf (the optimizer's own variables)."""
        return {key: leaf.detach().clone() for key, leaf in self._leaves.items()}

    def load_raw_state(self, raw: Mapping[str, Any]) -> None:
        with self._torch.no_grad():
            for key, leaf in self._leaves.items():
                leaf.copy_(raw[key])

    def set_physical(self, values: Mapping[str, float], tensors: Mapping[str, Any]) -> None:
        """Move every leaf so the physical values become ``values`` / ``tensors`` (resume across modes)."""
        with self._torch.no_grad():
            for key, leaf in self._leaves.items():
                kind, name = key[0], key[2:]
                target = (self._torch.tensor(float(values[name]), dtype=self._torch.float64) if kind == "s"
                          else tensors[name].to(self._torch.float64))
                leaf.copy_(self._raw(key, target))

    def shapes(self) -> dict[str, list[int]]:
        """Tensor id -> shape, for checking a checkpoint against the Study."""
        return {key[2:]: list(leaf.shape) for key, leaf in self._leaves.items() if key.startswith("t:")}

    # ---------------------------------------------------------------- mapping
    # True when the leaf is an unbounded z mapped through a sigmoid.
    def _squashed(self, key: str) -> bool:
        lower, upper = self._bounds[key]
        return self.mode == SIGMOID and lower is not None and upper is not None

    def _physical(self, key: str) -> Any:
        leaf = self._leaves[key]
        if not self._squashed(key):
            return leaf
        lower, upper = self._bounds[key]
        return lower + (upper - lower) * self._torch.sigmoid(leaf)

    # The leaf value that maps to the physical ``value``.
    def _raw(self, key: str, value: Any) -> Any:
        if not self._squashed(key):
            return value.detach().clone()
        lower, upper = self._bounds[key]
        fraction = ((value - lower) / (upper - lower)).clamp(_SIGMOID_EDGE, 1.0 - _SIGMOID_EDGE)
        return self._torch.logit(fraction).detach()


def start_tensors(torch: Any, specs: Mapping[str, Mapping[str, Any]], project_root: Path | None,
                  seed: int) -> dict[str, Any]:
    """Tensor id -> start value: ``assets/design/<id>.npy`` when it exists, else its ``init``.

    Raises ``invalid_study`` for ``init = "file"`` without the file and for a
    file whose shape is not the declared one, ``dependency_missing`` without
    numpy (the Project files are ``.npy``).
    """
    if not specs:
        return {}
    try:
        import numpy  # noqa: F401 - needed for the .npy files
    except ImportError:
        raise StudyError(ErrorCode.DEPENDENCY_MISSING,
                                "tensor design variables need numpy; install it in this environment") from None
    generator = torch.Generator().manual_seed(int(seed))
    out = {}
    for tensor_id, spec in specs.items():
        shape = tuple(spec["shape"])
        path = design_tensor_path(project_root, tensor_id) if project_root is not None else None
        if path is not None and path.is_file():
            array = load_array(path)
            if tuple(array.shape) != shape:
                raise invalid(f"assets/design/{tensor_id}.npy has shape {tuple(array.shape)}, "
                              f"but the study declares {shape}")
            value = torch.from_numpy(array)
        elif spec["init"] == "file":
            raise invalid(f"tensor '{tensor_id}' starts from assets/design/{tensor_id}.npy, "
                          "which is not in the Project")
        elif spec["init"] == "random":
            lower, upper = spec["lower"], spec["upper"]
            value = lower + (upper - lower) * torch.rand(shape, generator=generator, dtype=torch.float64)
        else:
            fill = {"zeros": 0.0, "ones": 1.0}.get(spec["init"], spec["value"])
            value = torch.full(shape, float(fill), dtype=torch.float64)
        out[tensor_id] = value.clamp(min=spec["lower"], max=spec["upper"])
    return out


def tensor_stats(torch: Any, value: Any) -> dict[str, float]:
    """``{min, max, mean}`` of a tensor, for step records."""
    with torch.no_grad():
        return {"min": float(value.min()), "max": float(value.max()), "mean": float(value.mean())}
