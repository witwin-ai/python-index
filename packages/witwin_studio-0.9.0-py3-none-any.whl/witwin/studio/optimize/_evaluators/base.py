"""The batch evaluation interface ``BatchDriver`` calls (plan §6).

A black-box method's batch is a set of independent points, so it can be
evaluated in any order and in parallel. ``Evaluator.evaluate_batch`` hides
how: the local serial evaluator and the local process pool ship here; a
Fleet (cloud) evaluator would plug in through ``make_evaluator`` too.

Contract: outcomes come back in the order of ``points``. When ``should_stop``
turns true (a stop request, or ``budget.max_time_s`` ran out) the evaluator
stops starting new points and returns the outcomes of a prefix of
``points``; the driver tells the strategy only that prefix.

``on_done(position, outcome)``, when given, is called as each point
finishes, in the order they finish (``position`` indexes ``points``), so the
run can report progress inside a slow batch. It runs in the calling
process and thread.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Mapping, Protocol, Sequence

if TYPE_CHECKING:
    from .._evaluate import Outcome
    from .._objectives import ObjectiveFn
    from .._scene import Scene
    from ...studies._model import Budget, Study


OnDone = Callable[[int, "Outcome"], None]


class Evaluator(Protocol):
    def evaluate_batch(self, points: Sequence[Mapping[str, float]], indexes: Sequence[int], *,
                       should_stop: Callable[[], bool] | None = None,
                       on_done: OnDone | None = None) -> list["Outcome"]:
        """Evaluate ``points``; ``indexes`` are their evaluation indexes (``ctx.step``)."""
        ...

    def close(self) -> None:
        """Release workers; called once when the run ends."""
        ...


@dataclass(frozen=True)
class EvaluatorSetup:
    """What ``make_evaluator`` receives.

    ``scene``, ``fn`` and ``project_root`` serve an in-process evaluator.
    ``project_dir`` / ``scene_id`` / ``study`` let a process pool load the
    same Project, Scene and objective in each worker (None when the run did
    not come from a saved Scene, e.g. ``optimize.run`` with an objective
    function; then only in-process evaluation is possible).
    """
    scene: "Scene"
    fn: "ObjectiveFn"
    project_root: Path | None
    budget: "Budget"
    study: "Study"
    project_dir: Path | None = None
    scene_id: str | None = None
    # Dataset runs: ``{"staging", "seed", "variables"}``, the ``SampleExport`` a worker
    # wraps its rebuilt export function in (``setup.fn`` is already wrapped).
    sample: dict | None = None
