"""Local process pool evaluator: ``budget.parallel = N > 1`` points at once (plan §6).

Workers are ``spawn`` processes, on every platform, so nothing relies on
``fork``: each one receives a picklable ``WorkerJob`` (the Scene document, the
Project root and the Study's objective reference), builds the Scene,
resolves the objective once and then evaluates one point per message until
it is told to stop. Workers start when a batch first needs them (at most
``min(N, batch size)``), so a method that asks one point at a time does not
pay for N Project loads.

The parent hands each idle worker the next point of the batch in order and
waits on every pipe and process handle at once
(``multiprocessing.connection.wait``, which works on Windows pipes too).
Outcomes come back in the order of ``points``, each with the worker id
(1..N) and the ``duration_s`` the worker measured.

Failures:

- the objective raises: the worker records a failed ``Outcome`` exactly as
  the serial evaluator does, and keeps going;
- the worker process dies (``os._exit``, a segfault, out of memory): its
  in-flight point becomes a failed ``Outcome`` (``objective_failed``, with
  the exit code) and the slot gets a new worker; ``Study.on_error`` then
  decides as for any failed evaluation;
- a worker cannot start (it dies or the Scene/objective fails to load in
  it): that slot is given up and logged. When no slot is left, the rest of
  the run is evaluated in this process (``SerialEvaluator``), so a broken
  pool slows the run down but never loses it.

Stop: once ``should_stop`` is true no new point is handed out; points in
flight get ``DRAIN_GRACE_S`` to finish, then their workers are terminated
and those points are dropped (the driver keeps the finished prefix). This
fits inside the ProjectServer's ``STOP_GRACE`` (10 s) with time left to
write ``optimization.json``. KeyboardInterrupt, or any other exception,
terminates every worker before it propagates.

Workers ignore SIGINT and SIGBREAK: Ctrl+C / Ctrl+Break reach the whole
console process group, and the parent decides what happens to its workers.

A script that calls ``optimize.run`` with ``parallel > 1`` must guard its
top level with ``if __name__ == "__main__":``; ``spawn`` imports the main
module again in each worker (standard ``multiprocessing`` rule). Without the
guard the workers fail to start and the run falls back to this process.
"""
from __future__ import annotations

import logging
import multiprocessing
import signal
import time
from dataclasses import dataclass
from multiprocessing.connection import Connection, wait
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ...studies._errors import ErrorCode, StudyError
from .._evaluate import Outcome
from .._records import EvalStatus
from .base import EvaluatorSetup, OnDone
from .serial import SerialEvaluator

logger = logging.getLogger("witwin.studio")

# Seconds in-flight points get to finish after a stop; below the server's STOP_GRACE (10 s).
DRAIN_GRACE_S = 5.0
# Seconds between should_stop checks while every worker is busy.
POLL_S = 0.1
# Seconds close() waits for an idle worker to exit before terminating it.
CLOSE_WAIT_S = 2.0


@dataclass(frozen=True)
class WorkerJob:
    """What every worker receives once; only plain data, so it pickles under ``spawn``.

    ``document`` is ``Scene.to_document()`` of the run's Scene, so a worker
    sees the Scene as the run saw it, including edits not saved yet.
    ``scene_path`` lets the Scene find its mesh files. ``objective`` is
    ``ObjectiveRef.to_dict()``.
    """
    document: dict[str, Any]
    scene_path: str | None
    project_root: str | None
    objective: dict[str, Any]
    sample: dict[str, Any] | None = None  # EvaluatorSetup.sample


def can_pool(setup: EvaluatorSetup) -> bool:
    """True when a worker can rebuild the run's objective from the Study.

    ``setup.project_dir`` is None when the run got an objective function in
    code (``optimize.run(objective=...)``): a function cannot be sent to a
    ``spawn`` process.
    """
    return setup.project_dir is not None and setup.study.objective is not None


class ProcessPoolEvaluator:
    """``Evaluator`` that runs a batch on up to ``budget.parallel`` worker processes."""

    def __init__(self, setup: EvaluatorSetup, *, drain_grace_s: float = DRAIN_GRACE_S) -> None:
        self._setup = setup
        self._size = setup.budget.parallel
        self._drain_grace_s = drain_grace_s
        self._context = multiprocessing.get_context("spawn")
        self._job = WorkerJob(setup.scene.to_document(),
                              None if setup.scene.path is None else str(setup.scene.path),
                              None if setup.project_root is None else str(setup.project_root),
                              setup.study.objective.to_dict(), setup.sample)
        self._slots: list[_Slot] = [_Slot(i + 1) for i in range(self._size)]
        self._fallback: SerialEvaluator | None = None
        self._on_done: OnDone | None = None  # the current batch's, while evaluate_batch runs

    def evaluate_batch(self, points: Sequence[Mapping[str, float]], indexes: Sequence[int], *,
                       should_stop: Callable[[], bool] | None = None,
                       on_done: OnDone | None = None) -> list[Outcome]:
        self._on_done = on_done
        try:
            return self._evaluate(points, indexes, should_stop or (lambda: False))
        except BaseException:
            self._terminate_all()
            raise
        finally:
            self._on_done = None

    def close(self) -> None:
        for slot in self._slots:
            if slot.process is not None and slot.process.is_alive() and slot.task is None:
                try:
                    slot.conn.send(None)
                except OSError:
                    pass
        deadline = time.monotonic() + CLOSE_WAIT_S
        for slot in self._slots:
            if slot.process is not None:
                slot.process.join(max(0.0, deadline - time.monotonic()))
        self._terminate_all()
        if self._fallback is not None:
            self._fallback.close()

    # ------------------------------------------------------------------ batch loop
    def _evaluate(self, points: Sequence[Mapping[str, float]], indexes: Sequence[int],
                  should_stop: Callable[[], bool]) -> list[Outcome]:
        count = len(points)
        outcomes: list[Outcome | None] = [None] * count
        handed = 0  # points[:handed] went to a worker (or the fallback)
        stopping_at: float | None = None
        self._start(min(self._size, count))
        while True:
            # The first point always runs, as in SerialEvaluator, so a batch always makes progress.
            if stopping_at is None and handed > 0 and should_stop():
                stopping_at = time.monotonic()
            for slot in self._slots:
                if stopping_at is not None or handed >= count:
                    break
                if not slot.idle:
                    continue
                if handed > 0 and should_stop():
                    stopping_at = time.monotonic()
                    break
                slot.hand(handed, points[handed], indexes[handed])
                handed += 1
            busy = [slot for slot in self._slots if slot.task is not None]
            if not any(slot.alive for slot in self._slots) and stopping_at is None and handed < count:
                handed = self._run_here(points, indexes, outcomes, handed, should_stop)
                busy = []
            if not busy and (handed >= count or stopping_at is not None):
                break
            if stopping_at is not None and time.monotonic() - stopping_at >= self._drain_grace_s:
                for slot in busy:
                    logger.warning("stopping: worker %d did not finish evaluation %d within %.0f s; "
                                   "terminating it", slot.id, indexes[slot.task], self._drain_grace_s)
                    slot.terminate()
                break
            self._wait(outcomes, indexes)
        done = []
        for outcome in outcomes:  # the finished prefix (a terminated point ends it)
            if outcome is None:
                break
            done.append(outcome)
        return done

    # Wait up to POLL_S for any worker message or exit, and handle what arrived.
    def _wait(self, outcomes: list[Outcome | None], indexes: Sequence[int]) -> None:
        live = [slot for slot in self._slots if slot.process is not None]
        handles: list[Any] = [slot.conn for slot in live] + [slot.process.sentinel for slot in live]
        if not handles:
            time.sleep(POLL_S)
            return
        ready = set(wait(handles, timeout=POLL_S))
        for slot in live:
            if slot.conn in ready or slot.process.sentinel in ready:
                self._read(slot, outcomes)
                if slot.process is not None and not slot.process.is_alive():
                    self._died(slot, outcomes, indexes)

    # Every message a worker has sent so far.
    def _read(self, slot: "_Slot", outcomes: list[Outcome | None]) -> None:
        try:
            while slot.conn is not None and slot.conn.poll():
                message = slot.conn.recv()
                kind = message[0]
                if kind == "ready":
                    slot.ready = True
                elif kind == "done":
                    self._finished(outcomes, slot.task, _outcome(message[1], slot.id))
                    slot.task = None
                elif kind == "init_failed":
                    logger.warning("worker %d could not start: %s", slot.id, message[1]["message"])
                    slot.give_up(message[1]["message"])
        except (EOFError, OSError):
            pass  # the process ended; _died handles it

    # A worker process ended without being asked to.
    def _died(self, slot: "_Slot", outcomes: list[Outcome | None], indexes: Sequence[int]) -> None:
        code = slot.process.exitcode
        if slot.task is not None:
            message = f"worker {slot.id} exited with code {code} while evaluating this point"
            logger.warning("evaluation %d: %s", indexes[slot.task], message)
            self._finished(outcomes, slot.task, Outcome(
                None, EvalStatus.FAILED, {}, time.monotonic() - slot.handed_at,
                StudyError(ErrorCode.OBJECTIVE_FAILED, message), worker=slot.id))
            slot.task = None
        if not slot.ready:
            logger.warning("worker %d exited with code %s before it was ready", slot.id, code)
            slot.give_up(f"exited with code {code} before it was ready")
            return
        slot.reap()
        slot.start(self._context, self._job)  # a fresh worker for the next point

    # No worker is left: evaluate the rest of the batch in this process.
    def _run_here(self, points: Sequence[Mapping[str, float]], indexes: Sequence[int],
                  outcomes: list[Outcome | None], handed: int,
                  should_stop: Callable[[], bool]) -> int:
        if self._fallback is None:
            reasons = "; ".join(sorted({slot.reason for slot in self._slots if slot.reason}))
            logger.warning("no worker process could start (%s); evaluating in this process",
                           reasons or "unknown reason")
            self._fallback = SerialEvaluator(self._setup)
        rest = list(range(handed, len(points)))
        self._fallback.evaluate_batch(
            [points[p] for p in rest], [indexes[p] for p in rest], should_stop=should_stop,
            on_done=lambda k, outcome: self._finished(outcomes, rest[k], outcome))
        return len(points)

    # Keep one finished point's outcome and pass it to the batch's on_done.
    def _finished(self, outcomes: list[Outcome | None], position: int, outcome: Outcome) -> None:
        outcomes[position] = outcome
        if self._on_done is not None:
            self._on_done(position, outcome)

    # Start workers in empty slots until ``wanted`` slots have one (given-up slots stay empty).
    def _start(self, wanted: int) -> None:
        for slot in self._slots:
            if sum(slot.alive for slot in self._slots) >= wanted:
                return
            if slot.process is None and not slot.given_up:
                slot.start(self._context, self._job)

    def _terminate_all(self) -> None:
        for slot in self._slots:
            slot.terminate()


class _Slot:
    """One worker position, id 1..N; a crashed worker is replaced in the same slot."""

    def __init__(self, worker_id: int) -> None:
        self.id = worker_id
        self.process: Any = None
        self.conn: Connection | None = None
        self.ready = False  # the current process loaded the objective; tells a crash from a start failure
        self.task: int | None = None  # batch position in flight
        self.handed_at = 0.0
        self.given_up = False
        self.reason: str | None = None

    @property
    def alive(self) -> bool:
        return self.process is not None and not self.given_up

    @property
    def idle(self) -> bool:
        return self.process is not None and self.ready and self.task is None and not self.given_up

    def start(self, context: Any, job: WorkerJob) -> None:
        parent, child = context.Pipe()
        self.process = context.Process(target=worker_main, args=(self.id, job, child),
                                       name=f"witwin-optimize-worker-{self.id}", daemon=True)
        self.process.start()
        child.close()  # only the worker holds this end, so its exit shows as EOF here
        self.conn = parent
        self.ready = False

    def hand(self, position: int, values: Mapping[str, float], index: int) -> None:
        self.task = position
        self.handed_at = time.monotonic()
        self.conn.send((index, {name: float(v) for name, v in values.items()}))

    def give_up(self, reason: str) -> None:
        self.given_up = True
        self.reason = reason
        self.terminate()

    def reap(self) -> None:
        if self.process is not None:
            self.process.join(0.5)
        if self.conn is not None:
            self.conn.close()
        self.process, self.conn = None, None
        self.ready = False

    def terminate(self) -> None:
        if self.process is not None and self.process.is_alive():
            self.process.terminate()
            self.process.join(1.0)
            if self.process.is_alive():
                self.process.kill()
                self.process.join(1.0)
        self.task = None
        self.reap()


# ---------------------------------------------------------------------- worker side
def worker_main(worker_id: int, job: WorkerJob, conn: Connection) -> None:
    """Worker process body: load once, then evaluate ``(index, values)`` messages until None or EOF."""
    for name in ("SIGINT", "SIGBREAK"):
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), signal.SIG_IGN)
    try:
        point = _load(job, worker_id)
    except Exception as exc:  # noqa: BLE001 - reported to the parent, which gives the slot up
        error = exc if isinstance(exc, StudyError) else StudyError(
            ErrorCode.INTERNAL, f"{type(exc).__name__}: {exc}")
        _send(conn, ("init_failed", error.to_dict()))
        return
    if not _send(conn, ("ready", worker_id)):
        return
    while True:
        try:
            message = conn.recv()
        except (EOFError, OSError):
            return  # the parent is gone
        if message is None:
            return
        index, values = message
        if not _send(conn, ("done", _wire(point.evaluate(values, index)))):
            return


# The Scene and objective of the job, as a PointEvaluator.
def _load(job: WorkerJob, worker_id: int) -> Any:
    from ..._scene import Scene
    from .._evaluate import PointEvaluator
    from .._objectives import resolve
    from ...studies._model import ObjectiveRef

    root = None if job.project_root is None else Path(job.project_root)
    scene = Scene(job.document, None if job.scene_path is None else Path(job.scene_path))
    fn = resolve(ObjectiveRef.from_dict(job.objective), root)
    if job.sample is not None:
        from ...datasets._writer import SampleExport

        fn = SampleExport(fn, **job.sample)
    return PointEvaluator(scene, fn, root, worker=worker_id)


# Send one message; False when the parent is gone.
def _send(conn: Connection, message: Any) -> bool:
    try:
        conn.send(message)
        return True
    except (OSError, EOFError):
        return False


# An Outcome as plain data (an exception object may not survive pickling).
def _wire(outcome: Outcome) -> dict[str, Any]:
    return {"loss": outcome.loss, "status": str(outcome.status), "metrics": dict(outcome.metrics),
            "duration_s": outcome.duration_s,
            "error": None if outcome.error is None else outcome.error.to_dict()}


def _outcome(data: Mapping[str, Any], worker_id: int) -> Outcome:
    error = data.get("error")
    return Outcome(data["loss"], EvalStatus(data["status"]), dict(data["metrics"]),
                   float(data["duration_s"]),
                   None if error is None else StudyError(
                       ErrorCode(error["code"]), error["message"], **dict(error.get("data") or {})),
                   worker=worker_id)
