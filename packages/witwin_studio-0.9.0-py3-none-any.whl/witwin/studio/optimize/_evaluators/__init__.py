"""Evaluators: how a batch of points is evaluated (plan §6, phase M6).

``make_evaluator`` is the one place that picks an implementation:

- ``budget.parallel = 1``: ``SerialEvaluator``, one point after another in
  this process;
- ``budget.parallel = N > 1``: ``ProcessPoolEvaluator``, N ``spawn`` worker
  processes (``pool.py``). A run whose objective is a function passed in code
  (``optimize.run(objective=...)``) cannot be sent to a worker and stays
  serial, with a warning.

Only ``BatchDriver`` (black-box and explore methods) uses an evaluator. The
gradient method ignores ``parallel``: each step needs the previous one.

There is no Fleet (cloud) evaluator yet: a run process has no interface to
submit child Runs to the ProjectServer. The design and the missing interface
are in ``dev_docs/studies/parallel.md``.
"""
from __future__ import annotations

import logging

from .base import Evaluator, EvaluatorSetup
from .pool import ProcessPoolEvaluator, can_pool
from .serial import SerialEvaluator

logger = logging.getLogger("witwin.studio")

__all__ = ["Evaluator", "EvaluatorSetup", "ProcessPoolEvaluator", "SerialEvaluator", "make_evaluator"]


def make_evaluator(setup: EvaluatorSetup) -> Evaluator:
    """The evaluator for one run, chosen from ``setup.budget``."""
    if setup.budget.parallel > 1:
        if can_pool(setup):
            return ProcessPoolEvaluator(setup)
        logger.warning("budget.parallel = %d needs the Study's own objective; an objective "
                       "function passed in code runs one point at a time", setup.budget.parallel)
    return SerialEvaluator(setup)
