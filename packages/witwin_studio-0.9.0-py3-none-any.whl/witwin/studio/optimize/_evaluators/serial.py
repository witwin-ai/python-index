"""Local serial evaluator: one point after another in this process."""
from __future__ import annotations

from typing import Callable, Mapping, Sequence

from .._evaluate import Outcome, PointEvaluator
from .base import EvaluatorSetup, OnDone


class SerialEvaluator:
    """``Evaluator`` that calls the objective in this process, in order."""

    def __init__(self, setup: EvaluatorSetup) -> None:
        self._point = PointEvaluator(setup.scene, setup.fn, setup.project_root)

    def evaluate_batch(self, points: Sequence[Mapping[str, float]], indexes: Sequence[int], *,
                       should_stop: Callable[[], bool] | None = None,
                       on_done: OnDone | None = None) -> list[Outcome]:
        outcomes = []
        for position, (values, index) in enumerate(zip(points, indexes)):
            if outcomes and should_stop is not None and should_stop():
                break  # the first point always runs, so a batch always makes progress
            outcomes.append(self._point.evaluate(values, index))
            if on_done is not None:
                on_done(position, outcomes[-1])
        return outcomes

    def close(self) -> None:
        pass
