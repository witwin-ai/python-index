"""The Method of Moving Asymptotes (Svanberg 1987; the 2007 "MMA and GCMMA" notes), in torch.

Problem, in the gradient driver's normalized coordinates ``x`` in [0, 1]^n::

    minimize   f0(x)
    subject to fi(x) <= 0,   i = 1..m
               0 <= x <= 1

Each iteration builds a convex separable approximation of f0 and fi around
the current point from their values and gradients, bounded by the moving
asymptotes ``low < x < upp``, and solves it exactly with the primal-dual
interior-point method of Svanberg's ``subsolv``. The asymptotes widen when
a variable keeps moving the same way and shrink when it oscillates.

Constants follow Svanberg's recommendation for problems written as above:
``a0 = 1, a = 0, c = 1000, d = 1``. So a constraint that cannot be met is
violated at a large cost instead of making the subproblem infeasible. Scale
the objective to roughly 1..100 and constraints to roughly 1 at the start;
MMA's step does not depend on a learning rate, but it does on that scale.

``move`` limits each step to that fraction of the range (0.5 is Svanberg's
default; topology optimization often uses 0.2). Without constraints a dummy
constraint ``-1 <= 0`` is used, so the same code serves m = 0. One change
from Svanberg's constants: the asymptotes may come as close as ``ASYMIN``
(1e-4 of the range, not 0.01), see there.

The whole state (previous points, asymptotes, iteration) is in
``state_dict``, so a resumed run continues bit for bit.
"""
from __future__ import annotations

from typing import Any, Mapping

EPSIMIN = 1e-7
RAA0 = 1e-5
ALBEFA = 0.1
ASYINIT = 0.5
ASYINCR = 1.2
ASYDECR = 0.7
# Closest the asymptotes may come to x, as a fraction of the range. Svanberg uses 0.01;
# then a variable whose optimum is inside its range cycles with a step of about 1 %
# of the range forever. 1e-4 lets those steps shrink until the variable settles.
ASYMIN = 1e-4
C_PENALTY = 1000.0


class MMA:
    """MMA iterations on one vector of ``n`` normalized variables."""

    def __init__(self, n: int, *, move: float = 0.5) -> None:
        import torch

        self._torch = torch
        self.n = n
        self.move = float(move)
        self.iteration = 0
        self.xold1: Any = None
        self.xold2: Any = None
        self.low: Any = None
        self.upp: Any = None

    def step(self, x: Any, f0: float, df0: Any, g: Any, dg: Any) -> Any:
        """The next point from the current one.

        ``x``: (n,) current point in [0, 1]. ``f0``: objective value;
        ``df0``: (n,) its gradient. ``g``: (m,) constraint values (<= 0 is
        feasible); ``dg``: (m, n) their gradients. m may be 0. All float64.
        """
        torch = self._torch
        x = x.detach().to(torch.float64)
        if g.numel() == 0:
            g = torch.tensor([-1.0], dtype=torch.float64)
            dg = torch.zeros(1, self.n, dtype=torch.float64)
        self.iteration += 1
        xmin = torch.zeros_like(x)
        xmax = torch.ones_like(x)
        low, upp = self._asymptotes(x, xmin, xmax)
        span = xmax - xmin
        alfa = torch.maximum(torch.maximum(low + ALBEFA * (x - low), x - self.move * span), xmin)
        beta = torch.minimum(torch.minimum(upp - ALBEFA * (upp - x), x + self.move * span), xmax)
        inv_span = 1.0 / torch.clamp(span, min=1e-5)
        ux2 = (upp - x) ** 2
        xl2 = (x - low) ** 2
        p0 = torch.clamp(df0, min=0.0)
        q0 = torch.clamp(-df0, min=0.0)
        pq0 = 0.001 * (p0 + q0) + RAA0 * inv_span
        p0 = (p0 + pq0) * ux2
        q0 = (q0 + pq0) * xl2
        P = torch.clamp(dg, min=0.0)
        Q = torch.clamp(-dg, min=0.0)
        PQ = 0.001 * (P + Q) + RAA0 * inv_span.unsqueeze(0)
        P = (P + PQ) * ux2.unsqueeze(0)
        Q = (Q + PQ) * xl2.unsqueeze(0)
        b = P @ (1.0 / (upp - x)) + Q @ (1.0 / (x - low)) - g
        m = g.numel()
        a = torch.zeros(m, dtype=torch.float64)
        c = torch.full((m,), C_PENALTY, dtype=torch.float64)
        d = torch.ones(m, dtype=torch.float64)
        xnew = _subsolv(torch, m, self.n, low, upp, alfa, beta, p0, q0, P, Q, 1.0, a, b, c, d)
        self.xold2 = self.xold1
        self.xold1 = x.clone()
        self.low, self.upp = low, upp
        return xnew

    # Asymptotes: a fixed distance at first, then widened or narrowed per variable.
    def _asymptotes(self, x: Any, xmin: Any, xmax: Any) -> tuple[Any, Any]:
        torch = self._torch
        span = xmax - xmin
        if self.iteration <= 2 or self.xold2 is None:
            return x - ASYINIT * span, x + ASYINIT * span
        trend = (x - self.xold1) * (self.xold1 - self.xold2)
        factor = torch.ones_like(x)
        factor[trend > 0] = ASYINCR
        factor[trend < 0] = ASYDECR
        low = x - factor * (self.xold1 - self.low)
        upp = x + factor * (self.upp - self.xold1)
        low = torch.minimum(torch.maximum(low, x - 10.0 * span), x - ASYMIN * span)
        upp = torch.minimum(torch.maximum(upp, x + ASYMIN * span), x + 10.0 * span)
        return low, upp

    def state_dict(self) -> dict[str, Any]:
        return {"iteration": self.iteration, "move": self.move, "xold1": self.xold1,
                "xold2": self.xold2, "low": self.low, "upp": self.upp}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        self.iteration = int(state["iteration"])
        for key in ("xold1", "xold2", "low", "upp"):
            setattr(self, key, state.get(key))


# Svanberg's subsolv: primal-dual Newton on the MMA subproblem; returns the new x.
def _subsolv(torch: Any, m: int, n: int, low: Any, upp: Any, alfa: Any, beta: Any, p0: Any, q0: Any,
             P: Any, Q: Any, a0: float, a: Any, b: Any, c: Any, d: Any) -> Any:
    een = torch.ones(n, dtype=torch.float64)
    eem = torch.ones(m, dtype=torch.float64)
    epsi = 1.0
    x = 0.5 * (alfa + beta)
    y = eem.clone()
    z = torch.tensor(1.0, dtype=torch.float64)
    lam = eem.clone()
    xsi = torch.maximum(een / (x - alfa), een)
    eta = torch.maximum(een / (beta - x), een)
    mu = torch.maximum(eem, 0.5 * c)
    zet = torch.tensor(1.0, dtype=torch.float64)
    s = eem.clone()

    def residual(x, y, z, lam, xsi, eta, mu, zet, s, epsi):
        ux1, xl1 = upp - x, x - low
        plam = p0 + P.T @ lam
        qlam = q0 + Q.T @ lam
        gvec = P @ (1.0 / ux1) + Q @ (1.0 / xl1)
        dpsidx = plam / ux1 ** 2 - qlam / xl1 ** 2
        return torch.cat([
            dpsidx - xsi + eta,
            c + d * y - mu - lam,
            (a0 - zet - a @ lam).reshape(1),
            gvec - a * z - y + s - b,
            xsi * (x - alfa) - epsi,
            eta * (beta - x) - epsi,
            mu * y - epsi,
            (zet * z - epsi).reshape(1),
            lam * s - epsi,
        ])

    while epsi > EPSIMIN:
        res = residual(x, y, z, lam, xsi, eta, mu, zet, s, epsi)
        norm, worst = torch.linalg.norm(res), torch.max(torch.abs(res))
        inner = 0
        while worst > 0.9 * epsi and inner < 200:
            inner += 1
            ux1, xl1 = upp - x, x - low
            ux2, xl2 = ux1 ** 2, xl1 ** 2
            plam = p0 + P.T @ lam
            qlam = q0 + Q.T @ lam
            gvec = P @ (1.0 / ux1) + Q @ (1.0 / xl1)
            GG = P / ux2.unsqueeze(0) - Q / xl2.unsqueeze(0)
            dpsidx = plam / ux2 - qlam / xl2
            delx = dpsidx - epsi / (x - alfa) + epsi / (beta - x)
            dely = c + d * y - lam - epsi / y
            delz = a0 - a @ lam - epsi / z
            dellam = gvec - a * z - y - b + epsi / lam
            diagx = 2.0 * (plam / (ux1 * ux2) + qlam / (xl1 * xl2)) + xsi / (x - alfa) + eta / (beta - x)
            diagy = d + mu / y
            diaglamyi = s / lam + 1.0 / diagy
            if m < n:
                blam = dellam + dely / diagy - GG @ (delx / diagx)
                Alam = torch.diag(diaglamyi) + (GG / diagx.unsqueeze(0)) @ GG.T
                AA = torch.zeros(m + 1, m + 1, dtype=torch.float64)
                AA[:m, :m] = Alam
                AA[:m, m] = a
                AA[m, :m] = a
                AA[m, m] = -zet / z
                solution = torch.linalg.solve(AA, torch.cat([blam, delz.reshape(1)]))
                dlam, dz = solution[:m], solution[m]
                dx = -delx / diagx - (GG.T @ dlam) / diagx
            else:
                dellamyi = dellam + dely / diagy
                Axx = torch.diag(diagx) + (GG.T / diaglamyi.unsqueeze(0)) @ GG
                azz = zet / z + a @ (a / diaglamyi)
                axz = -GG.T @ (a / diaglamyi)
                AA = torch.zeros(n + 1, n + 1, dtype=torch.float64)
                AA[:n, :n] = Axx
                AA[:n, n] = axz
                AA[n, :n] = axz
                AA[n, n] = azz
                bx = delx + GG.T @ (dellamyi / diaglamyi)
                bz = delz - a @ (dellamyi / diaglamyi)
                solution = torch.linalg.solve(AA, torch.cat([-bx, -bz.reshape(1)]))
                dx, dz = solution[:n], solution[n]
                dlam = (GG @ dx) / diaglamyi - dz * (a / diaglamyi) + dellamyi / diaglamyi
            dy = -dely / diagy + dlam / diagy
            dxsi = -xsi + epsi / (x - alfa) - (xsi * dx) / (x - alfa)
            deta = -eta + epsi / (beta - x) + (eta * dx) / (beta - x)
            dmu = -mu + epsi / y - (mu * dy) / y
            dzet = -zet + epsi / z - zet * dz / z
            ds = -s + epsi / lam - (s * dlam) / lam
            # Longest step that keeps every slack and multiplier positive and x inside (alfa, beta).
            xx = torch.cat([y, z.reshape(1), lam, xsi, eta, mu, zet.reshape(1), s])
            dxx = torch.cat([dy, dz.reshape(1), dlam, dxsi, deta, dmu, dzet.reshape(1), ds])
            limit = torch.max(torch.cat([
                -1.01 * dxx / xx, -1.01 * dx / (x - alfa), 1.01 * dx / (beta - x),
                torch.ones(1, dtype=torch.float64)]))
            step = 1.0 / limit
            old = (x, y, z, lam, xsi, eta, mu, zet, s)
            tries, new_norm = 0, 2.0 * norm
            while new_norm > norm and tries < 50:
                tries += 1
                x = old[0] + step * dx
                y = old[1] + step * dy
                z = old[2] + step * dz
                lam = old[3] + step * dlam
                xsi = old[4] + step * dxsi
                eta = old[5] + step * deta
                mu = old[6] + step * dmu
                zet = old[7] + step * dzet
                s = old[8] + step * ds
                res = residual(x, y, z, lam, xsi, eta, mu, zet, s, epsi)
                new_norm = torch.linalg.norm(res)
                step = step / 2.0
            norm, worst = new_norm, torch.max(torch.abs(res))
        epsi *= 0.1
    return x
