"""The design space of one run: its variables, bounds, steps and scales.

Black-box methods may work in the normalized space [0, 1]^n: ``to_unit`` and
``from_unit`` map between it and parameter values, so a method never deals
with units or scales. A ``log`` variable is mapped through its logarithm
(it needs ``0 < lower``). ``snap`` is what the driver applies to every point a
method asks for: round to the parameter's ``step`` (counted from ``lower``,
else from 0) and clamp to the bounds. So an integer-like variable (``step =
1``) only ever sees whole steps, whatever the method proposes.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from ..studies._errors import ErrorCode, StudyError, invalid

LINEAR = "linear"
LOG = "log"


@dataclass(frozen=True)
class Variable:
    """One design variable as a run sees it.

    ``value`` is the parameter's value when the run started. ``settings`` is
    the Study's ``variables.<name>`` table: the range keys this class also
    holds, and the method's per-variable settings.
    """
    name: str
    param_id: str
    value: float
    lower: float | None = None
    upper: float | None = None
    step: float | None = None
    scale: str = LINEAR
    settings: Mapping[str, Any] = field(default_factory=dict)

    @property
    def bounded(self) -> bool:
        return self.lower is not None and self.upper is not None

    # Value -> [0, 1]; needs both bounds. A zero-width range maps to 0.
    def to_unit(self, x: float) -> float:
        lo, hi = self._range()
        if hi == lo:
            return 0.0
        if self.scale == LOG:
            x, lo, hi = math.log(max(x, self.lower)), math.log(lo), math.log(hi)
        return min(1.0, max(0.0, (x - lo) / (hi - lo)))

    # [0, 1] -> snapped value; needs both bounds. ``u`` outside [0, 1] is clamped.
    def from_unit(self, u: float) -> float:
        lo, hi = self._range()
        u = min(1.0, max(0.0, float(u)))
        if self.scale == LOG:
            x = math.exp(math.log(lo) + u * (math.log(hi) - math.log(lo)))
        else:
            x = lo + u * (hi - lo)
        return self.snap(x)

    # Round to ``step`` and clamp to the bounds.
    def snap(self, x: float) -> float:
        x = float(x)
        if self.step is not None:
            origin = self.lower if self.lower is not None else 0.0
            x = origin + round((x - origin) / self.step) * self.step
            if self.upper is not None and x > self.upper:
                x -= self.step  # the last whole step inside the range
        if self.lower is not None:
            x = max(self.lower, x)
        if self.upper is not None:
            x = min(self.upper, x)
        return x

    def _range(self) -> tuple[float, float]:
        if not self.bounded:
            raise ValueError(f"{self.name} has no lower and upper bound")
        return float(self.lower), float(self.upper)


@dataclass(frozen=True)
class DesignSpace:
    """The variables of one run, in the Scene's display order."""
    variables: tuple[Variable, ...]

    @property
    def names(self) -> tuple[str, ...]:
        return tuple(v.name for v in self.variables)

    @property
    def dim(self) -> int:
        return len(self.variables)

    @property
    def bounded(self) -> bool:
        return all(v.bounded for v in self.variables)

    def __getitem__(self, name: str) -> Variable:
        for variable in self.variables:
            if variable.name == name:
                return variable
        raise KeyError(name)

    # Values at the start of the run.
    def current(self) -> dict[str, float]:
        return {v.name: v.value for v in self.variables}

    # A full, snapped point: missing names take their current value; unknown names raise KeyError.
    def snap(self, values: Mapping[str, float]) -> dict[str, float]:
        unknown = set(values) - set(self.names)
        if unknown:
            raise KeyError(f"not a variable of this run: {', '.join(sorted(unknown))}")
        return {v.name: v.snap(values.get(v.name, v.value)) for v in self.variables}

    # Point -> normalized coordinates in variable order; None unless every variable is bounded.
    def to_unit(self, values: Mapping[str, float]) -> tuple[float, ...] | None:
        if not self.bounded:
            return None
        return tuple(v.to_unit(values[v.name]) for v in self.variables)

    # Normalized coordinates in variable order -> snapped point.
    def from_unit(self, unit: Sequence[float]) -> dict[str, float]:
        if len(unit) != self.dim:
            raise ValueError(f"expected {self.dim} coordinates, got {len(unit)}")
        return {v.name: v.from_unit(u) for v, u in zip(self.variables, unit)}


def design_space(scene: Any, variables: Mapping[str, Mapping[str, Any]], *, free: Sequence[str],
                 requires_bounds: bool, allow_empty: bool = False) -> DesignSpace:
    """The run's ``DesignSpace`` from the Study's ``variables`` and the Scene's parameters.

    ``variables`` maps a parameter name to its table (``lower``, ``upper``,
    ``step``, ``scale`` and the method's settings, already checked by
    ``Study.from_dict``); ``free`` are the names of the free parameters (the
    compiled graph's ``inputs``). Raises ``no_variables`` for an empty table
    (unless ``allow_empty``: a gradient Study of tensors only),
    ``variable_not_found`` / ``variable_not_free`` for a name that is no
    parameter / reads other parameters, and ``bounds_missing``
    (``data.variables``) when ``requires_bounds`` and a variable lacks a bound.
    """
    if not variables and not allow_empty:
        raise StudyError(ErrorCode.NO_VARIABLES, "the Study varies no parameter; add one to its variables")
    known = {info.name for info in scene.formulas.parameters()}
    missing = [name for name in variables if name not in known]
    if missing:
        raise StudyError(ErrorCode.VARIABLE_NOT_FOUND,
                         f"not parameters of scene {scene.id}: {', '.join(missing)}", variables=missing)
    bound = [name for name in variables if name not in free]
    if bound:
        raise StudyError(ErrorCode.VARIABLE_NOT_FREE,
                         f"these parameters read other parameters, so a Study cannot vary them: "
                         f"{', '.join(bound)}", variables=bound)
    out = []
    for name, settings in variables.items():
        info = scene.parameters.info(name)
        if info.value is None:
            raise invalid(f"{name} has no value; fix its formula first")
        out.append(Variable(name, info.id, float(info.value), settings.get("lower"), settings.get("upper"),
                            settings.get("step"), settings.get("scale", LINEAR), dict(settings)))
    if requires_bounds:
        unbounded = [v.name for v in out if not v.bounded]
        if unbounded:
            raise StudyError(ErrorCode.BOUNDS_MISSING,
                             f"this method needs lower and upper bounds on: {', '.join(unbounded)}",
                             variables=unbounded)
    return DesignSpace(tuple(out))
