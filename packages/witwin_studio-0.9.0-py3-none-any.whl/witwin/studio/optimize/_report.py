"""Progress lines a Studio Run reads from stdout.

A copy of the line format of ``witwin_run`` (the helper a Run script imports;
server/witwin_server/features/runs/_runtime/witwin_run.py). The SDK cannot
import ``witwin_server``, and that helper must stay a single stdlib file the
server copies next to isolated scripts, so the format lives in both places:
``SENTINEL`` + compact JSON ``{"kind": ..., ...}`` on one line. The Run
executor turns ``progress`` lines into ``run_progress`` events and
``partial`` lines into ``run_partial`` events. tests/test_optimize.py checks
that the server's parser reads these lines.

Also here: ``PartialBuffer`` (black-box partial frames) and
``EvaluationsLog`` / ``read_evaluations`` (``evaluations.jsonl``).
"""
from __future__ import annotations

import json
import sys
from typing import Any, TextIO

# ASCII Unit Separator + tag; must equal witwin_run.SENTINEL.
SENTINEL = "\x1f@witwin "


class Reporter:
    """Writes progress and partial lines; ``seq`` counts partial frames from 0."""

    def __init__(self, stream: TextIO | None = None) -> None:
        self._stream = stream or sys.stdout
        self._seq = 0

    # Fraction in [0, 1] with an optional message.
    def progress(self, frac: float, message: str | None = None) -> None:
        fields: dict[str, Any] = {"frac": max(0.0, min(1.0, float(frac)))}
        if message is not None:
            fields["message"] = message
        self._emit("progress", fields)

    # One intermediate result frame.
    def partial(self, data: Any) -> None:
        self._emit("partial", {"seq": self._seq, "data": data})
        self._seq += 1

    # One whole line per write and a flush, so the executor's reader sees it at once.
    def _emit(self, kind: str, fields: dict[str, Any]) -> None:
        line = SENTINEL + json.dumps({"kind": kind, **fields}, separators=(",", ":"))
        self._stream.write(line + "\n")
        self._stream.flush()


class PartialBuffer:
    """Groups black-box evaluations into partial frames (plan §3.5).

    One frame per batch, or sooner when ``interval`` seconds passed since the
    last frame, so a long batch still shows progress and a 10 000-point
    sweep does not send 10 000 messages. Frame data:
    ``{"batch": int, "records": [EvalRecord dict, ...], "summary"?: {...}}``;
    ``summary`` (the strategy's) is only on the frame that ends a batch.
    """

    def __init__(self, reporter: Reporter, interval: float = 0.25,
                 clock: Any = None) -> None:
        import time

        self._reporter = reporter
        self._interval = interval
        self._clock = clock or time.monotonic
        self._records: list[dict[str, Any]] = []
        self._batch = 0
        self._last = self._clock()

    # One evaluation; flushes when the interval has passed.
    def add(self, record: Any) -> None:
        self._records.append(record.to_dict())
        self._batch = record.batch
        if self._clock() - self._last >= self._interval:
            self.flush()

    # The batch ended: send what is left with the strategy's summary.
    def end_batch(self, batch: int, summary: dict[str, Any]) -> None:
        self._batch = batch
        self.flush(summary)

    def flush(self, summary: dict[str, Any] | None = None) -> None:
        if not self._records and summary is None:
            return
        data: dict[str, Any] = {"batch": self._batch, "records": self._records}
        if summary is not None:
            data["summary"] = summary
        self._reporter.partial(data)
        self._records = []
        self._last = self._clock()


class EvaluationsLog:
    """``evaluations.jsonl``: one ``EvalRecord`` per line, flushed per line.

    A process that dies mid-run leaves every finished line intact; at most
    the last line is cut, and ``read_evaluations`` skips it.
    """

    def __init__(self, path: Any) -> None:
        self.path = path
        self._file = open(path, "w", encoding="utf-8", newline="\n")

    def write(self, record: Any) -> None:
        self._file.write(json.dumps(record.to_dict(), separators=(",", ":")) + "\n")
        self._file.flush()

    def close(self) -> None:
        self._file.close()


def read_evaluations(path: Any) -> list[dict[str, Any]]:
    """The lines of an ``evaluations.jsonl`` as dicts; unreadable lines (a cut last line) are skipped."""
    out = []
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                try:
                    item = json.loads(line)
                except ValueError:
                    continue
                if isinstance(item, dict):
                    out.append(item)
    except FileNotFoundError:
        return []
    return out
