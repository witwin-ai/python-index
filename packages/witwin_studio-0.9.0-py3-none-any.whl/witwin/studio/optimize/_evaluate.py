"""One objective evaluation without gradients (plan §3.2).

``PointEvaluator`` compiles the Formula Graph once on the torch backend (the
same graph the gradient method uses) and calls the objective under
``torch.no_grad()``, so one objective serves every method. Without torch it
falls back to the float backend: the objective then gets Python floats.
``ctx.differentiable`` is False here, so a Plugin objective can skip its
adjoint pass.

The objective may return a float, a one-element tensor, or a dict
``{"loss": <float or tensor>, <metric>: <number>, ...}``; numbers from
``ctx.report`` are metrics too. Anything else, a non-finite loss, or an
exception makes the evaluation ``failed`` with the error text; the driver
decides whether the run goes on (``Study.on_error``). KeyboardInterrupt is
not caught.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping

from ..studies._errors import ErrorCode, StudyError
from ._objectives import ObjectiveContext, ObjectiveFn
from ._records import CONSTRAINT_PREFIX, EvalStatus

if TYPE_CHECKING:
    from .._scene import Scene


@dataclass(frozen=True)
class Outcome:
    """What one evaluation produced; the driver turns it into an ``EvalRecord``."""
    loss: float | None
    status: EvalStatus = EvalStatus.OK
    metrics: dict[str, float] = field(default_factory=dict)
    duration_s: float = 0.0
    error: StudyError | None = None
    worker: int | None = None  # process-pool worker that ran it (1..N); None in this process


class PointEvaluator:
    """Evaluates the objective at single points of one Scene; reused for every point of a run."""

    def __init__(self, scene: "Scene", fn: ObjectiveFn, project_root: Path | None, *,
                 worker: int | None = None) -> None:
        try:
            import torch

            from ..formula.torch_backend import TorchBackend

            self._torch: Any = torch
            backend: Any = TorchBackend()
        except ImportError:
            from ..formula import FLOAT_BACKEND

            self._torch, backend = None, FLOAT_BACKEND
        self._fn = fn
        self._compiled = scene.formulas.compile(backend)
        self._ctx = ObjectiveContext(scene, self._compiled(), project_root=project_root)
        self._ctx.differentiable = False
        self._ctx.worker = worker

    def evaluate(self, values: Mapping[str, float], index: int) -> Outcome:
        """Call the objective at ``values`` (parameter name -> number); ``index`` becomes ``ctx.step``."""
        start = time.perf_counter()
        try:
            loss, metrics = self._call(values, index)
        except StudyError as exc:
            return Outcome(None, EvalStatus.FAILED, dict(self._ctx.metrics),
                           time.perf_counter() - start, exc)
        except Exception as exc:  # noqa: BLE001 - user code; recorded as a failed evaluation
            error = StudyError(ErrorCode.OBJECTIVE_FAILED, f"{type(exc).__name__}: {exc}")
            return Outcome(None, EvalStatus.FAILED, dict(self._ctx.metrics),
                           time.perf_counter() - start, error)
        return Outcome(loss, EvalStatus.OK, metrics, time.perf_counter() - start)

    def _call(self, values: Mapping[str, float], index: int) -> tuple[float, dict[str, float]]:
        ctx, torch = self._ctx, self._torch
        ctx.step, ctx.metrics = index, {}
        if torch is None:
            ctx.values = self._compiled({name: float(v) for name, v in values.items()})
            return scalar_loss(self._fn(ctx), ctx.metrics)
        with torch.no_grad():
            inputs = {name: torch.tensor(float(v), dtype=torch.float64) for name, v in values.items()}
            ctx.values = self._compiled(inputs)
            return scalar_loss(self._fn(ctx), ctx.metrics)


def scalar_loss(out: Any, reported: Mapping[str, float] | None = None) -> tuple[float, dict[str, float]]:
    """The objective's return value as ``(loss, metrics)``; raises ``StudyError``.

    ``objective_not_scalar`` for anything that is not one number (or a dict
    without ``loss``), ``objective_not_finite`` for NaN or infinity. A
    ``constraints`` table becomes metrics ``constraint.<name>``; black-box
    methods only record them.
    """
    metrics = dict(reported or {})
    if isinstance(out, Mapping):
        if "loss" not in out:
            raise StudyError(ErrorCode.OBJECTIVE_NOT_SCALAR,
                                    "an objective that returns a dict must include 'loss'")
        for key, value in out.items():
            if key == "constraints" and isinstance(value, Mapping):
                for name, g in value.items():
                    metrics[f"{CONSTRAINT_PREFIX}{name}"] = _number(g, f"constraint '{name}'")
            elif key != "loss":
                metrics[str(key)] = _number(value, f"metric '{key}'")
        out = out["loss"]
    loss = _number(out, "the objective")
    if not math.isfinite(loss):
        raise StudyError(ErrorCode.OBJECTIVE_NOT_FINITE, f"the objective returned {loss}")
    return loss, metrics


# A float from a number or a one-element tensor/array.
def _number(value: Any, what: str) -> float:
    if isinstance(value, bool):
        raise StudyError(ErrorCode.OBJECTIVE_NOT_SCALAR, f"{what} returned a bool")
    if isinstance(value, (int, float)):
        return float(value)
    numel = getattr(value, "numel", None) or getattr(value, "size", None)
    count = numel() if callable(numel) else numel
    if count == 1 and hasattr(value, "item"):
        return float(value.item() if callable(value.item) else value)
    shape = tuple(getattr(value, "shape", ()) or ())
    raise StudyError(ErrorCode.OBJECTIVE_NOT_SCALAR,
                            f"{what} must return one number, not {type(value).__name__}"
                            f"{f' of shape {shape}' if shape else ''}")
