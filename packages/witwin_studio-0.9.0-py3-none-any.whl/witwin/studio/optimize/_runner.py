"""``optimize.run``: run one optimize Study with the driver its method's family needs.

- ``gradient`` -> ``GradientDriver`` (``_gradient.py``): torch leaf tensors and a
  torch optimizer; the objective must return a tensor with a gradient.
- every other family -> ``BatchDriver`` (``_batch.py``): the method's
  ``Strategy`` asks for points, the driver evaluates them without gradients.

``run`` never writes the Scene; ``OptimizationResult.apply`` does that when
asked. ``check_study`` makes the refusals ``run`` would make before its
first evaluation, without evaluating anything.
"""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Mapping

from .._manifest import MANIFEST_NAME
from ._batch import EVALUATIONS_FILE, BatchCallback, BatchDriver, ProgressCallback
from ..studies._errors import ErrorCode, StudyError
from ._evaluators import Evaluator
from ._gradient import GradientDriver
from ._objectives import ObjectiveFn, resolve
from ._records import EvalRecord, StepRecord, StopReason
from ._report import EvaluationsLog
from ._result import OptimizationResult
from ._strategies import builtin as builtin_method
from ._strategies import resolve as resolve_method
from ._space import design_space
from ._strategies.base import Family, StrategySetup
from ..studies._model import Study, StudyKind

if TYPE_CHECKING:
    from .._scene import Scene

__all__ = ["OptimizationResult", "StepRecord", "StopReason", "check_study", "run"]


def run(scene: "Scene", study: Study | Mapping[str, Any], *,
        objective: ObjectiveFn | None = None, project_root: Path | str | None = None,
        on_step: Callable[[StepRecord], None] | None = None,
        should_stop: Callable[[], bool] | None = None,
        on_evaluation: Callable[[EvalRecord], None] | None = None,
        on_batch: BatchCallback | None = None,
        evaluations_file: Path | str | None = None,
        evaluator: Evaluator | None = None,
        on_driver: Callable[[Any], None] | None = None,
        output_dir: Path | str | None = None,
        resume_from: Path | str | None = None,
        on_progress: ProgressCallback | None = None) -> OptimizationResult:
    """Run one optimize Study on ``scene`` (the Scene its ``scene`` field names).

    ``study`` is a ``Study`` or a record dict. ``objective`` overrides the Study's objective with
    a function of your own; then the Study needs none. ``project_root``
    defaults to the folder holding ``witwin.toml`` above the Scene file; script
    objectives are found relative to it.

    Callbacks: ``on_evaluation`` gets every ``EvalRecord``; ``on_step`` every
    gradient ``StepRecord``; ``on_batch(batch, new_records, summary)`` runs
    after each black-box batch; ``on_progress(index, outcome)`` as each
    black-box evaluation finishes, before its batch is done; ``should_stop``
    is asked before each step or point. ``evaluations_file`` gets one JSON
    line per evaluation, flushed as it is written, so the file stays readable
    when the process dies; with an ``output_dir`` it defaults to
    ``<output_dir>/evaluations.jsonl`` (a black-box checkpoint is resumed
    from that file).
    ``evaluator`` replaces the black-box evaluator (tests, process pools).
    ``on_driver`` receives the driver before the loop starts (the process
    entry reads its ``progress``).

    ``output_dir`` is the folder for the run's checkpoint (``checkpoint.pt``
    and the tensor files of a gradient run, ``checkpoint.json`` of any other;
    ``_checkpoint``); ``resume_from`` is a checkpoint file, or the folder of
    the run that wrote it, that this run continues. A resumed black-box run
    starts with the evaluations it continues (they count against
    ``budget.max_evals``); a resumed gradient run with the next step.

    Raises ``StudyError`` when nothing can run (``invalid_study``,
    ``objective_not_found``, ``no_variables``, ``variable_not_found``,
    ``variable_not_free``, ``bounds_missing``, ``method_not_found``, ``method_unavailable``,
    ``dependency_missing``, ``torch_missing``, ``tensors_unsupported`` for a
    Study with tensor design variables and a method other than gradient,
    ``checkpoint_invalid``). A failure while running does
    not raise: the result has ``stopped_by == "error"``, the ``error``, and
    the evaluations done so far. KeyboardInterrupt stops the run with
    ``stopped_by == "stopped"``.
    """
    study = _as_study(scene, study, has_objective=objective is not None)
    known = builtin_method(study.method.kind)
    if known is not None:
        _check_tensors(study, known)
    method = resolve_method(study.method.kind)
    _check_tensors(study, method)
    gradient = Family(method.family) is Family.GRADIENT
    root = Path(project_root) if project_root is not None else _project_root(scene)
    fn = objective if objective is not None else resolve(study.objective, root)
    if output_dir is not None:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        if evaluations_file is None:
            evaluations_file = Path(output_dir) / EVALUATIONS_FILE
    log = EvaluationsLog(Path(evaluations_file)) if evaluations_file is not None else None

    def record(evaluation: EvalRecord) -> None:
        if log is not None:
            log.write(evaluation)
        if on_evaluation is not None:
            on_evaluation(evaluation)

    try:
        if gradient:
            driver: Any = GradientDriver(scene, study, fn, root, output_dir=output_dir,
                                         resume_from=resume_from)
            if on_driver is not None:
                on_driver(driver)
            result = driver.loop(on_step, should_stop, record)
        else:
            # A function passed as ``objective`` cannot be rebuilt in a worker process.
            driver = BatchDriver(scene, study, fn, root, method, evaluator=evaluator,
                                 project_dir=root if objective is None else None,
                                 output_dir=output_dir, resume_from=resume_from)
            if on_driver is not None:
                on_driver(driver)
            result = driver.loop(record, on_batch, should_stop, on_progress)
    finally:
        if log is not None:
            log.close()
    if log is not None:
        result.evaluations_file = Path(evaluations_file).name
    return result


def check_study(scene: "Scene", study: Study | Mapping[str, Any], *,
                project_root: Path | str | None = None) -> None:
    """Raise the ``StudyError`` ``run`` would raise before its first evaluation.

    Checks the method (installed, available), tensor variables, the design
    space (``no_variables``, ``variable_not_found``, ``variable_not_free``,
    ``bounds_missing``) and the
    method's own ``Optimizer.validate`` (a sweep's point count against
    ``budget.max_evals``, Monte Carlo distributions without the bounds they
    need, a GA elite as large as the population, too many variables for
    Bayesian Optimization). Runs no objective and no Project script; the
    ProjectServer calls it before it starts a Run. The objective itself is
    not looked up. Returns None when the Study can run.
    """
    from ..formula import FLOAT_BACKEND

    study = _as_study(scene, study, has_objective=True)
    known = builtin_method(study.method.kind)
    if known is not None:
        _check_tensors(study, known)
    method = resolve_method(study.method.kind)
    _check_tensors(study, method)
    free = scene.formulas.compile(FLOAT_BACKEND).inputs
    gradient = Family(method.family) is Family.GRADIENT
    mma = gradient and study.method.get("optimizer") == "mma"  # MMA keeps every variable in its bounds
    space = design_space(scene, study.variables, free=free, allow_empty=bool(study.tensors),
                         requires_bounds=mma or (not gradient and bool(getattr(method, "requires_bounds", True))))
    if gradient:
        return
    validate = getattr(method, "validate", None)
    if validate is not None:
        root = Path(project_root) if project_root is not None else _project_root(scene)
        validate(StrategySetup(space, dict(study.method.settings), study.seed or 0, study.budget,
                               study.direction, root))


# tensors_unsupported for a Study with tensor design variables and a method that is not gradient.
def _check_tensors(study: Study, method: Any) -> None:
    if study.tensors and Family(method.family) is not Family.GRADIENT:
        raise StudyError(ErrorCode.TENSORS_UNSUPPORTED,
                                f"{method.title} cannot optimize tensor design variables "
                                f"({', '.join(study.tensors)}); use Gradient Descent",
                                tensors=list(study.tensors))


# Normalize run()'s ``study`` argument.
def _as_study(scene: "Scene", study: Study | Mapping[str, Any], *, has_objective: bool) -> Study:
    if not isinstance(study, Study):
        study = Study.from_dict(study, require_objective=not has_objective)
    if study.kind is not StudyKind.OPTIMIZE:
        raise StudyError(ErrorCode.INVALID_STUDY, f"study {study.id} is a {study.kind} Study, not optimize")
    if study.objective is None and not has_objective:
        raise StudyError(ErrorCode.INVALID_STUDY, f"study {study.id} has no objective")
    return study


# The folder holding witwin.toml at or above the Scene file; None for a loose file.
def _project_root(scene: "Scene") -> Path | None:
    if scene.path is None:
        return None
    for folder in Path(scene.path).resolve().parents:
        if (folder / MANIFEST_NAME).is_file():
            return folder
    return None
