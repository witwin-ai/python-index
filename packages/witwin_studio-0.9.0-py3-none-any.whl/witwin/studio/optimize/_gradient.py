"""The gradient family's driver (plan §3.1, §5): torch leaves and a torch optimizer or MMA.

``GradientProblem`` compiles the Formula Graph once on the torch backend,
holds the design variables (``_design.DesignVariables``: scalar parameters
and tensor design variables) and evaluates the objective with gradients.
``GradientDriver`` steps an optimizer on it and records the run. Neither
writes the Scene.

Step numbering: step ``k`` evaluates the objective at the current values,
records ``loss``, ``values``, ``grad_norm`` and ``metrics`` of that
evaluation, then updates the variables. So every recorded ``values`` has a
known ``loss``, and ``best`` / ``last`` are values the objective actually saw.
``loss`` is the objective as returned, also for ``maximize`` (the optimizer
minimizes its negative). Each step is also one evaluation (``EvalRecord``
with ``index == batch == step``). A resumed run continues the step numbers
of its checkpoint.

Settings (``method``, see ``_strategies/gradient.py``):

- ``optimizer``: ``adam``, ``sgd``, ``lbfgs`` (torch) or ``mma`` (``_mma``).
- ``lr`` and ``schedule``: the learning rate of step ``k`` is ``lr`` times
  1 (``constant``), ``0.5 * (1 + cos(pi * ((k - 1) mod max_iters) / max_iters))``
  (``cosine``, a new cycle every ``max_iters`` steps) or ``gamma ** ((k - 1)
  // step_size)`` (``step``). It depends on the step number only, so a
  resumed run picks the schedule up where it stopped. MMA has no rate.
- ``grad_clip`` > 0: Adam and SGD scale the gradient down to that norm before
  stepping. L-BFGS ignores it, because its line search needs the true
  gradient. ``grad_norm`` is recorded before clipping, on the physical
  values (also under ``sigmoid``), of the minimized objective (penalty
  included).
- ``bounds``: ``clamp``, ``sigmoid`` or ``auto`` (sigmoid for L-BFGS, clamp
  otherwise); see ``_design``. MMA always keeps variables in their bounds
  and refuses a variable without both (``bounds_missing``).
- Constraints: the objective may return ``{"loss": ..., "constraints":
  {name: g}}`` with ``g <= 0`` feasible. MMA treats them as constraints; the
  torch optimizers minimize ``loss + penalty * sum(max(g, 0) ** 2)``. Each
  value is recorded as metric ``constraint.<name>``. ``best`` prefers
  feasible steps; among infeasible ones, the smallest total violation.
- ``checkpoint_every`` = N > 0: ``checkpoint.pt`` (``_checkpoint``) is
  written to the run's output folder every N steps and when the run ends
  (not on an error).

Tensor design variables are written to ``<output>/tensors/`` while the run
goes (at most every ``SNAPSHOT_INTERVAL`` seconds, and at the end):
``<id>.npy`` (latest value), ``<id>.transformed.npy`` (latest value after its
transforms, when it has any) and ``<id>.best.npy`` (value at the best step).

Budget: the run stops after ``min(max_iters, budget.max_evals)`` steps, or
once ``budget.max_time_s`` has passed (``stopped_by = "budget"``).
"""
from __future__ import annotations

import math
import secrets
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Mapping

from . import _checkpoint
from ._design import BOX, CLAMP, SIGMOID, DesignVariables, start_tensors, tensor_stats
from ..studies._errors import ErrorCode, StudyError
from ._objectives import ObjectiveContext, ObjectiveFn
from ._records import CONSTRAINT_PREFIX, EvalRecord, StepRecord, StopReason
from ._result import OptimizationResult
from ._space import DesignSpace, design_space
from ..studies._model import Direction, GradientOptimizer, Study
from ._tensors import save_array

if TYPE_CHECKING:
    from .._scene import Scene

SEED_LIMIT = 2 ** 31
TENSOR_DIR = "tensors"
SNAPSHOT_INTERVAL = 0.5  # seconds between live tensor snapshots


@dataclass
class Point:
    """One objective evaluation with gradients still attached."""
    loss: Any                                  # 0-d tensor, as the objective returned it
    constraints: dict[str, Any]                # name -> 0-d tensor (or float)
    metrics: dict[str, float] = field(default_factory=dict)

    @property
    def violation(self) -> float:
        return sum(max(_float(g), 0.0) for g in self.constraints.values())


class GradientProblem:
    """Compiled graph, design variables and objective of one gradient run (or gradient check)."""

    def __init__(self, scene: "Scene", study: Study, fn: ObjectiveFn, root: Path | None, *,
                 bounds: str, seed: int) -> None:
        try:
            import torch
        except ImportError:
            raise StudyError(ErrorCode.TORCH_MISSING,
                                    "optimization needs torch; install it in this environment") from None
        from ..formula.torch_backend import TorchBackend

        self.torch = torch
        self.study = study
        self._fn = fn
        self._compiled = scene.formulas.compile(TorchBackend())
        space = _scalar_space(scene, self._compiled.inputs, study)
        tensors = start_tensors(torch, study.tensors, root, seed)
        self.design = DesignVariables(torch, space, study.tensors, tensors, bounds)
        self.ctx = ObjectiveContext(scene, self._compiled(), project_root=root)
        self.ctx.differentiable = True

    @property
    def space(self) -> DesignSpace:
        return self.design.space

    def evaluate(self, step: int) -> Point:
        """Call the objective at the current leaves; raises ``StudyError``."""
        ctx = self.ctx
        ctx.step = step
        ctx.values = self._compiled(self.design.scalars())
        ctx.tensors = self.design.transformed()
        ctx.metrics = {}
        try:
            out = self._fn(ctx)
        except Exception as exc:  # noqa: BLE001 - user code; report it as the run's error
            raise StudyError(ErrorCode.OBJECTIVE_FAILED, f"{type(exc).__name__}: {exc}") from exc
        return self._checked(out)

    def value(self, step: int) -> float:
        """The loss at the current leaves without a gradient (``ctx.differentiable`` is False)."""
        from ._evaluate import scalar_loss

        ctx = self.ctx
        ctx.step, ctx.metrics, ctx.differentiable = step, {}, False
        try:
            with self.torch.no_grad():
                ctx.values = self._compiled(self.design.scalars())
                ctx.tensors = self.design.transformed()
                out = self._fn(ctx)
        except Exception as exc:  # noqa: BLE001 - user code; report it as the run's error
            raise StudyError(ErrorCode.OBJECTIVE_FAILED, f"{type(exc).__name__}: {exc}") from exc
        finally:
            ctx.differentiable = True
        return scalar_loss(out)[0]

    # Minimizing the objective (or its negative) plus the penalty of violated constraints.
    def minimized(self, point: Point, penalty: float) -> Any:
        sign = -1.0 if self.study.direction is Direction.MAXIMIZE else 1.0
        total = sign * point.loss
        if penalty > 0:
            for g in point.constraints.values():
                if self.torch.is_tensor(g):
                    total = total + penalty * self.torch.clamp(g, min=0.0) ** 2
        return total

    # The objective's return value as a Point, or an error.
    def _checked(self, out: Any) -> Point:
        torch = self.torch
        constraints: dict[str, Any] = {}
        if isinstance(out, Mapping) and "loss" in out:
            for key, value in out.items():
                if key == "constraints" and isinstance(value, Mapping):
                    constraints = {str(name): _scalar(torch, g, f"constraint '{name}'")
                                   for name, g in value.items()}
                elif key != "loss":
                    self.ctx.report(key, value)
            out = out["loss"]
        if not torch.is_tensor(out) or not out.requires_grad:
            raise StudyError(ErrorCode.OBJECTIVE_NOT_DIFFERENTIABLE,
                                    "the objective must return a torch tensor that depends on the "
                                    "design variables (it has no grad_fn)")
        loss = _scalar(torch, out, "the objective")
        metrics = dict(self.ctx.metrics)
        for name, g in constraints.items():
            metrics[f"{CONSTRAINT_PREFIX}{name}"] = _float(g)
        return Point(loss, constraints, metrics)


class GradientDriver:
    """State of one gradient run: problem, optimizer, schedule, records and checkpoints."""

    def __init__(self, scene: "Scene", study: Study, fn: ObjectiveFn, root: Path | None, *,
                 output_dir: Path | None = None, resume_from: Path | str | None = None) -> None:
        self._study = study
        self._settings = dict(study.method.settings)
        self._method = GradientOptimizer(self._settings["optimizer"])
        self._output_dir = Path(output_dir) if output_dir is not None else None
        seed = study.seed if study.seed is not None else secrets.randbelow(SEED_LIMIT)
        self.seed = seed
        self.problem = GradientProblem(scene, study, fn, root, bounds=self._bounds_mode(), seed=seed)
        self.torch = torch = self.problem.torch
        design = self.problem.design
        if self._method is GradientOptimizer.MMA:
            missing = design.unbounded()
            if missing:
                raise StudyError(ErrorCode.BOUNDS_MISSING,
                                        f"MMA needs lower and upper bounds on: {', '.join(missing)}",
                                        variables=missing)
            from ._mma import MMA

            self._mma: Any = MMA(sum(leaf.numel() for leaf in design.leaves()),
                                 move=self._settings.get("move", 0.5))
            self._optimizer: Any = None
        else:
            self._mma = None
            self._optimizer = _torch_optimizer(torch, self._method, self._settings["lr"], design.leaves())
        self._start = 0
        self._last_loss: float | None = None
        self._lr: float | None = None
        self._pending: StepRecord | None = None
        self._step_number = 0
        self._pending_tensors: dict[str, Any] = {}
        self._best_tensors: dict[str, Any] = {}
        self._best_violation = math.inf
        self._snapshot_at = 0.0
        self._steps_planned = 0
        if resume_from is not None:
            self._resume(_checkpoint.load(resume_from))
        space = self.problem.space
        self.result = OptimizationResult(study.id, scene.id, study.direction, self._method,
                                         {v.name: v.param_id for v in space.variables},
                                         kind=study.method.kind, variables=list(space.names), seed=seed)
        self.result.tensors = {tensor_id: {"shape": list(spec["shape"]), "label": spec["label"]}
                               for tensor_id, spec in study.tensors.items()}

    @property
    def progress(self) -> float:
        """Fraction of this run's planned steps done, in [0, 1]."""
        if not self._steps_planned:
            return 0.0
        return min(1.0, len(self.result.steps) / self._steps_planned)

    @property
    def start_step(self) -> int:
        """Step number of the checkpoint this run resumed from; 0 for a fresh run."""
        return self._start

    # Step until a stop condition; returns the result.
    def loop(self, on_step: Callable[[StepRecord], None] | None,
             should_stop: Callable[[], bool] | None,
             on_evaluation: Callable[[EvalRecord], None] | None = None) -> OptimizationResult:
        result, settings, budget = self.result, self._settings, self._study.budget
        steps = settings["max_iters"] if budget.max_evals is None else min(settings["max_iters"],
                                                                            budget.max_evals)
        self._steps_planned = steps
        deadline = None if budget.max_time_s is None else time.monotonic() + budget.max_time_s
        result.stopped_by = StopReason.MAX_ITERS if steps == settings["max_iters"] else StopReason.BUDGET
        every = int(settings.get("checkpoint_every", 0) or 0)
        saved_at = None
        self.problem.design.clamp_()
        try:
            for step in range(self._start + 1, self._start + steps + 1):
                if should_stop is not None and should_stop():
                    result.stopped_by = StopReason.STOPPED
                    break
                if deadline is not None and step > self._start + 1 and time.monotonic() >= deadline:
                    result.stopped_by = StopReason.BUDGET
                    break
                started = time.perf_counter()
                record = self._step(step)
                if record is None:
                    break
                result.steps.append(record)
                evaluation = EvalRecord(step, step, dict(record.values), record.loss,
                                        metrics=dict(record.metrics),
                                        duration_s=time.perf_counter() - started,
                                        grad_norm=record.grad_norm)
                result.evaluations.append(evaluation)
                if result.best is None or self._better(record):
                    result.best = record
                    self._best_violation = _violation(record)
                    self._best_tensors = self._pending_tensors
                previous, self._last_loss = self._last_loss, record.loss
                self._snapshot(final=False)
                if every and step % every == 0:
                    self.save_checkpoint(step)
                    saved_at = step
                if on_evaluation is not None:
                    on_evaluation(evaluation)
                if on_step is not None:
                    on_step(record)
                if previous is not None and abs(record.loss - previous) < settings["tol"]:
                    result.stopped_by = StopReason.TOL
                    break
        except KeyboardInterrupt:
            result.stopped_by = StopReason.STOPPED
        done = self._start + len(result.steps)
        if every and result.steps and result.stopped_by is not StopReason.ERROR and saved_at != done:
            self.save_checkpoint(done)
        self._snapshot(final=True)
        result.tensor_data = {"best": dict(self._best_tensors),
                              "last": self.problem.design.tensor_arrays() if result.steps else {}}
        return result

    # ---------------------------------------------------------------- one step
    # One optimizer step; None when the objective failed (recorded on the result).
    def _step(self, step: int) -> StepRecord | None:
        self._pending = None
        self.problem.design.advance(step)
        try:
            if self._mma is not None:
                self._mma_step(step)
            else:
                self._lr = self._settings["lr"] * _schedule_factor(self._settings, step)
                for group in self._optimizer.param_groups:
                    group["lr"] = self._lr
                self._step_number = step
                self._optimizer.step(self._closure)
                self.problem.design.clamp_()  # skips the sigmoid-mapped variables
        except StudyError as exc:
            self.result.stopped_by, self.result.error = StopReason.ERROR, exc
            return None
        return self._pending

    # Evaluate the objective and its gradient; L-BFGS calls this several times per step.
    def _closure(self) -> Any:
        self._optimizer.zero_grad()
        point = self.problem.evaluate(self._step_number)
        minimized = self.problem.minimized(point, float(self._settings.get("penalty", 0.0)))
        minimized.backward()
        if self._pending is None:  # keep the step's first point
            self._record(self._step_number, point, self.problem.design.grad_norm())
        clip = float(self._settings.get("grad_clip", 0.0) or 0.0)
        if clip > 0 and self._method in (GradientOptimizer.ADAM, GradientOptimizer.SGD):
            self.torch.nn.utils.clip_grad_norm_(self.problem.design.leaves(), clip)
        return minimized

    # One MMA iteration: evaluate, take gradients of objective and constraints, move.
    def _mma_step(self, step: int) -> None:
        torch, design = self.torch, self.problem.design
        leaves = design.leaves()
        point = self.problem.evaluate(step)
        f0 = self.problem.minimized(point, 0.0)
        names = [name for name, g in point.constraints.items() if torch.is_tensor(g)]
        outputs = [f0] + [point.constraints[name] for name in names]
        rows = []
        for i, output in enumerate(outputs):
            grads = torch.autograd.grad(output, leaves, retain_graph=i < len(outputs) - 1,
                                        allow_unused=True)
            rows.append(torch.cat([(g if g is not None else torch.zeros_like(leaf)).reshape(-1)
                                   for g, leaf in zip(grads, leaves)]))
        spans = design.unit_spans()
        df0 = rows[0] * spans
        dg = (torch.stack(rows[1:]) * spans.unsqueeze(0) if len(rows) > 1
              else torch.zeros(0, spans.numel(), dtype=torch.float64))
        g = torch.tensor([_float(point.constraints[name]) for name in names], dtype=torch.float64)
        self._record(step, point, float(torch.linalg.norm(rows[0])))
        with torch.no_grad():
            design.set_unit_vector(self._mma.step(design.unit_vector(), float(f0), df0, g, dg))

    def _record(self, step: int, point: Point, grad_norm: float) -> None:
        design, torch = self.problem.design, self.torch
        self._pending_tensors = design.tensor_arrays()
        self._pending = StepRecord(
            step, float(point.loss.item()), design.values(), grad_norm, dict(point.metrics),
            lr=self._lr if self._mma is None else None, beta=design.betas(),
            tensors={tensor_id: tensor_stats(torch, value) for tensor_id, value in self.problem.ctx.tensors.items()},
            feasible=point.violation <= 0.0)

    # True when ``record`` beats the current best: feasible first, then loss (or violation).
    def _better(self, record: StepRecord) -> bool:
        best = self.result.best
        if record.feasible != best.feasible:
            return record.feasible
        if not record.feasible:
            return _violation(record) < self._best_violation
        if self._study.direction is Direction.MAXIMIZE:
            return record.loss > best.loss
        return record.loss < best.loss

    def _bounds_mode(self) -> str:
        if self._method is GradientOptimizer.MMA:
            return BOX
        mode = self._settings.get("bounds", "auto")
        if mode == "auto":
            return SIGMOID if self._method is GradientOptimizer.LBFGS else CLAMP
        return mode

    # ---------------------------------------------------------------- checkpoints and files
    def save_checkpoint(self, step: int) -> None:
        """Write ``<output>/checkpoint.pt`` for ``step`` (the last step done); no-op without an output folder."""
        if self._output_dir is None:
            return
        design = self.problem.design
        state = self._mma.state_dict() if self._mma is not None else self._optimizer.state_dict()
        _checkpoint.save(self._output_dir / _checkpoint.CHECKPOINT_FILE, {
            "study_id": self._study.id, "step": int(step), "seed": self.seed,
            "optimizer": str(self._method), "bounds": design.mode,
            "raw": design.raw_state(), "values": design.values(), "tensors": design.tensor_arrays(),
            "optimizer_state": state, "lr": self._lr,
            "beta": {tensor_id: chain.state_dict() for tensor_id, chain in design.chains.items()},
            "last_loss": self._last_loss,
        })

    def _resume(self, state: Mapping[str, Any]) -> None:
        design = self.problem.design
        if state.get("study_id") != self._study.id:
            raise StudyError(ErrorCode.CHECKPOINT_INVALID,
                                    f"the checkpoint belongs to study {state.get('study_id')!r}, "
                                    f"not {self._study.id!r}")
        names = sorted(design.values())
        saved = sorted((state.get("values") or {}).keys())
        if names != saved:
            raise StudyError(ErrorCode.CHECKPOINT_INVALID,
                                    f"the checkpoint has the variables {saved}, the study has {names}")
        shapes = {key: list(value.shape) for key, value in (state.get("tensors") or {}).items()}
        if shapes != design.shapes():
            raise StudyError(ErrorCode.CHECKPOINT_INVALID,
                                    f"the checkpoint has the tensors {shapes}, the study has {design.shapes()}")
        same = state.get("optimizer") == str(self._method) and state.get("bounds") == design.mode
        if same:
            design.load_raw_state(state["raw"])
            if self._mma is not None:
                self._mma.load_state_dict(state["optimizer_state"])
            else:
                self._optimizer.load_state_dict(state["optimizer_state"])
        else:
            design.set_physical(state["values"], state["tensors"])
        for tensor_id, betas in (state.get("beta") or {}).items():
            if tensor_id in design.chains:
                design.chains[tensor_id].load_state_dict(betas)
        self._start = int(state["step"])
        self._last_loss = state.get("last_loss")

    # Write the tensor files of the output folder (throttled unless ``final``).
    def _snapshot(self, *, final: bool) -> None:
        design = self.problem.design
        if self._output_dir is None or not design.specs:
            return
        now = time.monotonic()
        if not final and now - self._snapshot_at < SNAPSHOT_INTERVAL:
            return
        self._snapshot_at = now
        folder = self._output_dir / TENSOR_DIR
        with self.torch.no_grad():
            transformed = design.transformed()
            for tensor_id, value in design.tensor_arrays().items():
                save_array(folder / f"{tensor_id}.npy", value.numpy())
                if design.chains[tensor_id]:
                    save_array(folder / f"{tensor_id}.transformed.npy", transformed[tensor_id].numpy())
        if final:
            for tensor_id, value in self._best_tensors.items():
                save_array(folder / f"{tensor_id}.best.npy", value.numpy())


# The Study's scalar design space; may be empty when the Study has tensor design variables.
def _scalar_space(scene: "Scene", free: Any, study: Study) -> DesignSpace:
    return design_space(scene, study.variables, free=free, requires_bounds=False,
                        allow_empty=bool(study.tensors))


# Learning-rate multiplier of ``step`` (from 1) for the method settings' schedule.
def _schedule_factor(settings: Mapping[str, Any], step: int) -> float:
    schedule = settings.get("schedule", "constant")
    if schedule == "cosine":
        period = int(settings["max_iters"])
        return 0.5 * (1.0 + math.cos(math.pi * ((step - 1) % period) / period))
    if schedule == "step":
        return float(settings.get("gamma", 0.5)) ** ((step - 1) // int(settings.get("step_size", 50)))
    return 1.0


# The torch optimizer of the gradient method's settings.
def _torch_optimizer(torch: Any, method: GradientOptimizer, lr: float, params: list[Any]) -> Any:
    if method is GradientOptimizer.SGD:
        return torch.optim.SGD(params, lr=lr)
    if method is GradientOptimizer.LBFGS:
        return torch.optim.LBFGS(params, lr=lr, line_search_fn="strong_wolfe")
    return torch.optim.Adam(params, lr=lr)


# A one-number tensor (0-d), or a float for a constant constraint; raises for anything else.
def _scalar(torch: Any, value: Any, what: str) -> Any:
    if torch.is_tensor(value):
        if value.numel() != 1:
            raise StudyError(ErrorCode.OBJECTIVE_NOT_SCALAR,
                                    f"{what} must be one number, not shape {tuple(value.shape)}")
        value = value.reshape(())
        number = float(value.item())
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        number = float(value)
    else:
        raise StudyError(ErrorCode.OBJECTIVE_NOT_SCALAR, f"{what} must be a number, not {value!r}")
    if not math.isfinite(number):
        raise StudyError(ErrorCode.OBJECTIVE_NOT_FINITE, f"{what} returned {number}")
    return value


def _float(value: Any) -> float:
    item = getattr(value, "item", None)
    return float(item() if callable(item) else value)


# Total constraint violation of a step, from its ``constraint.*`` metrics.
def _violation(record: StepRecord) -> float:
    return sum(max(v, 0.0) for k, v in record.metrics.items() if k.startswith(CONSTRAINT_PREFIX))
