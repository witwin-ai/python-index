"""Settings schemas: the JSON-Schema subset optimizer methods and objectives declare.

A method's ``settings_schema`` (and ``variable_schema``) is an object schema
``{"type": "object", "properties": {name: property}, "required": [...]}``.
The Studies panel renders it as a form, the same renderer that
shows a Plugin objective's ``args_schema``; ``check_settings`` validates a
record against it. One schema serves both, so a third-party method needs no
frontend code.

Supported property keys: ``type`` (``number``, ``integer``, ``string``,
``boolean``, ``array``, ``object``), ``enum``, ``default``, ``minimum``,
``maximum``, ``exclusiveMinimum``, ``exclusiveMaximum``, ``items`` (for
arrays), ``minItems``, ``title``, ``description``. Other keys are ignored
here and passed to the panel as they are; the panel reads ``enum_titles``
(display names of the ``enum`` values, same order, e.g. ``SGD`` for
``sgd``), ``show_if`` and ``placeholder`` (text of an empty number field,
the value used when the setting is unset, e.g. ``"1/n"``; ``SchemaForm.tsx``).
"""
from __future__ import annotations

import copy
import math
from typing import Any, Mapping

from ..studies._errors import invalid


def check_settings(schema: Mapping[str, Any], values: Mapping[str, Any], what: str) -> dict[str, Any]:
    """``values`` checked against ``schema``, with defaults filled in.

    Keys the schema does not declare are kept unchanged, so a record written
    by a newer method version survives a round trip. A declared key that is
    missing (or None) takes its ``default``; without a default it stays
    absent unless ``required`` lists it, which raises. Raises
    ``StudyError(invalid_study)`` naming ``what.key``.
    """
    if not isinstance(values, Mapping):
        raise invalid(f"{what} must be a table, not {type(values).__name__}")
    properties = schema.get("properties") or {}
    required = set(schema.get("required") or ())
    out = {key: value for key, value in values.items() if value is not None}
    for name, prop in properties.items():
        if name not in out:
            if "default" in prop:
                out[name] = copy.deepcopy(prop["default"])
            elif name in required:
                raise invalid(f"{what}.{name} is required")
            continue
        out[name] = check_value(out[name], prop, f"{what}.{name}")
    return out


def check_value(value: Any, prop: Mapping[str, Any], what: str) -> Any:
    """One value checked against one property schema; returns it normalized (int -> float for numbers)."""
    kind = prop.get("type")
    if kind in ("number", "integer"):
        value = _number(value, kind, what)
        _check_range(value, prop, what)
    elif kind == "string" and not isinstance(value, str):
        raise invalid(f"{what} must be a string, not {value!r}")
    elif kind == "boolean" and not isinstance(value, bool):
        raise invalid(f"{what} must be true or false, not {value!r}")
    elif kind == "object" and not isinstance(value, Mapping):
        raise invalid(f"{what} must be a table, not {value!r}")
    elif kind == "array":
        if isinstance(value, (str, bytes, Mapping)) or not hasattr(value, "__iter__"):
            raise invalid(f"{what} must be a list, not {value!r}")
        value = list(value)
        if len(value) < int(prop.get("minItems", 0)):
            raise invalid(f"{what} needs at least {prop['minItems']} item(s)")
        if isinstance(prop.get("items"), Mapping):
            value = [check_value(item, prop["items"], f"{what}[{i}]") for i, item in enumerate(value)]
    if "enum" in prop and value not in prop["enum"]:
        allowed = ", ".join(str(item) for item in prop["enum"])
        raise invalid(f"{what} must be one of {allowed}, not {value!r}")
    return value


# A finite number; ``integer`` also needs a whole number (bool is never a number).
def _number(value: Any, kind: str, what: str) -> float | int:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise invalid(f"{what} must be a finite number, not {value!r}")
    if kind == "integer":
        if value != int(value):
            raise invalid(f"{what} must be a whole number, not {value!r}")
        return int(value)
    return float(value)


def _check_range(value: float, prop: Mapping[str, Any], what: str) -> None:
    if "minimum" in prop and value < prop["minimum"]:
        raise invalid(f"{what} must be >= {prop['minimum']}, not {value!r}")
    if "maximum" in prop and value > prop["maximum"]:
        raise invalid(f"{what} must be <= {prop['maximum']}, not {value!r}")
    if "exclusiveMinimum" in prop and value <= prop["exclusiveMinimum"]:
        raise invalid(f"{what} must be > {prop['exclusiveMinimum']}, not {value!r}")
    if "exclusiveMaximum" in prop and value >= prop["exclusiveMaximum"]:
        raise invalid(f"{what} must be < {prop['exclusiveMaximum']}, not {value!r}")
