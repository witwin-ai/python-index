"""The outcome of one run; ``to_dict()`` is a Run's ``result.json`` (version 2) (plan §3.5).

::

    {"version": 2, "study_id", "scene_id", "kind", "method", "direction", "stopped_by",
     "seed", "variables": [names], "param_ids": {name: param_id},
     "best": {...}, "last": {...}, "summary": {...},
     "evaluation_count", "failed_count", "evaluations_file": "evaluations.jsonl",
     "steps": [...],        # gradient method only, as in version 1
     "tensors": {id: {shape, label, best, last}},   # tensor design variables only
     "error": {code, message, data?}}

``kind`` is the method kind; ``method`` is the torch optimizer for the
gradient method (as in version 1) and the kind otherwise. ``best`` / ``last``
are ``{step, loss, values}`` for the gradient method (version 1 shape) and
``{index, loss, values}`` otherwise. Each evaluation is one line of
``evaluations_file`` (``EvalRecord.to_dict``). ``tensors.<id>.best`` /
``.last`` are files next to ``result.json`` (``tensors/<id>.best.npy``,
``tensors/<id>.npy``); ``values`` never holds tensors.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from ..studies._errors import StudyError
from ._records import EvalRecord, EvalStatus, StepRecord, StopReason
from ..studies._model import GRADIENT_KIND, Direction

if TYPE_CHECKING:
    from .._scene import Scene

RESULT_VERSION = 2


@dataclass
class OptimizationResult:
    """Outcome of ``optimize.run``.

    ``evaluations`` holds every evaluation (one per step for the gradient
    method). ``best`` / ``last``: for the gradient method the best and last
    ``StepRecord`` of ``steps`` (as in version 1); for other methods the best
    and last ``EvalRecord`` that did not fail. None when there is none.
    ``param_ids`` maps each variable's name to its parameter id, so a renamed
    parameter can still be found when the result is applied.
    """
    study_id: str
    scene_id: str
    direction: Direction
    method: str
    param_ids: dict[str, str]
    stopped_by: StopReason = StopReason.MAX_ITERS
    error: StudyError | None = None
    steps: list[StepRecord] = field(default_factory=list)
    best: StepRecord | EvalRecord | None = None
    kind: str = GRADIENT_KIND
    variables: list[str] = field(default_factory=list)
    evaluations: list[EvalRecord] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)
    seed: int | None = None
    evaluations_file: str | None = None
    # Tensor design variables: id -> {shape, label}; tensor_data["best" | "last"] -> {id: tensor}.
    tensors: dict[str, dict[str, Any]] = field(default_factory=dict)
    tensor_data: dict[str, dict[str, Any]] = field(default_factory=dict)

    @property
    def last(self) -> StepRecord | EvalRecord | None:
        if self.kind == GRADIENT_KIND:
            return self.steps[-1] if self.steps else None
        return next((r for r in reversed(self.evaluations) if r.ok), None)

    @property
    def failed_count(self) -> int:
        return sum(1 for r in self.evaluations if r.status is EvalStatus.FAILED)

    # JSON-ready form (``optimization.json``).
    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "version": RESULT_VERSION, "study_id": self.study_id, "scene_id": self.scene_id,
            "kind": self.kind, "method": str(self.method), "direction": str(self.direction),
            "stopped_by": str(self.stopped_by), "seed": self.seed,
            "variables": list(self.variables), "param_ids": dict(self.param_ids),
            "best": _snapshot(self.best), "last": _snapshot(self.last),
            "summary": dict(self.summary), "evaluation_count": len(self.evaluations),
            "failed_count": self.failed_count,
        }
        if self.evaluations_file is not None:
            out["evaluations_file"] = self.evaluations_file
        if self.kind == GRADIENT_KIND:
            out["steps"] = [record.to_dict() for record in self.steps]
        if self.tensors:
            out["tensors"] = {tensor_id: {**meta, "best": f"tensors/{tensor_id}.best.npy",
                                          "last": f"tensors/{tensor_id}.npy"}
                              for tensor_id, meta in self.tensors.items()}
        if self.error is not None:
            out["error"] = self.error.to_dict()
        return out

    # The evaluation with this 1-based index; KeyError when there is none.
    def evaluation(self, index: int) -> EvalRecord:
        for record in self.evaluations:
            if record.index == index:
                return record
        raise KeyError(index)

    # Write a point's values into the Scene's parameters (not saved).
    def apply(self, scene: "Scene", which: Literal["best", "last"] | int = "best", *,
              project_root: Path | str | None = None) -> dict[str, float]:
        """``which`` is ``"best"``, ``"last"`` or an evaluation index. Each
        parameter is found by id and gets its value as a number formula.
        Returns the written values by current parameter name. Raises
        ValueError when there is no such point (or it failed).

        Tensor design variables of ``best`` / ``last`` are written to
        ``<project>/assets/design/<id>.npy`` right away (that is a Project
        file, not part of the Scene); an evaluation index writes scalars only.
        ``project_root`` defaults to the Project of the Scene's file.
        """
        if isinstance(which, int) and not isinstance(which, bool):
            try:
                record: Any = self.evaluation(which)
            except KeyError:
                raise ValueError(f"the run has no evaluation {which}") from None
            if not record.ok:
                raise ValueError(f"evaluation {which} failed; nothing to apply")
        else:
            record = self.best if which == "best" else self.last
        if record is None:
            raise ValueError("the run finished no evaluation; nothing to apply")
        written = {}
        for name, value in record.values.items():
            current = scene.formulas.parameter(self.param_ids[name]).name
            scene.parameters.set(current, repr(float(value)))
            written[current] = float(value)
        tensors = self.tensor_data.get(which) if isinstance(which, str) else None
        if tensors:
            from ._runner import _project_root
            from ._tensors import design_tensor_path, save_array

            root = Path(project_root) if project_root is not None else _project_root(scene)
            if root is None:
                raise ValueError("tensor design variables need the Project folder; pass project_root")
            for tensor_id, value in tensors.items():
                save_array(design_tensor_path(root, tensor_id), value.detach().cpu().numpy())
        return written


# ``best`` / ``last`` of optimization.json.
def _snapshot(record: StepRecord | EvalRecord | None) -> dict[str, Any] | None:
    if record is None:
        return None
    if isinstance(record, StepRecord):
        return {"step": record.step, "loss": record.loss, "values": dict(record.values)}
    return {"index": record.index, "loss": record.loss, "values": dict(record.values)}
