"""Run checkpoints in the Run's output folder (plan §5.8): ``checkpoint.pt`` of a
gradient run, ``checkpoint.json`` of a black-box run (end of this module).

A gradient checkpoint is everything a later run needs to go on as if it
had never stopped::

    {"format": FORMAT, "study_id", "step": <last step done>, "seed",
     "optimizer": "adam" | "sgd" | "lbfgs" | "mma", "bounds": "clamp" | "sigmoid" | "box",
     "raw": {key: tensor},                  # the optimizer's own variables
     "values": {name: float}, "tensors": {id: tensor},   # physical values
     "optimizer_state": {...},              # torch state_dict, or MMA's
     "lr": float | None,                    # learning rate of the last step
     "beta": {id: [beta, ...]},             # each projection's current beta
     "last_loss": float | None}             # for the tolerance test of the next step

It is written with ``torch.save`` and read with ``weights_only=True`` (plain
containers, numbers, strings and tensors only), so loading one never runs
code. Writes go through a temporary file and ``os.replace``, so a run killed
while saving leaves the previous checkpoint.

A resumed run continues the step numbers. It loads the optimizer's state
only when the optimizer and the bound mode are the same as when the
checkpoint was written; otherwise it starts the new optimizer from the saved
physical values.
"""
from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path
from typing import Any

from ..studies._errors import ErrorCode, StudyError

CHECKPOINT_FILE = "checkpoint.pt"
FORMAT = "witwin.optimize.checkpoint.v1"


def save(path: Path, state: dict[str, Any]) -> None:
    """Write ``state`` (see the module doc) atomically."""
    import torch

    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    with os.fdopen(fd, "wb") as f:
        torch.save({"format": FORMAT, **state}, f)
    _replace(tmp, path)


def _replace(tmp: str, path: Path, attempts: int = 20) -> None:
    """``os.replace`` that waits out another program's handle on Windows.

    Windows refuses to replace a file that another handle has open
    (WinError 5). Virus scanners and the search indexer open a file just
    written, so a Run that saves twice in quick succession failed with
    "PermissionError: [WinError 5]" (seen in optimization.web.spec.ts). The
    scan lasts milliseconds; retrying for up to ~1 s, as
    ``workflows._replace`` does, is enough. The last failure still raises.
    """
    for attempt in range(attempts):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            if attempt == attempts - 1:
                raise
            time.sleep(0.05)


def load(path: Path | str) -> dict[str, Any]:
    """A checkpoint written by ``save``; ``path`` may be the file or the Run folder holding it.

    Raises ``StudyError(checkpoint_invalid)`` when it is missing or unreadable.
    """
    import torch

    path = Path(path)
    if path.is_dir():
        path = path / CHECKPOINT_FILE
    if not path.is_file():
        raise StudyError(ErrorCode.CHECKPOINT_INVALID, f"no checkpoint at {path}")
    try:
        state = torch.load(path, map_location="cpu", weights_only=True)
    except Exception as exc:  # noqa: BLE001 - any unreadable file is the same refusal
        raise StudyError(ErrorCode.CHECKPOINT_INVALID,
                                f"{path.name} cannot be read: {type(exc).__name__}: {exc}") from None
    if not isinstance(state, dict) or state.get("format") != FORMAT:
        raise StudyError(ErrorCode.CHECKPOINT_INVALID, f"{path.name} is not a {FORMAT} checkpoint")
    return state


# ---------------------------------------------------------------------- black-box runs
# ``BatchDriver`` keeps a JSON checkpoint instead: a strategy's ``state_dict``
# is JSON-ready, and the evaluations themselves are already in the Run's
# ``evaluations.jsonl``, so the file stays small::
#
#     {"format": BATCH_FORMAT, "study_id", "kind", "seed",
#      "batch": <batches done>, "evaluations": <records done>,
#      "strategy": <Strategy.state_dict()>}
#
# A resumed run reads the first ``evaluations`` lines of the
# ``evaluations.jsonl`` next to the checkpoint.

BATCH_CHECKPOINT_FILE = "checkpoint.json"
BATCH_FORMAT = "witwin.optimize.batch_checkpoint.v1"


def save_batch(path: Path, state: dict[str, Any]) -> None:
    """Write a black-box checkpoint atomically."""
    import json

    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
        json.dump({"format": BATCH_FORMAT, **state}, f)
    _replace(tmp, path)


def load_batch(path: Path | str) -> tuple[dict[str, Any], Path]:
    """A checkpoint written by ``save_batch`` and the folder holding it; ``path`` may be that folder.

    Raises ``StudyError(checkpoint_invalid)`` when it is missing or unreadable.
    """
    import json

    path = Path(path)
    if path.is_dir():
        path = path / BATCH_CHECKPOINT_FILE
    if not path.is_file():
        raise StudyError(ErrorCode.CHECKPOINT_INVALID, f"no checkpoint at {path}")
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise StudyError(ErrorCode.CHECKPOINT_INVALID,
                                f"{path.name} cannot be read: {type(exc).__name__}: {exc}") from None
    if not isinstance(state, dict) or state.get("format") != BATCH_FORMAT:
        raise StudyError(ErrorCode.CHECKPOINT_INVALID, f"{path.name} is not a {BATCH_FORMAT} checkpoint")
    return state, path.parent


def find(folder: Path) -> Path | None:
    """The checkpoint a Run folder holds (gradient ``checkpoint.pt`` or black-box ``checkpoint.json``)."""
    for name in (CHECKPOINT_FILE, BATCH_CHECKPOINT_FILE):
        if (folder / name).is_file():
            return folder / name
    return None
