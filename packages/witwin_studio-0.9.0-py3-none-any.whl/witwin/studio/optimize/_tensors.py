"""Tensor design variables: the Study's ``tensors`` table and their Project files (plan §5.3).

A tensor design variable is a whole array the gradient method optimizes,
such as a density field. Its settings live in the Study record::

    [optimization.tensors.rho]
    shape = [40, 20]
    init = "constant"        # zeros | ones | random | constant | file
    value = 0.5              # used by init = "constant"
    lower = 0.0
    upper = 1.0
    label = "core"           # free text; only the objective interprets it
    transforms = [{kind = "filter", radius = 2.0},
                  {kind = "projection", beta = 1.0, eta = 0.5, beta_max = 32.0, every = 40}]

Its data lives in the Project, as user content, at ``assets/design/<id>.npy``
(created when a run's result is applied). That file is the tensor's current
value, like a parameter's value: a run starts from it when it exists, and
``init`` only gives the start value before the first Apply. ``init = "file"``
requires the file. ``random`` draws uniformly in ``[lower, upper]`` from the
run's seed.

``label`` is not a solver concept: the core never reads it. An objective
reads the tensor with ``ctx.tensor(id)`` and decides what it means.

Only the gradient method runs Studies with tensors; every other method
refuses them (``tensors_unsupported``). Reading and writing ``.npy`` files
needs numpy.
"""
from __future__ import annotations

import math
import os
import re
import tempfile
from pathlib import Path
from typing import Any, Mapping

from ..studies._errors import invalid

DESIGN_DIR = ("assets", "design")
INIT_KINDS = ("zeros", "ones", "random", "constant", "file")
TRANSFORM_KINDS = ("filter", "projection")
MAX_DIMS = 3
# Ids name files, so they keep to a portable file-name alphabet.
_ID_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_\-]{0,63}$")

__all__ = [
    "DESIGN_DIR", "INIT_KINDS", "TRANSFORM_KINDS", "check_tensor", "design_tensor_path",
    "load_array", "save_array",
]


def check_tensor(tensor_id: Any, settings: Any) -> dict[str, Any]:
    """One ``tensors.<id>`` table checked, defaults filled; raises ``invalid_study``.

    Defaults: ``init = "zeros"``, ``lower = 0``, ``upper = 1``, ``label = ""``,
    ``transforms = []``; ``value`` defaults to the middle of the bounds.
    ``shape`` is required: 1 to 3 whole numbers >= 1.
    """
    if not isinstance(tensor_id, str) or not _ID_PATTERN.match(tensor_id):
        raise invalid(f"tensors keys must be ids of letters, digits, '_' or '-', not {tensor_id!r}")
    what = f"tensors.{tensor_id}"
    if not isinstance(settings, Mapping):
        raise invalid(f"{what} must be a table, not {type(settings).__name__}")
    out = {key: value for key, value in settings.items() if value is not None}
    out["shape"] = _shape(out.get("shape"), f"{what}.shape")
    out["init"] = out.get("init", "zeros")
    if out["init"] not in INIT_KINDS:
        raise invalid(f"{what}.init must be one of {', '.join(INIT_KINDS)}, not {out['init']!r}")
    out["lower"] = _number(out.get("lower", 0.0), f"{what}.lower")
    out["upper"] = _number(out.get("upper", 1.0), f"{what}.upper")
    if not out["lower"] < out["upper"]:
        raise invalid(f"{what} needs lower < upper, not {out['lower']} and {out['upper']}")
    out["value"] = _number(out.get("value", 0.5 * (out["lower"] + out["upper"])), f"{what}.value")
    label = out.get("label", "")
    if not isinstance(label, str):
        raise invalid(f"{what}.label must be a string, not {label!r}")
    out["label"] = label
    transforms = out.get("transforms", [])
    if isinstance(transforms, (str, bytes, Mapping)) or not hasattr(transforms, "__iter__"):
        raise invalid(f"{what}.transforms must be a list, not {transforms!r}")
    out["transforms"] = [_transform(item, len(out["shape"]), f"{what}.transforms[{i}]")
                         for i, item in enumerate(transforms)]
    return out


def design_tensor_path(project_root: Path | str, tensor_id: str) -> Path:
    """``<project>/assets/design/<id>.npy``, the tensor's value in the Project."""
    return Path(project_root).joinpath(*DESIGN_DIR, f"{tensor_id}.npy")


def load_array(path: Path | str) -> Any:
    """A ``.npy`` file as a numpy array (float64)."""
    import numpy as np

    return np.load(Path(path), allow_pickle=False).astype(np.float64)


def save_array(path: Path | str, array: Any) -> Path:
    """Write ``array`` as ``.npy`` atomically (folders created on demand); returns the path."""
    import numpy as np

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.stem}.", suffix=".npy", dir=path.parent)
    with os.fdopen(fd, "wb") as f:
        np.save(f, np.asarray(array, dtype=np.float64), allow_pickle=False)
    os.replace(tmp, path)
    return path


# ``shape``: a list of 1..MAX_DIMS whole numbers >= 1.
def _shape(value: Any, what: str) -> list[int]:
    if isinstance(value, (str, bytes, Mapping)) or not hasattr(value, "__iter__"):
        raise invalid(f"{what} is required: a list of 1 to {MAX_DIMS} sizes, not {value!r}")
    sizes = list(value)
    if not 1 <= len(sizes) <= MAX_DIMS:
        raise invalid(f"{what} must have 1 to {MAX_DIMS} sizes, not {len(sizes)}")
    for size in sizes:
        if isinstance(size, bool) or not isinstance(size, (int, float)) or size != int(size) or size < 1:
            raise invalid(f"{what} sizes must be whole numbers >= 1, not {size!r}")
    return [int(size) for size in sizes]


# One transform entry, defaults filled (see transforms.build).
def _transform(item: Any, dims: int, what: str) -> dict[str, Any]:
    if not isinstance(item, Mapping):
        raise invalid(f"{what} must be a table, not {item!r}")
    kind = item.get("kind")
    out = {key: value for key, value in item.items() if value is not None}
    if kind == "filter":
        out["radius"] = _number(out.get("radius"), f"{what}.radius")
        if out["radius"] <= 0:
            raise invalid(f"{what}.radius must be > 0 cells, not {out['radius']}")
        return out
    if kind == "projection":
        out["beta"] = _number(out.get("beta", 1.0), f"{what}.beta")
        out["eta"] = _number(out.get("eta", 0.5), f"{what}.eta")
        out["beta_max"] = _number(out.get("beta_max", out["beta"]), f"{what}.beta_max")
        out["factor"] = _number(out.get("factor", 2.0), f"{what}.factor")
        every = out.get("every", 0)
        if isinstance(every, bool) or not isinstance(every, (int, float)) or every != int(every) or every < 0:
            raise invalid(f"{what}.every must be a whole number >= 0, not {every!r}")
        out["every"] = int(every)
        if out["beta"] <= 0:
            raise invalid(f"{what}.beta must be > 0, not {out['beta']}")
        if not 0.0 <= out["eta"] <= 1.0:
            raise invalid(f"{what}.eta must be in [0, 1], not {out['eta']}")
        if out["beta_max"] < out["beta"]:
            raise invalid(f"{what}.beta_max must be >= beta, not {out['beta_max']}")
        if out["factor"] <= 1.0:
            raise invalid(f"{what}.factor must be > 1, not {out['factor']}")
        return out
    raise invalid(f"{what}.kind must be one of {', '.join(TRANSFORM_KINDS)}, not {kind!r}")


def _number(value: Any, what: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise invalid(f"{what} must be a finite number, not {value!r}")
    return float(value)
