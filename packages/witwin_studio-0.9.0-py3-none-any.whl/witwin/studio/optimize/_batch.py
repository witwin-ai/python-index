"""The black-box driver (plan §3.1): an ask/tell loop around a method's ``Strategy``.

Each turn the strategy asks for a batch of points; the driver snaps them
(``step`` rounding, bounds), serves repeats from its cache, evaluates the
rest through an ``Evaluator``, records one ``EvalRecord`` per new point and
tells the strategy every record of the batch. The run ends when:

- the strategy asks for nothing (``max_iters``, or ``converged`` when the
  strategy says so);
- ``budget.max_evals`` evaluations ran or ``budget.max_time_s`` passed
  (``budget``); a batch that would go past ``max_evals`` is cut;
- a stop is requested or KeyboardInterrupt (``stopped``);
- an evaluation failed and ``on_error = "stop"`` (``error``). With the
  default ``"skip"`` a failed evaluation is recorded and the run goes on.

Cache: two points with the same values (each rounded to 12 significant
digits, plan §3.2) are evaluated once; the repeat is not counted against the
budget and the strategy gets the earlier record. A strategy that keeps asking
only for cached points is ended after ``MAX_IDLE_BATCHES`` such batches
(``converged``).

Progress: ``on_progress(index, outcome)`` is called as each evaluation of a
batch finishes, so a batch of slow evaluations still moves the progress bar;
``on_evaluation`` and ``on_batch`` (the records, the partials) come once the
batch is done.

Checkpoints (plan §5.8): with an ``output_dir`` the driver writes
``checkpoint.json`` (``_checkpoint.save_batch``) after a batch, at most every
``CHECKPOINT_INTERVAL_S``, and when the run ends. ``resume_from`` (that file,
or the Run folder holding it) restores the strategy (``load_state_dict``),
the seed and the evaluations done; the resumed run reports those
evaluations first, continues their indexes and counts them against
``budget.max_evals``.

A checkpoint only ever holds the state after a complete batch: a batch cut
short (a stop, the budget, the time limit) has advanced the strategy past
points that were never evaluated, so its state is not saved. The resumed
run asks that whole batch again and evaluates its points anew; their
earlier lines in ``evaluations.jsonl`` (past the checkpoint's count) are
ignored.
"""
from __future__ import annotations

import math
import secrets
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Mapping

from . import _checkpoint
from ..studies._errors import ErrorCode, StudyError
from ._evaluate import Outcome
from ._evaluators import Evaluator, EvaluatorSetup, make_evaluator
from ._objectives import ObjectiveFn
from ._records import EvalRecord, StopReason
from ._report import read_evaluations
from ._result import OptimizationResult
from ._space import DesignSpace, design_space
from ._strategies.base import Candidate, Optimizer, StrategySetup
from ..studies._model import OnError, Study

if TYPE_CHECKING:
    from .._scene import Scene

MAX_IDLE_BATCHES = 1000
SEED_LIMIT = 2 ** 31  # seeds drawn for a run without one are in [0, SEED_LIMIT)
CHECKPOINT_INTERVAL_S = 2.0  # least time between two checkpoint writes during a run
EVALUATIONS_FILE = "evaluations.jsonl"  # the Run folder's log a checkpoint counts lines of

BatchCallback = Callable[[int, list[EvalRecord], dict[str, Any]], None]
ProgressCallback = Callable[[int, Outcome], None]


class BatchDriver:
    """One black-box run: design space, strategy, evaluator and records."""

    def __init__(self, scene: "Scene", study: Study, fn: ObjectiveFn, root: Path | None,
                 optimizer: Optimizer, *, evaluator: Evaluator | None = None,
                 project_dir: Path | None = None, output_dir: Path | str | None = None,
                 resume_from: Path | str | None = None, sample_dir: Path | None = None) -> None:
        from ..formula import FLOAT_BACKEND

        self._study = study
        free = scene.formulas.compile(FLOAT_BACKEND).inputs
        self.space: DesignSpace = design_space(scene, study.variables, free=free,
                                               requires_bounds=optimizer.requires_bounds)
        saved, saved_dir = (None, None) if resume_from is None else _checkpoint.load_batch(resume_from)
        if saved is not None:
            _check_checkpoint(saved, study)
            seed = int(saved["seed"])  # a strategy may rebuild its draws from the seed (Monte Carlo)
        else:
            seed = study.seed if study.seed is not None else secrets.randbelow(SEED_LIMIT)
        self.setup = StrategySetup(self.space, dict(study.method.settings), seed, study.budget,
                                   study.direction, root)
        self.strategy = optimizer.factory(self.setup)
        sample = None
        if sample_dir is not None:
            # Dataset run: ``fn`` is the export; it stages each sample under ``sample_dir``.
            from ..datasets._writer import SampleExport

            sample = {"staging": str(sample_dir), "seed": seed, "variables": list(self.space.names)}
            fn = SampleExport(fn, **sample)
        self._evaluator = evaluator or make_evaluator(EvaluatorSetup(
            scene, fn, root, study.budget, study, project_dir=project_dir, scene_id=scene.id,
            sample=sample))
        self._cache: dict[tuple[float, ...], EvalRecord] = {}
        self._started = time.monotonic()
        self._output_dir = None if output_dir is None else Path(output_dir)
        self._saved_at: float | None = None
        self._snapshot: dict[str, Any] | None = None  # state after the last complete batch
        self._snapshot_saved = True                   # _snapshot is the file's content
        self._batch = 0      # batches done, restored ones included
        self._in_flight = 0  # evaluations of the current batch finished so far
        self._restored: list[EvalRecord] = []
        self.result = OptimizationResult(study.id, scene.id, study.direction, study.method.kind,
                                         {v.name: v.param_id for v in self.space.variables},
                                         kind=study.method.kind, variables=list(self.space.names),
                                         seed=seed)
        if saved is not None:
            self._resume(saved, saved_dir)

    @property
    def progress(self) -> float:
        """Fraction done in [0, 1]: evaluations of the expected total, or time of the time budget."""
        budget, done = self._study.budget, len(self.result.evaluations) + self._in_flight
        total = budget.max_evals or getattr(self.strategy, "expected_evals", None)
        fractions = [done / total] if total else []
        if budget.max_time_s:
            fractions.append((time.monotonic() - self._started) / budget.max_time_s)
        return min(1.0, max(fractions, default=0.0))

    def loop(self, on_evaluation: Callable[[EvalRecord], None] | None = None,
             on_batch: BatchCallback | None = None,
             should_stop: Callable[[], bool] | None = None,
             on_progress: ProgressCallback | None = None) -> OptimizationResult:
        """Run until a stop condition; returns the result (never raises for a failed evaluation)."""
        result = self.result
        stop = should_stop or (lambda: False)
        idle = 0
        if self._snapshot is None:  # the state before the first batch: a run stopped in it can go on
            self._take_snapshot()
        if self._restored:  # a resumed run first reports what it continues, as one batch
            for record in self._restored:
                if on_evaluation is not None:
                    on_evaluation(record)
            if on_batch is not None:
                on_batch(self._batch, list(self._restored), dict(self.strategy.summary() or {}))
        try:
            while True:
                if stop():
                    result.stopped_by = StopReason.STOPPED
                    break
                if self._out_of_budget():
                    result.stopped_by = StopReason.BUDGET
                    break
                asked = [_candidate(item) for item in self.strategy.ask()]
                if not asked:
                    converged = bool(getattr(self.strategy, "converged", False))
                    result.stopped_by = StopReason.CONVERGED if converged else StopReason.MAX_ITERS
                    break
                self._batch += 1
                ended, evaluated, complete = self._run_batch(self._batch, asked, stop, on_evaluation,
                                                             on_batch, on_progress)
                if complete:
                    self._take_snapshot()
                    self._save_checkpoint(force=False)
                if ended is not None:
                    result.stopped_by = ended
                    break
                idle = 0 if evaluated else idle + 1
                if idle >= MAX_IDLE_BATCHES:
                    result.stopped_by = StopReason.CONVERGED
                    break
        except KeyboardInterrupt:
            result.stopped_by = StopReason.STOPPED
        finally:
            self._evaluator.close()
        self._save_checkpoint(force=True)
        result.summary = dict(self.strategy.summary() or {})
        return result

    # Evaluate one batch and tell the strategy; returns (stop reason or None, evaluations run,
    # whether every asked point has a record).
    def _run_batch(self, batch: int, asked: list[Candidate], stop: Callable[[], bool],
                   on_evaluation: Callable[[EvalRecord], None] | None,
                   on_batch: BatchCallback | None,
                   on_progress: ProgressCallback | None = None) -> tuple[StopReason | None, int, bool]:
        result, budget = self.result, self._study.budget
        points = [self.space.snap(item.values) for item in asked]
        keys = [_key(self.space, values) for values in points]
        fresh: list[int] = []  # positions to evaluate: first sight of a key not in the cache
        seen: set[tuple[float, ...]] = set()
        for position, key in enumerate(keys):
            if key not in self._cache and key not in seen:
                seen.add(key)
                fresh.append(position)
        ended = None
        if budget.max_evals is not None:
            room = budget.max_evals - len(result.evaluations)
            if len(fresh) > room:
                fresh, ended = fresh[:room], StopReason.BUDGET
        first = len(result.evaluations) + 1
        indexes = list(range(first, first + len(fresh)))

        def done(position: int, outcome: Outcome) -> None:
            self._in_flight += 1
            if on_progress is not None:
                on_progress(indexes[position], outcome)

        try:
            outcomes = self._evaluator.evaluate_batch(
                [points[p] for p in fresh], indexes,
                should_stop=lambda: stop() or self._out_of_time(), on_done=done) if fresh else []
        finally:
            self._in_flight = 0
        new: list[EvalRecord] = []
        failure: StudyError | None = None
        for position, index, outcome in zip(fresh, indexes, outcomes):
            record = self._record(index, batch, points[position], outcome, asked[position].note)
            self._cache[keys[position]] = record
            result.evaluations.append(record)
            new.append(record)
            self._update_best(record)
            if on_evaluation is not None:
                on_evaluation(record)
            if outcome.error is not None and failure is None:
                failure = outcome.error
        told = []
        for key in keys:  # the prefix of the batch that has a record
            if key not in self._cache:
                break
            told.append(self._cache[key])
        self.strategy.tell(told)
        complete = len(told) == len(keys)
        if on_batch is not None:
            on_batch(batch, new, dict(self.strategy.summary() or {}))
        if failure is not None and self._study.on_error is OnError.STOP:
            result.error = failure
            return StopReason.ERROR, len(new), complete
        if len(outcomes) < len(fresh):
            return (StopReason.STOPPED if stop() else StopReason.BUDGET), len(new), complete
        return ended, len(new), complete

    def _record(self, index: int, batch: int, values: dict[str, float], outcome: Outcome,
                note: str | None) -> EvalRecord:
        return EvalRecord(index, batch, values, outcome.loss, outcome.status,
                          dict(outcome.metrics), outcome.duration_s,
                          None if outcome.error is None else outcome.error.message,
                          unit=self.space.to_unit(values), note=note, worker=outcome.worker)

    # Restore a checkpoint's evaluations and strategy (see the module doc).
    def _resume(self, saved: Mapping[str, Any], folder: Path) -> None:
        count = int(saved.get("evaluations", 0))
        rows = sorted((row for row in read_evaluations(folder / EVALUATIONS_FILE)
                       if isinstance(row.get("index"), int) and 1 <= row["index"] <= count),
                      key=lambda row: row["index"])
        if len(rows) != count:
            raise StudyError(ErrorCode.CHECKPOINT_INVALID,
                                    f"the checkpoint counts {count} evaluations, "
                                    f"{EVALUATIONS_FILE} next to it has {len(rows)}")
        for row in rows:
            record = EvalRecord.from_dict(row)
            self._cache[_key(self.space, record.values)] = record
            self.result.evaluations.append(record)
            self._update_best(record)
        self._restored = list(self.result.evaluations)
        self._batch = int(saved.get("batch", 0))
        self.strategy.load_state_dict(saved.get("strategy") or {})
        self._take_snapshot()  # so a resumed run stopped before its first batch can be continued too

    # Remember the state after a complete batch; _save_checkpoint writes it.
    def _take_snapshot(self) -> None:
        if self._output_dir is None:
            return
        study = self._study
        self._snapshot = {
            "study_id": study.id, "kind": study.method.kind, "seed": self.setup.seed,
            "batch": self._batch, "evaluations": len(self.result.evaluations),
            "strategy": self.strategy.state_dict(),
        }
        self._snapshot_saved = False

    # Write the last snapshot to checkpoint.json; at most every CHECKPOINT_INTERVAL_S unless forced.
    def _save_checkpoint(self, *, force: bool) -> None:
        if self._output_dir is None or self._snapshot is None or self._snapshot_saved:
            return
        now = time.monotonic()
        if not force and self._saved_at is not None and now - self._saved_at < CHECKPOINT_INTERVAL_S:
            return
        self._saved_at = now
        _checkpoint.save_batch(self._output_dir / _checkpoint.BATCH_CHECKPOINT_FILE, self._snapshot)
        self._snapshot_saved = True

    def _update_best(self, record: EvalRecord) -> None:
        if not record.ok:
            return
        best = self.result.best
        if best is None or self.setup.score(record) < self.setup.score(best):  # type: ignore[arg-type]
            self.result.best = record

    def _out_of_time(self) -> bool:
        limit = self._study.budget.max_time_s
        return limit is not None and time.monotonic() - self._started >= limit

    def _out_of_budget(self) -> bool:
        limit = self._study.budget.max_evals
        return self._out_of_time() or (limit is not None and len(self.result.evaluations) >= limit)


# checkpoint_invalid unless the checkpoint is this Study's, with the same method.
def _check_checkpoint(saved: Mapping[str, Any], study: Study) -> None:
    if saved.get("study_id") != study.id:
        raise StudyError(ErrorCode.CHECKPOINT_INVALID,
                                f"the checkpoint belongs to study {saved.get('study_id')!r}, "
                                f"not {study.id!r}")
    if saved.get("kind") != study.method.kind:
        raise StudyError(ErrorCode.CHECKPOINT_INVALID,
                                f"the checkpoint was written by method {saved.get('kind')!r}; "
                                f"this Study now uses {study.method.kind!r}")


# An asked item as a Candidate.
def _candidate(item: Mapping[str, float] | Candidate) -> Candidate:
    return item if isinstance(item, Candidate) else Candidate(dict(item))


# Cache key: the values in variable order, each to 12 significant digits.
def _key(space: DesignSpace, values: Mapping[str, float]) -> tuple[float, ...]:
    return tuple(float(f"{values[name]:.12g}") if math.isfinite(values[name]) else values[name]
                 for name in space.names)

