"""What a run records: one ``EvalRecord`` per objective evaluation (plan §3.5).

An evaluation is one call of the objective at one set of design-variable
values. Every method records evaluations: a black-box method one per point it
asks for, the gradient method one per step (``index == step``). Records are
the lines of ``evaluations.jsonl`` and the ``records`` of a batch partial.

``index`` counts evaluations from 1 in the order they finished; ``batch``
counts the method's batches (a generation, a sweep chunk, a gradient step)
from 1. ``loss`` is the objective as returned, also for ``maximize``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Mapping

# Metric name prefix of a constraint value the objective returned (``constraint.volume``).
CONSTRAINT_PREFIX = "constraint."


class StopReason(StrEnum):
    MAX_ITERS = "max_iters"  # ran every step, or the method ran its whole plan
    TOL = "tol"              # |loss change| fell below the gradient method's tol
    BUDGET = "budget"        # budget.max_evals or budget.max_time_s used up
    CONVERGED = "converged"  # the method decided it has converged
    STOPPED = "stopped"      # should_stop(), KeyboardInterrupt or a stop request
    ERROR = "error"          # the objective failed; see OptimizationResult.error


class EvalStatus(StrEnum):
    OK = "ok"
    FAILED = "failed"  # the objective raised or returned no finite number; ``error`` says why


@dataclass(frozen=True)
class EvalRecord:
    """One objective evaluation.

    ``values``: parameter name -> value the objective saw (after rounding to
    ``step`` and clamping to the bounds). ``unit``: the same point in the
    normalized space [0, 1]^n of the run's ``DesignSpace``, in its variable
    order, or None when a variable has no bounds. ``loss`` is None when
    ``status`` is ``failed``. ``note`` is free text from the method (the
    Agentic method's reason for a point). ``worker`` is the process-pool
    worker (1..N, ``budget.parallel``) that ran it; None when the run's own
    process did.
    """
    index: int
    batch: int
    values: dict[str, float]
    loss: float | None
    status: EvalStatus = EvalStatus.OK
    metrics: dict[str, float] = field(default_factory=dict)
    duration_s: float = 0.0
    error: str | None = None
    grad_norm: float | None = None
    unit: tuple[float, ...] | None = None
    note: str | None = None
    worker: int | None = None

    @property
    def ok(self) -> bool:
        return self.status is EvalStatus.OK

    # One ``evaluations.jsonl`` line; optional keys only when set.
    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"index": self.index, "batch": self.batch, "values": dict(self.values),
                               "loss": self.loss, "metrics": dict(self.metrics),
                               "status": str(self.status), "duration_s": self.duration_s}
        if self.error is not None:
            out["error"] = self.error
        if self.grad_norm is not None:
            out["grad_norm"] = self.grad_norm
        if self.note is not None:
            out["note"] = self.note
        if self.worker is not None:
            out["worker"] = self.worker
        return out

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "EvalRecord":
        """Read one ``evaluations.jsonl`` line back (``unit`` is not stored)."""
        return cls(index=int(data["index"]), batch=int(data.get("batch", 0)),
                   values={k: float(v) for k, v in (data.get("values") or {}).items()},
                   loss=None if data.get("loss") is None else float(data["loss"]),
                   status=EvalStatus(data.get("status", EvalStatus.OK)),
                   metrics={k: float(v) for k, v in (data.get("metrics") or {}).items()},
                   duration_s=float(data.get("duration_s", 0.0)), error=data.get("error"),
                   grad_norm=None if data.get("grad_norm") is None else float(data["grad_norm"]),
                   note=data.get("note"),
                   worker=None if data.get("worker") is None else int(data["worker"]))


@dataclass(frozen=True)
class StepRecord:
    """One gradient step: the objective ``loss`` at ``values`` (parameter name -> float).

    ``metrics`` include each constraint as ``constraint.<name>``. ``lr`` is
    the learning rate the step used (None for MMA). ``beta``: tensor id ->
    its last projection's beta. ``tensors``: tensor id -> ``{min, max,
    mean}`` of the tensor after its transforms. ``feasible`` is False when a
    constraint was above 0.
    """
    step: int
    loss: float
    values: dict[str, float]
    grad_norm: float
    metrics: dict[str, float] = field(default_factory=dict)
    lr: float | None = None
    beta: dict[str, float] = field(default_factory=dict)
    tensors: dict[str, dict[str, float]] = field(default_factory=dict)
    feasible: bool = True

    # The partial payload and the ``steps`` entry of ``optimization.json``; new keys only when set.
    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"step": self.step, "loss": self.loss, "values": dict(self.values),
                               "grad_norm": self.grad_norm, "metrics": dict(self.metrics)}
        if self.lr is not None:
            out["lr"] = self.lr
        if self.beta:
            out["beta"] = dict(self.beta)
        if self.tensors:
            out["tensors"] = {key: dict(stats) for key, stats in self.tensors.items()}
        if not self.feasible:
            out["feasible"] = False
        return out
