"""Objective functions: what they receive, and where they are found (plan P9).

An objective takes an ``ObjectiveContext`` and returns the loss: a float, a
one-element tensor, or ``{"loss": ..., <metric>: ...}``. The gradient method
needs a tensor that carries the gradient of the design variables
(``ctx.differentiable`` is True then); every other method calls it under
``torch.no_grad()`` and accepts plain numbers. It comes from one of two
places:

- a Project script: a function in any ``.py`` file of the Project, the
  "Project is a Python codebase" rule;
- a Plugin: an object registered under the entry point group
  ``witwin.objectives`` with ``id``, ``title``, ``fn(ctx, **args)`` and
  ``args_schema``. The run process finds it through package metadata, so it
  never loads the Studio Plugin system.
"""
from __future__ import annotations

import hashlib
import importlib.util
import logging
import sys
from dataclasses import dataclass, field
from importlib import metadata
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Mapping

from ..formula import BindingTarget, FormulaValues
from ..studies._model import ErrorCode, ObjectiveKind, ObjectiveRef, StudyError

if TYPE_CHECKING:
    from .._scene import Scene

ENTRY_POINT_GROUP = "witwin.objectives"

logger = logging.getLogger("witwin.studio")


class ObjectiveContext:
    """What an objective function receives at each evaluation.

    Attributes:
        scene: the Scene being optimized. Treat it as read-only: the runner
            never saves it, and its field numbers are the values at the start
            of the run, not the current step's.
        values: the current evaluation's ``FormulaValues`` from the
            torch-compiled Formula Graph. Values downstream of a design
            variable are tensors (with its gradient when ``differentiable``);
            the rest are Python floats. Without torch every value is a float.
        step: 1-based step (gradient method) or evaluation index (others).
        differentiable: True when the caller needs a gradient (the gradient
            method). False for black-box methods: an objective may then skip
            work that only serves the gradient, such as an adjoint solve.
        project_root: the Project folder, or None for a loose Scene file.
        tensors: tensor design variable id -> torch tensor, after the
            tensor's transforms (gradient method only; see ``tensor``).
        worker: the process-pool worker running this evaluation (1..N when
            ``budget.parallel > 1``), or None in the run's own process. Use
            it to give each worker its own scratch folder or GPU.

    The objective returns the loss, or ``{"loss": ..., "constraints":
    {name: g}, <metric>: ...}``: each constraint ``g <= 0`` is feasible. MMA
    keeps to them; the other gradient optimizers add a quadratic penalty.
    Their values are recorded as metrics ``constraint.<name>``.
    """

    def __init__(self, scene: "Scene", values: FormulaValues, *,
                 project_root: Path | None = None) -> None:
        self.scene = scene
        self.values = values
        self.step = 0
        self.differentiable = True
        self.project_root = project_root
        self.metrics: dict[str, float] = {}
        self.tensors: dict[str, Any] = {}
        self.worker: int | None = None

    # SI value of one bound field component (with gradient when differentiable).
    def binding(self, entity_id: str, target: str, index: int | None = None) -> Any:
        """``ctx.binding("box", "Transform.scale", 0)``; KeyError if that field has no formula.

        Only fields bound to a formula change with the design variables; read
        any other field from ``scene``.
        """
        key = BindingTarget(entity_id, target, index)
        if key not in self.values.bindings:
            raise KeyError(f"{entity_id} {target}"
                           f"{'' if index is None else f'[{index}]'} has no formula that evaluates")
        return self.values.bindings[key]

    # Value of one parameter by name, with gradient when it depends on a design variable.
    def parameter(self, name: str) -> Any:
        if name not in self.values.parameters:
            raise KeyError(f"no parameter '{name}' that evaluates")
        return self.values.parameters[name]

    # A tensor design variable by id, after its transforms, with gradient.
    def tensor(self, tensor_id: str) -> Any:
        """``ctx.tensor("rho")``: shape and bounds as the Study's ``tensors.rho`` declares;
        KeyError when the Study has no such tensor."""
        if tensor_id not in self.tensors:
            raise KeyError(f"the study has no tensor design variable '{tensor_id}'")
        return self.tensors[tensor_id]

    # Record an extra number for this step; it goes into the progress and the result.
    def report(self, name: str, value: Any) -> None:
        """``value`` is a float or a one-element tensor."""
        item = getattr(value, "item", None)
        self.metrics[str(name)] = float(item() if callable(item) else value)


ObjectiveFn = Callable[[ObjectiveContext], Any]


@dataclass(frozen=True)
class Objective:
    """A Plugin's objective, the object its ``witwin.objectives`` entry point names.

    In the Plugin's ``pyproject.toml``::

        [project.entry-points."witwin.objectives"]
        transmission = "acme_solver.objectives:transmission"

    where ``transmission = Objective(id="acme_solver.transmission", title="Transmission",
    fn=transmission_loss, args_schema={...})``. ``fn(ctx, **args)`` gets the
    Study's ``objective.args``. ``args_schema`` is a JSON-schema-like dict the
    Studies panel renders as fields. Any object with these four
    attributes works; this class is a convenience.
    """
    id: str
    title: str
    fn: Callable[..., Any]
    args_schema: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class _Registered:
    objective: Any   # an Objective, or any object with the same attributes
    source: str      # distribution name, else the entry point value


def list_objectives() -> list[dict[str, Any]]:
    """Every installed Plugin objective: ``[{id, title, args_schema, source}]``.

    ``source`` is the name of the distribution that registers it. An entry
    point that fails to load or lacks an attribute is skipped with a warning.
    """
    return [{"id": str(item.objective.id), "title": str(item.objective.title),
             "args_schema": dict(item.objective.args_schema or {}), "source": item.source}
            for item in _registered()]


def resolve(ref: ObjectiveRef, project_root: Path | None) -> ObjectiveFn:
    """The callable a Study's objective names; raises ``StudyError``.

    ``objective_not_found`` for a missing file, function or Plugin id, and for
    a script path outside the Project; ``objective_failed`` when importing the
    script raises.
    """
    if ref.kind is ObjectiveKind.SCRIPT:
        return _script_function(ref, project_root)
    for item in _registered():
        if item.objective.id == ref.id:
            plugin_fn, args = item.objective.fn, dict(ref.args)
            return lambda ctx: plugin_fn(ctx, **args)
    raise StudyError(ErrorCode.OBJECTIVE_NOT_FOUND,
                            f"no installed Plugin registers the objective '{ref.id}'")


# Load every entry point of the group; a broken one is logged and skipped.
def _registered() -> list[_Registered]:
    found: list[_Registered] = []
    for entry in metadata.entry_points(group=ENTRY_POINT_GROUP):
        try:
            obj = entry.load()
            if not all(hasattr(obj, name) for name in ("id", "title", "fn")):
                raise AttributeError("needs id, title and fn")
        except (ImportError, AttributeError) as exc:
            logger.warning("objective entry point %s = %s not loaded: %s",
                           entry.name, entry.value, exc)
            continue
        source = entry.dist.name if entry.dist is not None else entry.value
        found.append(_Registered(obj, source))
    return found


# Import a Project script by path and return its objective function.
def _script_function(ref: ObjectiveRef, project_root: Path | None) -> ObjectiveFn:
    return load_project_function(project_root, ref.path, ref.function, what="objective script",
                                 missing=ErrorCode.OBJECTIVE_NOT_FOUND,
                                 failed=ErrorCode.OBJECTIVE_FAILED)


def load_project_function(project_root: Path | None, path: str, function: str, *, what: str,
                          missing: ErrorCode, failed: ErrorCode) -> Callable[..., Any]:
    """Import the Project script ``path`` and return its ``function``.

    The module gets a private name built from the file path, so two scripts
    that share a file name do not collide and nothing shadows a real package.
    The Project root is on ``sys.path`` while the script imports, so it can
    import the Project's own modules (``from src.geometry import ...``).
    Raises ``StudyError(missing)`` without a Project folder, for a file
    outside it or a missing function, and ``StudyError(failed)`` when
    the import raises; ``what`` names the script in the message.
    """
    if project_root is None:
        raise StudyError(missing,
                                f"a {what} needs the Project folder; open the Scene "
                                "through open_project or pass project_root")
    root = Path(project_root).resolve()
    target = (root / path).resolve()
    if not target.is_relative_to(root) or not target.is_file():
        raise StudyError(missing, f"{what} '{path}' is not a file in the Project")
    digest = hashlib.sha1(str(target).encode("utf-8")).hexdigest()[:12]
    module_name = f"_witwin_objective_{digest}"
    spec = importlib.util.spec_from_file_location(module_name, target)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    sys.path.insert(0, str(root))
    try:
        spec.loader.exec_module(module)
    except Exception as exc:  # noqa: BLE001 - user code; report it as the run's error
        sys.modules.pop(module_name, None)
        raise StudyError(failed,
                                f"importing {path} failed: {type(exc).__name__}: {exc}") from exc
    finally:
        sys.path.remove(str(root))
    fn = getattr(module, function, None)
    if not callable(fn):
        raise StudyError(missing, f"{path} has no function '{function}'")
    return fn
