"""Gradient check: autograd against central differences at the current point (plan §5.7).

``check_gradient(scene, study)`` evaluates the objective once with its
gradient, then twice more per checked variable:

- a scalar ``x``: ``(f(x + h) - f(x - h)) / 2h`` against ``df/dx``;
- a tensor ``T``: the derivative along one random unit direction ``v``
  (fixed by ``seed``), ``(f(T + h v) - f(T - h v)) / 2h`` against
  ``<df/dT, v>``. One direction catches a wrong or missing gradient with
  probability one; it cannot say which element is wrong.

``h = eps * scale``: the variable's range ``upper - lower`` when it has both
bounds, else ``|x|`` (1 at 0). So a length in metres gets a step in
proportion to its size. The default ``eps = 1e-6`` keeps both the truncation
error (about ``h**2``) and the rounding error (about ``1e-16 / h``) far below
1e-5 relative for a smooth float64 objective. Points are not clamped, so a
variable on a bound is probed just outside it.

``f`` is the objective as returned (no ``maximize`` sign, no constraint
penalty), at the current values, with tensors after their transforms at
their starting beta. Cost: ``gradient_check_cost`` evaluations; run it as a
Run in Studio (``optimization.check_gradient``), since each evaluation may be
a full simulation.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Iterable, Mapping

from ._design import CLAMP
from ..studies._errors import invalid
from ._gradient import GradientProblem
from ._objectives import ObjectiveFn, resolve
from ..studies._model import Study

if TYPE_CHECKING:
    from .._scene import Scene

DEFAULT_EPS = 1e-6


@dataclass(frozen=True)
class GradientCheckRow:
    """One checked variable. ``kind`` is ``scalar`` or ``tensor`` (a directional derivative)."""
    name: str
    kind: str
    analytic: float
    numeric: float
    step: float

    @property
    def abs_error(self) -> float:
        return abs(self.analytic - self.numeric)

    @property
    def rel_error(self) -> float:
        """``|analytic - numeric| / max(|analytic|, |numeric|)``; 0 when both are 0."""
        scale = max(abs(self.analytic), abs(self.numeric))
        return self.abs_error / scale if scale > 0 else 0.0

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "kind": self.kind, "analytic": self.analytic, "numeric": self.numeric,
                "abs_error": self.abs_error, "rel_error": self.rel_error, "step": self.step}


@dataclass
class GradientCheck:
    """Outcome of ``check_gradient``: the loss at the point and one row per variable."""
    study_id: str
    loss: float
    eps: float
    rows: list[GradientCheckRow] = field(default_factory=list)
    evaluations: int = 0

    @property
    def max_rel_error(self) -> float:
        return max((row.rel_error for row in self.rows), default=0.0)

    def to_dict(self) -> dict[str, Any]:
        return {"study_id": self.study_id, "loss": self.loss, "eps": self.eps,
                "evaluations": self.evaluations, "max_rel_error": self.max_rel_error,
                "rows": [row.to_dict() for row in self.rows]}


def gradient_check_cost(scalars: int, tensors: int) -> int:
    """Objective evaluations ``check_gradient`` makes: one with the gradient, two per variable."""
    return 1 + 2 * (scalars + tensors)


def check_gradient(scene: "Scene", study: Study | Mapping[str, Any], *, eps: float = DEFAULT_EPS,
                   variables: Iterable[str] | None = None, objective: ObjectiveFn | None = None,
                   project_root: Path | str | None = None, seed: int = 0,
                   on_progress: Callable[[int, int], None] | None = None) -> GradientCheck:
    """Compare the objective's autograd gradient with central differences (see the module doc).

    ``variables`` limits the check to these scalar names and tensor ids
    (default: all of the Study's). ``on_progress(done, total)`` runs after
    each evaluation. Raises ``StudyError`` like ``optimize.run`` when
    the Study cannot run, and when the objective fails.
    """
    from ._runner import _as_study, _project_root

    study = _as_study(scene, study, has_objective=objective is not None)
    if not eps > 0:
        raise invalid(f"eps must be > 0, not {eps!r}")
    root = Path(project_root) if project_root is not None else _project_root(scene)
    fn = objective if objective is not None else resolve(study.objective, root)
    problem = GradientProblem(scene, study, fn, root, bounds=CLAMP,
                              seed=study.seed if study.seed is not None else seed)
    torch, design = problem.torch, problem.design
    scalars = list(problem.space.variables)
    tensors = list(design.specs)
    if variables is not None:
        wanted = list(variables)
        unknown = sorted(set(wanted) - {v.name for v in scalars} - set(tensors))
        if unknown:
            raise invalid(f"not variables of this study: {', '.join(unknown)}")
        scalars = [v for v in scalars if v.name in wanted]
        tensors = [t for t in tensors if t in wanted]
    total = gradient_check_cost(len(scalars), len(tensors))
    done = 0

    def tick() -> None:
        nonlocal done
        done += 1
        if on_progress is not None:
            on_progress(done, total)

    point = problem.evaluate(0)
    leaves = dict(zip(design.keys, design.leaves()))
    grads = torch.autograd.grad(point.loss, list(leaves.values()), allow_unused=True)
    gradient = {key: (g if g is not None else torch.zeros_like(leaf))
                for (key, leaf), g in zip(leaves.items(), grads)}
    result = GradientCheck(study.id, float(point.loss.item()), eps)
    tick()

    def probe(key: str, direction: Any, h: float) -> float:
        leaf = leaves[key]
        with torch.no_grad():
            start = leaf.detach().clone()
            leaf.copy_(start + h * direction)
        plus = problem.value(0)
        tick()
        with torch.no_grad():
            leaf.copy_(start - h * direction)
        minus = problem.value(0)
        tick()
        with torch.no_grad():
            leaf.copy_(start)
        return (plus - minus) / (2.0 * h)

    for variable in scalars:
        key = f"s:{variable.name}"
        h = eps * _scale(variable.lower, variable.upper, float(leaves[key].item()))
        numeric = probe(key, torch.tensor(1.0, dtype=torch.float64), h)
        result.rows.append(GradientCheckRow(variable.name, "scalar", float(gradient[key].item()), numeric, h))
    generator = torch.Generator().manual_seed(int(seed))
    for tensor_id in tensors:
        key, spec = f"t:{tensor_id}", design.specs[tensor_id]
        direction = torch.randn(leaves[key].shape, generator=generator, dtype=torch.float64)
        direction = direction / torch.linalg.norm(direction)
        h = eps * _scale(spec["lower"], spec["upper"], 1.0)
        numeric = probe(key, direction, h)
        analytic = float((gradient[key] * direction).sum())
        result.rows.append(GradientCheckRow(tensor_id, "tensor", analytic, numeric, h))
    result.evaluations = done
    return result


def _scale(lower: float | None, upper: float | None, x: float) -> float:
    if lower is not None and upper is not None and upper > lower:
        return float(upper - lower)
    return abs(x) if x != 0 and math.isfinite(x) else 1.0
