"""Particle Swarm (plan §2, §4; phase M3): global-best PSO in [0, 1]^n.

One ``ask`` is one iteration: every particle's position. Particle 0 starts
at the run's current point, the others uniformly at random; velocities start
uniform in [-v_max, v_max]. After each ``tell`` every particle moves::

    v = inertia * v + c1 * r1 * (personal best - x) + c2 * r2 * (swarm best - x)
    v = clip(v, -v_max, v_max);  x = x + v

with r1, r2 uniform in [0, 1] per particle and coordinate. ``v_max`` is a
fraction of each variable's bound width (the unit interval). A coordinate
that leaves [0, 1] is reflected back and its velocity reversed.

Positions stay continuous; the driver snaps each asked point to the
parameter's ``step``. A personal best is the point the driver evaluated
(``EvalRecord.unit``). A failed evaluation scores +inf, so it never becomes
a best. ``summary.per_batch`` describes the swarm's positions of each
iteration. Notes: dev_docs/studies/pso.md.
"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any, Mapping

from ._population import (
    CONVERGENCE_SETTINGS, Progress, make_rng, numpy, numpy_missing, scores_from_json,
    scores_to_json, unit_of,
)
from .base import Candidate, Family, Optimizer, StrategyBase, StrategySetup, object_schema

if TYPE_CHECKING:
    from .._records import EvalRecord

SETTINGS_SCHEMA = object_schema(
    particles={"type": "integer", "minimum": 1, "default": 30, "title": "Particles"},
    iterations={"type": "integer", "minimum": 1, "default": 50, "title": "Iterations"},
    inertia={"type": "number", "minimum": 0, "default": 0.7, "title": "Inertia"},
    c1={"type": "number", "minimum": 0, "default": 1.5, "title": "Cognitive c1"},
    c2={"type": "number", "minimum": 0, "default": 1.5, "title": "Social c2"},
    v_max={"type": "number", "exclusiveMinimum": 0, "default": 0.2, "title": "Max velocity",
           "description": "Fraction of each variable's bound width per iteration."},
    **CONVERGENCE_SETTINGS,
)


class SwarmStrategy(StrategyBase):
    """One PSO run; arrays are numpy, ``state_dict`` turns them into lists."""

    def __init__(self, setup: StrategySetup) -> None:
        super().__init__(setup)
        np = numpy()
        s = setup.settings
        self.dim = setup.space.dim
        self.size = int(s.get("particles", 30))
        self.iterations = int(s.get("iterations", 50))
        self.inertia = float(s.get("inertia", 0.7))
        self.c1 = float(s.get("c1", 1.5))
        self.c2 = float(s.get("c2", 1.5))
        self.v_max = float(s.get("v_max", 0.2))
        self.expected_evals = self.size * self.iterations
        self.rng = make_rng(setup.seed)
        self.progress = Progress(float(s.get("tol", 1e-6)), int(s.get("patience", 0)), setup.maximize)
        self.iteration = 0  # iterations told so far
        self.x = self.rng.random((self.size, self.dim))
        self.x[0] = setup.space.to_unit(setup.space.current())
        self.v = self.rng.uniform(-self.v_max, self.v_max, (self.size, self.dim))
        self.best_x = self.x.copy()             # personal bests
        self.best_score = np.full(self.size, math.inf)

    def ask(self) -> list[Candidate]:
        if self.converged or self.iteration >= self.iterations:
            return []
        return [Candidate(self.setup.space.from_unit(row.tolist())) for row in self.x]

    def tell(self, records: list["EvalRecord"]) -> None:
        np = numpy()
        scores = [self.setup.score(r) for r in records] + [math.inf] * (self.size - len(records))
        for i, record in enumerate(records):
            if scores[i] < self.best_score[i]:
                self.best_score[i] = scores[i]
                self.best_x[i] = unit_of(record, self.x[i])
        self.iteration += 1
        self.converged = self.progress.record(self.iteration, scores)
        leader = self.best_x[int(np.argmin(self.best_score))]
        r1 = self.rng.random((self.size, self.dim))
        r2 = self.rng.random((self.size, self.dim))
        v = (self.inertia * self.v + self.c1 * r1 * (self.best_x - self.x)
             + self.c2 * r2 * (leader - self.x))
        self.v = np.clip(v, -self.v_max, self.v_max)
        self.x = self.x + self.v
        self._reflect()

    def summary(self) -> dict[str, Any]:
        return self.progress.summary()

    def state_dict(self) -> dict[str, Any]:
        return {"iteration": self.iteration, "x": self.x.tolist(), "v": self.v.tolist(),
                "best_x": self.best_x.tolist(), "best_score": scores_to_json(self.best_score.tolist()),
                "converged": self.converged, "rng": self.rng.bit_generator.state,
                "progress": self.progress.state_dict()}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        np = numpy()
        self.iteration = int(state["iteration"])
        self.x = np.asarray(state["x"], dtype=float).reshape(self.size, self.dim)
        self.v = np.asarray(state["v"], dtype=float).reshape(self.size, self.dim)
        self.best_x = np.asarray(state["best_x"], dtype=float).reshape(self.size, self.dim)
        self.best_score = np.asarray(scores_from_json(state["best_score"]), dtype=float)
        self.converged = bool(state.get("converged", False))
        self.rng.bit_generator.state = state["rng"]
        self.progress.load_state_dict(state.get("progress", {}))

    # Mirror coordinates outside [0, 1] back inside and reverse their velocity.
    def _reflect(self) -> None:
        np = numpy()
        low, high = self.x < 0.0, self.x > 1.0
        self.x[low] = -self.x[low]
        self.x[high] = 2.0 - self.x[high]
        self.v[low | high] = -self.v[low | high]
        self.x = np.clip(self.x, 0.0, 1.0)  # a step longer than the width (v_max > 1)


OPTIMIZER = Optimizer(
    kind="pso", title="Particle Swarm", family=Family.BLACKBOX, factory=SwarmStrategy,
    settings_schema=SETTINGS_SCHEMA, requires_bounds=True,
    description="Moves a swarm of particles toward the best points found.",
    unavailable=numpy_missing,
)
