"""What the population methods (``genetic``, ``pso``) share: numpy, seeds, stats and the stall rule.

Both work in the normalized space [0, 1]^n of the run's ``DesignSpace`` and
need numpy, imported only when a run starts (the registry imports the method
modules on every Study read). A failed evaluation scores +inf
(``StrategySetup.score``), so it is always the worst point and never a best.

``Progress`` keeps ``summary.per_batch`` and decides ``converged``: the best
score so far must improve by more than ``tol`` relative to itself at least
once every ``patience`` batches; ``patience = 0`` turns the rule off.
"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any, Mapping, Sequence

from .base import Unavailable, missing_dependency

if TYPE_CHECKING:
    from .._records import EvalRecord

NUMPY_HINT = "install numpy (pip install numpy)"

# Settings both methods add to their schema.
CONVERGENCE_SETTINGS: dict[str, dict[str, Any]] = {
    "tol": {"type": "number", "minimum": 0, "default": 1e-6, "title": "Tolerance",
            "description": "Relative improvement of the best loss that counts as progress."},
    "patience": {"type": "integer", "minimum": 0, "default": 0, "title": "Patience",
                 "description": "Stop after this many batches without progress; 0: never."},
}


def numpy_missing() -> Unavailable | None:
    return missing_dependency("numpy", NUMPY_HINT)


def numpy() -> Any:
    import numpy as np

    return np


# A PCG64 generator seeded with the run's seed (plan §4: same seed, same run).
def make_rng(seed: int) -> Any:
    np = numpy()
    return np.random.Generator(np.random.PCG64(int(seed)))


# Scores as JSON: +inf (failed or not evaluated) becomes None.
def scores_to_json(scores: Sequence[float]) -> list[float | None]:
    return [float(s) if math.isfinite(s) else None for s in scores]


def scores_from_json(scores: Sequence[float | None]) -> list[float]:
    return [math.inf if s is None else float(s) for s in scores]


def unit_of(record: "EvalRecord", fallback: Sequence[float]) -> list[float]:
    """The point a record evaluated, in [0, 1]^n: snapped to ``step`` and the bounds by the driver."""
    return [float(u) for u in (record.unit if record.unit is not None else fallback)]


class Progress:
    """``summary.per_batch`` and the stall counter of one run.

    ``record`` takes the scores of a batch's population (lower is better,
    +inf for failed points). Each ``per_batch`` entry reports the loss as the
    objective returned it: ``best`` is the highest loss for ``maximize``.
    ``failed`` counts the +inf scores; ``best``, ``mean`` and ``worst`` are
    None when every point failed.
    """

    def __init__(self, tol: float, patience: int, maximize: bool) -> None:
        self.tol = float(tol)
        self.patience = int(patience)
        self.maximize = maximize
        self.per_batch: list[dict[str, Any]] = []
        self.best = math.inf  # best score so far
        self.stall = 0        # batches since the best last improved by more than tol

    # Adds one batch; returns True when the run has converged.
    def record(self, batch: int, scores: Sequence[float]) -> bool:
        finite = [s for s in scores if math.isfinite(s)]
        losses = [-s if self.maximize else s for s in finite]
        entry: dict[str, Any] = {"batch": batch, "best": None, "mean": None, "worst": None,
                                 "failed": len(scores) - len(finite)}
        if losses:
            high, low = max(losses), min(losses)
            entry.update(best=high if self.maximize else low, mean=sum(losses) / len(losses),
                         worst=low if self.maximize else high)
        self.per_batch.append(entry)
        new = min(finite, default=math.inf)
        improved = new < self.best and (
            not math.isfinite(self.best) or self.best - new > self.tol * abs(self.best))
        self.best = min(self.best, new)
        self.stall = 0 if improved else self.stall + 1
        return self.patience > 0 and self.stall >= self.patience

    def summary(self) -> dict[str, Any]:
        return {"per_batch": [dict(entry) for entry in self.per_batch]}

    def state_dict(self) -> dict[str, Any]:
        return {"per_batch": [dict(entry) for entry in self.per_batch],
                "best": scores_to_json([self.best])[0], "stall": self.stall}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        self.per_batch = [dict(entry) for entry in state.get("per_batch", [])]
        self.best = scores_from_json([state.get("best")])[0]
        self.stall = int(state.get("stall", 0))
