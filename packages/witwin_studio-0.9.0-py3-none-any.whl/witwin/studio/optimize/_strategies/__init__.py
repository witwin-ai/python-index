"""The method registry: built-in methods plus the ``witwin.optimizers`` entry point group.

Every built-in kind has one module here that defines ``OPTIMIZER`` (an
``Optimizer``): ``sweep``, ``custom_sweep``, ``monte_carlo``, ``genetic``,
``pso``, ``bayesian``, ``gradient`` and ``agentic``. A module whose strategy
is not written yet registers ``factory=None`` and reports ``available =
false`` with the reason "not implemented"; ``agentic`` says "coming soon".
Built-in modules must import quickly and without numpy or torch: records are
validated through them (``check_method_settings``) on every Study read.

Third-party methods register under ``witwin.optimizers``. A kind already
registered (a built-in one or another package's) is used only when the new
object sets ``replaces = True`` (plan 5.7: replacing is always explicit);
otherwise the entry point is skipped and ``method_problems()`` says why. A
replacement of a built-in kind must also name its entry point after that kind
(``sweep = "my_pkg:SWEEP"``): record reads look up only that name, so they
check a replaced kind's settings with the replacement's schema without
importing every package. Other third-party record settings are checked only
when a run starts, by ``resolve`` (loading every entry point on each record
read would be slow).
"""
from __future__ import annotations

import importlib
import logging
import sys
import threading
from dataclasses import dataclass
from importlib import metadata
from typing import Any, Mapping

from ...studies._errors import ErrorCode, StudyError
from .._schema import check_settings
from .base import (
    Candidate, Family, Optimizer, Strategy, StrategyBase, StrategySetup, Unavailable,
    coming_soon, missing_dependency, not_implemented, object_schema,
)

ENTRY_POINT_GROUP = "witwin.optimizers"
BUILTIN_SOURCE = "witwin-studio"

# kind -> module of this package, in the panel's display order.
BUILTIN_KINDS: dict[str, str] = {
    "sweep": "sweep",
    "custom_sweep": "custom_sweep",
    "monte_carlo": "monte_carlo",
    "gradient": "gradient",
    "genetic": "genetic",
    "pso": "pso",
    "bayesian": "bayesian",
    "agentic": "agentic",
}

logger = logging.getLogger("witwin.studio")

__all__ = [
    "BUILTIN_KINDS", "Candidate", "ENTRY_POINT_GROUP", "Family", "Optimizer", "Strategy",
    "StrategyBase", "StrategySetup", "Unavailable", "builtin", "check_method_settings",
    "check_variable_settings", "coming_soon", "list_methods", "method_problems", "missing_dependency",
    "not_implemented", "object_schema", "resolve",
]


@dataclass(frozen=True)
class Registered:
    optimizer: Optimizer
    source: str  # BUILTIN_SOURCE, the distribution name, else the entry point value


def builtin(kind: str) -> Optimizer | None:
    """The built-in method of ``kind``, or None."""
    module = BUILTIN_KINDS.get(kind)
    if module is None:
        return None
    return importlib.import_module(f"{__name__}.{module}").OPTIMIZER


def registered() -> list[Registered]:
    """Every method: built-in kinds first (a replacement in a built-in's place), then entry points.

    Broken entry points and kinds already taken without ``replaces`` are
    skipped; ``method_problems()`` lists them.
    """
    return _collect()[0]


def method_problems() -> list[str]:
    """Why some ``witwin.optimizers`` entry points are not used (broken, or a kind taken without replaces)."""
    return _collect()[1]


def _collect() -> tuple[list[Registered], list[str]]:
    problems: list[str] = []
    replacements: dict[str, Registered] = {}
    others: dict[str, Registered] = {}
    for entry in metadata.entry_points(group=ENTRY_POINT_GROUP):
        label = f"{entry.name} = {entry.value}"
        obj = _load(entry, problems)
        if obj is None:
            continue
        item = Registered(obj, entry.dist.name if entry.dist is not None else entry.value)
        replaces = bool(getattr(obj, "replaces", False))
        if obj.kind in BUILTIN_KINDS:
            if replaces and entry.name == obj.kind:
                replacements[obj.kind] = item
            else:
                problems.append(f"optimizer entry point {label} ignored: '{obj.kind}' is a built-in method; "
                                f"name the entry point '{obj.kind}' and set replaces = True to replace it")
        elif obj.kind in others and not replaces:
            problems.append(f"optimizer entry point {label} ignored: '{obj.kind}' is already registered "
                            f"by {others[obj.kind].source}; set replaces = True to replace it")
        else:
            others[obj.kind] = item
    for problem in problems:
        logger.warning("%s", problem)
    found = [replacements.get(kind) or Registered(builtin(kind), BUILTIN_SOURCE) for kind in BUILTIN_KINDS]
    return found + list(others.values()), problems


def _load(entry: metadata.EntryPoint, problems: list[str]) -> Any:
    try:
        obj = entry.load()
        if not all(hasattr(obj, name) for name in ("kind", "title", "family")):
            raise AttributeError("needs kind, title and family")
    except (ImportError, AttributeError) as exc:
        problems.append(f"optimizer entry point {entry.name} = {entry.value} not loaded: {exc}")
        return None
    return obj


# Names of the witwin.optimizers entry points of one sys.path, read once, so a
# record read checks for a replaced built-in without scanning every time.
_names_lock = threading.Lock()
_names: tuple[tuple[str, ...], dict[str, metadata.EntryPoint]] | None = None


def _replacement(kind: str) -> Any:
    """The object replacing built-in ``kind`` (its entry point is named ``kind``), or None."""
    global _names
    key = tuple(sys.path)
    with _names_lock:
        if _names is None or _names[0] != key:
            try:
                points = {entry.name: entry for entry in metadata.entry_points(group=ENTRY_POINT_GROUP)}
            except Exception:  # noqa: BLE001 - a broken environment must not stop record reads
                points = {}
            _names = (key, points)
        entry = _names[1].get(kind)
    if entry is None:
        return None
    obj = _load(entry, [])
    if obj is None or obj.kind != kind or not getattr(obj, "replaces", False):
        return None
    return obj


def _record_method(kind: str) -> Any:
    """The method whose schema checks a record's settings: a built-in (or its replacement), else None."""
    if kind not in BUILTIN_KINDS:
        return None
    return _replacement(kind) or builtin(kind)


def list_methods() -> list[dict[str, Any]]:
    """Every method as ``{kind, title, family, description, settings_schema, variable_schema,
    requires_bounds, default_max_evals, illustration, source, available, reason, code}``; ``reason`` and ``code`` are ``""``
    when ``available``."""
    rows = []
    for item in registered():
        opt = item.optimizer
        problem = _check(opt)
        rows.append({
            "kind": str(opt.kind), "title": str(opt.title), "family": str(Family(opt.family)),
            "description": str(getattr(opt, "description", "") or ""),
            "settings_schema": dict(getattr(opt, "settings_schema", None) or {}),
            "variable_schema": dict(getattr(opt, "variable_schema", None) or {}),
            "requires_bounds": bool(getattr(opt, "requires_bounds", True)),
            "default_max_evals": getattr(opt, "default_max_evals", None),
            "illustration": str(getattr(opt, "illustration", "") or ""),
            "source": item.source, "available": problem is None,
            "reason": "" if problem is None else problem.reason,
            "code": "" if problem is None else str(problem.code),
        })
    return rows


def resolve(kind: str) -> Optimizer:
    """The method a run uses; raises ``method_not_found``, ``method_unavailable`` or
    ``dependency_missing``."""
    opt = next((item.optimizer for item in registered() if item.optimizer.kind == kind), None)
    if opt is None:
        raise StudyError(ErrorCode.METHOD_NOT_FOUND,
                                f"no installed package registers the optimization method '{kind}'",
                                kind=kind)
    problem = _check(opt)
    if problem is not None:
        raise StudyError(problem.code, f"{opt.title} is not available: {problem.reason}",
                                kind=kind)
    return opt


def check_method_settings(kind: str, settings: Mapping[str, Any]) -> dict[str, Any]:
    """A ``method`` table (without ``kind``) checked against a built-in method's schema (or its replacement's)."""
    opt = _record_method(kind)
    if opt is None:
        return dict(settings)
    return check_settings(getattr(opt, "settings_schema", None) or {}, settings, "method")


def check_variable_settings(kind: str, settings: Mapping[str, Any], what: str) -> dict[str, Any]:
    """One ``variables.<name>`` table checked against a built-in method's variable schema (or its replacement's)."""
    opt = _record_method(kind)
    if opt is None or not getattr(opt, "variable_schema", None):
        return check_settings({}, settings, what)
    return check_settings(opt.variable_schema, settings, what)


# Optimizer.check(), also for duck-typed third-party objects without it.
def _check(opt: Any) -> Unavailable | None:
    if isinstance(opt, Optimizer):
        return opt.check()
    unavailable = getattr(opt, "unavailable", None)
    found = unavailable() if callable(unavailable) else None
    if found is None and getattr(opt, "factory", None) is None and str(opt.family) != Family.GRADIENT:
        return not_implemented()
    return found
