"""Agentic Optimization (plan §7; phase M7). Reserved slot: listed, never runnable yet.

The strategy will ask the Project's Agent Session for the next batch of
points (variables, bounds, the records so far, ``instructions``) and keep the
Agent's reason in each record's ``note`` (``base.Candidate``). Its ``ask``
may block while the model answers. Not part of M0–M6. Notes:
dev_docs/studies/agentic.md.
"""
from __future__ import annotations

from .base import Family, Optimizer, coming_soon, object_schema

SETTINGS_SCHEMA = object_schema(
    batch_size={"type": "integer", "minimum": 1, "default": 4, "title": "Batch size"},
    max_evals={"type": "integer", "minimum": 1, "default": 40, "title": "Max evaluations"},
    instructions={"type": "string", "default": "", "title": "Instructions"},
)

OPTIMIZER = Optimizer(
    kind="agentic", title="Agentic Optimization", family=Family.AGENTIC,
    settings_schema=SETTINGS_SCHEMA, requires_bounds=True,
    description="An Agent reads the results so far and proposes the next points.",
    unavailable=coming_soon,
)
