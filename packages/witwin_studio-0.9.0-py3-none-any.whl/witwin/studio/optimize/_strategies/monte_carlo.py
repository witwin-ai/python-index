"""Monte Carlo (plan §2, §3.4, §4; phase M2): tolerance, yield and sensitivity studies.

Draws ``samples`` points, each variable from its own distribution, and
evaluates every one; the summary gives the statistics of the loss and of each
reported metric, and the yield when a criterion is set. Notes:
dev_docs/studies/monte_carlo.md.

Every sampler first makes a matrix of uniform numbers in (0, 1)^(n x d), one
row per sample, one column per variable; each variable's distribution then
maps its column through its inverse CDF. So a sampler (``random``, ``lhs``,
``sobol``) never knows the distributions, and stratification survives the
mapping: LHS keeps one sample per stratum of every marginal.

- ``random``: numpy ``Generator(PCG64(seed))``.
- ``lhs``: Latin hypercube, written here: per variable a random permutation of
  the n strata plus a uniform jitter inside each stratum.
- ``sobol``: scrambled Sobol (``scipy.stats.qmc``), seeded from the run's seed.
  Balanced when ``samples`` is a power of two. Needs scipy; without it the run
  is refused with ``dependency_missing``.

numpy is imported only when a run starts: this module is read on every
Study record check and must import without it.
"""
from __future__ import annotations

import importlib.util
import math
import operator
import warnings
from dataclasses import dataclass
from statistics import NormalDist
from typing import TYPE_CHECKING, Any, Callable, Mapping

from ...studies._errors import ErrorCode, StudyError, invalid
from .._schema import check_settings
from .base import Family, Optimizer, StrategyBase, StrategySetup, missing_dependency, object_schema

if TYPE_CHECKING:
    import numpy as np

    from .._records import EvalRecord
    from .._space import Variable

SAMPLERS = ("random", "lhs", "sobol")
DISTRIBUTIONS = ("normal", "uniform", "lognormal", "truncnormal")
YIELD_OPS: dict[str, Callable[[float, float], bool]] = {
    "<": operator.lt, "<=": operator.le, ">": operator.gt, ">=": operator.ge,
}
Z95 = 1.959963984540054   # two-sided 95 % normal quantile, for the Wilson interval
PERCENTILES = (5, 50, 95)
SUMMARY_UPDATES = 50       # a batch is samples / SUMMARY_UPDATES points: the summary is recomputed per batch
_STD_NORMAL = NormalDist()
_U_MIN = 2.0 ** -53        # uniforms are clipped to [_U_MIN, 1 - _U_MIN]: inv_cdf refuses 0 and 1

YIELD_SCHEMA = object_schema(
    metric={"type": "string", "default": "loss", "title": "Metric"},
    op={"type": "string", "enum": list(YIELD_OPS), "default": "<", "title": "Passes when"},
    threshold={"type": "number", "title": "Threshold"},
)
YIELD_SCHEMA["required"] = ["threshold"]


def _sampler_property() -> dict[str, Any]:
    prop: dict[str, Any] = {"type": "string", "enum": list(SAMPLERS), "default": "random",
                            "enum_titles": ["Random", "Latin hypercube", "Sobol"], "title": "Sampler"}
    # find_spec only looks for the package; it does not import scipy.
    if importlib.util.find_spec("scipy") is None:
        prop["description"] = "sobol needs scipy, which is not installed"
    return prop


SETTINGS_SCHEMA = object_schema(
    samples={"type": "integer", "minimum": 1, "default": 200, "title": "Samples"},
    sampler=_sampler_property(),
    **{"yield": {"type": "object", "title": "Yield criterion",
                 "description": "{metric, op, threshold}; op is one of <, <=, >, >=.",
                 "properties": YIELD_SCHEMA["properties"], "required": ["threshold"]}},
)

# Column order of the Studies panel's Variables table follows this order.
VARIABLE_SCHEMA = object_schema(
    dist={"type": "string", "enum": list(DISTRIBUTIONS), "default": "normal", "title": "Distribution",
          "enum_titles": ["Normal", "Uniform", "Lognormal", "Truncated normal"]},
    sigma={"type": "number", "exclusiveMinimum": 0, "title": "σ"},
    rel_sigma={"type": "number", "exclusiveMinimum": 0, "title": "Relative σ"},
    mean={"type": "number", "title": "Mean"},
)


@dataclass(frozen=True)
class YieldCriterion:
    """A sample passes when ``metric op threshold``; ``metric`` is ``loss`` or a reported metric."""
    metric: str
    op: str
    threshold: float

    def passes(self, value: float) -> bool:
        return YIELD_OPS[self.op](value, self.threshold)

    @classmethod
    def parse(cls, data: Mapping[str, Any] | None) -> "YieldCriterion | None":
        if data is None:
            return None
        checked = check_settings(YIELD_SCHEMA, data, "method.yield")
        return cls(str(checked["metric"]), str(checked["op"]), float(checked["threshold"]))


@dataclass(frozen=True)
class Marginal:
    """One variable's distribution, as an inverse CDF from (0, 1) to values.

    ``mean`` and ``sigma`` are the arithmetic mean and standard deviation of
    the distribution as configured (for ``lognormal`` too, so a tolerance
    reads the same whichever shape it has). ``truncnormal`` is the normal
    distribution with ``mean`` and ``sigma`` cut to [lower, upper] (either
    side may be open), so its own mean and spread differ from them.
    """
    name: str
    dist: str
    mean: float
    sigma: float | None
    lower: float | None
    upper: float | None

    def ppf(self, u: "np.ndarray") -> "np.ndarray":
        import numpy as np

        if self.dist == "uniform":
            return self.lower + u * (self.upper - self.lower)
        if self.dist == "lognormal":
            # Mean m and standard deviation s of the lognormal give its log-space parameters.
            s2 = math.log1p((self.sigma / self.mean) ** 2)
            mu = math.log(self.mean) - s2 / 2
            return np.exp(mu + math.sqrt(s2) * _norm_ppf(u))
        if self.dist == "truncnormal":
            return self._truncated(u)
        return self.mean + self.sigma * _norm_ppf(u)

    # Inverse CDF of the truncated normal. Works on the side of the mean
    # nearer the cut, so a range far in one tail keeps its precision
    # (Phi(a) near 1 would leave no digits for the mass between the bounds).
    def _truncated(self, u: "np.ndarray") -> "np.ndarray":
        a = -math.inf if self.lower is None else (self.lower - self.mean) / self.sigma
        b = math.inf if self.upper is None else (self.upper - self.mean) / self.sigma
        flip = a > 0
        if flip:
            a, b, u = -b, -a, 1.0 - u
        lo, hi = _norm_cdf(a), _norm_cdf(b)
        z = _norm_ppf(lo + u * (hi - lo))
        z = z.clip(a, b)  # rounding may step a hair past the cut
        return self.mean + self.sigma * (-z if flip else z)


def marginals(variables: "tuple[Variable, ...]") -> list[Marginal]:
    """Each variable's distribution from its ``variables.<name>`` settings.

    Raises ``bounds_missing`` (``data.variables``) for a ``uniform`` variable
    without both bounds or a ``truncnormal`` one without any, and
    ``invalid_study`` for a spread that is missing or does not fit the shape.
    """
    out, no_bounds = [], []
    for v in variables:
        s = v.settings
        dist = s.get("dist", "normal")
        if dist not in DISTRIBUTIONS:
            raise invalid(f"variables.{v.name}.dist must be one of {', '.join(DISTRIBUTIONS)}, not {dist!r}")
        mean = float(s["mean"]) if s.get("mean") is not None else float(v.value)
        lower = None if v.lower is None else float(v.lower)
        upper = None if v.upper is None else float(v.upper)
        sigma = None
        if s.get("sigma") is not None:
            sigma = float(s["sigma"])
        elif s.get("rel_sigma") is not None:
            sigma = float(s["rel_sigma"]) * abs(mean)
        if dist == "uniform":
            if lower is None or upper is None:
                no_bounds.append(v.name)
                continue
            if not lower < upper:
                raise invalid(f"{v.name}: the uniform range needs lower < upper, not [{lower}, {upper}]")
            out.append(Marginal(v.name, dist, mean, sigma, lower, upper))
            continue
        if dist == "truncnormal" and lower is None and upper is None:
            no_bounds.append(v.name)
            continue
        if sigma is None:
            raise invalid(f"variables.{v.name} needs sigma or rel_sigma for a {dist} distribution")
        if not sigma > 0:
            raise invalid(f"{v.name}: rel_sigma of a zero mean gives no spread; set sigma instead")
        if dist == "lognormal" and mean <= 0:
            raise invalid(f"{v.name}: a lognormal distribution needs a mean > 0, not {mean}")
        if dist == "truncnormal":
            if lower is not None and upper is not None and not lower < upper:
                raise invalid(f"{v.name}: the truncation range needs lower < upper, not [{lower}, {upper}]")
            marginal = Marginal(v.name, dist, mean, sigma, lower, upper)
            if _truncated_mass(marginal) < 1e-12:
                raise invalid(f"{v.name}: the bounds leave almost no probability; "
                              "move the mean or widen sigma")
            out.append(marginal)
            continue
        out.append(Marginal(v.name, dist, mean, sigma, None, None))
    if no_bounds:
        raise StudyError(
            ErrorCode.BOUNDS_MISSING,
            "uniform needs a lower and an upper bound, truncnormal at least one: "
            + ", ".join(no_bounds), variables=no_bounds)
    return out


def unit_samples(sampler: str, n: int, d: int, seed: int) -> "np.ndarray":
    """An (n, d) matrix of uniform numbers in [_U_MIN, 1 - _U_MIN] from ``sampler``."""
    import numpy as np

    rng = np.random.Generator(np.random.PCG64(seed))
    if sampler == "random":
        u = rng.random((n, d))
    elif sampler == "lhs":
        u = np.empty((n, d))
        for j in range(d):
            u[:, j] = (rng.permutation(n) + rng.random(n)) / n
    elif sampler == "sobol":
        from scipy.stats import qmc

        with warnings.catch_warnings():
            # Sobol warns when n is not a power of two: the balance is then only approximate.
            warnings.simplefilter("ignore", UserWarning)
            u = qmc.Sobol(d, scramble=True, rng=rng).random(n)
    else:
        raise invalid(f"method.sampler must be one of {', '.join(SAMPLERS)}, not {sampler!r}")
    return u.clip(_U_MIN, 1.0 - _U_MIN)


def describe(values: list[float], drawn: int) -> dict[str, Any]:
    """``{count, failed, mean, std, min, max, p5, p50, p95}`` of the finite ``values``.

    ``failed`` counts the ``drawn`` samples without a value (a failed
    evaluation, or a metric the objective did not report). ``std`` is the
    sample standard deviation (n - 1); the numbers are None when ``count`` is 0.
    """
    import numpy as np

    out: dict[str, Any] = {"count": len(values), "failed": drawn - len(values)}
    if not values:
        return {**out, "mean": None, "std": None, "min": None, "max": None,
                **{f"p{p}": None for p in PERCENTILES}}
    a = np.asarray(values, dtype=float)
    out.update(mean=float(a.mean()), std=float(a.std(ddof=1)) if a.size > 1 else 0.0,
               min=float(a.min()), max=float(a.max()))
    for p, q in zip(PERCENTILES, np.percentile(a, PERCENTILES)):
        out[f"p{p}"] = float(q)
    return out


def wilson_interval(passed: int, total: int, z: float = Z95) -> tuple[float, float]:
    """Wilson score interval of the pass ratio ``passed / total``; (0, 1) when ``total`` is 0."""
    if total == 0:
        return 0.0, 1.0
    p = passed / total
    denom = 1.0 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    half = z / denom * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total))
    return max(0.0, center - half), min(1.0, center + half)


class MonteCarlo(StrategyBase):
    """Asks for the precomputed samples in batches and keeps every outcome for the summary.

    Outcomes are kept per sample, so a sample the driver served from its
    cache (an integer variable drawn twice) still counts once in the
    statistics. Failed samples are left out of the statistics and of the
    yield and counted in ``failed``.
    """

    def __init__(self, setup: StrategySetup) -> None:
        super().__init__(setup)
        settings = setup.settings
        self.samples = int(settings.get("samples", 200))
        self.sampler = _sampler(settings)
        self.criterion = YieldCriterion.parse(settings.get("yield"))
        self.marginals = marginals(setup.space.variables)
        self.expected_evals = self.samples
        u = unit_samples(self.sampler, self.samples, len(self.marginals), setup.seed)
        self._points = [m.ppf(u[:, j]) for j, m in enumerate(self.marginals)]
        parallel = int(getattr(setup.budget, "parallel", 1) or 1)
        self._batch = max(parallel, math.ceil(self.samples / SUMMARY_UPDATES))
        self._next = 0
        self._outcomes: list[tuple[float | None, dict[str, float]]] = []

    def ask(self) -> list[Mapping[str, float]]:
        stop = min(self.samples, self._next + self._batch)
        rows = [{m.name: float(column[i]) for m, column in zip(self.marginals, self._points)}
                for i in range(self._next, stop)]
        self._next = stop
        return rows

    def tell(self, records: list["EvalRecord"]) -> None:
        for record in records:
            ok = record.ok and record.loss is not None and math.isfinite(record.loss)
            metrics = {k: float(v) for k, v in record.metrics.items() if math.isfinite(v)} if ok else {}
            self._outcomes.append((float(record.loss) if ok else None, metrics))

    def summary(self) -> dict[str, Any]:
        drawn = len(self._outcomes)
        columns: dict[str, list[float]] = {"loss": [loss for loss, _ in self._outcomes if loss is not None]}
        for _, metrics in self._outcomes:
            for name, value in metrics.items():
                if name != "loss":
                    columns.setdefault(name, []).append(value)
        out: dict[str, Any] = {
            "sampler": self.sampler, "samples": self.samples, "drawn": drawn,
            "failed": sum(1 for loss, _ in self._outcomes if loss is None),
            "stats": {name: describe(values, drawn) for name, values in columns.items()},
        }
        if self.criterion is not None:
            out["yield"] = self._yield()
        return out

    # The yield over the samples that have a value of the criterion's metric.
    def _yield(self) -> dict[str, Any]:
        c = self.criterion
        values = [loss if c.metric == "loss" else metrics.get(c.metric)
                  for loss, metrics in self._outcomes]
        values = [v for v in values if v is not None]
        passed = sum(1 for v in values if c.passes(v))
        low, high = wilson_interval(passed, len(values))
        return {"metric": c.metric, "op": c.op, "threshold": c.threshold, "passed": passed,
                "total": len(values), "value": passed / len(values) if values else None,
                "low": low, "high": high}

    def state_dict(self) -> dict[str, Any]:
        return {"next": self._next, "outcomes": [[loss, metrics] for loss, metrics in self._outcomes]}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        self._next = int(state.get("next", 0))
        self._outcomes = [(None if loss is None else float(loss), dict(metrics))
                          for loss, metrics in state.get("outcomes", [])]


# The sampler setting; dependency_missing for sobol without scipy.
def _sampler(settings: Mapping[str, Any]) -> str:
    sampler = str(settings.get("sampler", "random"))
    if sampler == "sobol" and importlib.util.find_spec("scipy") is None:
        raise StudyError(ErrorCode.DEPENDENCY_MISSING,
                                "the sobol sampler needs scipy; pip install scipy", kind="monte_carlo")
    return sampler


def validate(setup: StrategySetup) -> None:
    """Refuse the sampler, the yield criterion and each distribution before the Run starts.

    The same functions the strategy runs, without drawing a sample (no numpy).
    """
    _sampler(setup.settings)
    YieldCriterion.parse(setup.settings.get("yield"))
    marginals(setup.space.variables)


def _norm_ppf(u: "np.ndarray") -> "np.ndarray":
    import numpy as np

    return np.vectorize(_STD_NORMAL.inv_cdf, otypes=[float])(u)


def _norm_cdf(z: float) -> float:
    if math.isinf(z):
        return 0.0 if z < 0 else 1.0
    return _STD_NORMAL.cdf(z)


# Probability mass of the normal between a truncnormal's bounds.
def _truncated_mass(m: Marginal) -> float:
    a = -math.inf if m.lower is None else (m.lower - m.mean) / m.sigma
    b = math.inf if m.upper is None else (m.upper - m.mean) / m.sigma
    if a > 0:
        a, b = -b, -a
    return _norm_cdf(b) - _norm_cdf(a)


OPTIMIZER = Optimizer(
    kind="monte_carlo", title="Monte Carlo", family=Family.EXPLORE, factory=MonteCarlo,
    settings_schema=SETTINGS_SCHEMA, variable_schema=VARIABLE_SCHEMA, requires_bounds=False,
    description="Samples the variables from distributions: tolerances, yield, sensitivity.",
    unavailable=lambda: missing_dependency("numpy", "pip install witwin-studio[optimize]"),
    validate=validate,
)
