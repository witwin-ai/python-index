"""Custom Sweep (plan §2, §4): evaluates the points the user lists, in their order.

``source`` says where the points come from:

- ``table``: ``rows`` stored in the Study, ``[{w = 1e-6, gap = 2e-7}, ...]``;
  the Studies panel edits and pastes them.
- ``csv``: the Project file ``path``, a header line of parameter names and
  one point per line (UTF-8, comma separated).
- ``script``: the function ``function`` (default ``points``) in the Project
  script ``path``, called once as ``points(ctx) -> list[dict]`` with a
  ``PointsContext``. It is imported the way a script objective is, so it can
  import the Project's own modules.

Every point must give a value for every variable of the run (the Study's
``variables``, or every design variable) and nothing else, so what runs is
exactly what was listed: an unknown name or a missing value is refused.
Values are checked, never moved: one outside the bounds or off the
parameter's ``step`` grid is refused (``sweep.check_point_value``). Bounds
are not required; a variable without them takes any finite value.

All points are read and checked when the run is set up, before the first
evaluation, so a bad file or script is refused (``invalid_study``) instead
of failing half way. A list longer than ``budget.max_evals`` is refused too.
A point listed twice is evaluated once (the driver's cache).

``summary``: ``{source, points, path?}``.
"""
from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from ...studies._errors import ErrorCode, StudyError, invalid
from .._space import Variable
from .base import Family, Optimizer, StrategyBase, StrategySetup, object_schema
from .sweep import MAX_BATCH, check_point_count, check_point_value

TABLE = "table"
CSV = "csv"
SCRIPT = "script"
DEFAULT_FUNCTION = "points"

SETTINGS_SCHEMA = object_schema(
    source={"type": "string", "enum": [TABLE, CSV, SCRIPT], "default": TABLE, "title": "Source",
            "enum_titles": ["Table", "CSV", "Script"]},
    rows={"type": "array", "items": {"type": "object"}, "title": "Points",
          "description": "source = table: one {parameter: value} table per point"},
    path={"type": "string", "title": "File",
          "description": "source = csv or script: a file of the Project"},
    function={"type": "string", "title": "Function",
              "description": f"source = script: the function to call (default {DEFAULT_FUNCTION})"},
)


@dataclass(frozen=True)
class PointsContext:
    """What a points script receives.

    ``variables`` are the run's design variables (``name``, ``value``,
    ``lower``, ``upper``, ``step``, ``scale``), ``seed`` the run's seed (use it
    for random points, so a run can be repeated), ``project_root`` the Project
    folder.
    """
    variables: tuple[Variable, ...]
    seed: int
    project_root: Path | None

    @property
    def names(self) -> tuple[str, ...]:
        return tuple(v.name for v in self.variables)

    # Values when the run started, by name.
    def current(self) -> dict[str, float]:
        return {v.name: v.value for v in self.variables}


class CustomSweepStrategy(StrategyBase):
    """Asks for the listed points in order, ``MAX_BATCH`` at a time."""

    def __init__(self, setup: StrategySetup) -> None:
        super().__init__(setup)
        settings = setup.settings
        self.source = str(settings.get("source", TABLE))
        self.path = settings.get("path") or None
        self.points = load_points(setup)
        check_point_count(len(self.points), setup.budget.max_evals, "custom sweep")
        self.expected_evals = len(self.points)
        self.position = 0

    def ask(self) -> list[Mapping[str, float]]:
        batch = self.points[self.position:self.position + MAX_BATCH]
        self.position += len(batch)
        return batch

    def summary(self) -> dict[str, Any]:
        out: dict[str, Any] = {"source": self.source, "points": len(self.points)}
        if self.source != TABLE and self.path:
            out["path"] = self.path
        return out

    def state_dict(self) -> dict[str, Any]:
        return {"position": self.position}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        self.position = min(len(self.points), max(0, int(state.get("position", 0))))


def load_points(setup: StrategySetup) -> list[dict[str, float]]:
    """Every point of the Study's source, checked; raises ``invalid_study`` naming the bad entry."""
    settings = setup.settings
    source = settings.get("source", TABLE)
    if source == TABLE:
        rows = settings.get("rows") or []
        if not isinstance(rows, list):
            raise invalid("method.rows must be a list of tables")
        points = _checked(setup, enumerate(rows, start=1), "row", "the table")
    elif source == CSV:
        path = _project_file(setup, settings.get("path"), "CSV file")
        points = _checked(setup, _read_csv(path, settings["path"], setup.space.names), "line",
                          settings["path"])
    elif source == SCRIPT:
        rows = _call_script(setup)
        points = _checked(setup, enumerate(rows, start=1), "point",
                          f"{settings['path']}:{_function(settings)}")
    else:
        raise invalid(f"method.source must be {TABLE}, {CSV} or {SCRIPT}, not {source!r}")
    if not points:
        where = "the table" if source == TABLE else settings.get("path")
        raise invalid(f"{where} lists no points")
    return points


# ``(number, row)`` pairs checked against the run's variables; ``number`` names the row in messages.
def _checked(setup: StrategySetup, rows: Iterable[tuple[int, Any]], noun: str,
             where: str) -> list[dict[str, float]]:
    space = setup.space
    names = space.names
    out = []
    for number, row in rows:
        label = f"{where}, {noun} {number}"
        if not isinstance(row, Mapping):
            raise invalid(f"{label} must be a table of parameter values, not {type(row).__name__}")
        unknown = [str(key) for key in row if key not in names]
        if unknown:
            raise invalid(f"{label}: {', '.join(unknown)} "
                          f"{'is not a variable' if len(unknown) == 1 else 'are not variables'} "
                          f"of this study (variables: {', '.join(names)})")
        missing = [name for name in names if row.get(name) is None or row.get(name) == ""]
        if missing:
            raise invalid(f"{label} has no value for {', '.join(missing)}")
        out.append({name: check_point_value(space[name], _number(row[name], f"{label}: {name}"),
                                            f"{label}: {name}")
                    for name in names})
    return out


def _number(value: Any, what: str) -> float:
    if isinstance(value, bool):
        raise invalid(f"{what} must be a number, not {value!r}")
    if isinstance(value, str):
        try:
            return float(value.strip())
        except ValueError:
            raise invalid(f"{what} must be a number, not {value!r}") from None
    item = getattr(value, "item", None)  # numpy and torch scalars
    try:
        number = float(item() if callable(item) else value)
    except (TypeError, ValueError):
        raise invalid(f"{what} must be a number, not {value!r}") from None
    if not math.isfinite(number):
        raise invalid(f"{what} must be a finite number, not {value!r}")
    return number


# A file of the Project; refuses a missing path, a file outside the Project or a missing file.
def _project_file(setup: StrategySetup, path: Any, what: str) -> Path:
    if not path:
        raise invalid(f"method.path is required: choose the {what}")
    if setup.project_root is None:
        raise invalid(f"a {what} needs the Project folder; open the Scene through open_project "
                      "or pass project_root")
    root = Path(setup.project_root).resolve()
    target = (root / str(path)).resolve()
    if not target.is_relative_to(root) or not target.is_file():
        raise invalid(f"{what} '{path}' is not a file in the Project")
    return target


# CSV rows as (line number, {column: cell}); refuses a header that misses a variable or names
# something else. Blank lines are skipped.
def _read_csv(path: Path, shown: str, names: tuple[str, ...]) -> list[tuple[int, dict[str, str]]]:
    try:
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.reader(handle)
            header = next(reader, None)
            if header is None:
                raise invalid(f"{shown} is empty; its first line must name the parameters")
            columns = [cell.strip() for cell in header]
            unknown = [c for c in columns if c not in names]
            if unknown:
                raise invalid(f"{shown}: column {', '.join(repr(c) for c in unknown)} "
                              f"{'is not a variable' if len(unknown) == 1 else 'are not variables'} "
                              f"of this study (variables: {', '.join(names)})")
            missing = [name for name in names if name not in columns]
            if missing:
                raise invalid(f"{shown} has no column for {', '.join(missing)}")
            repeated = sorted({c for c in columns if columns.count(c) > 1})
            if repeated:
                raise invalid(f"{shown}: column {', '.join(repeated)} appears twice")
            rows = []
            for line in reader:
                if not any(cell.strip() for cell in line):
                    continue
                if len(line) != len(columns):
                    raise invalid(f"{shown}, line {reader.line_num}: {len(line)} cells, "
                                  f"the header has {len(columns)}")
                rows.append((reader.line_num, dict(zip(columns, (cell.strip() for cell in line)))))
            return rows
    except UnicodeDecodeError as exc:
        raise invalid(f"{shown} is not UTF-8 text: {exc}") from None


def _function(settings: Mapping[str, Any]) -> str:
    return str(settings.get("function") or DEFAULT_FUNCTION).strip() or DEFAULT_FUNCTION


# Load the points script, call it once, and return what it gave as a list.
def _call_script(setup: StrategySetup) -> list[Any]:
    from .._objectives import load_project_function

    settings = setup.settings
    _project_file(setup, settings.get("path"), "points script")
    name = _function(settings)
    fn = load_project_function(setup.project_root, str(settings["path"]), name, what="points script",
                               missing=ErrorCode.INVALID_STUDY, failed=ErrorCode.INVALID_STUDY)
    ctx = PointsContext(setup.space.variables, setup.seed, setup.project_root)
    try:
        rows = fn(ctx)
    except Exception as exc:  # noqa: BLE001 - user code; refuse the run with its message
        raise StudyError(ErrorCode.INVALID_STUDY,
                                f"{settings['path']}:{name} failed: {type(exc).__name__}: {exc}") from exc
    if isinstance(rows, Mapping) or isinstance(rows, (str, bytes)) or not hasattr(rows, "__iter__"):
        raise invalid(f"{settings['path']}:{name} must return a list of {{parameter: value}} tables, "
                      f"not {type(rows).__name__}")
    return list(rows)


def validate(setup: StrategySetup) -> None:
    """Refuse bad points and a point count above ``budget.max_evals`` before the Run starts.

    A table or CSV source is read and checked in full. A script source is only
    checked to exist: running Project code belongs to the Run process.
    """
    if setup.settings.get("source", TABLE) == SCRIPT:
        _project_file(setup, setup.settings.get("path"), "points script")
        return
    CustomSweepStrategy(setup)


OPTIMIZER = Optimizer(
    kind="custom_sweep", title="Custom Sweep", family=Family.EXPLORE, factory=CustomSweepStrategy,
    settings_schema=SETTINGS_SCHEMA, requires_bounds=False, validate=validate,
    description="Evaluates points you list in a table, a CSV file or a script.",
)

__all__ = ["CustomSweepStrategy", "DEFAULT_FUNCTION", "OPTIMIZER", "PointsContext", "load_points"]
