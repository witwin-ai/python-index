"""Parameter Sweep (plan §2, §4): every point of a grid inside the bounds.

Each variable gets an axis: ``steps`` points evenly spaced over [lower, upper]
(geometrically on a ``log`` scale), or the explicit ``values`` in the order
given; without either, ``DEFAULT_STEPS`` points. Axis points are rounded to
the parameter's ``step`` and repeats dropped, so a coarse integer variable
gets one point per whole step, never the same point twice. Explicit values
are checked, not moved: one outside the bounds or off the ``step`` grid is
refused.

``mode``:

- ``grid``: the Cartesian product of the axes, in snake (boustrophedon) order:
  the last variable runs fastest and reverses direction on every pass, so
  neighbouring points differ in one variable by one axis point and an
  objective can reuse the previous simulation's state. Points are made one
  at a time from their position, so a large grid without ``max_evals``
  costs no memory.
- ``one_at_a_time``: one line per variable through the current point (every
  other variable at its value when the run started), lines in variable
  order. The current point shows up in several lines; it is evaluated once.

The point count is checked against ``budget.max_evals`` when the run is set
up, before any evaluation: a sweep that does not fit is refused
(``invalid_study``, ``data = {points, max_evals}``) rather than cut short.

Batches: one line of the fastest axis (``grid``) or of one variable
(``one_at_a_time``), at most ``MAX_BATCH`` points, so the panel gets a frame
per line.

``summary``: ``{mode, points, axes: [{name, values, scale}]}`` plus
``grid_shape`` (axis lengths in variable order) for ``grid`` and ``center``
(the current point) for ``one_at_a_time``.
"""
from __future__ import annotations

import math
from typing import Any, Mapping

from ...studies._errors import ErrorCode, StudyError, invalid
from .._space import Variable
from .base import Family, Optimizer, StrategyBase, StrategySetup, object_schema

GRID = "grid"
ONE_AT_A_TIME = "one_at_a_time"
DEFAULT_STEPS = 11
MAX_BATCH = 64
# Explicit values may sit this far (in steps) off the step grid and still count as on it.
STEP_TOLERANCE = 1e-9

SETTINGS_SCHEMA = object_schema(
    mode={"type": "string", "enum": [GRID, ONE_AT_A_TIME], "default": GRID, "title": "Mode",
          "enum_titles": ["Grid", "One at a time"],
          "description": "grid: every combination; one_at_a_time: one variable at a time"},
)

VARIABLE_SCHEMA = object_schema(
    steps={"type": "integer", "minimum": 2, "title": "Steps", "placeholder": str(DEFAULT_STEPS),
           "description": f"Evenly spaced points from lower to upper (default {DEFAULT_STEPS})"},
    values={"type": "array", "items": {"type": "number"}, "minItems": 1, "title": "Values",
            "description": "Explicit points; use instead of steps"},
)


class SweepStrategy(StrategyBase):
    """Asks for the sweep's points in order, one line per batch."""

    def __init__(self, setup: StrategySetup) -> None:
        super().__init__(setup)
        self.mode = str(setup.settings.get("mode", GRID))
        if self.mode not in (GRID, ONE_AT_A_TIME):
            raise invalid(f"method.mode must be {GRID} or {ONE_AT_A_TIME}, not {self.mode!r}")
        self.axes = [axis_points(v) for v in setup.space.variables]
        self.names = setup.space.names
        self.center = setup.space.snap(setup.space.current())
        if self.mode == GRID:
            self.total = math.prod(len(axis) for axis in self.axes)
            self._lines: list[list[dict[str, float]]] = []
        else:
            self._lines = self._oat_lines()
            self.total = sum(len(line) for line in self._lines)
        self.shape = [len(axis) for axis in self.axes]
        check_point_count(self.total, setup.budget.max_evals, "sweep")
        self.expected_evals = self.total
        self.position = 0  # points asked so far

    def ask(self) -> list[Mapping[str, float]]:
        if self.position >= self.total:
            return []
        if self.mode == GRID:
            line = len(self.axes[-1])
            end = self.position + min(MAX_BATCH, line - self.position % line)
            points = [self.grid_point(k) for k in range(self.position, end)]
        else:
            points = self._oat_batch()
        self.position += len(points)
        return points

    def grid_point(self, k: int) -> dict[str, float]:
        """The ``k``-th grid point (0-based) in snake order."""
        index = snake_index(k, self.shape)
        return {name: self.axes[i][index[i]] for i, name in enumerate(self.names)}

    def summary(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "mode": self.mode, "points": self.total,
            "axes": [{"name": v.name, "values": list(axis), "scale": v.scale}
                     for v, axis in zip(self.setup.space.variables, self.axes)],
        }
        if self.mode == GRID:
            out["grid_shape"] = list(self.shape)
        else:
            out["center"] = dict(self.center)
        return out

    def state_dict(self) -> dict[str, Any]:
        return {"position": self.position}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        self.position = min(self.total, max(0, int(state.get("position", 0))))

    # One line per variable through the center; a point already in an earlier line is left out.
    def _oat_lines(self) -> list[list[dict[str, float]]]:
        seen: set[tuple[float, ...]] = set()
        lines = []
        for name, axis in zip(self.names, self.axes):
            line = []
            for x in axis:
                point = {**self.center, name: x}
                key = tuple(point[n] for n in self.names)
                if key not in seen:
                    seen.add(key)
                    line.append(point)
            if line:
                lines.append(line)
        return lines

    # The next at most MAX_BATCH points of the line holding ``position``.
    def _oat_batch(self) -> list[dict[str, float]]:
        start = self.position
        for line in self._lines:
            if start < len(line):
                return line[start:start + MAX_BATCH]
            start -= len(line)
        return []


def snake_index(k: int, shape: list[int]) -> list[int]:
    """Axis indexes of the ``k``-th point of a snake walk over ``shape`` (last axis fastest).

    Recursive definition: the walk over (n0, rest) is n0 copies of the walk
    over ``rest``, every odd copy reversed. A reversed walk still moves one
    axis by one point at a time, so consecutive points always neighbour.
    """
    out = []
    inner = math.prod(shape)
    for size in shape:
        inner //= size
        i, k = divmod(k, inner)
        out.append(i)
        if i % 2 == 1:
            k = inner - 1 - k
    return out


def axis_points(variable: Variable) -> list[float]:
    """The sweep points of one variable: explicit ``values`` (checked) or ``steps`` points."""
    settings = variable.settings
    values, steps = settings.get("values"), settings.get("steps")
    where = f"variables.{variable.name}"
    if values is not None and steps is not None:
        raise invalid(f"{where}: give steps or values, not both")
    if values is not None:
        points = [check_point_value(variable, float(x), f"{where}.values[{i}]")
                  for i, x in enumerate(values)]
    else:
        count = DEFAULT_STEPS if steps is None else int(steps)
        if count < 2:
            raise invalid(f"{where}.steps must be >= 2, not {count}")
        points = [variable.from_unit(i / (count - 1)) for i in range(count)]
    return _unique(points)


def check_point_value(variable: Variable, x: float, what: str) -> float:
    """``x`` itself when it is finite, inside the bounds and on the ``step`` grid; else invalid_study.

    Sweeps refuse such a value instead of letting the driver clamp or round
    it, because a silently moved point would not be the point the user
    listed.
    """
    if not math.isfinite(x):
        raise invalid(f"{what} must be a finite number, not {x!r}")
    if variable.lower is not None and x < variable.lower:
        raise invalid(f"{what} = {x:g} is below the lower bound {variable.lower:g} of {variable.name}")
    if variable.upper is not None and x > variable.upper:
        raise invalid(f"{what} = {x:g} is above the upper bound {variable.upper:g} of {variable.name}")
    if variable.step is not None:
        origin = variable.lower if variable.lower is not None else 0.0
        steps = (x - origin) / variable.step
        if abs(steps - round(steps)) > STEP_TOLERANCE * max(1.0, abs(steps)):
            raise invalid(f"{what} = {x:g} is not a whole number of steps ({variable.step:g}) "
                          f"from {origin:g} for {variable.name}")
        x = variable.snap(x)
    return x


def check_point_count(points: int, max_evals: int | None, what: str) -> None:
    """Refuse a list of points larger than ``budget.max_evals`` before it starts."""
    if max_evals is not None and points > max_evals:
        raise StudyError(
            ErrorCode.INVALID_STUDY,
            f"the {what} has {points} points but budget.max_evals is {max_evals}; "
            f"raise max_evals or use fewer points", points=points, max_evals=max_evals)


# Points in their order with repeats (to 12 significant digits, as the driver's cache) dropped.
def _unique(points: list[float]) -> list[float]:
    seen: set[float] = set()
    out = []
    for x in points:
        key = float(f"{x:.12g}")
        if key not in seen:
            seen.add(key)
            out.append(x)
    return out


def validate(setup: StrategySetup) -> None:
    """Refuse the mode, explicit values and point count before the Run starts.

    Building the strategy is that check: it makes the axes (a few points per
    variable) and counts the grid without making it.
    """
    SweepStrategy(setup)


OPTIMIZER = Optimizer(
    kind="sweep", title="Parameter Sweep", family=Family.EXPLORE, factory=SweepStrategy,
    settings_schema=SETTINGS_SCHEMA, variable_schema=VARIABLE_SCHEMA, requires_bounds=True,
    validate=validate,
    description="Evaluates a grid of points inside the bounds.",
)

__all__ = ["DEFAULT_STEPS", "OPTIMIZER", "SweepStrategy", "axis_points", "check_point_count",
           "check_point_value", "snake_index"]
