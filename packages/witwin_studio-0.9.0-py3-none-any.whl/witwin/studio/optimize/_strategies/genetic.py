"""Genetic Algorithm (plan §2, §4; phase M3): real-coded GA in [0, 1]^n.

One ``ask`` is one generation. The first generation is the run's current
point plus ``population - 1`` uniform random points. Each later generation
keeps the ``elite`` best individuals unevaluated (their scores are known)
and asks for ``population - elite`` children: two parents by binary
tournament, simulated binary crossover (SBX, Deb and Agrawal 1995) with
probability ``crossover_prob`` and spread ``eta_c``, then polynomial mutation
of each gene with probability ``mutation_prob`` (default 1/n) and spread
``eta_m``. Both operators are the bounded forms, so a child never leaves
[0, 1]. A child's genes are replaced by the point the driver evaluated
(``EvalRecord.unit``), so a variable with a ``step`` only ever holds whole
steps.

A failed evaluation scores +inf: it loses every tournament and is never an
elite. ``summary.per_batch`` describes the population after each generation
(elites included, so ``best`` never gets worse). Notes:
dev_docs/studies/genetic.md.
"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any, Mapping

from ...studies._errors import invalid
from ._population import (
    CONVERGENCE_SETTINGS, Progress, make_rng, numpy_missing, scores_from_json,
    scores_to_json, unit_of,
)
from .base import Candidate, Family, Optimizer, StrategyBase, StrategySetup, object_schema

if TYPE_CHECKING:
    from .._records import EvalRecord

SETTINGS_SCHEMA = object_schema(
    population={"type": "integer", "minimum": 2, "default": 40, "title": "Population"},
    generations={"type": "integer", "minimum": 1, "default": 50, "title": "Generations"},
    crossover_prob={"type": "number", "minimum": 0, "maximum": 1, "default": 0.9,
                    "title": "Crossover rate"},
    eta_c={"type": "number", "minimum": 0, "default": 15, "title": "Crossover η"},
    mutation_prob={"type": "number", "minimum": 0, "maximum": 1, "title": "Mutation rate",
                   "placeholder": "1/n", "description": "Empty: 1 / n, n = number of variables."},
    eta_m={"type": "number", "minimum": 0, "default": 20, "title": "Mutation η"},
    elite={"type": "integer", "minimum": 0, "default": 2, "title": "Elite"},
    **CONVERGENCE_SETTINGS,
)

# Genes closer than this are treated as equal by SBX (no spread to draw from).
SBX_EPS = 1e-14


class GeneticStrategy(StrategyBase):
    """One GA run; state is plain lists so ``state_dict`` is JSON-ready."""

    def __init__(self, setup: StrategySetup) -> None:
        super().__init__(setup)
        s = setup.settings
        self.dim = setup.space.dim
        self.size = int(s.get("population", 40))
        self.generations = int(s.get("generations", 50))
        self.elite = int(s.get("elite", 2))
        validate(setup)
        self.crossover_prob = float(s.get("crossover_prob", 0.9))
        self.eta_c = float(s.get("eta_c", 15))
        mutation = s.get("mutation_prob")
        self.mutation_prob = 1.0 / self.dim if mutation is None else float(mutation)
        self.eta_m = float(s.get("eta_m", 20))
        self.expected_evals = self.size + (self.generations - 1) * (self.size - self.elite)
        self.rng = make_rng(setup.seed)
        self.progress = Progress(float(s.get("tol", 1e-6)), int(s.get("patience", 0)), setup.maximize)
        self.generation = 0                      # generations told so far
        self.population: list[list[float]] = []  # genes in [0, 1]^n after the last generation
        self.scores: list[float] = []            # one per individual; +inf when failed
        self.pending: list[list[float]] = []     # asked, not told yet
        self.kept: list[int] = []                # indexes of ``population`` carried into ``pending``'s generation

    def ask(self) -> list[Candidate]:
        if self.converged or self.generation >= self.generations:
            return []
        # A generation asked and not told (a run resumed between ask and tell) is asked again.
        if not self.pending and self.generation == 0:
            current = self.setup.space.to_unit(self.setup.space.current())
            self.pending = [list(current)] + self.rng.random((self.size - 1, self.dim)).tolist()
            self.kept = []
        elif not self.pending:
            self.kept = self._elite()
            self.pending = self._children(self.size - self.elite)
        return [Candidate(self.setup.space.from_unit(genes)) for genes in self.pending]

    def tell(self, records: list["EvalRecord"]) -> None:
        if not self.pending:
            return
        genes = [unit_of(r, g) for r, g in zip(records, self.pending)] + self.pending[len(records):]
        scores = [self.setup.score(r) for r in records] + [math.inf] * (len(self.pending) - len(records))
        self.population = [self.population[i] for i in self.kept] + genes
        self.scores = [self.scores[i] for i in self.kept] + scores
        self.pending, self.kept = [], []
        self.generation += 1
        self.converged = self.progress.record(self.generation, self.scores)

    def summary(self) -> dict[str, Any]:
        return self.progress.summary()

    def state_dict(self) -> dict[str, Any]:
        return {"generation": self.generation, "population": [list(g) for g in self.population],
                "scores": scores_to_json(self.scores), "pending": [list(g) for g in self.pending],
                "kept": list(self.kept), "converged": self.converged,
                "rng": self.rng.bit_generator.state, "progress": self.progress.state_dict()}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        self.generation = int(state["generation"])
        self.population = [[float(u) for u in g] for g in state["population"]]
        self.scores = scores_from_json(state["scores"])
        self.pending = [[float(u) for u in g] for g in state.get("pending", [])]
        self.kept = [int(i) for i in state.get("kept", [])]
        self.converged = bool(state.get("converged", False))
        self.rng.bit_generator.state = state["rng"]
        self.progress.load_state_dict(state.get("progress", {}))

    # Indexes of the ``elite`` best individuals; ties keep the earlier one.
    def _elite(self) -> list[int]:
        order = sorted(range(len(self.scores)), key=lambda i: self.scores[i])
        return order[:self.elite]

    def _children(self, count: int) -> list[list[float]]:
        children: list[list[float]] = []
        while len(children) < count:
            a, b = self._tournament(), self._tournament()
            if self.rng.random() < self.crossover_prob:
                a, b = self._sbx(a, b)
            children.append(self._mutate(a))
            if len(children) < count:
                children.append(self._mutate(b))
        return children

    # Binary tournament: the lower score of two random individuals (a copy of its genes).
    def _tournament(self) -> list[float]:
        i, j = (int(k) for k in self.rng.integers(0, len(self.population), size=2))
        return list(self.population[j if self.scores[j] < self.scores[i] else i])

    # Bounded SBX: each gene pair crosses with probability 1/2; children are swapped with 1/2.
    def _sbx(self, a: list[float], b: list[float]) -> tuple[list[float], list[float]]:
        c1, c2 = list(a), list(b)
        power = 1.0 / (self.eta_c + 1.0)
        for i in range(self.dim):
            if self.rng.random() > 0.5 or abs(a[i] - b[i]) <= SBX_EPS:
                continue
            y1, y2 = min(a[i], b[i]), max(a[i], b[i])
            spread = y2 - y1
            u = self.rng.random()
            low = _sbx_child(y1, y2, 1.0 + 2.0 * y1 / spread, u, self.eta_c, power, -1.0)
            high = _sbx_child(y1, y2, 1.0 + 2.0 * (1.0 - y2) / spread, u, self.eta_c, power, 1.0)
            if self.rng.random() < 0.5:
                low, high = high, low
            c1[i], c2[i] = low, high
        return c1, c2

    # Bounded polynomial mutation of each gene with probability ``mutation_prob``.
    def _mutate(self, genes: list[float]) -> list[float]:
        out = list(genes)
        power = 1.0 / (self.eta_m + 1.0)
        for i in range(self.dim):
            if self.rng.random() >= self.mutation_prob:
                continue
            y, u = out[i], self.rng.random()
            if u < 0.5:
                value = 2.0 * u + (1.0 - 2.0 * u) * (1.0 - y) ** (self.eta_m + 1.0)
                delta = value ** power - 1.0
            else:
                value = 2.0 * (1.0 - u) + 2.0 * (u - 0.5) * y ** (self.eta_m + 1.0)
                delta = 1.0 - value ** power
            out[i] = min(1.0, max(0.0, y + delta))
        return out


# One SBX child of the parents y1 <= y2; ``sign`` -1 for the one near y1, +1 for the one near y2.
def _sbx_child(y1: float, y2: float, beta: float, u: float, eta: float, power: float,
               sign: float) -> float:
    alpha = 2.0 - beta ** -(eta + 1.0)
    if u <= 1.0 / alpha:
        beta_q = (u * alpha) ** power
    else:
        beta_q = (1.0 / (2.0 - u * alpha)) ** power
    child = 0.5 * ((y1 + y2) + sign * beta_q * (y2 - y1))
    return min(1.0, max(0.0, child))


def validate(setup: StrategySetup) -> None:
    """Refuse ``elite >= population`` before the Run starts."""
    size, elite = int(setup.settings.get("population", 40)), int(setup.settings.get("elite", 2))
    if elite >= size:
        raise invalid(f"method.elite must be less than method.population ({size}), not {elite}")


OPTIMIZER = Optimizer(
    kind="genetic", title="Genetic Algorithm", family=Family.BLACKBOX, factory=GeneticStrategy,
    settings_schema=SETTINGS_SCHEMA, requires_bounds=True,
    description="Evolves a population; copes with many local optima and integer variables.",
    unavailable=numpy_missing,
    validate=validate,
)
