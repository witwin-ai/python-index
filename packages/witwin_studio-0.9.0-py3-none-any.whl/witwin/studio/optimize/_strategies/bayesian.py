"""Bayesian Optimization (plan §2, §4; phase M4) with BoTorch.

For objectives that are slow to evaluate, up to ``MAX_VARIABLES`` variables,
single objective. BoTorch is the optional extra ``witwin-studio[bayes]``;
it is imported only when a run starts, so the registry stays light. Without
it the method is listed with ``available = false`` and a run is refused with
``dependency_missing``.

A run has two phases:

1. Initial design: ``initial_points`` (default 2n + 1) scrambled Sobol points,
   asked as one batch. Records carry the note ``NOTE_INITIAL``.
2. Model phase: each ``ask`` refits a ``SingleTaskGP`` on every successful
   record so far and maximizes an acquisition function with ``optimize_acqf``.
   Records carry ``"model: <acquisition>"``.

The GP works in the run's normalized space [0, 1]^n (``DesignSpace.to_unit``),
so inputs are already normalized; outcomes are standardized (``Standardize``)
and are ``-setup.score(record)``, because BoTorch maximizes and ``score`` is a
number to minimize (already negated for ``maximize``).

Acquisition: ``log_ei`` uses analytic ``LogExpectedImprovement`` when
``batch_size = 1`` and ``qLogExpectedImprovement`` otherwise; ``ucb`` uses
``UpperConfidenceBound`` / ``qUpperConfidenceBound`` with ``beta``. A batch is
built greedily, one point at a time with the points already chosen passed as
``X_pending`` (the same sequential-greedy scheme as ``optimize_acqf(...,
sequential=True)``), because each point must be snapped and checked for
repeats before the next one is chosen.

Snapping and repeats: every proposed point goes through ``from_unit`` (the
driver's ``step`` rounding and bounds), so an integer variable only sees whole
steps. A snapped point that equals an observed, failed or already chosen
point is skipped for the next-best restart, then for the best of a fresh
Sobol set; when even that finds nothing new the discrete space is used up and
the run ends ``converged``.

Failed records are not fitted (the GP needs a number) but count against
the evaluation limit and are never proposed again. ``state_dict`` stores the
observed points and the Sobol position, so a resumed run refits the same
model. Runs are reproducible for one seed on one machine: every random draw
(Sobol scramble, restarts, MC samples, fit retries) is seeded from the run's
seed and the ask count, and the model step runs torch on one thread (see
``_one_thread``), so the same seed gives the same points on one machine.
"""
from __future__ import annotations

import logging
import math
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Iterator, Mapping

from ...studies._errors import ErrorCode, StudyError
from .base import Candidate, Family, Optimizer, StrategyBase, StrategySetup, missing_dependency, object_schema

if TYPE_CHECKING:
    from .._records import EvalRecord

MAX_VARIABLES = 20
NOTE_INITIAL = "initial"
NOTE_FALLBACK = "fallback: Sobol"  # the GP fit failed or too few successful points to fit
MODEL_NOTE_PREFIX = "model: "
INSTALL_HINT = "install it with pip install witwin-studio[bayes] (or pip install botorch)"
# Fresh Sobol draws per wanted initial point before giving up on finding a new snapped point.
SOBOL_TRIES = 64
MIN_FIT_POINTS = 2  # successful points needed before the GP is fitted
MC_SAMPLES = 128    # QMC samples of the q-batch acquisition functions
# Evaluations when the Study's budget sets no max_evals; the GP refit grows as n^3,
# so the method always stops. The panel shows it in the budget's field.
DEFAULT_MAX_EVALS = 50

logger = logging.getLogger("witwin.studio")

SETTINGS_SCHEMA = object_schema(
    initial_points={"type": "integer", "minimum": 1, "title": "Initial points", "placeholder": "2n + 1",
                    "description": "Sobol points before the model is used. Empty: 2 × number of "
                                   "variables + 1."},
    acquisition={"type": "string", "enum": ["log_ei", "ucb"], "default": "log_ei",
                 "enum_titles": ["Log EI", "UCB"], "title": "Acquisition",
                 "description": "Log EI: expected improvement (log form). UCB: upper "
                                "confidence bound; larger beta explores more."},
    beta={"type": "number", "exclusiveMinimum": 0, "default": 2.0, "title": "UCB beta",
          "show_if": {"acquisition": ["ucb"]},
          "description": "Exploration weight of UCB; ignored by Log EI."},
    batch_size={"type": "integer", "minimum": 1, "default": 1, "title": "Batch size",
                "description": "Points proposed per model fit; > 1 lets them run in parallel."},
    num_restarts={"type": "integer", "minimum": 1, "default": 10, "title": "Restarts",
                  "description": "Starting points of the acquisition optimizer."},
    raw_samples={"type": "integer", "minimum": 1, "default": 256, "title": "Raw samples",
                 "description": "Random points scored to choose the restarts."},
)


def validate(setup: StrategySetup) -> None:
    """Refuse more than ``MAX_VARIABLES`` variables before the Run starts (imports no BoTorch)."""
    dim = setup.space.dim
    if dim > MAX_VARIABLES:
        raise StudyError(
            ErrorCode.INVALID_STUDY,
            f"Bayesian Optimization handles up to {MAX_VARIABLES} variables, this Study has "
            f"{dim}. Use Genetic Algorithm, Particle Swarm or Gradient Descent, or pick "
            f"fewer variables for this Study.", variables=dim, limit=MAX_VARIABLES)


def evaluation_limit(setup: StrategySetup) -> int:
    """``budget.max_evals``, else ``DEFAULT_MAX_EVALS``."""
    return setup.budget.max_evals or DEFAULT_MAX_EVALS


def _unavailable():
    return missing_dependency("botorch", INSTALL_HINT)


class BayesianStrategy(StrategyBase):
    """One Bayesian Optimization run; see the module docstring."""

    def __init__(self, setup: StrategySetup) -> None:
        super().__init__(setup)
        space = setup.space
        validate(setup)
        settings = setup.settings
        self.max_evals = evaluation_limit(setup)
        initial = settings.get("initial_points")
        self.initial_points = min(int(initial) if initial is not None else 2 * space.dim + 1,
                                  self.max_evals)
        self.acquisition = str(settings.get("acquisition", "log_ei"))
        self.beta = float(settings.get("beta", 2.0))
        self.batch_size = int(settings.get("batch_size", 1))
        self.num_restarts = int(settings.get("num_restarts", 10))
        self.raw_samples = max(int(settings.get("raw_samples", 256)), self.num_restarts)
        self.expected_evals = self.max_evals
        # index -> {"values", "unit", "y" (None when failed), "initial"}; y is the fitted target.
        self._observed: dict[int, dict[str, Any]] = {}
        self._sobol_drawn = 0  # points taken from the run's Sobol sequence, for resume
        self._asks = 0         # model asks so far; part of each ask's random seed
        self._torch = _import_botorch()
        self._sobol = self._torch.quasirandom.SobolEngine(space.dim, scramble=True, seed=setup.seed)

    # ---- Strategy -------------------------------------------------------------------

    def ask(self) -> list[Candidate]:
        room = self.max_evals - len(self._observed)
        if room <= 0:
            return []
        initial_seen = sum(1 for obs in self._observed.values() if obs["initial"])
        if initial_seen < self.initial_points:
            count = min(self.initial_points - initial_seen, room)
            return self._sobol_batch(count, NOTE_INITIAL)
        count = min(self.batch_size, room)
        if len(self._fit_rows()) < MIN_FIT_POINTS:
            return self._sobol_batch(count, NOTE_FALLBACK)
        self._asks += 1
        try:
            return self._model_batch(count)
        except Exception as exc:  # noqa: BLE001 - a numerical failure of the fit; go on sampling
            logger.warning("bayesian: model step failed (%s: %s); asking Sobol points",
                           type(exc).__name__, exc)
            return self._sobol_batch(count, NOTE_FALLBACK)

    def tell(self, records: list["EvalRecord"]) -> None:
        for record in records:
            if record.index in self._observed:  # a repeat served from the driver's cache
                continue
            score = self.setup.score(record)
            unit = record.unit if record.unit is not None else self.setup.space.to_unit(record.values)
            self._observed[record.index] = {
                "values": dict(record.values), "unit": [float(u) for u in unit],
                "y": -score if math.isfinite(score) else None,
                "initial": record.note == NOTE_INITIAL,
            }

    def summary(self) -> dict[str, Any]:
        best_so_far: list[float | None] = []
        best = None
        for index in sorted(self._observed):
            y = self._observed[index]["y"]
            if y is not None and (best is None or y > best):
                best = y
            best_so_far.append(None if best is None else self._loss(best))
        ordered = [self._observed[i] for i in sorted(self._observed)]
        return {
            "best_so_far": best_so_far,
            "initial_points": self.initial_points,
            "acquisition": self.acquisition,
            "batch_size": self.batch_size,
            "fitted": sum(1 for obs in ordered if obs["y"] is not None),
            "failed": sum(1 for obs in ordered if obs["y"] is None),
            "dim": self.setup.space.dim,
        }

    def state_dict(self) -> dict[str, Any]:
        return {"observed": [{"index": i, **self._observed[i]} for i in sorted(self._observed)],
                "sobol_drawn": self._sobol_drawn, "asks": self._asks}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        self._observed = {}
        for row in state.get("observed", ()):
            self._observed[int(row["index"])] = {
                "values": {k: float(v) for k, v in row["values"].items()},
                "unit": [float(u) for u in row["unit"]],
                "y": None if row.get("y") is None else float(row["y"]),
                "initial": bool(row.get("initial", False)),
            }
        self._sobol = self._torch.quasirandom.SobolEngine(self.setup.space.dim, scramble=True,
                                                          seed=self.setup.seed)
        self._sobol_drawn = int(state.get("sobol_drawn", 0))
        if self._sobol_drawn:
            self._sobol.fast_forward(self._sobol_drawn)
        self._asks = int(state.get("asks", 0))

    # ---- proposals ------------------------------------------------------------------

    # ``count`` new snapped points from the run's Sobol sequence; fewer when the space runs out.
    def _sobol_batch(self, count: int, note: str) -> list[Candidate]:
        taken = self._taken()
        out: list[Candidate] = []
        for _ in range(count * SOBOL_TRIES):
            if len(out) == count:
                break
            unit = self._sobol.draw(1, dtype=self._torch.float64)[0].tolist()
            self._sobol_drawn += 1
            values = self.setup.space.from_unit(unit)
            key = _key(values, self.setup.space.names)
            if key in taken:
                continue
            taken.add(key)
            out.append(Candidate(values, note=note))
        if not out:
            self.converged = True
        return out

    # ``count`` points from the fitted GP, greedily with the earlier ones as X_pending.
    def _model_batch(self, count: int) -> list[Candidate]:
        torch = self._torch
        from botorch.optim import optimize_acqf

        seed = (self.setup.seed * 1_000_003 + self._asks) % (2 ** 31)
        dim = self.setup.space.dim
        bounds = torch.stack([torch.zeros(dim, dtype=torch.float64),
                              torch.ones(dim, dtype=torch.float64)])
        taken = self._taken()
        chosen: list[list[float]] = []
        out: list[Candidate] = []
        with torch.random.fork_rng(devices=[]), torch.enable_grad(), _quiet(), _one_thread(torch):
            torch.manual_seed(seed)
            model, best_f = self._fit()
            for slot in range(count):
                pending = torch.tensor(chosen, dtype=torch.float64) if chosen else None
                acq, name = self._acquisition(model, best_f, pending, seed + slot)
                raw, _ = optimize_acqf(acq, bounds=bounds, q=1, num_restarts=self.num_restarts,
                                       raw_samples=self.raw_samples, return_best_only=False,
                                       options={"seed": seed + slot})
                found = self._first_new(acq, raw.reshape(-1, dim), taken)
                if found is None:
                    found = self._first_new(acq, self._random_units(seed + slot), taken)
                if found is None:
                    break
                values, unit = found
                taken.add(_key(values, self.setup.space.names))
                chosen.append(unit)
                out.append(Candidate(values, note=MODEL_NOTE_PREFIX + name))
        if not out:
            self.converged = True
        return out

    # The best-scoring candidate (rows of ``units``) whose snapped point is new, as (values, unit).
    def _first_new(self, acq: Any, units: Any, taken: set[tuple[str, ...]]
                   ) -> tuple[dict[str, float], list[float]] | None:
        torch, space = self._torch, self.setup.space
        with torch.no_grad():
            scores = acq(units.unsqueeze(-2)).reshape(-1)
        for row in torch.argsort(scores, descending=True).tolist():
            values = space.from_unit(units[row].tolist())
            if _key(values, space.names) not in taken:
                return values, list(space.to_unit(values))
        return None

    # Fresh Sobol points for the repeat fallback; not taken from the run's sequence.
    def _random_units(self, seed: int) -> Any:
        engine = self._torch.quasirandom.SobolEngine(self.setup.space.dim, scramble=True, seed=seed)
        return engine.draw(self.raw_samples, dtype=self._torch.float64)

    def _fit(self) -> tuple[Any, float]:
        torch = self._torch
        from botorch.fit import fit_gpytorch_mll
        from botorch.models import SingleTaskGP
        from botorch.models.transforms import Standardize
        from gpytorch.mlls import ExactMarginalLogLikelihood

        rows = self._fit_rows()
        x = torch.tensor([obs["unit"] for obs in rows], dtype=torch.float64)
        y = torch.tensor([[obs["y"]] for obs in rows], dtype=torch.float64)
        model = SingleTaskGP(x, y, outcome_transform=Standardize(m=1))
        fit_gpytorch_mll(ExactMarginalLogLikelihood(model.likelihood, model))
        return model, float(y.max())

    def _acquisition(self, model: Any, best_f: float, pending: Any, seed: int) -> tuple[Any, str]:
        from botorch import acquisition as acqf
        from botorch.sampling import SobolQMCNormalSampler

        torch = self._torch
        if self.batch_size == 1:
            if self.acquisition == "ucb":
                return acqf.UpperConfidenceBound(model, beta=self.beta), "ucb"
            return acqf.LogExpectedImprovement(model, best_f=best_f), "log_ei"
        sampler = SobolQMCNormalSampler(sample_shape=torch.Size([MC_SAMPLES]), seed=seed)
        if self.acquisition == "ucb":
            return acqf.qUpperConfidenceBound(model, beta=self.beta, sampler=sampler,
                                              X_pending=pending), "q_ucb"
        return acqf.qLogExpectedImprovement(model, best_f=best_f, sampler=sampler,
                                            X_pending=pending), "q_log_ei"

    # ---- bookkeeping ----------------------------------------------------------------

    def _fit_rows(self) -> list[dict[str, Any]]:
        return [self._observed[i] for i in sorted(self._observed) if self._observed[i]["y"] is not None]

    # Keys of every observed point, failed ones included, so none is proposed twice.
    def _taken(self) -> set[tuple[str, ...]]:
        names = self.setup.space.names
        return {_key(obs["values"], names) for obs in self._observed.values()}

    # A fitted target back to the objective's loss as returned.
    def _loss(self, y: float) -> float:
        return y if self.setup.maximize else -y


# The driver's cache key: values in variable order, 12 significant digits.
def _key(values: Mapping[str, float], names: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(f"{float(values[name]):.12g}" for name in names)


def _import_botorch() -> Any:
    try:
        import botorch  # noqa: F401
        import torch
    except ImportError as exc:
        raise StudyError(ErrorCode.DEPENDENCY_MISSING,
                                f"Bayesian Optimization needs botorch; {INSTALL_HINT}") from exc
    return torch


# Runs torch on one CPU thread inside the block. The GP has at most a few hundred points,
# so thread start-up dominates: one thread made a model step about 12x faster on an
# 8-thread machine (1.2 s -> 0.1 s, Branin, 10 points). It also makes the digits repeat.
@contextmanager
def _one_thread(torch: Any) -> Iterator[None]:
    before = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        yield
    finally:
        torch.set_num_threads(before)


# Silences BoTorch's and GPyTorch's numerical warnings (jitter, standardization, restarts):
# they are expected on small, noiseless data sets and would flood the run's console.
def _quiet() -> Any:
    import warnings
    from contextlib import ExitStack

    from botorch.exceptions.warnings import BotorchWarning
    from linear_operator.utils.warnings import NumericalWarning

    stack = ExitStack()
    stack.enter_context(warnings.catch_warnings())
    warnings.simplefilter("ignore", BotorchWarning)
    warnings.simplefilter("ignore", NumericalWarning)
    return stack


OPTIMIZER = Optimizer(
    kind="bayesian", title="Bayesian Optimization", family=Family.BLACKBOX,
    factory=BayesianStrategy, settings_schema=SETTINGS_SCHEMA, requires_bounds=True,
    default_max_evals=DEFAULT_MAX_EVALS,
    description="Fits a surrogate model; for objectives that are slow to evaluate (up to 20 variables).",
    unavailable=_unavailable,
    validate=validate,
)
