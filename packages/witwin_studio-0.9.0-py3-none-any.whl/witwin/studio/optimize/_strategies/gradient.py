"""Gradient Descent: the gradient family's registry entry (plan §2, §5).

This method has no ``Strategy``: ``optimize._gradient.GradientDriver`` runs
it (torch leaf tensors, a torch optimizer or MMA, one point per step). This
module declares its ``method`` settings; ``dev_docs/studies/gradient.md``
explains each one. A new optimizer name also goes into ``studies._model.GradientOptimizer``.

``show_if`` on a property (``{setting: [values]}``) tells the panel to draw
that field only while another setting has one of those values; validation
ignores it, so a hidden setting keeps its value.
"""
from __future__ import annotations

from ...studies._model import GradientOptimizer
from .base import Family, Optimizer, object_schema

# Optimizers that take a learning rate and a schedule; MMA chooses its own step.
_STEPPED = [str(GradientOptimizer.ADAM), str(GradientOptimizer.SGD), str(GradientOptimizer.LBFGS)]
# Optimizers that use gradient clipping: L-BFGS's line search needs the true gradient.
_CLIPPED = [str(GradientOptimizer.ADAM), str(GradientOptimizer.SGD)]
_OPTIMIZER_TITLES = {GradientOptimizer.ADAM: "Adam", GradientOptimizer.SGD: "SGD", GradientOptimizer.LBFGS: "L-BFGS", GradientOptimizer.MMA: "MMA"}

SETTINGS_SCHEMA = object_schema(
    optimizer={"type": "string", "enum": [str(m) for m in GradientOptimizer], "default": str(GradientOptimizer.ADAM),
               "enum_titles": [_OPTIMIZER_TITLES[m] for m in GradientOptimizer], "title": "Optimizer",
               "description": "adam, sgd and lbfgs are torch optimizers; mma is the Method of Moving "
                              "Asymptotes, which also honours the objective's constraints."},
    lr={"type": "number", "exclusiveMinimum": 0, "default": 0.01, "title": "Learning rate",
        "show_if": {"optimizer": _STEPPED}},
    max_iters={"type": "integer", "minimum": 1, "default": 200, "title": "Max iterations"},
    tol={"type": "number", "minimum": 0, "default": 1e-6, "title": "Tolerance",
         "description": "Stop when the loss changes by less than this between steps; 0 never stops."},
    schedule={"type": "string", "enum": ["constant", "cosine", "step"], "default": "constant",
              "enum_titles": ["Constant", "Cosine", "Step"], "title": "Schedule", "show_if": {"optimizer": _STEPPED},
              "description": "Learning rate over the steps: constant; cosine from lr down to 0 over "
                             "Max iterations, then again; step multiplies it by Gamma every Step size steps."},
    step_size={"type": "integer", "minimum": 1, "default": 50, "title": "Step size",
               "show_if": {"schedule": ["step"]}},
    gamma={"type": "number", "exclusiveMinimum": 0, "maximum": 1, "default": 0.5, "title": "Gamma",
           "show_if": {"schedule": ["step"]}},
    grad_clip={"type": "number", "minimum": 0, "default": 0.0, "title": "Gradient clip",
               "show_if": {"optimizer": _CLIPPED},
               "description": "Largest gradient norm per step; a longer gradient is scaled down to it. 0 = off."},
    bounds={"type": "string", "enum": ["auto", "clamp", "sigmoid"], "default": "auto", "title": "Bounds",
            "enum_titles": ["Auto", "Clamp", "Sigmoid"],
            "show_if": {"optimizer": _STEPPED},
            "description": "clamp puts a variable back inside its bounds after each step; sigmoid optimizes "
                           "an unbounded variable mapped into them. auto: sigmoid for lbfgs, clamp otherwise."},
    penalty={"type": "number", "minimum": 0, "default": 10.0, "title": "Penalty",
             "show_if": {"optimizer": _STEPPED},
             "description": "Weight of the squared violation of each constraint the objective returns "
                            "(MMA handles constraints itself)."},
    move={"type": "number", "exclusiveMinimum": 0, "maximum": 1, "default": 0.5, "title": "Move limit",
          "show_if": {"optimizer": [str(GradientOptimizer.MMA)]},
          "description": "Largest change per step, as a fraction of each variable's range."},
    checkpoint_every={"type": "integer", "minimum": 0, "default": 10, "title": "Save every",
                      "description": "Steps between checkpoints a later run can continue from; 0 = none."},
)

OPTIMIZER = Optimizer(
    kind="gradient", title="Gradient Descent", family=Family.GRADIENT,
    settings_schema=SETTINGS_SCHEMA, requires_bounds=False,
    description="Follows the objective's gradient; needs a differentiable objective.",
)
