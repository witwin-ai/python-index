"""Host-side validation for solver binary result references."""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any


def safe_solver_dir_name(solver_id: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in solver_id)


def read_result_ref(ref: Any, *, root: Path) -> bytes:
    if not isinstance(ref, dict):
        raise ValueError("resultRef must be an object")
    path_raw = ref.get("path")
    if not path_raw:
        raise ValueError("resultRef path is required")
    path = Path(str(path_raw))
    try:
        resolved = path.resolve()
        resolved.relative_to(Path(root).resolve())
    except Exception as exc:  # noqa: BLE001
        raise ValueError("resultRef path must stay inside solver result directory") from exc

    payload = resolved.read_bytes()
    expected = str(ref.get("contentHash") or "")
    if not expected.startswith("sha256:") or len(expected.split(":", 1)[1]) != 64:
        raise ValueError("resultRef contentHash must be sha256")
    actual = hashlib.sha256(payload).hexdigest()
    if actual != expected.split(":", 1)[1]:
        raise ValueError("resultRef content hash mismatch")
    size = ref.get("size")
    if size is not None and int(size) != len(payload):
        raise ValueError("resultRef size mismatch")
    return payload
