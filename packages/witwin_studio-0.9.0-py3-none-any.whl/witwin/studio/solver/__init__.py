"""Solvers: the child-side SDK and headless solves (decision D11, phase P5).

A Plugin's solver entry (``solver_host.py``) runs as a child process and talks
RFC-012 JSON-RPC over stdin/stdout::

    from witwin.studio.solver import query, serve

    def solve(ctx, scene, config):
        ctx.progress(0.5, "halfway")
        return {"value": 42}

    serve(solve)                      # scene: the ProjectServer's live Scene model
    serve(solve, scene="document")    # scene: the .wtscene document; no witwin_server import

The same child runs under the ProjectServer and headless
(``Project.solve`` / ``witwin solve``, :mod:`.client`). This package moved
from ``witwin_server.features.solvers`` (``sdk``, ``protocol``, ``scene_ref``,
``spec``, ``result_ref``); the old paths are gone (2026-11-03).
"""
from ._serve import SolveContext, SolverCancelled, method, query, serve
from .client import SolveRun, SolverError, SolverProcess, find_solver, list_solvers
from .protocol import SOLVER_SENTINEL, encode_message, parse_solver_line
from .result_ref import read_result_ref, safe_solver_dir_name
from .scene_ref import (
    FORMAT as SCENE_REF_FORMAT,
    SCENE_DOCUMENT,
    SCENE_LIVE,
    load_scene_ref,
    make_document_scene_ref,
)
from .spec import SolverResources, SolverRuntimeSpec, SolverSpec

__all__ = [
    "SCENE_DOCUMENT",
    "SCENE_LIVE",
    "SCENE_REF_FORMAT",
    "SOLVER_SENTINEL",
    "SolveContext",
    "SolveRun",
    "SolverCancelled",
    "SolverError",
    "SolverProcess",
    "SolverResources",
    "SolverRuntimeSpec",
    "SolverSpec",
    "encode_message",
    "find_solver",
    "list_solvers",
    "load_scene_ref",
    "make_document_scene_ref",
    "method",
    "parse_solver_line",
    "query",
    "read_result_ref",
    "safe_solver_dir_name",
    "serve",
]
