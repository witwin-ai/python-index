"""Declarative solver specifications from `contributes.solvers` in ``witwin.toml``.

Moved from ``witwin_server.features.solvers.spec`` (decision D11, phase P5);
the old path is gone. The ProjectServer and headless solves
(``witwin.studio.solver.client``) parse runtimes the same way.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from .._environment import project_python as _project_python

_ENV_PATTERN = re.compile(r"\$\{env:([A-Za-z_][A-Za-z0-9_]*)\}")
# The Project interpreter (decision D11.7): the Project's .venv, or the one the
# user chose, else the caller's own. See witwin.studio._environment.
PROJECT_PYTHON = "${project:python}"
_CUDA_ARCH = re.compile(r"^sm_\d{2,3}[a-z]?$")
_RESOURCE_KEYS = frozenset({"gpu", "min_vram_gb", "cuda_arch", "remote"})


@dataclass(frozen=True)
class SolverResources:
    """Hardware a solver needs: ``[contributes.solvers.resources]`` (remote-solver plan R0).

    ``gpu`` NVIDIA cards, each with at least ``min_vram_gb`` GB and, when
    ``cuda_arch`` is not empty, one of those architectures (the ones the
    Plugin is compiled for). ``gpu = 0`` (the default) means a CPU is enough.
    ``remote = False`` keeps the solver on this machine whatever the
    placement setting says.

    A card is a mapping like ``GpuInfo.to_json()`` of studio.runs' GPU pool:
    ``{"index", "name", "vramGb", "cudaArch"}``. ``vramGb`` or ``cudaArch``
    None means the detector could not tell; such a card counts as fitting, so
    an old driver never blocks a solve that worked before R0.
    """

    gpu: int = 0
    min_vram_gb: float = 0.0
    cuda_arch: Tuple[str, ...] = ()
    remote: bool = True

    @property
    def needs_gpu(self) -> bool:
        return self.gpu > 0

    def fits(self, card: Mapping[str, Any]) -> bool:
        vram = card.get("vramGb")
        if self.min_vram_gb and vram is not None and float(vram) < self.min_vram_gb:
            return False
        arch = card.get("cudaArch")
        if self.cuda_arch and arch and str(arch) not in self.cuda_arch:
            return False
        return True

    def shortfall(self, cards: Sequence[Mapping[str, Any]]) -> Optional[str]:
        """Why ``cards`` cannot run this solver, or None when they can."""
        if not self.needs_gpu:
            return None
        if sum(1 for card in cards if self.fits(card)) >= self.gpu:
            return None
        have = ", ".join(describe_gpu(card) for card in cards) or "no NVIDIA GPU"
        return f"needs {self.describe()}; this machine has {have}"

    def describe(self) -> str:
        if not self.needs_gpu:
            return "no GPU"
        text = f"{self.gpu} NVIDIA GPU" + ("s" if self.gpu > 1 else "")
        if self.min_vram_gb:
            text += f" with at least {self.min_vram_gb:g} GB"
        if self.cuda_arch:
            text += f" ({' or '.join(self.cuda_arch)})"
        return text

    def to_json(self) -> Dict[str, Any]:
        return {
            "gpu": self.gpu,
            "minVramGb": self.min_vram_gb,
            "cudaArch": list(self.cuda_arch),
            "remote": self.remote,
        }


def describe_gpu(card: Mapping[str, Any]) -> str:
    """``RTX 4090 (24 GB, sm_89)``; the parts the detector did not know are left out."""
    details = []
    if card.get("vramGb") is not None:
        details.append(f"{float(card['vramGb']):g} GB")
    if card.get("cudaArch"):
        details.append(str(card["cudaArch"]))
    name = str(card.get("name") or f"GPU {card.get('index')}")
    return f"{name} ({', '.join(details)})" if details else name


def parse_resources(solver_id: str, raw: Any) -> SolverResources:
    """``[contributes.solvers.resources]``; raises ``ValueError`` for a malformed table.

    Unknown keys are refused, so a camelCase ``minVramGb`` fails loudly
    instead of silently meaning "any card".
    """
    if raw is None:
        return SolverResources()
    if not isinstance(raw, dict):
        raise ValueError(f"{solver_id}: resources must be a table")
    unknown = sorted(set(raw) - _RESOURCE_KEYS)
    if unknown:
        raise ValueError(f"{solver_id}: unknown resources keys {unknown}; expected {sorted(_RESOURCE_KEYS)}")
    gpu = raw.get("gpu", 0)
    if isinstance(gpu, bool) or not isinstance(gpu, int) or gpu < 0:
        raise ValueError(f"{solver_id}: resources.gpu must be a whole number >= 0")
    vram = raw.get("min_vram_gb", 0)
    if isinstance(vram, bool) or not isinstance(vram, (int, float)) or vram < 0:
        raise ValueError(f"{solver_id}: resources.min_vram_gb must be a number >= 0")
    arch = raw.get("cuda_arch", [])
    if not isinstance(arch, list) or not all(isinstance(a, str) and _CUDA_ARCH.match(a) for a in arch):
        raise ValueError(f'{solver_id}: resources.cuda_arch must be a list like ["sm_86", "sm_89"]')
    remote = raw.get("remote", True)
    if not isinstance(remote, bool):
        raise ValueError(f"{solver_id}: resources.remote must be true or false")
    return SolverResources(gpu=gpu, min_vram_gb=float(vram), cuda_arch=tuple(arch), remote=remote)


@dataclass(frozen=True)
class SolverRuntimeSpec:
    kind: str
    executable: str
    args: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    # True for `python = "${project:python}"`. The host resolves the
    # interpreter again at each spawn, so a .venv created after the
    # ProjectServer started is used without a restart.
    project_python: bool = False
    # Project folder for ${project:python}; None means WITWIN_PROJECT_DIR (the
    # ProjectServer sets it), else the current folder.
    project_dir: Optional[str] = None

    def spawn_executable(self) -> str:
        if self.project_python:
            return _project_python(Path(self.project_dir) if self.project_dir else None)
        return self.executable


@dataclass(frozen=True)
class SolverSpec:
    solver_id: str
    plugin_id: str
    plugin_root: Path
    entry: Path
    runtime: SolverRuntimeSpec
    title: str = ""
    # Producer code version (per-solver override else the plugin package version).
    # Folded into a bake's dependencyKey so a plugin upgrade invalidates datasets
    # baked by an older version (Play Mode & Baked Playback plan 搂3.4). Empty when
    # undeclared, which the bake staleness check treats as "unknown / don't invalidate".
    version: str = ""
    lifecycle: str = "warm"
    idle_timeout_sec: float = 300.0
    cancel_grace_sec: float = 5.0
    heartbeat_interval_sec: float = 30.0
    heartbeat_timeout_sec: float = 5.0
    heartbeat_misses: int = 2
    max_parallel: int = 1
    capabilities: Dict[str, Any] = field(default_factory=dict)
    resources: SolverResources = field(default_factory=SolverResources)
    # Where the Plugin was loaded from (``ext.source``: builtin, local,
    # environment, cloud, ...); empty when the caller did not say. Placement
    # reads it: only an ``environment`` Plugin is installed on a cloud machine.
    plugin_source: str = ""

    @property
    def id(self) -> str:
        return self.solver_id

    @classmethod
    def from_manifest(
        cls,
        plugin_id: str,
        plugin_root: Path,
        item: Dict[str, Any],
        *,
        plugin_version: Optional[str] = None,
        project_dir: Optional[Path] = None,
        plugin_source: Optional[str] = None,
    ) -> "SolverSpec":
        if not isinstance(item, dict):
            raise ValueError("contributes.solvers entries must be objects")
        solver_id = str(item.get("id") or "").strip()
        if not solver_id:
            raise ValueError("contributes.solvers entry requires id")
        entry_raw = str(item.get("entry") or "").strip()
        if not entry_raw:
            raise ValueError(f"{solver_id}: entry is required")

        root = Path(plugin_root).resolve()
        entry = (root / entry_raw).resolve()
        try:
            entry.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"{solver_id}: entry must resolve inside plugin root") from exc
        if not entry.exists():
            raise ValueError(f"{solver_id}: entry does not exist: {entry_raw}")

        lifecycle = str(item.get("lifecycle") or "warm")
        if lifecycle != "warm":
            raise ValueError(f"{solver_id}: only warm lifecycle is supported in RFC-012 Layer A")
        max_parallel = int(item.get("maxParallel", 1))
        if max_parallel != 1:
            raise ValueError(f"{solver_id}: maxParallel > 1 is not supported in RFC-012 Layer A")

        runtime = _parse_runtime(solver_id, root, item.get("runtime"), project_dir)
        resources = parse_resources(solver_id, item.get("resources"))
        return cls(
            solver_id=solver_id,
            plugin_id=plugin_id,
            plugin_root=root,
            entry=entry,
            runtime=runtime,
            title=str(item.get("title") or solver_id),
            # A per-solver `version` overrides the plugin package version.
            version=str(item.get("version") or plugin_version or "").strip(),
            lifecycle=lifecycle,
            idle_timeout_sec=float(item.get("idleTimeoutSec", 300.0)),
            cancel_grace_sec=float(item.get("cancelGraceSec", 5.0)),
            heartbeat_interval_sec=float(item.get("heartbeatIntervalSec", 30.0)),
            heartbeat_timeout_sec=float(item.get("heartbeatTimeoutSec", 5.0)),
            heartbeat_misses=max(1, int(item.get("heartbeatMisses", 2))),
            max_parallel=max_parallel,
            capabilities=dict(item.get("capabilities") or {}),
            resources=resources,
            plugin_source=str(plugin_source or ""),
        )


def _expand_env(value: str, project_dir: Optional[Path] = None) -> str:
    value = value.replace("${backend:python}", sys.executable)
    if PROJECT_PYTHON in value:
        value = value.replace(PROJECT_PYTHON, _project_python(project_dir))

    def repl(match: re.Match[str]) -> str:
        name = match.group(1)
        if name not in os.environ:
            raise ValueError(f"unresolved environment variable in solver runtime: {name}")
        return os.environ[name]

    return _ENV_PATTERN.sub(repl, value)


def _parse_runtime(
    solver_id: str, plugin_root: Path, runtime: Any, project_dir: Optional[Path] = None,
) -> SolverRuntimeSpec:
    if not isinstance(runtime, dict):
        raise ValueError(f"{solver_id}: runtime is required")

    def _expand(value: str) -> str:
        return _expand_env(value, project_dir)

    runtime_env = {
        str(k): _expand(str(v))
        for k, v in (runtime.get("env") or {}).items()
        if isinstance(k, str)
    }
    if runtime.get("python"):
        raw_python = str(runtime["python"])
        executable = _resolve_executable(plugin_root, _expand(raw_python))
        args = [_expand(str(arg)) for arg in (runtime.get("args") or [])]
        return SolverRuntimeSpec(
            kind="python",
            executable=executable,
            args=args,
            env=runtime_env,
            project_python=raw_python.strip() == PROJECT_PYTHON,
            project_dir=str(project_dir) if project_dir is not None else None,
        )
    if runtime.get("conda"):
        args = [_expand(str(arg)) for arg in (runtime.get("args") or [])]
        return SolverRuntimeSpec(
            kind="conda",
            executable=_resolve_conda_python(_expand(str(runtime["conda"]))),
            args=args,
            env=runtime_env,
        )
    if runtime.get("command"):
        command = _expand(str(runtime["command"]))
        args = [_expand(str(arg)) for arg in (runtime.get("args") or [])]
        return SolverRuntimeSpec(kind="command", executable=command, args=args, env=runtime_env)
    raise ValueError(f"{solver_id}: runtime must declare python, conda, or command")


def _resolve_executable(plugin_root: Path, raw: str) -> str:
    candidate = Path(raw)
    if not candidate.is_absolute():
        candidate = (plugin_root / candidate).resolve()
    if not candidate.exists():
        raise ValueError(f"solver runtime executable does not exist: {raw}")
    return str(candidate)


def _conda_base_fast() -> Optional[Path]:
    """Locate the conda install without paying for `conda info --base`.

    That subprocess costs ~4s on Windows, and solver specs are parsed while
    plugins register, so it lands on every ProjectServer startup. The layout is
    derivable in every normal case: the interpreter is either the base itself or
    `<base>/envs/<name>`, and conda exports its root.
    """
    candidates: List[Path] = []
    for var in ("CONDA_ROOT", "CONDA_PREFIX_1"):
        value = os.environ.get(var)
        if value:
            candidates.append(Path(value))
    prefix = Path(sys.prefix)
    candidates.extend([prefix, prefix.parent.parent])
    conda = shutil.which("conda")
    if conda:
        # <base>/Library/bin/conda.bat, <base>/Scripts/conda.exe, <base>/bin/conda
        conda_path = Path(conda)
        candidates.extend([conda_path.parents[1], conda_path.parents[2]])
    for candidate in candidates:
        try:
            if (candidate / "envs").is_dir():
                return candidate
        except OSError:
            continue
    return None


def _resolve_conda_python(env_name: str) -> str:
    base = _conda_base_fast()
    if base is None:
        conda = shutil.which("conda")
        if not conda:
            raise ValueError("solver runtime conda requested, but conda is not on PATH")
        result = subprocess.run(
            [conda, "info", "--base"],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            raise ValueError("unable to resolve conda base for solver runtime")
        raw = (result.stdout or "").strip()
        if not raw:
            raise ValueError("conda base path is empty")
        base = Path(raw)
    if os.name == "nt":
        python = base / "envs" / env_name / "python.exe"
    else:
        python = base / "envs" / env_name / "bin" / "python"
    if not python.exists():
        raise ValueError(f"conda env python does not exist for solver runtime: {env_name}")
    return str(python)
