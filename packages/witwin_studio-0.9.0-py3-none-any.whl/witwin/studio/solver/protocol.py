"""Sentinel-framed JSON-RPC messages for RFC-012 solver processes."""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

SOLVER_SENTINEL = "\x1f@witwin-solver "


def encode_message(message: Dict[str, Any]) -> str:
    """Encode one JSON-RPC message as a sentinel-tagged stdout line."""
    return SOLVER_SENTINEL + json.dumps(message, separators=(",", ":"), ensure_ascii=False)


def parse_solver_line(line: str) -> Optional[Dict[str, Any]]:
    """Parse a solver protocol line.

    Non-sentinel lines and malformed sentinel payloads are treated as plain
    native stdout, so host readers can safely demote them to run logs.
    """
    if not line.startswith(SOLVER_SENTINEL):
        return None
    payload = line[len(SOLVER_SENTINEL):].strip()
    try:
        decoded = json.loads(payload)
    except json.JSONDecodeError:
        return None
    return decoded if isinstance(decoded, dict) else None
