"""Headless solves: run a Plugin's solver child without the editor (decision D11, P5).

``Project.solve`` and ``witwin solve`` use this module. A solve:

1. finds the solver in the Plugins the Project can see: explicit local paths
   (``WITWIN_LOCAL_PLUGIN_PATHS`` or ``plugin_paths``) first, then
   ``witwin.plugins`` entry points in the Project environment
   (``witwin.studio._plugins``);
2. reads the scene from its ``.wtscene`` file and hands it over as a
   content-hashed scene reference, as the ProjectServer does;
3. starts the solver's ``solver_host.py`` with the interpreter its runtime
   names (``${project:python}`` is the Project interpreter) and talks the
   RFC-012 JSON-RPC protocol over stdin/stdout;
4. records the outcome as a ``witwin.result.v1`` Result that the Results panel
   lists when Studio next opens the folder.

**Attach mode.** When ``.witwin/runtime/server.json`` names a live
ProjectServer for the folder, the solve goes through that server
(``POST /v1/solve``) instead: the editor shows it live, the server records the
Result, and no second GPU child starts next to the editor's.

**Live scene until P7.** Solvers written with ``serve(..., scene="document")``
need nothing from Studio. Solvers that take the live ``Scene`` model (the
default, and every domain Plugin today) import ``witwin_server`` in the child;
a headless solve then puts a ``witwin_server`` it can find on the child's
``PYTHONPATH`` (``WITWIN_SERVER_PATH``, an installed or checked-out
``witwin_server``, or the copy bundled next to ``witwin.studio`` in Studio).
"""
from __future__ import annotations

import importlib.util
import json
import logging
import os
import subprocess
import sys
import threading
import tomllib
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from .._plugins import MANIFEST_FILENAME, discover_environment_plugins
from .protocol import parse_solver_line
from .result_ref import safe_solver_dir_name
from .scene_ref import make_document_scene_ref
from .spec import SolverSpec

logger = logging.getLogger("witwin.studio.solver")

LOCAL_PLUGIN_PATHS_ENV = "WITWIN_LOCAL_PLUGIN_PATHS"
SERVER_PATH_ENV = "WITWIN_SERVER_PATH"
# Importing torch / CUDA in the child can take a while on a cold cache; the
# ProjectServer's 10 s assumes a warm machine and a child it keeps alive.
INITIALIZE_TIMEOUT_SECONDS = 120.0
SHUTDOWN_GRACE_SECONDS = 10.0
# Same folders the ProjectServer uses (SolverHost._scene_ref_dir/_result_ref_dir).
SCENE_REF_PARTS = (".witwin", "solver_scene_refs")
RESULT_REF_PARTS = (".witwin", "solver_results")

ProgressCallback = Callable[[float, Optional[str]], None]
LogCallback = Callable[[str], None]


class SolverError(RuntimeError):
    """A solve or query failed; ``code`` is the protocol error code."""

    def __init__(self, code: str, message: str, detail: Any = None):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message
        self.detail = detail


# --------------------------------------------------------------------------- #
# Finding solvers
# --------------------------------------------------------------------------- #
def _split_paths(value: str) -> List[Path]:
    normalized = value.replace("\n", os.pathsep).replace(";", os.pathsep)
    return [Path(item.strip().strip('"')) for item in normalized.split(os.pathsep) if item.strip()]


def _plugin_package_roots(path: Path) -> List[Path]:
    """One Plugin root, or every Plugin root directly inside a folder."""
    path = Path(path).expanduser()
    if (path / MANIFEST_FILENAME).is_file():
        return [path]
    if not path.is_dir():
        return []
    return sorted(
        (item for item in path.iterdir() if item.is_dir() and (item / MANIFEST_FILENAME).is_file()),
        key=lambda item: item.name.lower(),
    )


def plugin_roots(project_root: Path, plugin_paths: Iterable[Path] = ()) -> List[Path]:
    """Plugin roots in precedence order: explicit paths, then the Project environment."""
    explicit = [Path(p) for p in plugin_paths]
    explicit += _split_paths(os.environ.get(LOCAL_PLUGIN_PATHS_ENV, ""))
    roots: List[Path] = []
    for path in explicit:
        roots += _plugin_package_roots(path)
    roots += [plugin.root for plugin in discover_environment_plugins(project_root, require_pyproject=False)]
    seen: set[str] = set()
    unique: List[Path] = []
    for root in roots:
        key = os.path.normcase(str(Path(root).resolve()))
        if key not in seen:
            seen.add(key)
            unique.append(Path(root))
    return unique


def list_solvers(project_root: Path, *, plugin_paths: Iterable[Path] = ()) -> List[SolverSpec]:
    """Every solver the Project can run headless; the first root that declares an id wins."""
    project_root = Path(project_root).resolve()
    found: Dict[str, SolverSpec] = {}
    for root in plugin_roots(project_root, plugin_paths):
        try:
            manifest = tomllib.loads((root / MANIFEST_FILENAME).read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            logger.warning("skipping %s: unreadable %s (%s)", root, MANIFEST_FILENAME, exc)
            continue
        plugin_id = str(manifest.get("id") or root.name)
        for item in (manifest.get("contributes") or {}).get("solvers") or []:
            try:
                spec = SolverSpec.from_manifest(
                    plugin_id, root, item,
                    plugin_version=str(manifest.get("version") or ""), project_dir=project_root,
                )
            except ValueError as exc:
                logger.warning("skipping a solver of %s: %s", plugin_id, exc)
                continue
            found.setdefault(spec.solver_id, spec)
    return list(found.values())


def find_solver(project_root: Path, solver_id: str, *, plugin_paths: Iterable[Path] = ()) -> SolverSpec:
    solvers = list_solvers(project_root, plugin_paths=plugin_paths)
    for spec in solvers:
        if spec.solver_id == solver_id:
            return spec
    known = ", ".join(sorted(spec.solver_id for spec in solvers)) or "none"
    raise SolverError(
        "unknown_solver",
        f"no installed Plugin declares solver {solver_id!r} (found: {known}). Install its "
        f"distribution in the Project environment (`witwin add`) or set {LOCAL_PLUGIN_PATHS_ENV}.",
    )


# --------------------------------------------------------------------------- #
# The child process
# --------------------------------------------------------------------------- #
def _outside_site_packages(path: Path) -> bool:
    return not any(part.lower() in ("site-packages", "dist-packages") for part in path.parts)


def _support_paths() -> List[str]:
    """Source folders the child needs on ``PYTHONPATH`` beside its own packages.

    ``witwin.studio`` itself when it runs from a checkout or Studio's bundle
    (an installed copy is already on the child's path when the Project
    environment depends on it), and ``witwin_server`` for live-scene solvers
    until phase P7.
    """
    paths: List[str] = []
    studio_src = Path(__file__).resolve().parents[3]  # .../witwin/studio/solver/client.py -> src
    if _outside_site_packages(studio_src):
        paths.append(str(studio_src))
    explicit = os.environ.get(SERVER_PATH_ENV, "").strip()
    server_root: Optional[Path] = Path(explicit) if explicit else None
    if server_root is None:
        try:
            spec = importlib.util.find_spec("witwin_server")
        except (ImportError, ValueError):
            spec = None
        if spec is not None and spec.submodule_search_locations:
            server_root = Path(list(spec.submodule_search_locations)[0]).parent
    if server_root is None:
        for candidate in (studio_src, studio_src.parent.parent / "server"):
            if (candidate / "witwin_server" / "__init__.py").is_file():
                server_root = candidate
                break
    if server_root is not None and str(server_root) not in paths:
        paths.append(str(server_root))
    return paths


class SolverProcess:
    """One solver child speaking the RFC-012 protocol on stdin/stdout."""

    def __init__(
        self,
        spec: SolverSpec,
        project_root: Path,
        *,
        on_notification: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        on_output: Optional[LogCallback] = None,
    ):
        self.spec = spec
        self.project_root = Path(project_root).resolve()
        self.on_notification = on_notification
        self.on_output = on_output
        self._proc: Optional[subprocess.Popen] = None
        self._lock = threading.Lock()
        self._next_id = 0
        self._pending: Dict[int, Tuple[threading.Event, Dict[str, Any]]] = {}
        self._stderr_tail: List[str] = []
        self._exit_code: Optional[int] = None

    @property
    def result_dir(self) -> Path:
        return self.project_root.joinpath(*RESULT_REF_PARTS) / safe_solver_dir_name(self.spec.solver_id)

    def command(self) -> List[str]:
        runtime = self.spec.runtime
        if runtime.kind in ("python", "conda"):
            return [runtime.spawn_executable(), "-u", str(self.spec.entry), *runtime.args]
        return [runtime.executable, *runtime.args, str(self.spec.entry)]

    def environment(self) -> Dict[str, str]:
        env = dict(os.environ)
        env.update(self.spec.runtime.env)
        env["WITWIN_SOLVER_RESULT_DIR"] = str(self.result_dir)
        env["WITWIN_PROJECT_DIR"] = str(self.project_root)
        env["PYTHONUNBUFFERED"] = "1"
        env.setdefault("PYTHONIOENCODING", "utf-8")
        paths = [str(self.spec.plugin_root), *_support_paths()]
        if env.get("PYTHONPATH"):
            paths.append(env["PYTHONPATH"])
        env["PYTHONPATH"] = os.pathsep.join(paths)
        return env

    def start(self, timeout: float = INITIALIZE_TIMEOUT_SECONDS) -> Dict[str, Any]:
        self.result_dir.mkdir(parents=True, exist_ok=True)
        try:
            self._proc = subprocess.Popen(
                self.command(),
                cwd=str(self.spec.plugin_root),
                env=self.environment(),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except OSError as exc:
            raise SolverError("solver_spawn_failed", str(exc)) from exc
        threading.Thread(target=self._read_stdout, daemon=True).start()
        threading.Thread(target=self._read_stderr, daemon=True).start()
        threading.Thread(target=self._wait_exit, daemon=True).start()
        return self.request("initialize", {"protocolVersion": 1, "hostVersion": "witwin.studio"}, timeout=timeout)

    def request(self, method: str, params: Dict[str, Any], timeout: Optional[float] = None) -> Dict[str, Any]:
        event = threading.Event()
        slot: Dict[str, Any] = {}
        with self._lock:
            self._next_id += 1
            request_id = self._next_id
            self._pending[request_id] = (event, slot)
        self._send({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
        if not event.wait(timeout):
            with self._lock:
                self._pending.pop(request_id, None)
            raise SolverError("timeout", f"{method} timed out after {timeout} s")
        if "error" in slot:
            error = slot["error"] or {}
            raise SolverError(str(error.get("code") or "solver_error"), str(error.get("message") or ""), error.get("data"))
        return slot.get("result") or {}

    def notify(self, method: str, params: Dict[str, Any]) -> None:
        self._send({"jsonrpc": "2.0", "method": method, "params": params})

    def close(self, timeout: float = SHUTDOWN_GRACE_SECONDS) -> None:
        proc = self._proc
        if proc is None or proc.poll() is not None:
            return
        try:
            self.request("shutdown", {}, timeout=timeout)
        except SolverError:
            pass
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=timeout)

    def _send(self, message: Dict[str, Any]) -> None:
        proc = self._proc
        if proc is None or proc.stdin is None or proc.poll() is not None:
            raise SolverError("solver_exited", self._exit_message())
        try:
            proc.stdin.write(json.dumps(message) + "\n")
            proc.stdin.flush()
        except (OSError, ValueError) as exc:
            raise SolverError("solver_exited", self._exit_message()) from exc

    def _read_stdout(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        for line in self._proc.stdout:
            line = line.rstrip("\r\n")
            message = parse_solver_line(line)
            if message is None:
                if line.strip() and self.on_output:
                    self.on_output(line)
                continue
            if "id" in message and ("result" in message or "error" in message):
                with self._lock:
                    pending = self._pending.pop(message.get("id"), None)
                if pending is not None:
                    event, slot = pending
                    slot.update(message)
                    event.set()
            elif isinstance(message.get("method"), str) and self.on_notification:
                self.on_notification(message["method"], message.get("params") or {})

    def _read_stderr(self) -> None:
        assert self._proc is not None and self._proc.stderr is not None
        for line in self._proc.stderr:
            line = line.rstrip("\r\n")
            self._stderr_tail = (self._stderr_tail + [line])[-40:]
            if line.strip() and self.on_output:
                self.on_output(line)

    def _wait_exit(self) -> None:
        assert self._proc is not None
        self._exit_code = self._proc.wait()
        with self._lock:
            pending = list(self._pending.values())
            self._pending.clear()
        for event, slot in pending:
            slot["error"] = {"code": "solver_exited", "message": self._exit_message()}
            event.set()

    def _exit_message(self) -> str:
        tail = "\n".join(self._stderr_tail[-15:])
        return f"solver process exited (code {self._exit_code})" + (f"\n{tail}" if tail else "")


# --------------------------------------------------------------------------- #
# Runs
# --------------------------------------------------------------------------- #
class SolveRun:
    """One solve: ``progress`` while it runs, ``result()`` when it ends.

    Keep the run open (``with project.solve(...) as run:``) to ``query`` a
    result handle; ``close()`` releases it and stops the child.
    """

    def __init__(self, solver_id: str, scene_id: Optional[str], config: Dict[str, Any]):
        self.id = f"run_{uuid.uuid4().hex[:12]}"
        self.solver_id = solver_id
        self.scene_id = scene_id
        self.config = config
        self.status = "queued"
        self.progress: Optional[Tuple[float, Optional[str]]] = None
        self.logs: List[str] = []
        self.outputs: Optional[Dict[str, Any]] = None
        self.error: Optional[SolverError] = None
        self.record: Any = None  # the ResultRecord written for this run, if any
        self.result_version: Optional[int] = None
        self.attached = False
        self._done = threading.Event()
        self._on_progress: Optional[ProgressCallback] = None
        self._on_log: Optional[LogCallback] = None
        self._process: Optional[SolverProcess] = None
        self._attached_server: Any = None

    def __repr__(self) -> str:
        return f"<SolveRun {self.id} {self.solver_id} {self.status}>"

    def wait(self, timeout: Optional[float] = None) -> bool:
        return self._done.wait(timeout)

    def result(self, timeout: Optional[float] = None) -> Dict[str, Any]:
        """The solver's outputs (``{"result": ...}`` or ``{"resultHandle": ...}``); raises on failure."""
        if not self._done.wait(timeout):
            raise SolverError("timeout", f"{self.id} is still {self.status}")
        if self.error is not None:
            raise self.error
        return dict(self.outputs or {})

    def query(self, op: str, timeout: Optional[float] = None, **params: Any) -> Any:
        """Run a query the solver registered with ``@query`` on this run's result handle."""
        outputs = self.result(timeout)
        handle = outputs.get("resultHandle")
        if not handle:
            raise SolverError("no_result_handle", f"{self.solver_id} returned a plain result; there is nothing to query")
        payload = {"runId": self.id, "resultHandle": handle, "op": op, "params": params}
        if self.attached:
            return _post(self._attached_server, "/v1/solve/query", {"solverId": self.solver_id, **payload})["data"]
        if self._process is None:
            raise SolverError("closed", f"{self.id} is closed")
        return self._process.request("query", payload, timeout=timeout).get("data")

    def cancel(self) -> None:
        if self._process is not None and not self._done.is_set():
            self._process.notify("$/cancelRequest", {"runId": self.id})

    def close(self) -> None:
        process, self._process = self._process, None
        if process is not None:
            handle = (self.outputs or {}).get("resultHandle")
            if handle:
                try:
                    process.request("releaseResult", {"resultHandle": handle}, timeout=SHUTDOWN_GRACE_SECONDS)
                except SolverError:
                    pass
            process.close()

    def __enter__(self) -> "SolveRun":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # -- child notifications -------------------------------------------------
    def _notification(self, method: str, params: Dict[str, Any]) -> None:
        if method == "$/progress":
            frac = float(params.get("frac") or 0.0)
            self.progress = (frac, params.get("message"))
            if self._on_progress:
                self._on_progress(frac, params.get("message"))
        elif method == "$/log":
            self._log(f"[{params.get('level') or 'info'}] {params.get('message')}")

    def _log(self, line: str) -> None:
        self.logs.append(line)
        if self._on_log:
            self._on_log(line)

    def _finish(self, status: str, outputs: Optional[Dict[str, Any]] = None, error: Optional[SolverError] = None) -> None:
        self.status = status
        self.outputs = outputs
        self.error = error
        self._done.set()


def _post(server: Any, path: str, body: Dict[str, Any], timeout: Optional[float] = None) -> Dict[str, Any]:
    request = urllib.request.Request(
        f"{server.url}{path}",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", **server.headers()},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        try:
            error = (json.loads(detail) or {}).get("error") or {}
        except ValueError:
            error = {}
        raise SolverError(str(error.get("code") or f"http_{exc.code}"), str(error.get("message") or detail)) from exc
    except (OSError, urllib.error.URLError) as exc:
        raise SolverError("server_unreachable", f"{server.url}: {exc}") from exc


def result_summary(
    solver_id: str, title: str, run_id: str, scene_id: Optional[str],
    config: Dict[str, Any], outputs: Optional[Dict[str, Any]],
) -> str:
    """Markdown for the Result a solve records; the ProjectServer's attach route uses it too."""
    # The plots are their own Result entries; repeating them here only adds bulk.
    shown = json.dumps({k: v for k, v in (outputs or {}).items() if k != "plots"}, indent=2, default=str)
    if len(shown) > 4000:
        shown = shown[:4000] + "\n..."
    return "\n".join([
        f"**Solver** `{solver_id}` ({title})",
        f"**Run** `{run_id}`" + (f" on scene `{scene_id}`" if scene_id else ""),
        "",
        "**Config**",
        "```json",
        json.dumps(config, indent=2, default=str),
        "```",
        "",
        "**Outputs**",
        "```json",
        shown,
        "```",
    ])


def solve_outputs(reply: Dict[str, Any]) -> Dict[str, Any]:
    """A run's outputs from the solver child's reply: the result (or its handle
    or ref) plus the ``summary`` and ``plots`` the solver set with
    ``ctx.set_outputs``. The ProjectServer's solver host uses it too."""
    if "resultHandle" in reply:
        outputs: Dict[str, Any] = {"resultHandle": reply["resultHandle"]}
    elif "resultRef" in reply:
        outputs = {"resultRef": reply["resultRef"]}
    else:
        outputs = {"result": reply.get("result")}
    for key in ("summary", "plots"):
        if key in reply:
            outputs[key] = reply[key]
    return outputs


def result_source(solver_id: str, plugin_id: str, run_id: str, config: Dict[str, Any],
                  outputs: Optional[Dict[str, Any]], created_by: str) -> Dict[str, Any]:
    """The ``source`` block of a solve Result (``witwin.result.v1``)."""
    return {
        "kind": "solve", "solverId": solver_id, "pluginId": plugin_id, "runId": run_id,
        "config": config, "createdBy": created_by,
        # Plots are stored as the Result's entries, not a second time here.
        "outputs": {k: v for k, v in (outputs or {}).items() if k != "plots"},
    }


def start_solve(
    project: Any,
    solver_id: str,
    *,
    scene: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
    record: bool = True,
    attach: Optional[bool] = None,
    plugin_paths: Sequence[Path] = (),
    on_progress: Optional[ProgressCallback] = None,
    on_log: Optional[LogCallback] = None,
) -> SolveRun:
    """Start a solve for ``project`` (a ``witwin.studio.Project``); see ``Project.solve``."""
    from .._discovery import running_server

    config = dict(config or {})
    server = running_server(project.root) if attach is not False else None
    if attach and server is None:
        raise SolverError("no_server", f"no running ProjectServer serves {project.root}")
    scene_id = scene or (None if server is not None else project.main_scene_id)
    run = SolveRun(solver_id, scene_id, config)
    run._on_progress, run._on_log = on_progress, on_log
    target = _run_attached if server is not None else _run_local
    args = (run, project, server, record) if server is not None else (run, project, record, plugin_paths)
    threading.Thread(target=target, args=args, daemon=True, name=f"witwin-solve-{run.id}").start()
    return run


def _run_attached(run: SolveRun, project: Any, server: Any, record: bool) -> None:
    run.attached = True
    run._attached_server = server
    run.status = "running"
    try:
        reply = _post(server, "/v1/solve", {
            "solverId": run.solver_id, "scene": run.scene_id, "config": run.config, "record": record,
        })
    except Exception as exc:  # noqa: BLE001 - any failure must end the run, or result() would hang
        run._finish("failed", error=exc if isinstance(exc, SolverError) else SolverError("solve_failed", str(exc)))
        return
    run.id = str(reply.get("runId") or run.id)
    run.result_version = reply.get("resultVersion")
    if reply.get("status") == "succeeded":
        run._finish("succeeded", outputs=reply.get("outputs") or {})
    else:
        error = reply.get("error") or {}
        run._finish(
            "cancelled" if reply.get("status") == "cancelled" else "failed",
            error=SolverError(str(error.get("code") or "solver_error"), str(error.get("message") or reply.get("status")), error),
        )


def _run_local(run: SolveRun, project: Any, record: bool, plugin_paths: Sequence[Path]) -> None:
    from .. import wtscene

    scene_ref = None
    try:
        spec = find_solver(project.root, run.solver_id, plugin_paths=plugin_paths)
        if run.scene_id:
            path = project._scene_index().get(run.scene_id)
            if path is None:
                raise SolverError("unknown_scene", f"no scene {run.scene_id!r} in {project.root}")
            scene_doc = wtscene.loads(Path(path).read_text(encoding="utf-8"))
            scene_ref = make_document_scene_ref(scene_doc, project.root.joinpath(*SCENE_REF_PARTS))
        process = SolverProcess(spec, project.root, on_notification=run._notification, on_output=run._log)
        run._process = process
        run.status = "running"
        process.start()
        params: Dict[str, Any] = {"runId": run.id, "config": run.config}
        if scene_ref is not None:
            params["sceneRef"] = scene_ref
        reply = process.request("solve", params)
    except Exception as exc:  # noqa: BLE001 - any failure must end the run, or result() would hang
        error = exc if isinstance(exc, SolverError) else SolverError("solve_failed", str(exc))
        run._finish("cancelled" if error.code == "cancelled" else "failed", error=error)
        _discard_scene_ref(scene_ref)
        run.close()
        return
    _discard_scene_ref(scene_ref)
    outputs = solve_outputs(reply)
    run.outputs = outputs
    if record:
        try:
            title = spec.title or spec.solver_id
            run.record = project.results.record(
                f"{title} (headless)",
                plots=outputs.get("plots"),
                text=result_summary(spec.solver_id, title, run.id, run.scene_id, run.config, outputs),
                scene_id=run.scene_id,
                source=result_source(spec.solver_id, spec.plugin_id, run.id, run.config, outputs, "witwin.studio"),
            )
            run.result_version = run.record.version
        except OSError as exc:
            run._log(f"could not record the Result: {exc}")
    run._finish("succeeded", outputs=outputs)
    if "resultHandle" not in outputs:
        run.close()


def _discard_scene_ref(scene_ref: Optional[Dict[str, Any]]) -> None:
    ref = (scene_ref or {}).get("sceneDoc")
    if isinstance(ref, dict) and ref.get("transient") and ref.get("path"):
        Path(str(ref["path"])).unlink(missing_ok=True)


def main_progress_printer(stream: Any = None) -> ProgressCallback:
    out = stream or sys.stderr

    def show(frac: float, message: Optional[str]) -> None:
        out.write(f"\r{frac * 100:5.1f}%  {message or ''}"[:120].ljust(80))
        out.flush()

    return show
