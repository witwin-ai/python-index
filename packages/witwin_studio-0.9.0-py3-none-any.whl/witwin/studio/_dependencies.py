"""Add a Plugin to a Project's Python dependencies, never from PyPI (decision D11, P4).

The sibling of ``_scaffold.py``: that module creates a Project's
``pyproject.toml``; this one adds Plugin distributions (``wt-<domain>``) to it.
``witwin add`` and the Studio Plugins page both go through ``add_plugin``.

Nothing resolves from PyPI by default (owner rule, 2026-11-01). A Plugin comes
from one of three places, each written as a standard ``[tool.uv.sources]``
entry:

- the witwin index, a PEP 503 tree on GitHub Pages (``WITWIN_INDEX_URL``),
  declared with ``explicit = true`` so uv uses it only for names pinned to it;
- a git URL (``{ git = ..., tag = ... }``);
- a local folder (``{ path = ..., editable = true }``).

uv honours a source only for direct dependencies. A Plugin's own first-party
dependencies (``witwin-studio``; ``wt-humanoid`` for ``wt-genesis``) would
otherwise fall through to PyPI, so every first-party name the Project resolves
becomes a direct dependency pinned to the index: names uv reports as missing
are pinned and the lock runs again, and ``uv.lock`` is checked before anything
is installed. A first-party package locked from any other remote registry
fails the install. On failure ``pyproject.toml`` and ``uv.lock`` are restored.

The edits keep comments and layout (tomlkit), and never replace a dependency
or a source the user wrote.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import tomlkit
from tomlkit.exceptions import TOMLKitError

from ._scaffold import PYPROJECT, STUDIO_DISTRIBUTION

WITWIN_INDEX_NAME = "witwin"
# Studio's copy: studio/electron/python/projectEnvironment.ts. The publish
# workflow (.github/workflows/python-index.yml) serves this URL.
WITWIN_INDEX_URL = "https://witwin-ai.github.io/python-index/simple/"
UV_ENV = "WITWIN_UV"
LOCK_FILE = "uv.lock"

# Rounds of "pin what uv could not find, lock again"; no Plugin chain is this deep.
MAX_LOCK_ROUNDS = 6

_NOT_FOUND = re.compile(r"\b([A-Za-z0-9][A-Za-z0-9._-]*) was not found in the package registry")
_NOT_PYTHON = re.compile(r"does not appear to be a Python project", re.IGNORECASE)

Runner = Callable[[List[str], Path, Callable[[str], None]], int]


def normalize(name: str) -> str:
    """PEP 503 name normalization."""
    return re.sub(r"[-_.]+", "-", name.strip()).lower()


def requirement_name(requirement: str) -> Optional[str]:
    match = re.match(r"\s*([A-Za-z0-9][A-Za-z0-9._-]*)", requirement or "")
    return normalize(match.group(1)) if match else None


def is_first_party(name: str) -> bool:
    """Names that exist only on the witwin index; they are always pinned there."""
    name = normalize(name)
    return name.startswith("wt-") or name == STUDIO_DISTRIBUTION


def _witwin_namespace(name: str) -> bool:
    """Names a missing-package report may pin to the witwin index."""
    name = normalize(name)
    return is_first_party(name) or name == "witwin" or name.startswith("witwin-")


# --------------------------------------------------------------------------- #
# pyproject.toml edits (tomlkit documents)
# --------------------------------------------------------------------------- #
def _project_dependencies(doc: tomlkit.TOMLDocument):
    project = doc.get("project")
    if not isinstance(project, dict):
        raise ValueError(f"{PYPROJECT} has no [project] table")
    if "dependencies" in (project.get("dynamic") or []):
        raise ValueError(f"{PYPROJECT} declares dependencies as dynamic; add the Plugin where they come from")
    deps = project.get("dependencies")
    if deps is None:
        deps = tomlkit.array()
        deps.multiline(True)
        project["dependencies"] = deps
    return deps


def dependency_names(doc: tomlkit.TOMLDocument) -> List[str]:
    project = doc.get("project")
    deps = project.get("dependencies") if isinstance(project, dict) else None
    return [name for name in (requirement_name(str(dep)) for dep in deps or []) if name]


def add_dependency(doc: tomlkit.TOMLDocument, requirement: str) -> bool:
    """Append ``requirement`` unless a dependency with that name exists (the user's pin wins)."""
    deps = _project_dependencies(doc)
    if requirement_name(requirement) in dependency_names(doc):
        return False
    deps.append(requirement)
    return True


def _uv_table(doc: tomlkit.TOMLDocument, key: str, *, create: bool):
    tool = doc.get("tool")
    if tool is None:
        if not create:
            return None
        tool = tomlkit.table(is_super_table=True)
        doc["tool"] = tool
    uv = tool.get("uv")
    if uv is None:
        if not create:
            return None
        uv = tomlkit.table(is_super_table=True)
        tool["uv"] = uv
    item = uv.get(key)
    if item is None and create:
        item = tomlkit.table() if key == "sources" else tomlkit.aot()
        uv[key] = item
    return item


def source_names(doc: tomlkit.TOMLDocument) -> List[str]:
    sources = _uv_table(doc, "sources", create=False)
    return [normalize(str(key)) for key in (sources or {})]


def set_source(doc: tomlkit.TOMLDocument, name: str, source: Dict[str, object]) -> bool:
    """Add ``[tool.uv.sources].<name>`` unless the name already has a source."""
    if normalize(name) in source_names(doc):
        return False
    # Parsed from text so it keeps uv's own spacing: `{ index = "witwin" }`.
    body = ", ".join(f"{key} = {tomlkit.item(value).as_string()}" for key, value in source.items())
    inline = tomlkit.parse(f"x = {{ {body} }}")["x"]
    _uv_table(doc, "sources", create=True)[normalize(name)] = inline
    return True


def ensure_index(doc: tomlkit.TOMLDocument, url: str = WITWIN_INDEX_URL, name: str = WITWIN_INDEX_NAME) -> str:
    """Declare the witwin index with ``explicit = true``; return the name sources use.

    An existing entry with the same URL keeps its name and gains ``explicit``.
    """
    wanted = url.rstrip("/").lower()
    indexes = _uv_table(doc, "index", create=False)
    for entry in indexes or []:
        if str(entry.get("url", "")).rstrip("/").lower() == wanted:
            if "explicit" not in entry:
                entry["explicit"] = True
            return str(entry.get("name") or name)
    entry = tomlkit.table()
    entry["name"] = name
    entry["url"] = url
    entry["explicit"] = True
    _uv_table(doc, "index", create=True).append(entry)
    return name


def pin_first_party(doc: tomlkit.TOMLDocument, index_name: str = WITWIN_INDEX_NAME) -> List[str]:
    """Pin every first-party direct dependency without a source to the index."""
    return [
        name for name in dependency_names(doc)
        if is_first_party(name) and set_source(doc, name, {"index": index_name})
    ]


_TABLE_HEADER = re.compile(r"^\[\[?[A-Za-z0-9_.\"' -]+\]\]?[ \t]*(#.*)?$")


def dumps(doc: tomlkit.TOMLDocument) -> str:
    """tomlkit text with exactly one blank line before each table header and a final newline.

    tomlkit appends new tables with no spacing (or doubled spacing). Only blank
    lines next to a header line outside a multi-line string are touched.
    """
    out: List[str] = []
    in_string = False
    for line in tomlkit.dumps(doc).splitlines():
        if not in_string and _TABLE_HEADER.match(line):
            while out and not out[-1].strip():
                out.pop()
            # A comment block right above a header describes that table
            # (scaffold.render_pyproject's note on bypass-selection): the blank
            # line goes above the comments, not between them and the header.
            start = len(out)
            while start and out[start - 1].lstrip().startswith("#"):
                start -= 1
            end = start
            while start and not out[start - 1].strip():
                start -= 1
            out[start:end] = [""] if start else []
        out.append(line)
        if line.count('"""') % 2 or line.count("'''") % 2:
            in_string = not in_string
    return "\n".join(out).rstrip("\n") + "\n"


# --------------------------------------------------------------------------- #
# uv output and uv.lock
# --------------------------------------------------------------------------- #
def names_not_found(lines: Sequence[str]) -> List[str]:
    """Witwin-namespace names uv reported as "not found in the package registry"."""
    names: List[str] = []
    for line in lines:
        for match in _NOT_FOUND.finditer(line):
            name = normalize(match.group(1))
            if _witwin_namespace(name) and name not in names:
                names.append(name)
    return names


def lock_violations(lock_text: str, index_url: str = WITWIN_INDEX_URL) -> List[str]:
    """First-party packages ``uv.lock`` resolved from a remote registry other than the index.

    Git, path and editable sources pass: the user chose them. uv writes a
    local (``file://``) index as a relative path, and only the Project's own
    ``pyproject.toml`` can name one, so those pass too.
    """
    wanted = index_url.rstrip("/").lower()
    violations: List[str] = []
    for package in tomllib.loads(lock_text).get("package", []):
        name = str(package.get("name", ""))
        registry = str((package.get("source") or {}).get("registry", ""))
        if not is_first_party(name) or not re.match(r"https?://", registry, re.IGNORECASE):
            continue
        if registry.rstrip("/").lower() != wanted:
            violations.append(normalize(name))
    return violations


# --------------------------------------------------------------------------- #
# Running uv
# --------------------------------------------------------------------------- #
def find_uv() -> Optional[str]:
    """``WITWIN_UV``, the ``uv`` wheel in this interpreter (Studio's managed
    runtime ships it), then ``uv`` on PATH."""
    explicit = os.environ.get(UV_ENV, "").strip()
    if explicit and Path(explicit).is_file():
        return explicit
    try:
        from uv import find_uv_bin  # type: ignore[import-not-found]

        return str(find_uv_bin())
    except (ImportError, FileNotFoundError):
        pass
    return shutil.which("uv")


def _run(cmd: List[str], cwd: Path, on_line: Callable[[str], None]) -> int:
    env = {**os.environ, "NO_COLOR": "1", "UV_NO_PROGRESS": "1"}
    proc = subprocess.Popen(
        cmd, cwd=str(cwd), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace",
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        if line.strip():
            on_line(line.rstrip())
    return proc.wait()


@dataclass
class AddResult:
    ok: bool
    #: False when a git URL or folder is not a Python project; Studio then
    #: falls back to its own clone install.
    handled: bool = True
    requirement: Optional[str] = None
    pinned: List[str] = field(default_factory=list)
    error: Optional[str] = None
    log: List[str] = field(default_factory=list)


def add_plugin(
    root: Path | str,
    spec: str,
    *,
    tag: Optional[str] = None,
    rev: Optional[str] = None,
    branch: Optional[str] = None,
    editable: bool = True,
    index_url: str = WITWIN_INDEX_URL,
    uv: Optional[str] = None,
    python: Optional[str] = None,
    sync: bool = True,
    run: Optional[Runner] = None,
    on_line: Optional[Callable[[str], None]] = None,
) -> AddResult:
    """Add a Plugin to the Project at ``root`` and sync its environment.

    ``spec`` is a requirement (``wt-radar>=0.3,<0.4``, from the witwin index),
    a git URL (``git+https://...``, with ``tag`` / ``rev`` / ``branch``) or a
    local folder (added editable unless ``editable`` is False). ``python``
    picks the interpreter for a new ``.venv``.
    """
    root = Path(root).resolve()
    pyproject = root / PYPROJECT
    lock = root / LOCK_FILE
    result = AddResult(ok=False)

    def say(line: str) -> None:
        result.log.append(line)
        if on_line:
            on_line(line)

    if not pyproject.is_file():
        result.handled = False
        result.error = f"no {PYPROJECT} in {root}; run `witwin init` first"
        return result
    uv = uv or find_uv()
    if not uv:
        result.error = f"uv was not found; install it or set {UV_ENV}"
        return result
    runner = run or _run
    original = pyproject.read_bytes()
    original_lock = lock.read_bytes() if lock.is_file() else None

    def restore() -> None:
        if pyproject.read_bytes() != original:
            pyproject.write_bytes(original)
        if original_lock is not None:
            if lock.read_bytes() != original_lock:
                lock.write_bytes(original_lock)
        elif lock.exists():
            lock.unlink()

    def uv_call(args: List[str]) -> Tuple[int, List[str]]:
        lines: List[str] = []
        say("$ uv " + " ".join(args))

        def collect(line: str) -> None:
            lines.append(line)
            say(line)

        return runner([uv, *args], root, collect), lines

    python_args: List[str] = []
    # A new .venv uses the given interpreter (Studio passes its own, so solver
    # children match what Studio tests against); a pinned or existing one stays.
    if python and not (root / ".venv" / "pyvenv.cfg").is_file() and not (root / ".python-version").is_file():
        python_args = ["--python", python]

    try:
        local = Path(spec).expanduser()
        if spec.startswith("git+") or local.is_dir():
            # uv reads the Plugin's pyproject.toml for its name and writes the
            # git or path source itself; --frozen skips resolving here.
            before = set(dependency_names(tomlkit.parse(pyproject.read_text(encoding="utf-8"))))
            args = ["add", "--frozen"]
            if spec.startswith("git+"):
                args.append(spec)
                for flag, value in (("--tag", tag), ("--rev", rev), ("--branch", branch)):
                    if value:
                        args += [flag, value]
            else:
                args += (["--editable"] if editable else []) + [str(local.resolve())]
            code, lines = uv_call(args)
            if code != 0:
                restore()
                if any(_NOT_PYTHON.search(line) for line in lines):
                    result.handled = False
                    result.error = f"{spec} is not a Python project"
                    return result
                raise RuntimeError(f"uv add exited with code {code}: {lines[-1] if lines else ''}")
            doc = tomlkit.parse(pyproject.read_text(encoding="utf-8"))
            result.requirement = next((name for name in dependency_names(doc) if name not in before), None)
            index_name = ensure_index(doc, index_url)
        else:
            doc = tomlkit.parse(pyproject.read_text(encoding="utf-8"))
            index_name = ensure_index(doc, index_url)
            add_dependency(doc, spec)
            set_source(doc, requirement_name(spec) or spec, {"index": index_name})
            result.requirement = spec
        result.pinned += pin_first_party(doc, index_name)
        # A Plugin is what usually brings torch and the solvers in; lock them
        # at the cloud platform's versions (``_platform.py``).
        from ._platform import write_constraints

        write_constraints(doc)
        pyproject.write_text(dumps(doc), encoding="utf-8")

        for round_ in range(MAX_LOCK_ROUNDS):
            code, lines = uv_call(["lock", *python_args])
            if code == 0:
                offending = lock_violations(lock.read_text(encoding="utf-8"), index_url) if lock.is_file() else []
            else:
                offending = names_not_found(lines)
            if code == 0 and not offending:
                break
            fresh = [name for name in offending if name not in source_names(doc)]
            if not fresh or round_ + 1 == MAX_LOCK_ROUNDS:
                if code == 0:
                    raise RuntimeError("first-party packages resolved outside the witwin index: " + ", ".join(offending))
                raise RuntimeError(f"uv lock exited with code {code}: {lines[-1] if lines else ''}")
            for name in fresh:
                add_dependency(doc, name)
                set_source(doc, name, {"index": index_name})
            result.pinned += fresh
            pyproject.write_text(dumps(doc), encoding="utf-8")
            say("pinned to the witwin index: " + ", ".join(fresh))

        if sync:
            code, lines = uv_call(["sync", "--locked", *python_args])
            if code != 0:
                raise RuntimeError(f"uv sync exited with code {code}: {lines[-1] if lines else ''}")
        result.ok = True
        return result
    except (RuntimeError, ValueError, OSError, TOMLKitError) as exc:
        restore()
        result.error = str(exc)
        return result
