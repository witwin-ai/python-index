"""Mesh files of a Scene: ``<scene>.binary/<binary_id>.meshbin``.

A ``.meshbin`` file is one WTB1 payload of subtype ``mesh`` (RFC-019 §6):

    0   4   magic b"WTB1"
    4   4   u32 header_len: bytes of the JSON header
    8   n   JSON header {"type": "mesh", "v": 1, "meta": {...}, "buffers": [...]}
    ..      zero padding to a 16-byte boundary, then the buffers, each on a
            16-byte boundary (offsets relative to the buffer region)

Buffers: ``position`` f32 (N, 3), ``index`` u32 (3M,), optional ``normal``
f32 (N, 3), ``uv`` f32 (N, 2), ``skin_index`` u16 (N, 4), ``skin_weight``
f32 (N, 4). Meta: ``version``, ``flags``, ``vertex_count``, ``index_count``,
``bounds`` (object-local min xyz, max xyz).

This is the one encoder: the ProjectServer's
``mesh/meshbin.encode_mesh`` (studio.assets) re-exports ``encode_mesh`` from
here, so a file a script writes is byte-identical to the file Studio would
write for the same arrays. The server has its own ``decode_mesh`` on top of its
WTB1 reader; both read WTB1 only.

Imports numpy at module load. ``witwin.studio`` itself does not import this
module, so ``import witwin.studio`` stays numpy-free.
"""
from __future__ import annotations

import hashlib
import json
import struct
from dataclasses import dataclass
from typing import List, Optional, Sequence

import numpy as np

__all__ = [
    "DecodedMesh",
    "EXTENSION",
    "compute_bounds",
    "content_hash_of",
    "decode_mesh",
    "encode_mesh",
]

EXTENSION = ".meshbin"
VERSION = 1

_MAGIC = b"WTB1"
_PREAMBLE = 8  # magic + u32 header_len
_ALIGN = 16
# A header is a few hundred bytes; anything this large is corrupt or hostile.
_MAX_HEADER_BYTES = 1 << 20

# Attribute flag bits (meta.flags). The server's meshbin.FLAG_* and the
# frontend mesh parser use the same values.
FLAG_POSITION = 1 << 0
FLAG_INDEX = 1 << 1
FLAG_NORMAL = 1 << 2
FLAG_UV = 1 << 3
FLAG_SKIN_INDEX = 1 << 4
FLAG_SKIN_WEIGHT = 1 << 5

_DTYPES = {
    "f32": np.dtype("<f4"),
    "f64": np.dtype("<f8"),
    "i8": np.dtype("i1"),
    "u8": np.dtype("u1"),
    "i16": np.dtype("<i2"),
    "u16": np.dtype("<u2"),
    "i32": np.dtype("<i4"),
    "u32": np.dtype("<u4"),
    "i64": np.dtype("<i8"),
    "u64": np.dtype("<u8"),
}
_NAME_BY_DTYPE = {dt: name for name, dt in _DTYPES.items()}


def _align(value: int) -> int:
    return (value + _ALIGN - 1) // _ALIGN * _ALIGN


def compute_bounds(positions: np.ndarray) -> List[float]:
    """Axis-aligned bounds ``[minx, miny, minz, maxx, maxy, maxz]`` of (N, 3) positions."""
    if positions is None or len(positions) == 0:
        return [0.0] * 6
    mn = positions.min(axis=0)
    mx = positions.max(axis=0)
    return [float(mn[0]), float(mn[1]), float(mn[2]), float(mx[0]), float(mx[1]), float(mx[2])]


# The WTB1 container writer. Must stay byte-identical to the server's
# core/protocol/wtb.encode: sorted keys, compact separators, 16-byte alignment.
# server/tests/test_sdk_meshbin_compat.py compares the two.
def _encode_wtb(type_: str, buffers: Sequence[tuple], meta: dict) -> bytes:
    specs = []
    arrays = []
    cursor = 0
    for name, value in buffers:
        arr = np.ascontiguousarray(value)
        dt = arr.dtype.newbyteorder("<") if arr.dtype.byteorder == ">" else arr.dtype
        dtype_name = _NAME_BY_DTYPE.get(np.dtype(dt))
        if dtype_name is None:
            raise TypeError(f"buffer {name!r}: unsupported dtype {arr.dtype}")
        arr = arr.astype(_DTYPES[dtype_name], copy=False)
        specs.append({"name": name, "dtype": dtype_name, "shape": [int(d) for d in arr.shape],
                      "offset": cursor, "length": int(arr.nbytes)})
        arrays.append(arr)
        cursor = _align(cursor + arr.nbytes)
    header = json.dumps({"type": type_, "v": 1, "meta": dict(meta), "buffers": specs},
                        ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    region = _align(_PREAMBLE + len(header))
    out = bytearray(region + cursor)
    out[:4] = _MAGIC
    struct.pack_into("<I", out, 4, len(header))
    out[_PREAMBLE:_PREAMBLE + len(header)] = header
    for spec, arr in zip(specs, arrays):
        start = region + spec["offset"]
        out[start:start + spec["length"]] = arr.tobytes()
    return bytes(out)


def encode_mesh(
    positions: np.ndarray,
    indices: np.ndarray,
    normals: Optional[np.ndarray] = None,
    uvs: Optional[np.ndarray] = None,
    skin_indices: Optional[np.ndarray] = None,
    skin_weights: Optional[np.ndarray] = None,
    bounds: Optional[List[float]] = None,
) -> bytes:
    """Encode mesh arrays as a WTB1 ``mesh`` payload (the ``.meshbin`` file bytes).

    ``positions`` (N, 3) any float dtype, stored as float32; ``indices`` (M, 3)
    or flat, stored as uint32. Empty optional attributes are left out.
    ``bounds`` defaults to the bounds of ``positions``.
    """
    pos = np.ascontiguousarray(positions, dtype=np.float32).reshape(-1, 3)
    buffers = [("position", pos), ("index", np.ascontiguousarray(indices, dtype=np.uint32).ravel())]
    flags = FLAG_POSITION | FLAG_INDEX
    for name, value, dtype, width, flag in (
        ("normal", normals, np.float32, 3, FLAG_NORMAL),
        ("uv", uvs, np.float32, 2, FLAG_UV),
        ("skin_index", skin_indices, np.uint16, 4, FLAG_SKIN_INDEX),
        ("skin_weight", skin_weights, np.float32, 4, FLAG_SKIN_WEIGHT),
    ):
        if value is not None and len(value) > 0:
            buffers.append((name, np.ascontiguousarray(value, dtype=dtype).reshape(-1, width)))
            flags |= flag
    if bounds is None:
        bounds = compute_bounds(pos)
    meta = {
        "version": VERSION,
        "flags": flags,
        "vertex_count": int(pos.shape[0]),
        "index_count": int(buffers[1][1].size),
        "bounds": [float(b) for b in bounds],
    }
    return _encode_wtb("mesh", buffers, meta)


@dataclass
class DecodedMesh:
    """Arrays of one ``.meshbin`` file; absent attributes are None."""

    positions: np.ndarray
    indices: np.ndarray
    normals: Optional[np.ndarray] = None
    uvs: Optional[np.ndarray] = None
    skin_indices: Optional[np.ndarray] = None
    skin_weights: Optional[np.ndarray] = None
    bounds: Optional[List[float]] = None


def decode_mesh(data: bytes) -> DecodedMesh:
    """Read a WTB1 ``mesh`` payload. ``ValueError`` for anything else, including
    the retired pre-WTB1 ``WTMESH1`` files."""
    raw = bytes(data)
    if raw[:4] != _MAGIC or len(raw) < _PREAMBLE:
        raise ValueError(f"meshbin: not a WTB1 payload (magic {raw[:8]!r})")
    (header_len,) = struct.unpack_from("<I", raw, 4)
    if header_len > _MAX_HEADER_BYTES or _PREAMBLE + header_len > len(raw):
        raise ValueError("meshbin: header length out of range")
    try:
        header = json.loads(raw[_PREAMBLE:_PREAMBLE + header_len].decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("meshbin: invalid JSON header") from exc
    if not isinstance(header, dict) or header.get("type") != "mesh":
        raise ValueError(f"meshbin: expected a mesh payload, got {header.get('type') if isinstance(header, dict) else header!r}")
    region = _align(_PREAMBLE + header_len)
    buffers = {}
    for spec in header.get("buffers") or []:
        dt = _DTYPES.get(spec.get("dtype"))
        if dt is None:
            raise ValueError(f"meshbin: buffer {spec.get('name')!r} has unknown dtype {spec.get('dtype')!r}")
        start = region + int(spec["offset"])
        length = int(spec["length"])
        if start + length > len(raw) or length % dt.itemsize:
            raise ValueError(f"meshbin: buffer {spec.get('name')!r} out of range")
        buffers[spec["name"]] = np.frombuffer(raw, dtype=dt, count=length // dt.itemsize, offset=start)

    def take(name: str, width: int) -> Optional[np.ndarray]:
        arr = buffers.get(name)
        return None if arr is None else arr.reshape(-1, width).copy()

    positions = take("position", 3)
    indices = take("index", 3)
    if positions is None or indices is None:
        raise ValueError("meshbin: position and index buffers are required")
    meta = header.get("meta") or {}
    return DecodedMesh(
        positions=positions, indices=indices, normals=take("normal", 3), uvs=take("uv", 2),
        skin_indices=take("skin_index", 4), skin_weights=take("skin_weight", 4),
        bounds=[float(b) for b in meta["bounds"]] if "bounds" in meta else None,
    )


def content_hash_of(data: bytes) -> str:
    """``sha256:<hex>`` of a payload: the ``content_hash`` a Mesh source records."""
    return "sha256:" + hashlib.sha256(data).hexdigest()
