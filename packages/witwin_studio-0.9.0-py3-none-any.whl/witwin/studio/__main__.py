"""``python -m witwin.studio`` runs the ``witwin`` command."""
from ._cli import main

raise SystemExit(main())
