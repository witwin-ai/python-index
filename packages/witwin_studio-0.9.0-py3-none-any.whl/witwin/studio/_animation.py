"""Keyframe animation of a Scene: the Timeline clip as data, its interpolation, and motion helpers.

The clip lives in the scene document under ``timeline``, in the shape the
ProjectServer's ``TimelineManager.to_dict`` and the ``.wtscene`` codec use::

    {"clip": {"name": "Timeline", "duration": 10.0, "fps": 30.0,
              "tracks": {"<object_id>/<Component>/<field>": {
                  "path": ..., "object_id": ..., "component_name": ..., "field_name": ...,
                  "keyframes": [{"time": 0.0, "value": [0, 0, 0], "interpolation": "linear"}]}}},
     "current_time": 0.0, "is_looping": False}

A track animates one field: ``Transform.position`` / ``rotation`` / ``scale``
or a number (or vector of numbers) of another component. Values are stored as
the field holds them, so Transform.rotation keyframes hold the field's
``[z, x, y]`` radians (SciPy "ZXY"). This API takes and returns rotations as
degrees ``[x, y, z]``, like the scene Tools.

Interpolation (``value_at``, ``segment_value``) is the one the Timeline uses
everywhere: the ProjectServer's ``TimelineTrack`` (features/timeline/data.py)
calls ``ease`` and ``lerp_value`` from here, and Studio's
``interpolateSortedKeyframes`` (studio/src/features/timeline/utils/timelineMath.ts)
is its TypeScript twin. Before the first key the value is the first key's,
after the last key the last key's; a ``step`` key holds its value until the
next key; ``linear`` lerps every number of the value; ``bezier`` lerps with
smoothstep easing ``t*t*(3-2t)``. Angles are lerped as plain numbers, so a
rotation from 0 to 720 degrees turns twice. Playback runs over the keyframe
range (first to last key), not over the clip duration; ``loop`` wraps there.
"""
from __future__ import annotations

import bisect
import math
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

from ._scene import _euler_to_quat, _quat_mul, _quat_to_euler

INTERPOLATIONS = ("linear", "step", "bezier")
# Keys closer than this are the same key (TimelineTrack.add_keyframe's tolerance).
KEY_TOLERANCE = 1e-4
TRANSFORM = "Transform"
TRANSFORM_FIELDS = ("position", "rotation", "scale")
DEFAULT_CLIP = {"name": "Timeline", "duration": 10.0, "fps": 30.0}
# Euler slot of each axis in the Transform.rotation field ([z, x, y]).
_SLOT = {"x": 1, "y": 2, "z": 0}
# A heading turn is split into keys this far apart, so lerping Euler angles
# between them stays close to the true turn when the object is also tilted.
_MAX_TURN_STEP = math.radians(10.0)

Keyframe = Union[Tuple[float, Any], Mapping[str, Any]]


# --------------------------------------------------------------------------- #
# Interpolation (shared with the ProjectServer's TimelineTrack)
# --------------------------------------------------------------------------- #
def ease(interpolation: str, t: float) -> float:
    """Segment parameter ``t`` (0..1) after easing: smoothstep for ``bezier``, unchanged otherwise."""
    return t * t * (3 - 2 * t) if interpolation == "bezier" else t


def lerp_value(a: Any, b: Any, t: float) -> Any:
    """Lerp numbers and equal-length lists of numbers; anything else switches at ``t = 0.5``."""
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a + (b - a) * t
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        if len(a) != len(b):
            return a if t < 0.5 else b
        return [lerp_value(x, y, t) for x, y in zip(a, b)]
    return a if t < 0.5 else b


def segment_value(v0: Any, interpolation: str, t0: float, v1: Any, t1: float, time: float) -> Any:
    """Value at ``time`` between a key ``(t0, v0, interpolation)`` and the next key ``(t1, v1)``."""
    if interpolation == "step":
        return v0
    duration = t1 - t0
    if duration <= 0:
        return v0
    return lerp_value(v0, v1, ease(interpolation, (time - t0) / duration))


def value_at(keyframes: Sequence[Mapping[str, Any]], time: float) -> Any:
    """Interpolated value of time-sorted ``{time, value, interpolation}`` keys; None without keys."""
    if not keyframes:
        return None
    if time <= keyframes[0]["time"]:
        return keyframes[0]["value"]
    if time >= keyframes[-1]["time"]:
        return keyframes[-1]["value"]
    following = bisect.bisect_right([float(k["time"]) for k in keyframes], time)
    prev, nxt = keyframes[following - 1], keyframes[following]
    return segment_value(prev["value"], str(prev.get("interpolation") or "linear"), float(prev["time"]),
                         nxt["value"], float(nxt["time"]), time)


def default_interpolation(value: Any) -> str:
    """``linear`` for numbers and lists of numbers, ``step`` for anything else (flags, names)."""
    if isinstance(value, bool):
        return "step"
    if isinstance(value, (int, float)):
        return "linear"
    if isinstance(value, (list, tuple)) and value and all(
            isinstance(v, (int, float)) and not isinstance(v, bool) for v in value):
        return "linear"
    return "step"


# --------------------------------------------------------------------------- #
# Rotations: degrees [x, y, z] <-> the Transform.rotation field, and up frames
# --------------------------------------------------------------------------- #
def degrees_to_field(xyz_degrees: Sequence[float]) -> List[float]:
    """``[x, y, z]`` degrees -> Transform.rotation field ``[z, x, y]`` radians (no wrapping)."""
    x, y, z = (math.radians(float(v)) for v in xyz_degrees)
    return [z, x, y]


def field_to_degrees(field_value: Sequence[float]) -> List[float]:
    """Transform.rotation field ``[z, x, y]`` radians -> ``[x, y, z]`` degrees (no rounding)."""
    z, x, y = (float(v) for v in list(field_value)[:3])
    return [math.degrees(x) + 0.0, math.degrees(y) + 0.0, math.degrees(z) + 0.0]


# The up="z" model frame turns into the Scene by -90 degrees about X
# (geometry/_frame.py): model (x, y, z) -> Scene (x, z, -y).
_Z_UP_TO_SCENE = [-math.sin(math.pi / 4), 0.0, 0.0, math.cos(math.pi / 4)]
_SCENE_TO_Z_UP = [math.sin(math.pi / 4), 0.0, 0.0, math.cos(math.pi / 4)]
# A turn about one model axis is a turn about this Scene axis (slot, sign).
_Z_UP_AXIS = {"x": ("x", 1.0), "y": ("z", -1.0), "z": ("y", 1.0)}


def _conjugate(frame: Sequence[float], field_value: Sequence[float]) -> List[float]:
    inverse = [-frame[0], -frame[1], -frame[2], frame[3]]
    return _quat_to_euler(_quat_mul(_quat_mul(frame, _euler_to_quat(field_value)), inverse))


# The one axis a rotation turns about; -1 for no rotation, None for several axes.
def _single_axis(xyz: Sequence[float]) -> Optional[int]:
    nonzero = [i for i, v in enumerate(xyz) if abs(float(v)) > 1e-12]
    return nonzero[0] if len(nonzero) == 1 else (-1 if not nonzero else None)


def rotations_to_scene(rotations: Sequence[Sequence[float]], up: Optional[str] = None) -> List[List[float]]:
    """``[x, y, z]`` degree rotations in the ``up`` frame -> Scene-frame degrees, keeping turns.

    ``up`` None / ``"y"``: unchanged. ``"z"``: a model-frame rotation (Z up)
    turned into the Scene frame. When every rotation turns about the same
    single axis the angle maps exactly (model Z -> Scene Y, Y -> -Z, X -> X),
    so 720 degrees stays two turns; otherwise each rotation is converted and
    unwrapped against the previous one.
    """
    if up is None or str(up).lower() == "y":
        return [[float(v) for v in r] for r in rotations]
    if str(up).lower() != "z":
        raise ValueError(f"up must be 'y' or 'z', got {up!r}")
    axes = {_single_axis(r) for r in rotations} - {-1}
    if len(axes) <= 1 and None not in axes:
        axis = "xyz"[axes.pop()] if axes else "x"
        scene_axis, sign = _Z_UP_AXIS[axis]
        out = []
        for r in rotations:
            values = [0.0, 0.0, 0.0]
            values["xyz".index(scene_axis)] = sign * float(r["xyz".index(axis)]) + 0.0
            out.append(values)
        return out
    fields = [_conjugate(_Z_UP_TO_SCENE, degrees_to_field(r)) for r in rotations]
    return [field_to_degrees(f) for f in unwrap_fields(fields)]


def rotation_from_scene(field_value: Sequence[float], up: Optional[str] = None) -> List[float]:
    """Transform.rotation field -> ``[x, y, z]`` degrees in the ``up`` frame.

    A turn about one axis maps exactly (so 720 degrees reads back as 720),
    like ``rotations_to_scene``.
    """
    degrees = field_to_degrees(field_value)
    if up is None or str(up).lower() == "y":
        return degrees
    axis = _single_axis(degrees)
    if axis is not None:
        out = [0.0, 0.0, 0.0]
        if axis >= 0:
            model_axis = next(a for a, (s, _) in _Z_UP_AXIS.items() if s == "xyz"[axis])
            out["xyz".index(model_axis)] = _Z_UP_AXIS[model_axis][1] * degrees[axis] + 0.0
        return out
    return field_to_degrees(_conjugate(_SCENE_TO_Z_UP, field_value))


def unwrap_fields(fields: Sequence[Sequence[float]]) -> List[List[float]]:
    """Shift each Euler angle by whole turns so it moves less than half a turn from the previous key."""
    out: List[List[float]] = []
    for value in fields:
        value = [float(v) for v in value]
        if out:
            value = [v + 2 * math.pi * round((p - v) / (2 * math.pi)) for v, p in zip(value, out[-1])]
        out.append(value)
    return out


# --------------------------------------------------------------------------- #
# Motion helpers: pure functions returning keyframes (the Agent Tools use them too)
# --------------------------------------------------------------------------- #
def _vec3(value: Any, what: str) -> List[float]:
    out = [float(v) for v in value]
    if len(out) != 3:
        raise ValueError(f"{what} needs 3 numbers, got {len(out)}")
    return out


def points_to_scene(points: Iterable[Sequence[float]], up: Optional[str] = None) -> List[List[float]]:
    """Points in the ``up`` frame -> Scene frame (``"z"``: ``(x, y, z) -> (x, z, -y)``)."""
    out = [_vec3(p, "a point") for p in points]
    if up is None or str(up).lower() == "y":
        return out
    if str(up).lower() != "z":
        raise ValueError(f"up must be 'y' or 'z', got {up!r}")
    return [[x, z, -y + 0.0] for x, y, z in out]


def points_from_scene(points: Iterable[Sequence[float]], up: Optional[str] = None) -> List[List[float]]:
    """The inverse of ``points_to_scene``."""
    out = [_vec3(p, "a point") for p in points]
    if up is None or str(up).lower() == "y":
        return out
    return [[x, -z + 0.0, y] for x, y, z in out]


def scale_to_scene(scale: Sequence[float], up: Optional[str] = None) -> List[float]:
    """Scale factors per axis in the ``up`` frame -> Scene axes (``"z"``: model y and z swap)."""
    x, y, z = _vec3(scale, "scale")
    return [x, y, z] if up is None or str(up).lower() == "y" else [x, z, y]


def path_keyframes(points: Sequence[Sequence[float]], *, speed: Optional[float] = None,
                   duration: Optional[float] = None, start: float = 0.0,
                   closed: bool = False) -> List[Tuple[float, List[float]]]:
    """``(time, position)`` keys that move along a polyline at constant speed.

    Give ``speed`` (m/s) or ``duration`` (s), not both. ``closed`` returns to
    the first point. Repeated points are dropped. Linear keys at every vertex
    make the speed exactly constant along the whole path.
    """
    pts: List[List[float]] = []
    for p in points:
        p = _vec3(p, "a path point")
        if not pts or math.dist(p, pts[-1]) > 1e-9:
            pts.append(p)
    if closed and len(pts) > 1 and math.dist(pts[0], pts[-1]) > 1e-9:
        pts.append(list(pts[0]))
    if len(pts) < 2:
        raise ValueError("a path needs at least two distinct points")
    lengths = [math.dist(a, b) for a, b in zip(pts, pts[1:])]
    total = sum(lengths)
    if (speed is None) == (duration is None):
        raise ValueError("give exactly one of speed (m/s) or duration (s)")
    if speed is not None and not speed > 0:
        raise ValueError("speed must be > 0")
    if duration is not None and not duration > 0:
        raise ValueError("duration must be > 0")
    rate = float(speed) if speed is not None else total / float(duration)
    keys, travelled = [(float(start), pts[0])], 0.0
    for length, point in zip(lengths, pts[1:]):
        travelled += length
        keys.append((float(start) + travelled / rate, point))
    if duration is not None:  # no rounding drift on the end time the caller gave
        keys[-1] = (float(start) + float(duration), keys[-1][1])
    return keys


def circle_points(center: Sequence[float], radius: float, *, turns: float = 1.0, start_angle: float = 0.0,
                  clockwise: bool = False, segments_per_turn: int = 120) -> List[List[float]]:
    """A horizontal circle (or arc) in the Scene frame around ``center``, as polyline points.

    ``start_angle`` is degrees from +X, counter-clockwise seen from above
    (towards -Z in the Scene, +Y in a Z-up model frame). 120 segments per turn
    keep every point on the circle and the chord sag under 0.04 % of the radius.
    """
    cx, cy, cz = _vec3(center, "center")
    if not radius > 0:
        raise ValueError("radius must be > 0")
    if not turns > 0:
        raise ValueError("turns must be > 0")
    count = max(3, int(math.ceil(segments_per_turn * turns)))
    sign = -1.0 if clockwise else 1.0
    a0 = math.radians(start_angle)
    points = []
    for i in range(count + 1):
        a = a0 + sign * 2 * math.pi * turns * i / count
        points.append([cx + radius * math.cos(a), cy, cz - radius * math.sin(a)])
    return points


def _heading(direction: Sequence[float]) -> Optional[float]:
    """Yaw about +Y (radians) that turns +X towards the horizontal part of ``direction``."""
    dx, _, dz = direction
    if math.hypot(dx, dz) < 1e-12:
        return None
    return math.atan2(-dz, dx)


def _wrap(angle: float) -> float:
    return (angle + math.pi) % (2 * math.pi) - math.pi


def facing_keyframes(keys: Sequence[Tuple[float, Sequence[float]]], *, forward: Sequence[float] = (1.0, 0.0, 0.0),
                     base: Sequence[float] = (0.0, 0.0, 0.0),
                     turn_time: float = 0.5) -> List[Tuple[float, List[float]]]:
    """Transform.rotation keys that keep ``forward`` (a Scene-frame local axis) pointing along the path.

    ``keys`` are the position keys of ``path_keyframes``. The object turns
    about the vertical axis only, on top of ``base`` (the rotation field at
    rest), so a tilt stays. Each corner turns over ``turn_time`` seconds
    centred on the vertex (at most a quarter of either segment).
    ``turn_time=0`` turns all the time instead: one key at the middle of each
    segment, which follows a curve given as a dense polyline (an orbit)
    exactly at those points. Headings are unwrapped, so a loop keeps turning
    the same way instead of spinning back.
    """
    base_q = _euler_to_quat([float(v) for v in base])
    f_yaw = _heading(_rotate(base_q, forward))
    if f_yaw is None:
        raise ValueError("forward must not point straight up")
    times = [float(t) for t, _ in keys]
    yaws: List[float] = []  # turn about +Y on top of base, per segment
    for (_, a), (_, b) in zip(keys, keys[1:]):
        h = _heading([b[i] - a[i] for i in range(3)])
        yaw = (h - f_yaw) if h is not None else (yaws[-1] if yaws else 0.0)
        if yaws:
            yaw = yaws[-1] + _wrap(yaw - yaws[-1])
        yaws.append(yaw)
    timed: List[Tuple[float, float]] = [(times[0], yaws[0])]
    if turn_time <= 0:
        timed += [((times[i] + times[i + 1]) / 2, yaw) for i, yaw in enumerate(yaws)]
    else:
        for i in range(1, len(yaws)):
            if abs(yaws[i] - yaws[i - 1]) < 1e-12:
                continue
            corner = times[i]
            timed.append((corner - min(turn_time / 2, (corner - times[i - 1]) / 4), yaws[i - 1]))
            timed.append((corner + min(turn_time / 2, (times[i + 1] - corner) / 4), yaws[i]))
    timed.append((times[-1], yaws[-1]))
    return _yaw_fields(timed, base)


def _rotate(q: Sequence[float], v: Sequence[float]) -> List[float]:
    """Vector ``v`` turned by unit quaternion ``q`` ``(x, y, z, w)``."""
    x, y, z, w = q
    out = _quat_mul(_quat_mul([x, y, z, w], [float(v[0]), float(v[1]), float(v[2]), 0.0]), [-x, -y, -z, w])
    return out[:3]


def _yaw_fields(timed: Sequence[Tuple[float, float]], base: Sequence[float]) -> List[Tuple[float, List[float]]]:
    bz, bx, by = (float(v) for v in base)
    upright = abs(bz) < 1e-9 and abs(bx) < 1e-9
    if upright:
        # The common case: a yaw is just the Y angle, so it maps exactly.
        return [(t, [0.0, 0.0, by + yaw]) for t, yaw in timed]
    # A tilted object: yaw (about the parent's +Y) times the rest rotation,
    # with extra keys inside each turn so the lerped Euler angles follow it.
    expanded: List[Tuple[float, float]] = [timed[0]]
    for (t0, y0), (t1, y1) in zip(timed, timed[1:]):
        steps = max(1, int(math.ceil(abs(y1 - y0) / _MAX_TURN_STEP)))
        for k in range(1, steps + 1):
            expanded.append((t0 + (t1 - t0) * k / steps, y0 + (y1 - y0) * k / steps))
    base_q = _euler_to_quat([bz, bx, by])
    fields = [_quat_to_euler(_quat_mul([0.0, math.sin(yaw / 2), 0.0, math.cos(yaw / 2)], base_q))
              for _, yaw in expanded]
    return list(zip([t for t, _ in expanded], unwrap_fields(fields)))


def spin_keyframes(base: Sequence[float], axis: str, *, degrees_per_second: float, duration: float,
                   start: float = 0.0, start_angle: float = 0.0,
                   up: Optional[str] = None) -> List[Tuple[float, List[float]]]:
    """Two linear Transform.rotation keys that turn at a constant rate about one Euler axis.

    The angle is added to that axis's Euler angle of ``base`` (the field
    value at rest; the order is Z, then X, then Y), so spinning about Y keeps
    an X or Z tilt. ``axis`` is ``"x"``, ``"y"`` or ``"z"`` in the ``up``
    frame; in a Z-up frame ``"z"`` is the Scene's Y. A negative rate turns
    the other way (clockwise seen from the axis tip).
    """
    axis = str(axis).lower()
    if axis not in _SLOT:
        raise ValueError(f"axis must be 'x', 'y' or 'z', got {axis!r}")
    if not duration > 0:
        raise ValueError("duration must be > 0")
    sign = 1.0
    if up is not None and str(up).lower() == "z":
        axis, sign = _Z_UP_AXIS[axis]
    slot = _SLOT[axis]
    first = [float(v) for v in base]
    first[slot] += sign * math.radians(start_angle)
    last = list(first)
    last[slot] += sign * math.radians(degrees_per_second * duration)
    return [(float(start), first), (float(start) + float(duration), last)]


def motion_keyframes(points: Sequence[Sequence[float]], *, speed: Optional[float] = None,
                     duration: Optional[float] = None, start: float = 0.0, closed: bool = False,
                     face: bool = False, forward: Sequence[float] = (1.0, 0.0, 0.0),
                     base: Sequence[float] = (0.0, 0.0, 0.0), turn_time: float = 0.5,
                     ) -> Tuple[List[Tuple[float, List[float]]], List[Tuple[float, List[float]]]]:
    """Position keys along Scene-frame ``points`` and, with ``face``, the rotation keys that face along them."""
    position_keys = path_keyframes(points, speed=speed, duration=duration, start=start, closed=closed)
    rotation_keys = (facing_keyframes(position_keys, forward=forward, base=base, turn_time=turn_time)
                     if face else [])
    return position_keys, rotation_keys


def motion_summary(position_keys: Sequence[Tuple[float, Sequence[float]]],
                   rotation_keys: Sequence[Any] = ()) -> Dict[str, Any]:
    """``{"start", "end", "length", "speed", "keys"}`` of a ``motion_keyframes`` result (seconds, meters)."""
    length = sum(math.dist(a, b) for (_, a), (_, b) in zip(position_keys, position_keys[1:]))
    start, end = position_keys[0][0], position_keys[-1][0]
    return {"start": start, "end": end, "length": length, "speed": length / (end - start),
            "keys": len(position_keys) + len(rotation_keys)}


# --------------------------------------------------------------------------- #
# Animation: the Scene's clip
# --------------------------------------------------------------------------- #
def split_target(target: str) -> Tuple[str, str]:
    """``"Transform.position"`` / ``"position"`` / ``"Component.field"`` -> ``(component, field)``."""
    if not isinstance(target, str) or not target.strip():
        raise ValueError("target must be 'Component.field' or a Transform field name")
    text = target.strip()
    if "." not in text:
        if text in TRANSFORM_FIELDS:
            return TRANSFORM, text
        raise ValueError(f"target {target!r}: use 'Component.field' or position / rotation / scale")
    component, _, field = text.partition(".")
    if not component or not field or "." in field:
        raise ValueError(f"target {target!r}: use 'Component.field'")
    if component == TRANSFORM and field not in TRANSFORM_FIELDS:
        raise ValueError(f"Transform has no animatable field {field!r} (position, rotation, scale)")
    return component, field


def values_to_storage(component: str, field: str, values: Sequence[Any], up: Optional[str] = None) -> List[Any]:
    """Key values in this API's units -> as the track stores them.

    Transform values move from the ``up`` frame into the Scene frame and
    rotations become the field's radians; other components' values are
    stored as given. Rotations convert together, so whole turns survive.
    """
    if component != TRANSFORM:
        return list(values)
    if field == "position":
        return points_to_scene(values, up)
    if field == "rotation":
        return [degrees_to_field(r) for r in rotations_to_scene([_vec3(v, "rotation") for v in values], up)]
    return [scale_to_scene(v, up) for v in values]


def value_from_storage(component: str, field: str, value: Any, up: Optional[str] = None) -> Any:
    """The inverse of ``values_to_storage`` for one stored value."""
    if component != TRANSFORM:
        return value
    if field == "rotation":
        return rotation_from_scene(value, up)
    if field == "position":
        return points_from_scene([value], up)[0]
    return scale_to_scene(value, up)  # swapping y and z is its own inverse


def _key(item: Keyframe) -> Tuple[float, Any, Optional[str]]:
    if isinstance(item, Mapping):
        if "time" not in item or "value" not in item:
            raise ValueError("a keyframe needs 'time' and 'value'")
        time, value, interpolation = item["time"], item["value"], item.get("interpolation")
    else:
        time, value = item
        interpolation = None
    time = float(time)
    if not math.isfinite(time) or time < 0:
        raise ValueError(f"keyframe time must be a number >= 0, got {time}")
    if value is None:
        raise ValueError("a keyframe value cannot be None")
    if hasattr(value, "tolist"):
        value = value.tolist()
    if isinstance(value, tuple):
        value = list(value)
    if interpolation is not None and interpolation not in INTERPOLATIONS:
        raise ValueError(f"interpolation must be one of {INTERPOLATIONS}, got {interpolation!r}")
    return time, value, interpolation


def merge_keyframes(existing: Sequence[Mapping[str, Any]],
                    incoming: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    """Existing and new keys sorted by time; a new key replaces any key within ``KEY_TOLERANCE``."""
    # Within one call the last of several keys at the same time wins; sorted()
    # is stable, so "last" is the caller's order.
    fresh: List[Dict[str, Any]] = []
    for key in sorted((dict(k) for k in incoming), key=lambda k: float(k["time"])):
        if fresh and float(key["time"]) - float(fresh[-1]["time"]) <= KEY_TOLERANCE:
            fresh[-1] = key
        else:
            fresh.append(key)
    times = [float(k["time"]) for k in fresh]

    def replaced(time: float) -> bool:
        i = bisect.bisect_left(times, time - KEY_TOLERANCE)
        return i < len(times) and times[i] <= time + KEY_TOLERANCE

    out = [dict(k) for k in existing if not replaced(float(k["time"]))] + fresh
    out.sort(key=lambda k: float(k["time"]))
    return out


class Animation:
    """Keyframe animation of a Scene (the Timeline clip): ``scene.animation``.

    Keys are written in the format Studio's Timeline reads and writes, so a
    clip made here plays in the editor, and one made in the editor samples
    here the same way. Targets are ``"Transform.position"`` (or just
    ``"position"``), ``"Transform.rotation"``, ``"Transform.scale"`` or
    ``"Component.field"`` for a number or vector of numbers. Transform values
    are local (relative to the parent) in meters; rotations are degrees
    ``[x, y, z]``. ``up="z"`` takes positions and rotations in a Z-up model
    frame. A field bound to a formula cannot have keys (a ``ValueError``),
    just as an animated field cannot be bound.

        anim = scene.animation
        anim.set_keyframes(car, "position", [(0, [0, 0, 0]), (4, [40, 0, 0])])
        anim.rotate(radar, axis="y", rpm=15, duration=8)
        anim.set_clip(duration=8, loop=True)
        anim.transform_at(car, 2.0)["position"]   # [20.0, 0.0, 0.0]
    """

    def __init__(self, scene: Any):
        self._scene = scene

    # -- document access -------------------------------------------------
    def _peek(self) -> Dict[str, Any]:
        return self._scene._doc.get("timeline") or {}

    def _timeline(self) -> Dict[str, Any]:
        doc = self._scene._doc
        timeline = doc.get("timeline")
        if not isinstance(timeline, dict) or not timeline:
            timeline = {"clip": {**DEFAULT_CLIP, "tracks": {}}, "current_time": 0.0, "is_looping": False}
            doc["timeline"] = timeline
        clip = timeline.setdefault("clip", {})
        for key, value in DEFAULT_CLIP.items():
            clip.setdefault(key, value)
        clip.setdefault("tracks", {})
        return timeline

    def _tracks(self) -> Dict[str, Dict[str, Any]]:
        return (self._peek().get("clip") or {}).get("tracks") or {}

    def _entity_id(self, entity: Any) -> str:
        entity_id = getattr(entity, "id", entity)
        if entity_id not in self._scene._objects:
            raise KeyError(f"entity not in scene: {entity_id}")
        return str(entity_id)

    def _resolve(self, entity: Any, target: str) -> Tuple[str, str, str]:
        entity_id = self._entity_id(entity)
        component, field = split_target(target)
        if component != TRANSFORM and component not in self._scene.objects[entity_id].components:
            raise KeyError(f"'{self._scene.objects[entity_id].name}' has no {component} component")
        return entity_id, component, field

    def _require_not_bound(self, entity_id: str, component: str, field: str) -> None:
        target = f"{component}.{field}"
        if any(info.target.target == target for info in self._scene.formulas.bindings_for(entity_id)):
            raise ValueError(f"{target} is bound to a formula; unbind it before adding keyframes")

    # -- clip settings ----------------------------------------------------
    @property
    def duration(self) -> float:
        """Clip length in seconds (the Timeline's ruler); keys past it extend it."""
        return float((self._peek().get("clip") or {}).get("duration", DEFAULT_CLIP["duration"]))

    @duration.setter
    def duration(self, value: float) -> None:
        self.set_clip(duration=value)

    @property
    def fps(self) -> float:
        return float((self._peek().get("clip") or {}).get("fps", DEFAULT_CLIP["fps"]))

    @fps.setter
    def fps(self, value: float) -> None:
        self.set_clip(fps=value)

    @property
    def loop(self) -> bool:
        """Whether playback wraps from the last key back to the first."""
        return bool(self._peek().get("is_looping", False))

    @loop.setter
    def loop(self, value: bool) -> None:
        self.set_clip(loop=value)

    def set_clip(self, *, duration: Optional[float] = None, fps: Optional[float] = None,
                 loop: Optional[bool] = None, name: Optional[str] = None) -> None:
        """Clip settings, with the ProjectServer's limits: duration >= 0.1 s, fps >= 1."""
        timeline = self._timeline()
        clip = timeline["clip"]
        if duration is not None:
            clip["duration"] = max(0.1, float(duration))
        if fps is not None:
            clip["fps"] = float(max(1.0, float(fps)))
        if loop is not None:
            timeline["is_looping"] = bool(loop)
        if name is not None:
            clip["name"] = str(name)

    @property
    def range(self) -> Tuple[float, float]:
        """``(first key time, last key time)`` over every track; ``(0, 0)`` without keys."""
        times = [float(k["time"]) for track in self._tracks().values() for k in track.get("keyframes") or []]
        return (min(times), max(times)) if times else (0.0, 0.0)

    # -- tracks -----------------------------------------------------------
    @property
    def tracks(self) -> List[Dict[str, Any]]:
        """One row per track: ``object_id``, ``target``, ``count``, ``start``, ``end``."""
        rows = []
        for track in self._tracks().values():
            keys = track.get("keyframes") or []
            rows.append({
                "object_id": track.get("object_id"),
                "target": f"{track.get('component_name')}.{track.get('field_name')}",
                "count": len(keys),
                "start": float(keys[0]["time"]) if keys else None,
                "end": float(keys[-1]["time"]) if keys else None,
            })
        return rows

    def _track(self, entity_id: str, component: str, field: str) -> Optional[Dict[str, Any]]:
        return self._tracks().get(f"{entity_id}/{component}/{field}")

    def set_keyframes(self, entity: Any, target: str, keyframes: Iterable[Keyframe], *,
                      interpolation: Optional[str] = None, replace: bool = False,
                      up: Optional[str] = None) -> int:
        """Add keys to one field's track; returns how many were written.

        ``keyframes`` are ``(time, value)`` pairs or ``{"time", "value",
        "interpolation"}`` mappings. A key at the time of an existing key
        (within 0.1 ms) replaces it; ``replace=True`` drops the track's other
        keys first. A key's ``interpolation`` (``linear``, ``step``,
        ``bezier``) shapes the way from it to the next key: ``step`` holds its
        value until the next key's time. ``interpolation`` here is the default
        for keys that name none; without it numbers are ``linear`` and other
        values ``step``. A key past the clip's duration extends it.
        """
        entity_id, component, field = self._resolve(entity, target)
        self._require_not_bound(entity_id, component, field)
        if interpolation is not None and interpolation not in INTERPOLATIONS:
            raise ValueError(f"interpolation must be one of {INTERPOLATIONS}, got {interpolation!r}")
        parsed = [_key(item) for item in keyframes]
        if not parsed:
            return 0
        values = values_to_storage(component, field, [value for _, value, _ in parsed], up)
        incoming = [{"time": time, "value": value,
                     "interpolation": interp or interpolation or default_interpolation(value)}
                    for (time, _, interp), value in zip(parsed, values)]
        self._put_track(entity_id, component, field, incoming, replace=replace)
        return len(incoming)

    def _put_track(self, entity_id: str, component: str, field: str, incoming: Sequence[Mapping[str, Any]], *,
                   replace: bool) -> None:
        """Merge ``{time, value, interpolation}`` keys in storage units into a track; extend the clip."""
        timeline = self._timeline()
        path = f"{entity_id}/{component}/{field}"
        tracks = timeline["clip"]["tracks"]
        track = tracks.get(path)
        existing = [] if replace or track is None else list(track.get("keyframes") or [])
        tracks[path] = {"path": path, "object_id": entity_id, "component_name": component,
                        "field_name": field, "keyframes": merge_keyframes(existing, incoming)}
        last = max(float(k["time"]) for k in incoming)
        if last > float(timeline["clip"].get("duration") or 0.0):
            timeline["clip"]["duration"] = last

    def keyframes(self, entity: Any, target: str, *, up: Optional[str] = None) -> List[Dict[str, Any]]:
        """A track's keys as ``{"time", "value", "interpolation"}`` in this API's units; [] without a track."""
        entity_id, component, field = self._resolve(entity, target)
        track = self._track(entity_id, component, field)
        return [{"time": float(k["time"]), "value": value_from_storage(component, field, k["value"], up),
                 "interpolation": k.get("interpolation") or "linear"}
                for k in (track or {}).get("keyframes") or []]

    def remove(self, entity: Any, target: Optional[str] = None) -> int:
        """Remove one field's track, or every track of ``entity``; returns how many tracks went."""
        entity_id = getattr(entity, "id", entity)
        tracks = self._tracks()
        if target is None:
            paths = [p for p, t in tracks.items() if t.get("object_id") == entity_id]
        else:
            component, field = split_target(target)
            paths = [p for p in (f"{entity_id}/{component}/{field}",) if p in tracks]
        for path in paths:
            del tracks[path]
        return len(paths)

    def _remove_component(self, entity_id: str, component: str) -> None:
        tracks = self._tracks()
        for path in [p for p, t in tracks.items()
                     if t.get("object_id") == entity_id and t.get("component_name") == component]:
            del tracks[path]

    def clear(self) -> None:
        """Remove every track; the clip settings stay."""
        tracks = self._tracks()
        tracks.clear()

    # -- sampling ---------------------------------------------------------
    def sample(self, time: float) -> Dict[str, Dict[str, Dict[str, Any]]]:
        """Every animated field at ``time``: ``{object_id: {component: {field: value}}}``.

        Values are as stored (Transform.rotation in field radians ``[z, x, y]``):
        the ProjectServer's ``TimelineManager.get_animated_state_at`` shape.
        """
        state: Dict[str, Dict[str, Dict[str, Any]]] = {}
        for track in self._tracks().values():
            value = value_at(track.get("keyframes") or [], float(time))
            if value is not None:
                state.setdefault(str(track.get("object_id")), {}).setdefault(
                    str(track.get("component_name")), {})[str(track.get("field_name"))] = value
        return state

    def value_at(self, entity: Any, target: str, time: float, *, up: Optional[str] = None) -> Any:
        """One field's value at ``time`` in this API's units; None when the field has no keys."""
        entity_id, component, field = self._resolve(entity, target)
        track = self._track(entity_id, component, field)
        value = value_at((track or {}).get("keyframes") or [], float(time))
        return None if value is None else value_from_storage(component, field, value, up)

    def _local(self, entity_id: str, time: float) -> Tuple[List[float], List[float], List[float]]:
        """Local position, rotation field and scale of ``entity_id`` at ``time``."""
        transform = self._scene.objects[entity_id].transform
        values = {"position": list(transform.position), "rotation": transform._euler(),
                  "scale": list(transform.scale)}
        for field in TRANSFORM_FIELDS:
            track = self._track(entity_id, TRANSFORM, field)
            if track and track.get("keyframes"):
                values[field] = [float(v) for v in value_at(track["keyframes"], float(time))]
        return values["position"], values["rotation"], values["scale"]

    def transform_at(self, entity: Any, time: float, *, up: Optional[str] = None) -> Dict[str, List[float]]:
        """Local ``position``, ``rotation`` (degrees) and ``scale`` at ``time``; unanimated fields keep their value."""
        position, rotation, scale = self._local(self._entity_id(entity), time)
        return {"position": points_from_scene([position], up)[0], "rotation": rotation_from_scene(rotation, up),
                "scale": scale_to_scene(scale, up)}

    def world_matrix(self, entity: Any, time: float):
        """4 x 4 numpy world matrix of ``entity`` at ``time`` (Scene frame), parents animated too."""
        objects = self._scene._objects

        def local(entity_id: str):
            if entity_id not in objects:
                return None
            return (*self._local(entity_id, time), objects[entity_id].get("parent_id"))

        return chain_matrix(local, self._entity_id(entity))

    def apply(self, time: float) -> None:
        """Write every animated field's value at ``time`` into the Scene (keys stay).

        Like the Timeline scrubbing to ``time``: afterwards the Scene's
        Transforms and component fields hold the pose at ``time``, so
        ``save()`` stores that pose as the rest values.
        """
        for entity_id, components in self.sample(time).items():
            if entity_id not in self._scene._objects:
                continue
            entity = self._scene.objects[entity_id]
            for component, fields in components.items():
                for field, value in fields.items():
                    if component == TRANSFORM:
                        if field == "rotation":
                            entity.transform._set_euler(value)
                        elif field in ("position", "scale"):
                            setattr(entity.transform, field, value)
                    elif component in entity.components:
                        entity.components[component][field] = value

    # -- motion helpers ---------------------------------------------------
    def follow_path(self, entity: Any, points: Sequence[Sequence[float]], *, speed: Optional[float] = None,
                    duration: Optional[float] = None, start: float = 0.0, closed: bool = False,
                    face: bool = False, forward: str = "+x", turn_time: float = 0.5,
                    up: Optional[str] = None) -> Dict[str, Any]:
        """Move ``entity`` along a polyline at constant speed; optionally turn it to face along the path.

        ``points`` are positions in the parent's frame (the world for a top
        level object), in meters, in the ``up`` frame. Give ``speed`` (m/s)
        or ``duration`` (s). ``face=True`` also keys the rotation so the
        object's local ``forward`` axis (``"+x"``, ``"-x"``, ``"+y"``,
        ``"-y"``, ``"+z"``, ``"-z"`` in the ``up`` frame, not the vertical
        one) points along the path, turning about the vertical axis over
        ``turn_time`` seconds at each corner. Replaces the position (and
        rotation) track. Returns ``{"start", "end", "length", "speed", "keys"}``.
        """
        return self._move(entity, points_to_scene(points, up), speed=speed, duration=duration, start=start,
                          closed=closed, face=face, forward=forward_axis(forward, up), turn_time=turn_time)

    def orbit(self, entity: Any, center: Sequence[float], radius: float, *, speed: Optional[float] = None,
              period: Optional[float] = None, turns: float = 1.0, start: float = 0.0, start_angle: float = 0.0,
              clockwise: bool = False, face: bool = False, forward: str = "+x",
              up: Optional[str] = None) -> Dict[str, Any]:
        """Fly ``entity`` around a horizontal circle at constant speed: ``follow_path`` on a circle.

        ``center`` (its height is the orbit height) and ``radius`` in meters;
        ``period`` is seconds per turn, or give ``speed`` in m/s.
        ``start_angle`` is degrees from +X, counter-clockwise seen from above
        unless ``clockwise``.
        """
        if (speed is None) == (period is None):
            raise ValueError("give exactly one of speed (m/s) or period (s per turn)")
        (scene_center,) = points_to_scene([center], up)
        points = circle_points(scene_center, radius, turns=turns, start_angle=start_angle, clockwise=clockwise)
        duration = None if period is None else float(period) * float(turns)
        return self._move(entity, points, speed=speed, duration=duration, start=start, closed=False, face=face,
                          forward=forward_axis(forward, up), turn_time=0.0)

    # follow_path / orbit on Scene-frame points; replaces the position (and rotation) track.
    def _move(self, entity: Any, points: List[List[float]], *, speed: Optional[float], duration: Optional[float],
              start: float, closed: bool, face: bool, forward: List[float], turn_time: float) -> Dict[str, Any]:
        entity_id = self._entity_id(entity)
        base = self._scene.objects[entity_id].transform._euler()
        position_keys, rotation_keys = motion_keyframes(points, speed=speed, duration=duration, start=start,
                                                        closed=closed, face=face, forward=forward, base=base,
                                                        turn_time=turn_time)
        self._write(entity_id, "position", position_keys, replace=True)
        if rotation_keys:
            self._write(entity_id, "rotation", rotation_keys, replace=True)
        return motion_summary(position_keys, rotation_keys)

    def rotate(self, entity: Any, *, axis: str = "y", rpm: Optional[float] = None,
               degrees_per_second: Optional[float] = None, duration: Optional[float] = None,
               turns: Optional[float] = None, start: float = 0.0, start_angle: float = 0.0,
               up: Optional[str] = None) -> Dict[str, Any]:
        """Spin ``entity`` in place at a constant rate (a radar antenna, a fan).

        Give the rate as ``rpm`` or ``degrees_per_second`` (negative turns the
        other way) and the length as ``duration`` (s) or ``turns``. The angle
        is added to the rest rotation's Euler angle for ``axis``, so a tilt
        about the other axes stays. Replaces the rotation track. Whole turns
        loop without a jump. Returns ``{"start", "end", "degrees"}``.
        """
        if (rpm is None) == (degrees_per_second is None):
            raise ValueError("give exactly one of rpm or degrees_per_second")
        rate = float(rpm) * 6.0 if rpm is not None else float(degrees_per_second)
        if rate == 0:
            raise ValueError("the rotation rate must not be 0")
        if (duration is None) == (turns is None):
            raise ValueError("give exactly one of duration (s) or turns")
        length = float(duration) if duration is not None else abs(float(turns) * 360.0 / rate)
        entity_id = self._entity_id(entity)
        keys = spin_keyframes(self._scene.objects[entity_id].transform._euler(), axis, degrees_per_second=rate,
                              duration=length, start=start, start_angle=start_angle, up=up)
        self._write(entity_id, "rotation", keys, replace=True)
        return {"start": keys[0][0], "end": keys[-1][0], "degrees": rate * length}

    # Keys already in storage units (Scene frame, rotation field) for one Transform field.
    def _write(self, entity_id: str, field: str, keys: Sequence[Tuple[float, List[float]]], *,
               replace: bool) -> None:
        self._require_not_bound(entity_id, TRANSFORM, field)
        self._put_track(entity_id, TRANSFORM, field,
                        [{"time": float(t), "value": [float(v) for v in value], "interpolation": "linear"}
                         for t, value in keys], replace=replace)

    def __repr__(self) -> str:
        return f"Animation(tracks={len(self._tracks())}, duration={self.duration}, loop={self.loop})"


def chain_matrix(local: Any, entity_id: Optional[str]):
    """4 x 4 numpy world matrix: the product of ``local(id)`` matrices up the parent chain.

    ``local(id)`` returns ``(position, rotation field, scale, parent_id)`` or
    None for an unknown id, which ends the chain (as a missing parent does).
    The ProjectServer's Agent Tools pass the live objects' values here, the
    SDK its document's, so both compose a pose the same way.
    """
    import numpy as np

    from ._mesh_entities import _local_matrix

    matrix = np.eye(4)
    seen = set()
    while entity_id and entity_id != "root" and entity_id not in seen:
        seen.add(entity_id)
        found = local(entity_id)
        if found is None:
            break
        position, rotation, scale, parent_id = found
        matrix = _local_matrix(position, _euler_to_quat(rotation), scale) @ matrix
        entity_id = parent_id
    return matrix


def forward_axis(forward: str, up: Optional[str] = None) -> List[float]:
    """A signed axis name (``"+x"``, ``"-z"`` ...) in the ``up`` frame as a Scene-frame vector."""
    text = str(forward).strip().lower()
    if len(text) == 1:
        text = "+" + text
    if len(text) != 2 or text[0] not in "+-" or text[1] not in "xyz":
        raise ValueError(f"forward must be one of +x, -x, +y, -y, +z, -z, got {forward!r}")
    vector = [0.0, 0.0, 0.0]
    vector["xyz".index(text[1])] = 1.0 if text[0] == "+" else -1.0
    return points_to_scene([vector], up)[0]
