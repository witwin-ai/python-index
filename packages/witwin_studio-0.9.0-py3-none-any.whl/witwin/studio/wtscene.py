"""``.wtscene`` file format v2 (TOML) read/write.

This is the one implementation of the scene file format (decision D11).
``witwin_server`` imports it from here, so the editor and user code always
read and write the same bytes.

Translates between a scene document (the dict ``loads`` returns, which is also
the server's ``Scene.to_dict`` / ``Scene.from_dict`` payload) and the on-disk
TOML described in SCENE_DESIGN.md §10. The format borrows Godot's ``.tscn``
structure (§11):

* **Declaration order is the tree** (§14.5). Entities are emitted depth-first
  from the roots; sibling order is the array order, and ``parent`` names the
  parent entity. There is no separate ``children_order`` table.
* **A ``[deps]`` table** declares referenced subscenes once by short alias; a
  ``scene_ref`` entity references one by ``instance`` (§11).
* **Only non-defaults are written** (§10.4): identity transforms, ``parent =
  "root"``, empty component lists, and the default visibility are omitted.
* **scene_ref overrides** are Godot-style diff entries: a top-level
  ``[[override]]`` per changed child carries only the changed fields (§14.4).

Reading uses stdlib ``tomllib`` (fast); writing uses ``tomlkit`` (inline tables
+ arrays-of-tables). Saving rewrites scene files, so comments are not
preserved here — that is an accepted trade (§10.1).
"""
from __future__ import annotations

import logging
import tomllib
from typing import Any, Dict, List

import tomlkit

from .formula import FormulaError, FormulaGraph
from .units import key_to_si

logger = logging.getLogger("witwin.studio")

# 3 adds [[parameter]] rows and per-entity ``fields`` (Formula Graph).
FORMAT = 3
# Oldest FORMAT ``loads`` accepts; older files raise ``SceneFormatError`` and
# are never migrated. 2 is still read because FORMAT 3 only added optional
# tables, so a FORMAT 2 file is a valid FORMAT 3 document without them, and the
# shipped Home Simulation starter (wt_home_simulation) is still FORMAT 2.
# Raise this to 3 once that template is rewritten.
OLDEST_FORMAT = 2

# How Studio stages a Scene: "world" (sky, sun, ground; metre-scale scenes) or
# "bench" (neutral backdrop and headlight, shown magnified; parts and fields at
# micro- to millimetre scale). The header key is optional and written only for
# "bench", so it needs no FORMAT bump and older files read as "world".
STAGES = ("world", "bench")
DEFAULT_STAGE = "world"


class SceneFormatError(ValueError):
    """A ``.wtscene`` whose ``format`` this version does not read."""


def _checked_format(raw: Dict[str, Any]) -> int:
    """The header ``format`` as an int, or ``SceneFormatError`` when it is unreadable."""
    value = raw.get("format")
    if value is None:
        raise SceneFormatError("scene file has no 'format' key; it was not written by WiTwin Studio")
    if isinstance(value, bool) or not isinstance(value, int):
        raise SceneFormatError(f"scene file format {value!r} is not an integer")
    if value < OLDEST_FORMAT or value > FORMAT:
        raise SceneFormatError(
            f"scene file format {value} is not supported; this version reads formats "
            f"{OLDEST_FORMAT} to {FORMAT} and does not convert older files"
        )
    return value


def scene_stage(value: Any) -> str:
    """A header ``stage`` value as one of ``STAGES``; anything else is the default."""
    return value if value in STAGES else DEFAULT_STAGE


# Vector length of a Transform field's ``fields`` expr array. Rotation is bound
# per Euler component (what the Properties panel shows), not per quaternion one.
TRANSFORM_FIELD_SIZE = 3

# Keys of a [[parameter]] row, in write order. Ranges live in Studies
# (``studies/<id>.toml``), not on parameters; other keys are dropped.
_PARAMETER_KEYS = ("id", "name", "expr", "description")

# Identity transform components used to decide what to omit (§10.4 lever 2).
_IDENTITY_POS = [0.0, 0.0, 0.0]
_IDENTITY_ROT = [0.0, 0.0, 0.0, 1.0]
_IDENTITY_SCL = [1.0, 1.0, 1.0]

_SCENE_DEP_PREFIX = "scene:"
_SCENE_REF_COMPONENT = "SceneReference"
_SCENE_REF_TYPE = "builtin.scene_ref"


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #
def _approx(a: List[float], b: List[float]) -> bool:
    if a is None or len(a) != len(b):
        return False
    return all(abs(float(x) - float(y)) < 1e-9 for x, y in zip(a, b))


def _is_identity_transform(t: Dict[str, Any]) -> bool:
    if not t:
        return True
    if t.get("freeze_position") or t.get("freeze_rotation") or t.get("freeze_scale"):
        return False
    return (
        _approx(t.get("position"), _IDENTITY_POS)
        and _approx(t.get("rotation"), _IDENTITY_ROT)
        and _approx(t.get("scale"), _IDENTITY_SCL)
    )


def _drop_none(value: Any) -> Any:
    """Recursively strip ``None`` (TOML has no null). Returns ``None`` if the
    whole value is ``None`` so the caller can omit the key entirely."""
    if value is None:
        return None
    if isinstance(value, dict):
        cleaned = {}
        for k, v in value.items():
            cv = _drop_none(v)
            if cv is not None:
                cleaned[k] = cv
        return cleaned
    if isinstance(value, (list, tuple)):
        return [_drop_none(x) for x in value if x is not None]
    return value


def _flatten_component(comp: Dict[str, Any]) -> Dict[str, Any]:
    """``{"type": X, "properties": {...}}`` -> ``{"type": X, ...props}`` (§10.4).

    ``None`` values are dropped (TOML has no null); an absent key falls back to
    the component's field default on load.
    """
    flat: Dict[str, Any] = {"type": comp.get("type")}
    for k, v in (comp.get("properties") or {}).items():
        cv = _drop_none(v)
        if cv is not None:
            flat[k] = cv
    return flat


def _unflatten_component(flat: Dict[str, Any]) -> Dict[str, Any]:
    """Inverse of :func:`_flatten_component`."""
    props = {k: v for k, v in flat.items() if k != "type"}
    return {"type": flat.get("type"), "properties": props}


def _transform_to_toml(t: Dict[str, Any]) -> "tomlkit.items.InlineTable":
    it = tomlkit.inline_table()
    it["pos"] = [float(x) for x in t.get("position", _IDENTITY_POS)]
    it["rot"] = [float(x) for x in t.get("rotation", _IDENTITY_ROT)]
    if t.get("rotation_euler") is not None:
        it["eul"] = [float(x) for x in t["rotation_euler"][:3]]
    it["scl"] = [float(x) for x in t.get("scale", _IDENTITY_SCL)]
    if t.get("freeze_position"):
        it["freeze_position"] = True
    if t.get("freeze_rotation"):
        it["freeze_rotation"] = True
    if t.get("freeze_scale"):
        it["freeze_scale"] = True
    return it


def _transform_from_toml(t: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "position": list(t.get("pos", _IDENTITY_POS)),
        "rotation": list(t.get("rot", _IDENTITY_ROT)),
        "scale": list(t.get("scl", _IDENTITY_SCL)),
    }
    if t.get("eul") is not None:
        out["rotation_euler"] = list(t["eul"][:3])
    if t.get("freeze_position"):
        out["freeze_position"] = True
    if t.get("freeze_rotation"):
        out["freeze_rotation"] = True
    if t.get("freeze_scale"):
        out["freeze_scale"] = True
    return out


def _timeline_to_toml(timeline: Dict[str, Any]):
    if not timeline:
        return None

    tbl = tomlkit.table()
    if "current_time" in timeline:
        tbl["current_time"] = float(timeline.get("current_time") or 0.0)
    if "is_looping" in timeline:
        tbl["is_looping"] = bool(timeline.get("is_looping"))

    clip = timeline.get("clip") or {}
    clip_tbl = tomlkit.table()
    if clip.get("name"):
        clip_tbl["name"] = clip["name"]
    if "duration" in clip:
        clip_tbl["duration"] = float(clip.get("duration") or 0.0)
    if "fps" in clip:
        clip_tbl["fps"] = float(clip.get("fps") or 0.0)

    tracks = clip.get("tracks") or {}
    track_aot = tomlkit.aot()
    for path, track in tracks.items():
        track_tbl = tomlkit.table()
        track_tbl["path"] = track.get("path") or path
        track_tbl["object_id"] = track.get("object_id", "")
        track_tbl["component_name"] = track.get("component_name", "")
        track_tbl["field_name"] = track.get("field_name", "")
        keyframe_aot = tomlkit.aot()
        for keyframe in track.get("keyframes") or []:
            kf_tbl = tomlkit.table()
            for key, value in _drop_none(keyframe).items():
                kf_tbl[key] = value
            keyframe_aot.append(kf_tbl)
        track_tbl["keyframes"] = keyframe_aot
        track_aot.append(track_tbl)
    if len(track_aot) > 0:
        clip_tbl["track"] = track_aot

    tbl["clip"] = clip_tbl
    return tbl


def _timeline_from_toml(raw: Dict[str, Any]) -> Dict[str, Any]:
    clip_raw = raw.get("clip") or {}
    tracks: Dict[str, Any] = {}
    for track_raw in clip_raw.get("track") or []:
        track = dict(track_raw)
        path = str(track.pop("path", "")) or (
            f"{track.get('object_id', '')}/"
            f"{track.get('component_name', '')}/"
            f"{track.get('field_name', '')}"
        )
        tracks[path] = {
            "path": path,
            "object_id": track.get("object_id", ""),
            "component_name": track.get("component_name", ""),
            "field_name": track.get("field_name", ""),
            "keyframes": [dict(kf) for kf in track.get("keyframes") or []],
        }

    timeline = {
        "clip": {
            "name": clip_raw.get("name", "Timeline"),
            "duration": clip_raw.get("duration", 10.0),
            "fps": clip_raw.get("fps", 30.0),
            "tracks": tracks,
        },
        "current_time": raw.get("current_time", 0.0),
        "is_looping": bool(raw.get("is_looping", False)),
    }
    return timeline


def _component_inline(flat: Dict[str, Any]) -> "tomlkit.items.InlineTable":
    it = tomlkit.inline_table()
    for k, v in flat.items():
        it[k] = v
    return it


def _pick(row: Dict[str, Any], keys: tuple) -> Dict[str, Any]:
    """The listed keys of a row that are present and not ``None``, in ``keys`` order."""
    return {k: row[k] for k in keys if row.get(k) is not None}


def _parameters_to_toml(rows: List[Dict[str, Any]]):
    """``[[parameter]]`` rows (Formula Graph records); ``None`` when there are none.

    ``design = false`` is the default and is not written, so files without
    design variables keep the plain four keys.
    """
    if not rows:
        return None
    aot = tomlkit.aot()
    for row in rows:
        tbl = tomlkit.table()
        for key, value in _pick(row, _PARAMETER_KEYS).items():
            tbl[key] = value
        aot.append(tbl)
    return aot


# A TOML value with every dict as an inline table, nested ones included.
def _inline_value(value: Any) -> Any:
    if not isinstance(value, dict):
        return value
    it = tomlkit.inline_table()
    for key, item in value.items():
        it[key] = _inline_value(item)
    return it


def _field_entry(entry: Dict[str, Any]) -> Dict[str, Any]:
    """One ``fields`` entry: ``target``, optional ``unit``, optional ``expr``.

    ``expr`` is a string for a scalar field and a list (one slot per vector
    component, ``""`` = not bound) for a vector field.
    """
    out = _pick(entry, ("target", "unit", "expr"))
    if isinstance(out.get("expr"), (list, tuple)):
        out["expr"] = [str(x) for x in out["expr"]]
    return out


# --------------------------------------------------------------------------- #
# Ordering: derive declaration (DFS) order from objects + children_order
# --------------------------------------------------------------------------- #
def _dfs_order(objects: Dict[str, Any], children_order: Dict[str, List[str]]) -> List[str]:
    """Return entity ids in depth-first declaration order (§14.5)."""
    by_parent: Dict[str, List[str]] = {}
    for oid, od in objects.items():
        parent = od.get("parent_id") or "root"
        by_parent.setdefault(parent, []).append(oid)

    def ordered(parent: str) -> List[str]:
        kids = by_parent.get(parent, [])
        pref = children_order.get(parent, [])
        seen: set = set()
        result: List[str] = []
        for k in pref:
            if k in kids and k not in seen:
                result.append(k)
                seen.add(k)
        for k in kids:
            if k not in seen:
                result.append(k)
                seen.add(k)
        return result

    result: List[str] = []

    def visit(parent: str) -> None:
        for child in ordered(parent):
            result.append(child)
            visit(child)

    visit("root")
    # Defensive: include any orphan whose parent is missing, so nothing is lost.
    for oid in objects:
        if oid not in result:
            result.append(oid)
    return result


# --------------------------------------------------------------------------- #
# Serialize: scene document -> TOML text
# --------------------------------------------------------------------------- #
def dumps(data: Dict[str, Any]) -> str:
    """Serialize a scene document (``Scene.to_dict()`` payload) to ``.wtscene`` TOML text."""
    doc = tomlkit.document()
    doc["format"] = FORMAT
    doc["id"] = data.get("scene_id", "scene")
    name = data.get("name")
    if name and name != data.get("scene_id"):
        doc["name"] = name
    doc["role"] = data.get("role", "normal")
    if scene_stage(data.get("stage")) != DEFAULT_STAGE:
        doc["stage"] = scene_stage(data.get("stage"))
    caps = data.get("capabilities") or []
    if caps:
        doc["capabilities"] = list(caps)

    deps = data.get("deps") or {}
    if deps:
        deps_tbl = tomlkit.table()
        for alias, target in deps.items():
            deps_tbl[alias] = f"{_SCENE_DEP_PREFIX}{target}"
        doc["deps"] = deps_tbl

    timeline_tbl = _timeline_to_toml(data.get("timeline") or {})
    if timeline_tbl is not None:
        doc["timeline"] = timeline_tbl

    parameter_aot = _parameters_to_toml(data.get("parameters") or [])
    if parameter_aot is not None:
        doc["parameter"] = parameter_aot


    objects = data.get("objects", {})
    children_order = data.get("children_order", {}) or {}
    order = _dfs_order(objects, children_order)

    entity_aot = tomlkit.aot()
    overrides_out: List[Dict[str, Any]] = []

    for oid in order:
        od = objects.get(oid)
        if od is None:
            continue
        ent = tomlkit.table()
        ent["id"] = oid
        ent_name = od.get("name")
        if ent_name and ent_name != oid:
            ent["name"] = ent_name
        parent = od.get("parent_id") or "root"
        if parent != "root":
            ent["parent"] = parent
        etype = od.get("entity_type")
        if etype:
            ent["type"] = etype

        is_scene_ref = etype == _SCENE_REF_TYPE
        components = od.get("components") or []

        if is_scene_ref:
            # Lift the SceneReference component to header fields + overrides.
            ref_props: Dict[str, Any] = {}
            remaining = []
            for comp in components:
                if comp.get("type") == _SCENE_REF_COMPONENT:
                    ref_props = comp.get("properties") or {}
                else:
                    remaining.append(comp)
            components = remaining
            ent["instance"] = ref_props.get("instance", "")
            if ref_props.get("editable"):
                ent["editable"] = True
            for ov in ref_props.get("overrides") or []:
                overrides_out.append({"ref": oid, **ov})

        if od.get("is_active") is False:
            ent["visible"] = False
        if od.get("tag"):
            ent["tag"] = od["tag"]
        if od.get("locked"):
            ent["locked"] = True
        if od.get("mesh_path"):
            ent["mesh_path"] = od["mesh_path"]

        transform = od.get("transform") or {}
        if not _is_identity_transform(transform):
            ent["transform"] = _transform_to_toml(transform)

        if components:
            arr = tomlkit.array()
            arr.multiline(len(components) > 1)
            for comp in components:
                arr.append(_component_inline(_flatten_component(comp)))
            ent["components"] = arr

        fields = od.get("fields") or []
        if fields:
            arr = tomlkit.array()
            arr.multiline(len(fields) > 1)
            for entry in fields:
                arr.append(_component_inline(_field_entry(entry)))
            ent["fields"] = arr

        entity_aot.append(ent)

    doc["entity"] = entity_aot

    if overrides_out:
        ov_aot = tomlkit.aot()
        for ov in overrides_out:
            t = tomlkit.table()
            t["ref"] = ov["ref"]
            t["target"] = ov.get("target", "")
            if ov.get("removed"):
                t["removed"] = True
            if "visible" in ov:
                t["visible"] = bool(ov["visible"])
            if ov.get("transform"):
                t["transform"] = _transform_to_toml(ov["transform"])
            comps = ov.get("components")
            if comps:
                arr = tomlkit.array()
                arr.multiline(len(comps) > 1)
                for comp in comps:
                    arr.append(_component_inline(_flatten_component(comp)))
                t["components"] = arr
            ov_aot.append(t)
        doc["override"] = ov_aot

    text = tomlkit.dumps(doc)
    # SCENE_DESIGN.md §10.3: enforce LF (no CR), UTF-8 written by the caller.
    return text.replace("\r\n", "\n").replace("\r", "\n")


# --------------------------------------------------------------------------- #
# Parse: TOML text -> scene document
# --------------------------------------------------------------------------- #
def loads(text: str) -> Dict[str, Any]:
    """Parse ``.wtscene`` TOML text into a scene document (``Scene.from_dict()`` payload).

    Raises ``SceneFormatError`` when the header ``format`` is missing or outside
    ``OLDEST_FORMAT`` .. ``FORMAT``.
    """
    raw = tomllib.loads(text)
    format_version = _checked_format(raw)

    scene_id = raw.get("id") or "scene"
    result: Dict[str, Any] = {
        "format_version": format_version,
        "scene_id": scene_id,
        "name": raw.get("name", scene_id),
        "role": raw.get("role", "normal"),
        "stage": scene_stage(raw.get("stage")),
        "capabilities": list(raw.get("capabilities") or []),
        "deps": {},
        "objects": {},
        "children_order": {},
    }

    for alias, value in (raw.get("deps") or {}).items():
        target = value
        if isinstance(value, str) and value.startswith(_SCENE_DEP_PREFIX):
            target = value[len(_SCENE_DEP_PREFIX):]
        result["deps"][alias] = target

    result["parameters"] = [_pick(row, _PARAMETER_KEYS) for row in raw.get("parameter") or []]

    if raw.get("timeline"):
        result["timeline"] = _timeline_from_toml(raw["timeline"])

    # Group overrides by the scene_ref instance they apply to.
    overrides_by_ref: Dict[str, List[Dict[str, Any]]] = {}
    for ov in raw.get("override") or []:
        ref = ov.get("ref")
        if not ref:
            continue
        entry: Dict[str, Any] = {"target": ov.get("target", "")}
        if ov.get("removed"):
            entry["removed"] = True
        if "visible" in ov:
            entry["visible"] = bool(ov["visible"])
        if ov.get("transform"):
            entry["transform"] = _transform_from_toml(ov["transform"])
        if ov.get("components"):
            entry["components"] = [_unflatten_component(c) for c in ov["components"]]
        overrides_by_ref.setdefault(ref, []).append(entry)

    objects = result["objects"]
    children_order = result["children_order"]

    for ent in raw.get("entity") or []:
        oid = ent.get("id")
        if not oid:
            continue
        parent = ent.get("parent", "root")
        etype = ent.get("type")
        components = [_unflatten_component(c) for c in (ent.get("components") or [])]

        if etype == _SCENE_REF_TYPE:
            ref_props: Dict[str, Any] = {
                "instance": ent.get("instance", ""),
                "editable": bool(ent.get("editable", False)),
            }
            if oid in overrides_by_ref:
                ref_props["overrides"] = overrides_by_ref[oid]
            components.append({"type": _SCENE_REF_COMPONENT, "properties": ref_props})

        transform = (
            _transform_from_toml(ent["transform"]) if ent.get("transform") else {}
        )

        objects[oid] = {
            "name": ent.get("name", oid),
            "parent_id": parent,
            "is_active": ent.get("visible", True),
            "tag": ent.get("tag"),
            "locked": ent.get("locked", False),
            "entity_type": etype,
            "transform": transform,
            "components": components,
        }
        if ent.get("mesh_path"):
            objects[oid]["mesh_path"] = ent["mesh_path"]
        if ent.get("fields"):
            objects[oid]["fields"] = [_field_entry(e) for e in ent["fields"]]

        children_order.setdefault(parent, []).append(oid)

    return result


# --------------------------------------------------------------------------- #
# Formula Graph records in a scene document
# --------------------------------------------------------------------------- #
def load_formulas(data: Dict[str, Any]) -> FormulaGraph:
    """Build the Formula Graph of a scene document and evaluate it once.

    The records are the document's top-level ``parameters`` and each object's
    ``fields`` (parameters-expressions-plan.md §3.1). Broken formulas load as
    node errors (the graph's rule). A ``fields`` entry without a string
    ``target`` cannot be attached to anything; it is dropped with a warning
    instead of failing the whole scene. A malformed ``[[parameter]]`` row
    drops every record, also with a warning, so the scene still opens.
    Component values in the document are already the evaluated numbers, so
    nothing is written back here. Units are converted with ``units.key_to_si``.
    """
    fields: Dict[str, List[Dict[str, Any]]] = {}
    for obj_id, odict in (data.get("objects") or {}).items():
        entries = []
        for entry in odict.get("fields") or []:
            if isinstance(entry, dict) and isinstance(entry.get("target"), str):
                entries.append(entry)
            else:
                logger.warning("scene %s: dropped malformed field entry on '%s': %r",
                               data.get("scene_id"), obj_id, entry)
        if entries:
            fields[obj_id] = entries
    try:
        graph = FormulaGraph.from_records(data.get("parameters") or [], fields, to_si=key_to_si)
    except (FormulaError, TypeError, ValueError) as exc:
        logger.warning("scene %s: formula records not loaded: %s", data.get("scene_id"), exc)
        graph = FormulaGraph(key_to_si)
    graph.recompute()
    return graph


def store_formulas(data: Dict[str, Any], graph: FormulaGraph) -> None:
    """Write the graph's records into a scene document, in place.

    Sets the top-level ``parameters`` list and every object's ``fields`` list;
    objects without side-metadata lose their ``fields`` key. Records of
    entities that are not in ``data["objects"]`` (deleted, runtime-only) are
    left out. Vector ``expr`` arrays are padded to the field length, one slot
    per component.
    """
    records = graph.to_records()
    data["parameters"] = records.parameters
    for obj_id, odict in (data.get("objects") or {}).items():
        entries = records.fields.get(obj_id)
        if entries:
            odict["fields"] = [_padded_field_entry(odict, entry) for entry in entries]
        else:
            odict.pop("fields", None)


def _padded_field_entry(odict: Dict[str, Any], entry: Dict[str, Any]) -> Dict[str, Any]:
    """Pad a vector ``expr`` array to the field's length.

    The graph writes the shortest array that holds its bindings
    (``["", "w"]`` for index 1 of a 3-vector); the file states every component.
    A field the object does not have keeps the graph's length.
    """
    expr = entry.get("expr")
    if not isinstance(expr, list):
        return entry
    component, _, field = str(entry.get("target", "")).partition(".")
    size = TRANSFORM_FIELD_SIZE if component == "Transform" else 0
    for comp in odict.get("components") or []:
        if comp.get("type") == component:
            value = (comp.get("properties") or {}).get(field)
            size = len(value) if isinstance(value, (list, tuple)) else 0
    if len(expr) >= size:
        return entry
    return {**entry, "expr": list(expr) + [""] * (size - len(expr))}
