"""Result views (``witwin.view.v1``): what a Result shows in Studio's Result View.

A view is data plus a kind; Studio draws it. Plugins and scripts never write
UI code for a plot. Design: ``dev_docs/frontend/results-visualization-panel.md``.

    from witwin.studio import views as wv

    s11 = wv.line("S11", x=freq_ghz, series=[wv.series(s11_db, label="S11")],
                  x_label="Frequency", x_unit="GHz", y_label="|S11|", y_unit="dB")
    rd = wv.heatmap("Range-Doppler", rd_db, x=range_m, y=(-v_max, v_max),
                    frames=times_s, frame_unit="s", timeline=True)
    project.results.record("Radar sweep", views=[s11, rd])

The builders keep numpy arrays as they are. ``pack`` (called by
``ResultStore.record`` and the server's ``ResultsHandler.commit_views``) moves
every array longer than ``INLINE_LIMIT`` into one ``.npz`` under
``.witwin/results/blobs/`` and leaves ``{"array": {path, key, shape, dtype}}``
in its place, so a record stays a few hundred bytes and Studio reads the data
through ``GET /project/array/window``.

numpy is imported only when an array is packed: building views from plain
lists, and importing this module, stay light (``tests/test_import_weight.py``).
"""
from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Union

FORMAT = "witwin.view.v1"
KINDS = ("line", "heatmap")
# Arrays with at most this many elements stay inline as JSON lists: axis
# ranges and short curves are cheaper inline than as an extra HTTP read.
INLINE_LIMIT = 256

ArrayLike = Any

__all__ = ["FORMAT", "INLINE_LIMIT", "KINDS", "heatmap", "line", "pack", "series"]


def _axis(label: Optional[str], unit: Optional[str], values: Optional[ArrayLike] = None,
          scale: Optional[str] = None) -> Optional[Dict[str, Any]]:
    axis: Dict[str, Any] = {}
    if label:
        axis["label"] = label
    if unit:
        axis["unit"] = unit
    if scale and scale != "linear":
        axis["scale"] = scale
    if values is not None:
        axis["values"] = values
    return axis or None


def _frames(values: Optional[ArrayLike], label: Optional[str], unit: Optional[str],
            timeline: bool) -> Optional[Dict[str, Any]]:
    if values is None:
        return None
    frames: Dict[str, Any] = {"axis": 0, "values": values}
    if label:
        frames["label"] = label
    if unit:
        frames["unit"] = unit
    if timeline:
        frames["timeline"] = True
    return frames


def _base(kind: str, title: str, id: Optional[str], owner: Optional[Mapping[str, Any]],
          summary: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    view: Dict[str, Any] = {"id": id or f"{kind}_{uuid.uuid4().hex[:6]}", "kind": kind, "title": title}
    if owner:
        view["owner"] = dict(owner)
    if summary:
        view["summary"] = dict(summary)
    return view


def series(values: ArrayLike, *, label: Optional[str] = None) -> Dict[str, Any]:
    """One curve of a line view: ``(N,)``, or ``(F, N)`` when the view has frames."""
    entry: Dict[str, Any] = {"values": values}
    if label:
        entry["label"] = label
    return entry


def line(
    title: str,
    *,
    x: ArrayLike,
    series: Sequence[Mapping[str, Any]],
    x_label: Optional[str] = None,
    x_unit: Optional[str] = None,
    x_scale: str = "linear",
    y_label: Optional[str] = None,
    y_unit: Optional[str] = None,
    y_scale: str = "linear",
    frames: Optional[ArrayLike] = None,
    frame_label: Optional[str] = None,
    frame_unit: Optional[str] = None,
    timeline: bool = False,
    id: Optional[str] = None,
    owner: Optional[Mapping[str, Any]] = None,
    summary: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    """A line view: curves over one shared ``x``.

    ``frames`` gives one coordinate per frame (axis 0 of every series);
    ``timeline=True`` with ``frame_unit="s"`` makes Studio follow the Timeline.
    ``owner`` is ``{"object_id": ..., "component_name": ...}`` of the object
    that produced it, so selecting that object brings the view forward.
    """
    view = _base("line", title, id, owner, summary)
    view["x"] = _axis(x_label, x_unit, x, x_scale)
    y_axis = _axis(y_label, y_unit, None, y_scale)
    if y_axis:
        view["y"] = y_axis
    view["series"] = [dict(entry) for entry in series]
    frame_axis = _frames(frames, frame_label, frame_unit, timeline)
    if frame_axis:
        view["frames"] = frame_axis
    return view


def heatmap(
    title: str,
    values: ArrayLike,
    *,
    x: Optional[ArrayLike] = None,
    y: Optional[ArrayLike] = None,
    x_label: Optional[str] = None,
    x_unit: Optional[str] = None,
    y_label: Optional[str] = None,
    y_unit: Optional[str] = None,
    value_label: Optional[str] = None,
    value_unit: Optional[str] = None,
    colormap: Optional[str] = None,
    range: Optional[Tuple[float, float]] = None,
    frames: Optional[ArrayLike] = None,
    frame_label: Optional[str] = None,
    frame_unit: Optional[str] = None,
    timeline: bool = False,
    id: Optional[str] = None,
    owner: Optional[Mapping[str, Any]] = None,
    summary: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    """A heatmap view of ``values`` shaped ``(H, W)``, or ``(F, H, W)`` with ``frames``.

    ``x`` / ``y`` are per-column / per-row coordinates, or just ``(min, max)``.
    Rows run along ``y``, columns along ``x``. ``range`` fixes the colour scale.
    """
    view = _base("heatmap", title, id, owner, summary)
    view["values"] = values
    for key, axis in (("x", _axis(x_label, x_unit, _pair_or_array(x))),
                      ("y", _axis(y_label, y_unit, _pair_or_array(y))),
                      ("value", _axis(value_label, value_unit))):
        if axis:
            view[key] = axis
    if colormap:
        view["colormap"] = colormap
    if range is not None:
        view["range"] = {"min": float(range[0]), "max": float(range[1])}
    frame_axis = _frames(frames, frame_label, frame_unit, timeline)
    if frame_axis:
        view["frames"] = frame_axis
    return view


def _pair_or_array(value: Optional[ArrayLike]) -> Optional[ArrayLike]:
    if isinstance(value, tuple):
        return [float(value[0]), float(value[1])]
    return value


# --------------------------------------------------------------------------- #
# Packing arrays into a blob
# --------------------------------------------------------------------------- #
BLOBS_PARTS = (".witwin", "results", "blobs")


def _is_array(value: Any) -> bool:
    # Duck-typed so plain lists never import numpy; torch tensors and other
    # array-likes with ``__array__`` count too.
    return hasattr(value, "__array__") and not isinstance(value, (str, bytes, dict))


def _tolist(array: Any) -> List[Any]:
    data = array.tolist()
    return data if isinstance(data, list) else [data]


def pack(views: Sequence[Mapping[str, Any]], project_root: Union[str, Path],
         *, inline_limit: int = INLINE_LIMIT) -> List[Dict[str, Any]]:
    """Return JSON-safe copies of ``views``, writing their large arrays to one blob.

    Arrays with more than ``inline_limit`` elements go into
    ``<project>/.witwin/results/blobs/<id>.npz`` (one file per call) and are
    replaced by ``{"array": {"path", "key", "shape", "dtype"}}``, ``path``
    relative to the Project root. Complex arrays keep their dtype; Studio shows
    the magnitude. Nothing is written when every array is small.
    """
    root = Path(project_root)
    arrays: Dict[str, Any] = {}
    blob_name = f"{uuid.uuid4().hex[:16]}.npz"
    rel_path = "/".join(BLOBS_PARTS + (blob_name,))

    def convert(value: Any, key_hint: str) -> Any:
        if isinstance(value, Mapping):
            return {k: convert(v, f"{key_hint}.{k}") for k, v in value.items()}
        if isinstance(value, (list, tuple)) and not _is_array(value):
            return [convert(v, f"{key_hint}.{i}") for i, v in enumerate(value)]
        if not _is_array(value):
            return value
        import numpy as np

        array = np.asarray(value)
        if array.dtype.kind not in "biufc":
            raise TypeError(f"view array {key_hint} has dtype {array.dtype}; use numbers")
        if array.dtype == np.float64 and array.size > inline_limit:
            # float32 halves the blob; views are for looking at, not for re-solving.
            array = array.astype(np.float32)
        if array.size <= inline_limit:
            if array.dtype.kind == "c":
                array = np.abs(array)
            return _tolist(array)
        key = f"a{len(arrays)}"
        arrays[key] = np.ascontiguousarray(array)
        return {"array": {"path": rel_path, "key": key,
                          "shape": [int(n) for n in array.shape], "dtype": str(array.dtype)}}

    packed = []
    for index, view in enumerate(views):
        kind = view.get("kind")
        if kind not in KINDS:
            raise ValueError(f"view {index} has kind {kind!r}; expected one of {KINDS}")
        packed.append(convert(dict(view), str(view.get("id") or index)))
    if arrays:
        import numpy as np

        blob = root.joinpath(*BLOBS_PARTS, blob_name)
        blob.parent.mkdir(parents=True, exist_ok=True)
        np.savez(blob, **arrays)
    return packed
