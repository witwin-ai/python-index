"""Keep a Project's lock in step with the WiTwin cloud platform.

A cloud machine (Fleet) carries a Project base environment with the platform
packages already installed: torch with its CUDA libraries, the ``witwin``
solvers, drjit, mitsuba, cupy. At boot it runs ``uv sync --locked --inexact``
over that environment. uv keeps an installed package only when the locked
version is the same string, so a Project whose ``uv.lock`` holds the
platform's versions installs only what it adds; any other version is a
download of up to several GB (CLOUD_MACHINE_ENVIRONMENT_PLAN.md section 3.2).

This module writes those versions into ``pyproject.toml`` as uv constraints,
limited to Linux x86_64 by a marker, so locking on Windows or macOS still
chooses freely for those platforms. It also lists the locked packages that
differ from the platform, for ``witwin platform`` and for the machine's boot
report. ``_platform_pins.py`` holds the versions; it is generated from the
image's lock and changes with each image release.
"""
from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import tomlkit
from tomlkit.items import AoT, Table

from ._platform_pins import CONSTRAINED, INSTALLED, MARKER, PYTHON

PYPROJECT = "pyproject.toml"
LOCK_FILE = "uv.lock"


def _normalize(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name.strip()).lower()


def _requirement_name(requirement: str) -> Optional[str]:
    match = re.match(r"\s*([A-Za-z0-9][A-Za-z0-9._-]*)", requirement or "")
    return _normalize(match.group(1)) if match else None


def constraints() -> List[str]:
    """The uv constraint lines for the cloud platform, one per top-level package."""
    return [f"{name}=={INSTALLED[name]}; {MARKER}" for name in CONSTRAINED]


def _is_platform_constraint(line: str) -> bool:
    return _requirement_name(line) in CONSTRAINED and MARKER in line


def write_constraints(doc: tomlkit.TOMLDocument) -> bool:
    """Set the platform lines in ``[tool.uv].constraint-dependencies``; True if changed.

    Earlier platform lines (same names, same marker) are replaced; constraints
    the user wrote are kept, and a user constraint on a platform package wins
    over ours, so that package gets no platform line.
    """
    tool = doc.get("tool")
    if tool is None:
        tool = tomlkit.table(is_super_table=True)
        doc["tool"] = tool
    uv = tool.get("uv")
    if uv is None:
        uv = tomlkit.table()
        tool["uv"] = uv
    current = [str(item) for item in uv.get("constraint-dependencies") or []]
    kept = [line for line in current if not _is_platform_constraint(line)]
    user_names = {_requirement_name(line) for line in kept}
    wanted = kept + [line for line in constraints() if _requirement_name(line) not in user_names]
    if wanted == current:
        return False
    array = tomlkit.array()
    array.multiline(True)
    for line in wanted:
        array.append(line)
    # tomlkit writes a comment added to a table that already holds sub-tables
    # (``[tool.uv.sources]``) after those sub-tables, far from the key; skip it there.
    has_subtables = any(isinstance(value, (Table, AoT)) for value in uv.values())
    if "constraint-dependencies" not in uv and not has_subtables:
        uv.add(tomlkit.comment(
            "WiTwin cloud machines have these versions installed; a lock that keeps "
            "them makes `uv sync` there download only what this Project adds."
        ))
    uv["constraint-dependencies"] = array
    return True


def apply_to_project(root: Path | str) -> bool:
    """Write the platform constraints into ``<root>/pyproject.toml``; True if it changed."""
    path = Path(root) / PYPROJECT
    doc = tomlkit.parse(path.read_text(encoding="utf-8"))
    if not write_constraints(doc):
        return False
    path.write_text(tomlkit.dumps(doc), encoding="utf-8", newline="\n")
    return True


def has_constraints(root: Path | str) -> bool:
    path = Path(root) / PYPROJECT
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    lines = ((data.get("tool") or {}).get("uv") or {}).get("constraint-dependencies") or []
    present = {_requirement_name(line) for line in lines if MARKER in str(line)}
    return set(CONSTRAINED) <= present


# The large packages: CUDA libraries, torch, the solvers. A Project that locks
# another version of one of these downloads hundreds of MB to several GB at
# boot. Any other platform package (numpy, pillow) is a small download.
_LARGE = re.compile(
    r"^(torch|triton|nvidia-.*|cuda-.*|cupy-.*|cutensor-.*|drjit|mitsuba|slangtorch"
    r"|nvmath-python|rayd-.*|witwin|witwin-.*)$"
)


def is_large(name: str) -> bool:
    return bool(_LARGE.match(_normalize(name)))


@dataclass(frozen=True)
class Mismatch:
    """A locked package whose version differs from the platform's."""

    name: str
    locked: str
    platform: str
    large: bool = False


def lock_mismatches(lock_text: str) -> List[Mismatch]:
    """Platform packages ``uv.lock`` pins to other versions than the image has.

    A universal lock may hold several versions of one package (one per
    platform fork); the package matches when any of them is the platform's,
    because that is the one the Linux fork can choose.
    """
    data = tomllib.loads(lock_text)
    locked: Dict[str, List[str]] = {}
    for package in data.get("package") or []:
        name = _normalize(str(package.get("name") or ""))
        if name in INSTALLED and package.get("version"):
            locked.setdefault(name, []).append(str(package["version"]))
    return [
        Mismatch(name, ", ".join(sorted(versions)), INSTALLED[name], is_large(name))
        for name, versions in sorted(locked.items())
        if INSTALLED[name] not in versions
    ]


def project_mismatches(root: Path | str) -> Optional[List[Mismatch]]:
    """``lock_mismatches`` for ``<root>/uv.lock``; None when there is no lock."""
    path = Path(root) / LOCK_FILE
    if not path.is_file():
        return None
    return lock_mismatches(path.read_text(encoding="utf-8"))


def platform_python() -> str:
    """The cloud machines' Python version (major.minor)."""
    return PYTHON


# ``witwin.toml`` ``[cloud] image``: which machine image a Project's cloud
# machines boot (plan section 3.6). "devel" adds nvcc and a C++ compiler for
# Projects that build CUDA extensions at run time; it is larger and slower to
# start, so only a Project that declares it gets it. The key name awaits the
# witwin.toml format owner's confirmation.
CLOUD_IMAGES = ("runtime", "devel")


def cloud_image(witwin_toml_text: str) -> str:
    """The image flavor a ``witwin.toml`` asks for; "runtime" when absent or unknown."""
    try:
        data = tomllib.loads(witwin_toml_text)
    except ValueError:
        return "runtime"
    value = str((data.get("cloud") or {}).get("image") or "runtime").strip().lower()
    return value if value in CLOUD_IMAGES else "runtime"
