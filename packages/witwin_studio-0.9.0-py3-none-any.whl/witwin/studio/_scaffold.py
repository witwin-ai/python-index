"""The one writer of a Project's Python files: ``pyproject.toml``, ``README.md``, ``.gitignore``.

Every way a Project gets these files goes through ``scaffold_project``: the
``witwin init`` command, a new Project created by ``ensure_witwin_project``, a
new Project created by Studio (Electron leaves ``PENDING_MARKER`` and the
ProjectServer calls ``scaffold_if_pending`` on start), and the "Make Python
Project" action. Decision D11, phase P2 of ``dev_docs/project-as-python-codebase.md``.

The writer never overwrites a user file. A missing file is created; an
existing ``pyproject.toml`` only gains the ``witwin-studio`` dependency, and an
existing ``.gitignore`` only gains the patterns a Python Project needs.

A Project created from nothing (``init_git=True``: ``witwin init`` or
``ensure_witwin_project`` in a new or empty folder, and the pending marker) also
gets ``.gitattributes`` and starts as a git repository with one commit
(``_git.py``). The other callers never run ``git init``.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import tomlkit

from . import _git, _gitignore

PYPROJECT = "pyproject.toml"
README = "README.md"
GITIGNORE = ".gitignore"

STUDIO_DISTRIBUTION = "witwin-studio"

# Patterns a Python Project must ignore: runtime state and the uv/venv folder.
PYTHON_IGNORE_PATTERNS = (".witwin/", ".venv/")

# Studio writes this file when it creates a Project; the ProjectServer scaffolds
# on start and deletes it. Studio's copy of the path:
# studio/electron/project/projectManager.ts (PYTHON_SCAFFOLD_MARKER); a server
# test checks the two agree.
PENDING_MARKER = (".witwin", "python-scaffold.pending")

_FALLBACK_DISTRIBUTION = "witwin-project"


def studio_requirement() -> str:
    """The dependency line new Projects get, compatible with this package's version.

    Before 1.0 a minor version may break the API, so the range stops at the
    next minor; from 1.0 on it stops at the next major.
    """
    from . import __version__

    major, minor = (int(part) for part in __version__.split(".")[:2])
    upper = f"{major}.{minor + 1}" if major == 0 else f"{major + 1}"
    return f"{STUDIO_DISTRIBUTION}>={major}.{minor},<{upper}"


def distribution_name(project_name: str) -> str:
    """A PEP 503 normalized distribution name for a Project name ("Radar Lab" -> "radar-lab")."""
    slug = re.sub(r"[^a-z0-9]+", "-", (project_name or "").lower()).strip("-")
    return slug or _FALLBACK_DISTRIBUTION


def _requirement_name(requirement: str) -> Optional[str]:
    match = re.match(r"\s*([A-Za-z0-9][A-Za-z0-9._-]*)", requirement or "")
    return re.sub(r"[-_.]+", "-", match.group(1)).lower() if match else None


def render_pyproject(project_name: str) -> str:
    name = tomlkit.item(distribution_name(project_name)).as_string()
    description = tomlkit.item(f"WiTwin Studio Project: {project_name}").as_string()
    requirement = tomlkit.item(studio_requirement()).as_string()
    from ._platform import constraints

    platform_lines = "".join(f"    {tomlkit.item(line).as_string()},\n" for line in constraints())
    return f"""[project]
name = {name}
version = "0.1.0"
description = {description}
requires-python = ">=3.11"
# Plugins this Project uses are dependencies too, e.g. "wt-radar".
dependencies = [
    {requirement},
]

[build-system]
requires = ["hatchling>=1.21"]
build-backend = "hatchling.build"

# The Project has no importable package yet, so installing it installs only the
# dependencies. To add reusable code, create src/<package>/ and delete this
# table.
[tool.hatch.build.targets.wheel]
bypass-selection = true

[tool.uv]
# WiTwin cloud machines have these versions installed; a lock that keeps them
# makes `uv sync` there download only what this Project adds. They apply on
# Linux x86_64 only. `witwin platform --write` refreshes them.
constraint-dependencies = [
{platform_lines}]
"""


def render_readme(project_name: str) -> str:
    return f"""# {project_name}

A WiTwin Studio Project. It is also an ordinary Python project: you can open,
edit and run it without the editor.

## Set up

```bash
uv sync                 # or: python -m venv .venv, activate it, pip install -e .
```

## Use from Python

```python
import witwin.studio as ws

project = ws.open_project(".")
scene = project.scene()          # the main scene
print(list(scene.objects))
```

## Commands

- `witwin check` validates the Project files.
- `witwin run scripts/<name>.py` runs a Script with the Project on its path.
- `witwin open` opens the Project in WiTwin Studio.

## Layout

- `witwin.toml`: the Studio manifest (Project id, main scene).
- `pyproject.toml`: the Python dependencies, including the Plugins this Project uses.
- `scenes/`: the Scene files (`.wtscene`, TOML). Studio and code edit the same
  files; saving from either side rewrites the file, so comments in it are not kept.
- `.witwin/`: local runtime state (caches, Agent Sessions, Result history). It
  is not shared and git ignores it.
"""


@dataclass
class ScaffoldResult:
    """Project-relative names of what a scaffold call did."""

    written: List[str] = field(default_factory=list)
    updated: List[str] = field(default_factory=list)
    problems: List[str] = field(default_factory=list)
    # Set only when the call was asked to start a repository (init_git=True).
    git: Optional[_git.GitInitResult] = None

    @property
    def changed(self) -> bool:
        return bool(self.written or self.updated or (self.git and self.git.initialized))


def _has_readme(root: Path) -> bool:
    return any(path.is_file() and path.name.lower().startswith("readme") for path in root.iterdir())


def _project_name(root: Path, name: Optional[str]) -> str:
    if name:
        return name
    try:
        from ._manifest import read_witwin_project

        return read_witwin_project(root).name
    except (OSError, ValueError):
        return root.name or "WiTwin Project"


def _pyproject_dependency_state(text: str) -> tuple[Any, Optional[str], bool]:
    """``(doc, problem, has_studio_dependency)`` for a pyproject.toml text."""
    try:
        doc = tomlkit.parse(text)
    except Exception as exc:  # noqa: BLE001 - any parse error leaves the file alone
        return None, f"{PYPROJECT} is not valid TOML ({exc}); it was left unchanged", False
    project = doc.get("project")
    if not isinstance(project, dict):
        # A tool-only pyproject (formatter settings, say) is not a package
        # definition; adding [project] would change how tools treat the folder.
        return doc, f"{PYPROJECT} has no [project] table; add {STUDIO_DISTRIBUTION} to its dependencies yourself", False
    if "dependencies" in (project.get("dynamic") or []):
        return doc, f"{PYPROJECT} declares dependencies as dynamic; add {STUDIO_DISTRIBUTION} where they come from", False
    deps = project.get("dependencies") or []
    has = any(_requirement_name(str(dep)) == STUDIO_DISTRIBUTION for dep in deps)
    return doc, None, has


def _scaffold_pyproject(root: Path, project_name: str, result: ScaffoldResult) -> None:
    path = root / PYPROJECT
    if not path.exists():
        path.write_text(render_pyproject(project_name), encoding="utf-8", newline="\n")
        result.written.append(PYPROJECT)
        return
    doc, problem, has = _pyproject_dependency_state(path.read_text(encoding="utf-8"))
    if problem:
        result.problems.append(problem)
        return
    if has:
        return
    project = doc["project"]
    deps = project.get("dependencies")
    if deps is None:
        deps = tomlkit.array()
        deps.multiline(True)
        project["dependencies"] = deps
    deps.append(studio_requirement())
    path.write_text(tomlkit.dumps(doc), encoding="utf-8", newline="\n")
    result.updated.append(PYPROJECT)


def _scaffold_gitignore(root: Path, result: ScaffoldResult) -> None:
    content, present = _gitignore.read_gitignore(root)
    if not present:
        # The managed default already lists every PYTHON_IGNORE_PATTERNS entry.
        _gitignore.write_gitignore(root, _gitignore.DEFAULT_GITIGNORE)
        result.written.append(GITIGNORE)
        return
    new_content, added, _ = _gitignore.ensure_patterns(content, PYTHON_IGNORE_PATTERNS)
    if added:
        _gitignore.write_gitignore(root, new_content)
        result.updated.append(GITIGNORE)


def _template_id(root: Path) -> Optional[str]:
    """``[project].template_id``, which Studio writes when it copies a template."""
    try:
        from ._manifest import read_project_table

        value = str(read_project_table(root).get("template_id") or "").strip()
    except (OSError, ValueError):
        return None
    return value or None


def scaffold_project(
    root: Path | str,
    *,
    name: Optional[str] = None,
    init_git: bool = False,
    git_identity: Optional[_git.GitIdentity] = None,
) -> ScaffoldResult:
    """Make ``root`` a Python project; idempotent, never overwrites a user file.

    ``name`` is the display name used in the new files; it defaults to
    ``[project].name`` from ``witwin.toml``, then the folder name.

    ``init_git`` is for a Project created from nothing only: it adds
    ``.gitattributes``, runs ``git init`` and commits everything. It leaves git
    alone when git is missing or the folder is already in a work tree.
    ``git_identity`` is used when git has no user.name / user.email for the
    folder; ``WITWIN_GIT_AUTHOR_NAME`` / ``WITWIN_GIT_AUTHOR_EMAIL`` come next.
    """
    root = Path(root).resolve()
    result = ScaffoldResult()
    project_name = _project_name(root, name)
    _scaffold_pyproject(root, project_name, result)
    if not _has_readme(root):
        (root / README).write_text(render_readme(project_name), encoding="utf-8", newline="\n")
        result.written.append(README)
    _scaffold_gitignore(root, result)
    if init_git:
        # Written even when git is missing: the line matters as soon as the
        # user starts a repository later.
        attributes = _git.ensure_gitattributes(root)
        if attributes:
            getattr(result, attributes).append(_git.GITATTRIBUTES)
        result.git = start_project_repo(root, git_identity=git_identity)
    return result


def start_project_repo(root: Path | str, *, git_identity: Optional[_git.GitIdentity] = None) -> _git.GitInitResult:
    """``.gitattributes``, ``git init`` and the first commit of a Project made from nothing.

    ``scaffold_project(init_git=True)`` calls it. The ProjectServer calls it on
    a background thread for a Project Studio just created (and for an empty
    folder it was started on), after it has loaded the main Scene: the first
    commit then holds the final witwin.toml and Scene file, and the git
    commands (about half a second) do not delay startup.
    """
    root = Path(root).resolve()
    _git.ensure_gitattributes(root)
    return _git.init_project_repo(root, identity=git_identity, template_id=_template_id(root))


def python_project_status(root: Path | str) -> Dict[str, Any]:
    """What ``scaffold_project`` would still add; ``complete`` when nothing."""
    root = Path(root).resolve()
    status: Dict[str, Any] = {
        "pyproject": (root / PYPROJECT).is_file(),
        "readme": _has_readme(root),
        "gitignore": (root / GITIGNORE).is_file(),
        "studio_dependency": False,
        "missing_ignore_patterns": list(PYTHON_IGNORE_PATTERNS),
        "problems": [],
    }
    if status["pyproject"]:
        _, problem, has = _pyproject_dependency_state((root / PYPROJECT).read_text(encoding="utf-8"))
        status["studio_dependency"] = has
        if problem:
            status["problems"].append(problem)
    if status["gitignore"]:
        content, _ = _gitignore.read_gitignore(root)
        status["missing_ignore_patterns"] = _gitignore.missing_required_patterns(content, PYTHON_IGNORE_PATTERNS)
    status["complete"] = (
        status["pyproject"] and status["readme"] and status["gitignore"]
        and status["studio_dependency"] and not status["missing_ignore_patterns"]
    )
    return status


def pending_marker(root: Path | str) -> Path:
    return Path(root).joinpath(*PENDING_MARKER)


def mark_pending(root: Path | str) -> Path:
    marker = pending_marker(root)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text("Studio created this Project; the ProjectServer scaffolds it on start.\n", encoding="utf-8")
    return marker


def scaffold_if_pending(
    root: Path | str, *, init_git: bool = True, git_identity: Optional[_git.GitIdentity] = None,
) -> Optional[ScaffoldResult]:
    """Scaffold a Project Studio just created, then clear the marker. None when not pending.

    The marker means Studio made this folder a moment ago (New Project or a
    template card), so the Project also starts as a git repository.
    ``init_git=False`` leaves that step to the caller (``start_project_repo``).
    """
    marker = pending_marker(root)
    if not marker.is_file():
        return None
    # Remove the marker before the commit: .witwin/ is ignored, but a user
    # .gitignore that lacks it would otherwise commit the marker.
    marker.unlink(missing_ok=True)
    return scaffold_project(root, init_git=init_git, git_identity=git_identity)
