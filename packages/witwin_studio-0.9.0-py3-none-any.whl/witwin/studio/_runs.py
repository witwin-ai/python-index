"""The Run folder ``.witwin/runs/<run_id>/`` and its metric files (dev_docs/studies-plan.md §6.2).

Every Run uses this one folder, whoever writes it: the ProjectServer for a Run
Studio started (``plugins_builtin/runs/report.py``), ``witwin.studio.tracking`` for a
script run without Studio. Both call the writers here, so the layout and the
row format are defined once.

Files:

- ``run.json``: ``{"runId", "source", "script", "args", "config", "pid",
  "startedAt", "finishedAt", "status"}``. Studio Runs only carry ``runId``,
  ``source`` and ``config``; their state is the ProjectServer's RunRecord.
- ``metrics.jsonl``: one row per ``ws.log`` call,
  ``{"step": 120, "epoch": 3, "t": 12.5, "values": {"train/loss": 0.12}}``;
  ``epoch`` is left out when the script gave none, ``t`` is seconds since the
  first row.
- ``checkpoints.jsonl``: one ``ws.checkpoint`` per line,
  ``{"path", "step", "epoch"?, "t", "metrics"}``.
- ``summary.json``: the merged ``ws.summary`` values.

Non-finite values are stored as the strings ``"NaN"``, ``"Infinity"`` and
``"-Infinity"``. Plain JSON has no token for them (Python would write a bare
``NaN`` that JavaScript's ``JSON.parse`` rejects), and ``null`` would lose
which of the three it was, which is what tells "the loss diverged" apart from
"the loss broke". Python's ``float()`` and JavaScript's ``Number()`` both read
these strings back.
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional

RUNS_PARTS = (".witwin", "runs")
RUN_FILE = "run.json"
METRICS_FILE = "metrics.jsonl"
CHECKPOINTS_FILE = "checkpoints.jsonl"
SUMMARY_FILE = "summary.json"
MANIFEST_NAME = "witwin.toml"

_NON_FINITE = {"NaN": math.nan, "Infinity": math.inf, "-Infinity": -math.inf}


def runs_root(project_root: Path) -> Path:
    return Path(project_root).joinpath(*RUNS_PARTS)


def run_dir(project_root: Path, run_id: str) -> Path:
    """``<project>/.witwin/runs/<run_id>``. Raises ValueError for an id that is not one folder name."""
    if not run_id or run_id in (".", "..") or any(sep in run_id for sep in ("/", "\\", ":")):
        raise ValueError(f"not a Run id: {run_id!r}")
    return runs_root(project_root) / run_id


def find_project_root(start: Path) -> Optional[Path]:
    """The nearest folder at or above ``start`` holding ``witwin.toml``, or None."""
    start = Path(start).resolve()
    for folder in (start, *start.parents):
        if (folder / MANIFEST_NAME).is_file():
            return folder
    return None


# ---- values -------------------------------------------------------------------


def encode_number(value: float) -> Any:
    """A float as JSON can carry it: finite floats as is, NaN and infinities as strings."""
    if math.isfinite(value):
        return value
    if math.isnan(value):
        return "NaN"
    return "Infinity" if value > 0 else "-Infinity"


def decode_number(value: Any) -> Optional[float]:
    """The float a stored value means; None for anything that is not a number."""
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        return _NON_FINITE.get(value)
    return None


# ---- writers ------------------------------------------------------------------


def _dumps(value: Any) -> str:
    # allow_nan=False: a non-finite float that slipped past encode_number fails
    # here instead of writing a line JavaScript cannot parse.
    return json.dumps(value, separators=(",", ":"), allow_nan=False)


def append_jsonl(path: Path, rows: Iterable[Dict[str, Any]]) -> int:
    """Append one line per row; returns how many were written.

    One write per call keeps a batch whole when two writers race, and each
    line is complete, so a reader never sees half a row except the last one
    of a process that was killed mid-write (readers skip it).
    """
    lines = [_dumps(row) for row in rows]
    if not lines:
        return 0
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(lines) + "\n")
    return len(lines)


def write_json(path: Path, value: Dict[str, Any]) -> None:
    """Replace a JSON file atomically, so a reader never sees it half written."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(tmp, path)


def merge_json(path: Path, values: Dict[str, Any]) -> Dict[str, Any]:
    """Merge ``values`` into the JSON object at ``path`` and return the result."""
    current = read_json(path)
    current.update(values)
    write_json(path, current)
    return current


def append_metrics(folder: Path, rows: Iterable[Dict[str, Any]]) -> int:
    return append_jsonl(Path(folder) / METRICS_FILE, rows)


def append_checkpoints(folder: Path, rows: Iterable[Dict[str, Any]]) -> int:
    return append_jsonl(Path(folder) / CHECKPOINTS_FILE, rows)


def merge_summary(folder: Path, values: Dict[str, Any]) -> Dict[str, Any]:
    return merge_json(Path(folder) / SUMMARY_FILE, values)


def merge_config(folder: Path, run_id: str, values: Dict[str, Any], *, source: str) -> Dict[str, Any]:
    """Merge ``values`` into ``run.json``'s ``config``; creates the file for a new Run."""
    path = Path(folder) / RUN_FILE
    record = read_json(path) or {"runId": run_id, "source": source}
    record["config"] = {**(record.get("config") or {}), **values}
    write_json(path, record)
    return record


# ---- readers ------------------------------------------------------------------


def read_json(path: Path) -> Dict[str, Any]:
    """A JSON object file, or ``{}`` when it is missing or unreadable."""
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def iter_jsonl(path: Path, offset: int = 0) -> Iterator[tuple[int, Dict[str, Any]]]:
    """``(end offset, row)`` for each whole line from byte ``offset`` on.

    A last line without a newline is still being written; it is not yielded,
    so a caller that resumes from the last end offset reads it whole later.
    Lines that are not JSON objects are skipped.
    """
    try:
        fh = open(path, "rb")
    except OSError:
        return
    with fh:
        fh.seek(offset)
        position = offset
        for raw in fh:
            if not raw.endswith(b"\n"):
                return
            position += len(raw)
            try:
                row = json.loads(raw)
            except ValueError:
                continue
            if isinstance(row, dict):
                yield position, row


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    return [row for _, row in iter_jsonl(path)]


def read_checkpoints(folder: Path) -> List[Dict[str, Any]]:
    return read_jsonl(Path(folder) / CHECKPOINTS_FILE)


def read_summary(folder: Path) -> Dict[str, Any]:
    return read_json(Path(folder) / SUMMARY_FILE)


def read_run(folder: Path) -> Dict[str, Any]:
    return read_json(Path(folder) / RUN_FILE)


def run_status(record: Dict[str, Any]) -> str:
    """A headless Run's status; ``failed`` for one whose process ended without saying so.

    The SDK writes the final status at exit. A process that was killed never
    gets there, so a ``running`` record whose pid is gone ended badly.
    """
    status = str(record.get("status") or "running")
    pid = record.get("pid")
    if status == "running" and isinstance(pid, int):
        from ._discovery import _pid_alive

        if not _pid_alive(pid):
            return "failed"
    return status


def list_runs(project_root: Path) -> List[Path]:
    """Run folders that hold a ``run.json``, newest first by its change time."""
    root = runs_root(project_root)
    try:
        folders = [entry for entry in root.iterdir() if (entry / RUN_FILE).is_file()]
    except OSError:
        return []
    return sorted(folders, key=lambda folder: (folder / RUN_FILE).stat().st_mtime, reverse=True)


__all__ = [
    "CHECKPOINTS_FILE", "METRICS_FILE", "RUN_FILE", "SUMMARY_FILE",
    "append_checkpoints", "append_jsonl", "append_metrics", "decode_number", "encode_number",
    "find_project_root", "iter_jsonl", "list_runs", "merge_config", "merge_json", "merge_summary",
    "read_checkpoints", "read_json", "read_jsonl", "read_run", "read_summary", "run_dir", "run_status", "runs_root",
    "write_json",
]
