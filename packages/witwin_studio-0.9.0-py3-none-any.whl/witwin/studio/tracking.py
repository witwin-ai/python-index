"""Metric logging for training scripts (dev_docs/studies-plan.md §6).

    import witwin.studio as ws

    args = ws.config(total_steps=epochs * len(loader))   # Study args, {} without a Study
    for epoch in range(epochs):
        for batch in loader:
            ws.log({"train/loss": loss}, epoch=epoch)      # step counts up by itself
        ws.log({"val/loss": val_loss}, epoch=epoch)
        ws.checkpoint(f"checkpoints/epoch{epoch}.pt", metrics={"val/loss": val_loss})
    ws.summary(best_val_loss=best)

Exactly one writer records a Run, so no row is stored twice (§6.2):

- **Studio started the Run** (``WITWIN_RUN_ID`` is set): rows go to stdout as
  ``witwin_run`` sentinel lines, at most every 0.25 s or 256 rows, and the
  ProjectServer writes the files. A cloud Run's stdout is forwarded the same
  way, so this also works where the Run's folder is on another machine.
- **No Studio** (``python scripts/train.py``): this module writes
  ``.witwin/runs/<run_id>/`` under the Project found by walking up from the
  working directory to ``witwin.toml``. Outside a Project nothing is recorded
  and the script runs as usual.

Rows are flushed when the process exits (``atexit``) and by a timer 0.25 s
after the last unflushed row, so a long-lived kernel (a cloud Run) does not
hold back the tail. Standard library only: values are turned into floats with
``.item()`` / ``float()`` so numpy and torch scalars work without importing
either. NaN and infinities are kept (stored as strings, see ``_runs``); charts
break the line there.
"""
from __future__ import annotations

import atexit
import json
import os
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional

from . import _runs
from ._ids import short_id

RUN_ID_ENV = "WITWIN_RUN_ID"
STUDY_ARGS_ENV = "WITWIN_STUDY_ARGS"
# Batch limits for the Studio writer (§6.2): a sentinel line per 0.25 s at
# most keeps a tight training loop from flooding the Run's stdout reader.
FLUSH_SECONDS = 0.25
FLUSH_ROWS = 256


# ---- value coercion -----------------------------------------------------------


def _unwrap(value: Any) -> Any:
    # numpy / torch 0-d values: .item() gives a Python number without importing them.
    item = getattr(value, "item", None)
    if callable(item) and not isinstance(value, (bool, int, float, str)):
        try:
            return item()
        except (TypeError, ValueError, RuntimeError) as exc:  # a tensor of more than one element
            raise TypeError(f"expected a single number, got {type(value).__name__}: {exc}") from None
    return value


def _number(name: str, value: Any) -> Any:
    value = _unwrap(value)
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise TypeError(f"metric {name!r} is {type(value).__name__}, not a number") from None
    return _runs.encode_number(number)


def _int(name: str, value: Any) -> int:
    value = _unwrap(value)
    try:
        return int(value)
    except (TypeError, ValueError):
        raise TypeError(f"{name} must be an integer, got {value!r}") from None


def _epoch(value: Any) -> Any:
    # Whole epochs stay ints; a fractional epoch (epoch + batch / len) is a float.
    value = _unwrap(value)
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    return _number("epoch", value)


def _jsonable(value: Any) -> Any:
    """Summary and config values: JSON scalars, lists and dicts; other objects become text."""
    value = _unwrap(value)
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        return _runs.encode_number(value)
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, os.PathLike):
        return os.fspath(value)
    try:
        return _runs.encode_number(float(value))
    except (TypeError, ValueError):
        return str(value)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---- writers ------------------------------------------------------------------


class _Sink:
    """Where records go. ``metric`` gets rows, the others one record each."""

    def metric(self, rows: List[Dict[str, Any]]) -> None: ...

    def checkpoint(self, record: Dict[str, Any]) -> None: ...

    def summary(self, values: Dict[str, Any]) -> None: ...

    def config(self, values: Dict[str, Any]) -> None: ...

    def close(self, status: str) -> None: ...


class _StudioSink(_Sink):
    """Sentinel lines on stdout; the ProjectServer writes the Run folder (``report.apply``)."""

    def _emit(self, kind: str, **fields: Any) -> None:
        # witwin_run is the wire format's one definition. A Studio Run finds the
        # server's copy first on sys.path; plain ``encode`` exists in every
        # version of it, so an older server still reads these lines.
        from witwin_run import encode

        stream = sys.stdout
        if stream is None:  # pythonw, or stdout closed during shutdown
            return
        stream.write(encode(kind, **fields) + "\n")
        stream.flush()

    def metric(self, rows):
        self._emit("metric", rows=rows)

    def checkpoint(self, record):
        self._emit("checkpoint", **record)

    def summary(self, values):
        self._emit("summary", values=values)

    def config(self, values):
        self._emit("config", values=values)


class _FolderSink(_Sink):
    """``.witwin/runs/<run_id>/`` written by this process (no Studio)."""

    def __init__(self, project_root: Path) -> None:
        root = _runs.runs_root(project_root)
        run_id = short_id("run")
        while (root / run_id).exists():
            run_id = short_id("run")
        self.run_id = run_id
        self.folder = _runs.run_dir(project_root, run_id)
        script = Path(sys.argv[0]).resolve() if sys.argv and sys.argv[0] else None
        try:
            shown = script.relative_to(project_root).as_posix() if script else None
        except ValueError:
            shown = script.as_posix() if script else None
        _runs.write_json(self.folder / _runs.RUN_FILE, {
            "runId": run_id,
            "source": "headless",
            "script": shown,
            "args": list(sys.argv[1:]),
            "config": {},
            # Lets a reader tell a killed script from a running one (_runs.run_status).
            "pid": os.getpid(),
            "startedAt": _now_iso(),
            "finishedAt": None,
            "status": "running",
        })

    def metric(self, rows):
        _runs.append_metrics(self.folder, rows)

    def checkpoint(self, record):
        _runs.append_checkpoints(self.folder, [record])

    def summary(self, values):
        _runs.merge_summary(self.folder, values)

    def config(self, values):
        _runs.merge_config(self.folder, self.run_id, values, source="headless")

    def close(self, status):
        _runs.merge_json(self.folder / _runs.RUN_FILE, {"status": status, "finishedAt": _now_iso()})


class _Tracker:
    def __init__(self, sink: _Sink, clock: Callable[[], float] = time.monotonic,
                 flush_seconds: float = FLUSH_SECONDS, flush_rows: int = FLUSH_ROWS) -> None:
        self.sink = sink
        self._clock = clock
        self._flush_seconds = flush_seconds
        self._flush_rows = flush_rows
        # Reentrant: the flush timer and atexit both flush while a log() may hold it.
        self._lock = threading.RLock()
        self._rows: List[Dict[str, Any]] = []
        self._next_step = 0
        self._last_step: Optional[int] = None
        self._epoch: Any = None
        self._t0: Optional[float] = None
        self._last_flush = clock()
        self._timer: Optional[threading.Timer] = None
        self._config: Dict[str, Any] = {}
        self._closed = False

    def _elapsed(self) -> float:
        now = self._clock()
        if self._t0 is None:
            self._t0 = now
        return round(now - self._t0, 3)

    def log(self, values: Mapping[str, Any], step: Any, epoch: Any) -> None:
        if not isinstance(values, Mapping):
            raise TypeError(f"ws.log takes a dict of metric values, got {type(values).__name__}")
        coerced = {str(name): _number(str(name), value) for name, value in values.items()}
        with self._lock:
            # step: given -> used and the next one follows it; omitted -> counts up from 0.
            current = _int("step", step) if step is not None else self._next_step
            self._next_step = current + 1
            self._last_step = current
            row: Dict[str, Any] = {"step": current}
            if epoch is not None:
                self._epoch = _epoch(epoch)
                row["epoch"] = self._epoch
            row["t"] = self._elapsed()
            row["values"] = coerced
            self._rows.append(row)
            if len(self._rows) >= self._flush_rows or self._clock() - self._last_flush >= self._flush_seconds:
                self.flush()
            elif self._timer is None:
                timer = threading.Timer(self._flush_seconds, self.flush)
                timer.daemon = True
                self._timer = timer
                timer.start()

    def flush(self) -> None:
        with self._lock:
            timer, self._timer = self._timer, None
            if timer is not None and timer is not threading.current_thread():
                timer.cancel()
            rows, self._rows = self._rows, []
            self._last_flush = self._clock()
            if rows:
                self.sink.metric(rows)

    def checkpoint(self, path: Any, metrics: Optional[Mapping[str, Any]]) -> None:
        if metrics is not None and not isinstance(metrics, Mapping):
            raise TypeError("ws.checkpoint metrics must be a dict")
        record: Dict[str, Any] = {"path": Path(os.fspath(path)).as_posix()}
        with self._lock:
            # Rows logged before the checkpoint reach the files before it.
            self.flush()
            record["step"] = self._last_step
            if self._epoch is not None:
                record["epoch"] = self._epoch
            record["t"] = self._elapsed()
            record["metrics"] = {str(k): _number(str(k), v) for k, v in (metrics or {}).items()}
            self.sink.checkpoint(record)

    def summary(self, values: Dict[str, Any]) -> None:
        clean = {str(key): _jsonable(value) for key, value in values.items()}
        with self._lock:
            self.flush()
            self.sink.summary(clean)

    def config(self, values: Dict[str, Any]) -> Dict[str, Any]:
        clean = {str(key): _jsonable(value) for key, value in values.items()}
        with self._lock:
            self._config.update(clean)
            if clean:
                self.sink.config(clean)
            return dict(self._config)

    def close(self, status: str) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self.flush()
            self.sink.close(status)


# ---- the process-wide tracker -------------------------------------------------

_tracker: Optional[_Tracker] = None
_tracker_lock = threading.Lock()
_status = "succeeded"


def _make_sink() -> _Sink:
    if os.environ.get(RUN_ID_ENV):
        return _StudioSink()
    root = _runs.find_project_root(Path.cwd())
    if root is None:
        return _Sink()
    try:
        return _FolderSink(root)
    except OSError:
        # A read-only Project folder: record nothing rather than stop the script.
        return _Sink()


def _on_uncaught(previous: Callable[..., Any]) -> Callable[..., Any]:
    def hook(exc_type, exc, tb):
        global _status
        _status = "cancelled" if issubclass(exc_type, KeyboardInterrupt) else "failed"
        previous(exc_type, exc, tb)

    return hook


def _get() -> _Tracker:
    global _tracker
    with _tracker_lock:
        if _tracker is None:
            sink = _make_sink()
            _tracker = _Tracker(sink)
            atexit.register(_at_exit)
            if isinstance(sink, _FolderSink):
                # run.json's status: an uncaught exception reaches this hook,
                # a normal exit does not. Studio Runs get theirs from the exit code.
                sys.excepthook = _on_uncaught(sys.excepthook)
        return _tracker


def _at_exit() -> None:
    tracker = _tracker
    if tracker is not None:
        try:
            tracker.close(_status)
        except Exception:  # noqa: BLE001 - never turn a finished script into a failed exit
            pass


def _reset() -> None:
    """Forget the process-wide tracker (tests). Its atexit hook then does nothing."""
    global _tracker, _status
    with _tracker_lock:
        tracker, _tracker = _tracker, None
        _status = "succeeded"
    if tracker is not None:
        with tracker._lock:
            if tracker._timer is not None:
                tracker._timer.cancel()
                tracker._timer = None


# ---- public functions ---------------------------------------------------------


def log(values: Mapping[str, Any], *, step: Optional[int] = None, epoch: Optional[float] = None) -> None:
    """Record metric values at one step.

    ``step`` counts up from 0 when omitted; a given step also sets where the
    count goes on. ``epoch`` is an extra x axis and does not change the step.
    Each value must convert to a float (numpy / torch scalars do).
    """
    _get().log(values, step, epoch)


def config(**values: Any) -> Dict[str, Any]:
    """Record Run settings and return the Study's arguments.

    ``total_steps`` lets Studio show progress and the time left. The return
    value is the JSON in ``WITWIN_STUDY_ARGS`` (a Train Study's ``args`` and
    ``inputs``), or ``{}`` when the script was not started by a Study.
    """
    if values:
        _get().config(values)
    raw = os.environ.get(STUDY_ARGS_ENV)
    if not raw:
        return {}
    try:
        args = json.loads(raw)
    except ValueError:
        return {}
    return args if isinstance(args, dict) else {}


def checkpoint(path: Any, *, metrics: Optional[Mapping[str, Any]] = None) -> None:
    """Note a saved checkpoint: its path and the metrics at that point. The file is not copied."""
    _get().checkpoint(path, metrics)


def summary(**values: Any) -> None:
    """Record final values of the Run (merged over earlier calls)."""
    _get().summary(values)


__all__ = ["checkpoint", "config", "log", "summary"]
