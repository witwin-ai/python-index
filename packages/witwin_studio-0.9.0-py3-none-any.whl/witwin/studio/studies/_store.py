"""``project.studies``: the Project's Studies, one ``studies/<id>.toml`` file each.

The file name is the Study id; the file does not repeat it. This module is
the one writer of these files: the ProjectServer, the Agent's Tools and
scripts all go through ``StudyStore``. Writes are atomic (temp file and
rename), so a reader never sees half a file. ``variables`` and ``tensors``
are written as sub-tables (``[variables.w]``), the other tables inline.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterator, List, Mapping, Optional, Sequence

import tomlkit

from .._ids import slugify
from ._errors import ErrorCode, StudyError
from ._model import STUDY_ID_PATTERN, Study, StudyKind

FOLDER = "studies"
SUFFIX = ".toml"
# Study keys whose value maps a name to a settings table; written as TOML sub-tables.
_SUBTABLES = ("variables", "tensors")

__all__ = ["FOLDER", "StudyStore", "dumps", "loads"]


class StudyStore(Sequence[Study]):
    """The Studies of the Project at ``root``, sorted by id.

        study = project.studies.add("Fit width", scene="main",
                                    objective={"kind": "script", "path": "scripts/objective.py"},
                                    variables={"w": {"lower": 1e-3, "upper": 4e-3}})
        project.studies.update(study.id, method={"kind": "bayesian"})
        project.studies.remove(study.id)

    Iterating lists the Studies that load; ``problems()`` names the files that
    do not, so one broken file never hides the others.
    """

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root)

    @property
    def folder(self) -> Path:
        return self.root / FOLDER

    def path(self, study_id: str) -> Path:
        """``studies/<id>.toml``; ``invalid_study`` for an id that is not a file name."""
        if not STUDY_ID_PATTERN.match(study_id or ""):
            raise StudyError(ErrorCode.INVALID_STUDY, f"not a Study id: {study_id!r}")
        return self.folder / f"{study_id}{SUFFIX}"

    def list(self) -> List[Study]:
        return [study for study, _ in self._load_all() if study is not None]

    def problems(self) -> List[Dict[str, Any]]:
        """``{id, path, message}`` of every Study file that does not load."""
        return [problem for _, problem in self._load_all() if problem is not None]

    def get(self, study_id: str) -> Study:
        """The Study; ``study_not_found`` without its file, ``invalid_study`` when it does not load."""
        path = self.path(study_id)
        if not path.is_file():
            raise StudyError(ErrorCode.STUDY_NOT_FOUND, f"no Study '{study_id}' in {FOLDER}/")
        return loads(path.read_text(encoding="utf-8"), study_id)

    def add(self, name: str, *, kind: str = StudyKind.OPTIMIZE, id: Optional[str] = None,
            **fields: Any) -> Study:
        """Write a new Study and return it; never overwrites a file.

        ``id`` defaults to a slug of ``name`` not used yet (``fit_width``,
        ``fit_width_2``). ``fields`` are record keys (``scene``, ``variables``,
        ``method``, ``script`` ...), validated by ``Study.from_dict``.
        """
        taken = {study_id for study_id in self._ids()}
        study_id = id or _free_id(name, taken)
        if study_id in taken:
            raise StudyError(ErrorCode.STUDY_EXISTS, f"a Study '{study_id}' already exists")
        study = Study.from_dict({**{k: v for k, v in fields.items() if v is not None},
                                 "id": study_id, "name": name, "kind": kind})
        self._write(study, new=True)
        return study

    def save(self, study: Study) -> Study:
        """Write ``study`` over its file (or create it) and return it."""
        self._write(study, new=False)
        return study

    def update(self, study_id: str, **changes: Any) -> Study:
        """Change some fields of a Study and return it (``Study.updated`` rules)."""
        study = self.get(study_id).updated(changes)
        self._write(study, new=False)
        return study

    def remove(self, study_id: str) -> None:
        """Delete the Study's file; ``study_not_found`` when there is none. Past Runs stay."""
        path = self.path(study_id)
        if not path.is_file():
            raise StudyError(ErrorCode.STUDY_NOT_FOUND, f"no Study '{study_id}' in {FOLDER}/")
        path.unlink()

    def duplicate(self, study_id: str, name: Optional[str] = None) -> Study:
        """Write a copy of a Study under a new id and return it; ``name`` defaults to "<name> copy".

        A dataset Study's own ``dataset.dir`` is dropped, so the copy writes to
        ``datasets/<new id>`` and never into the original's dataset.
        """
        source = self.get(study_id)
        record = source.to_dict()
        record.pop("id", None)
        record.pop("name", None)
        kind = record.pop("kind")
        dataset = record.get("dataset")
        if isinstance(dataset, dict):
            record["dataset"] = {key: value for key, value in dataset.items() if key != "dir"}
        return self.add(name or f"{source.name} copy", kind=kind, **record)

    def rename_variable(self, scene_id: str, old: str, new: str) -> List[str]:
        """Rename parameter ``old`` to ``new`` in every Study of ``scene_id``; returns the ids changed.

        Whoever renames a parameter calls this, so Studies keep naming it.
        Files that do not load are left alone.
        """
        changed = []
        for study in self.list():
            if study.scene != scene_id:
                continue
            renamed = study.renamed_variable(old, new)
            if renamed is not study:
                self._write(renamed, new=False)
                changed.append(study.id)
        return changed

    def remove_variable(self, scene_id: str, name: str) -> List[str]:
        """Stop varying parameter ``name`` in every Study of ``scene_id``; returns the ids changed.

        Whoever deletes a parameter calls this. Files that do not load are
        left alone.
        """
        changed = []
        for study in self.list():
            if study.scene != scene_id:
                continue
            trimmed = study.without_variable(name)
            if trimmed is not study:
                self._write(trimmed, new=False)
                changed.append(study.id)
        return changed

    def __getitem__(self, index: int) -> Study:  # type: ignore[override]
        return self.list()[index]

    def __iter__(self) -> Iterator[Study]:
        return iter(self.list())

    def __len__(self) -> int:
        return len(self.list())

    def __repr__(self) -> str:
        return f"StudyStore({[study.id for study in self.list()]})"

    def _ids(self) -> List[str]:
        if not self.folder.is_dir():
            return []
        return sorted(path.stem for path in self.folder.glob(f"*{SUFFIX}")
                      if path.is_file() and STUDY_ID_PATTERN.match(path.stem))

    def _load_all(self) -> List[tuple]:
        out = []
        for study_id in self._ids():
            path = self.folder / f"{study_id}{SUFFIX}"
            try:
                out.append((loads(path.read_text(encoding="utf-8"), study_id), None))
            except (OSError, StudyError) as exc:
                message = exc.message if isinstance(exc, StudyError) else str(exc)
                out.append((None, {"id": study_id, "path": f"{FOLDER}/{path.name}", "message": message}))
        return out

    def _write(self, study: Study, *, new: bool) -> None:
        path = self.path(study.id)
        if new and path.exists():
            raise StudyError(ErrorCode.STUDY_EXISTS, f"a Study '{study.id}' already exists")
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
                f.write(dumps(study))
            os.replace(tmp, path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise


def dumps(study: Study) -> str:
    """The TOML text of ``study`` (without its id, which is the file name)."""
    doc = tomlkit.document()
    nested = {}
    for key, value in study.to_dict().items():
        if key == "id" or value is None:
            continue
        if key in _SUBTABLES and isinstance(value, dict):
            nested[key] = value
        else:
            doc[key] = _inline(value)
    # Sub-tables last: a plain key after a table header would belong to that table.
    for key, groups in nested.items():
        outer = tomlkit.table(is_super_table=True)
        for name, settings in groups.items():
            inner = tomlkit.table()
            for setting, value in (settings or {}).items():
                inner[setting] = _inline(value)
            outer[name] = inner
        doc[key] = outer
    return tomlkit.dumps(doc)


def loads(text: str, study_id: str) -> Study:
    """Parse one Study file; ``invalid_study`` for bad TOML or a bad record."""
    try:
        data = tomlkit.parse(text)
    except Exception as exc:  # noqa: BLE001 - tomlkit raises its own parse errors
        raise StudyError(ErrorCode.INVALID_STUDY, f"{study_id}{SUFFIX} is not valid TOML: {exc}") from None
    record = _plain(data)
    record.pop("id", None)
    return Study.from_dict({**record, "id": study_id})


# A slug of ``name`` not in ``taken``: "fit_width", then "fit_width_2" ...
def _free_id(name: str, taken: set) -> str:
    base = slugify(name, fallback="study")[:60].strip("_") or "study"
    if not base[0].isalnum():
        base = f"study_{base}"
    candidate, n = base, 2
    while candidate in taken:
        candidate, n = f"{base}_{n}", n + 1
    return candidate


# A TOML value with every dict as an inline table, nested ones included.
def _inline(value: Any) -> Any:
    if isinstance(value, Mapping):
        table = tomlkit.inline_table()
        for key, item in value.items():
            table[key] = _inline(item)
        return table
    if isinstance(value, (list, tuple)):
        return [_inline(item) for item in value]
    return value


# tomlkit containers as plain dict / list / scalars.
def _plain(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if hasattr(value, "unwrap"):
        return value.unwrap()
    return value
