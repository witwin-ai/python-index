"""How a train Study's script is called; shared by Studio's Runs and headless Workflows.

The script gets the Study's ``args`` and ``inputs`` twice: as ``--name value``
on its command line (``cli_args``), for scripts that use argparse, and as
JSON in ``WITWIN_STUDY_ARGS``, which ``witwin.studio.tracking.config()``
returns.
"""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional

from ._model import Study


def train_values(study: Study, overrides: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    """The values a Run of ``study`` passes: ``args``, then ``inputs``, then ``overrides`` (a Workflow step's)."""
    return {**dict(study.args), **dict(study.inputs), **dict(overrides or {})}


def cli_args(values: Mapping[str, Any]) -> List[str]:
    """A train script's command line: ``--name value`` per value, in order.

    ``True`` is a bare ``--name`` flag, ``False`` and None are left out, a list
    repeats its values after one ``--name`` (argparse ``nargs="+"``).
    """
    out: List[str] = []
    for name, value in values.items():
        if value is None or value is False:
            continue
        out.append(f"--{name}")
        if value is True:
            continue
        if isinstance(value, (list, tuple)):
            out.extend(str(item) for item in value)
        else:
            out.append(str(value))
    return out
