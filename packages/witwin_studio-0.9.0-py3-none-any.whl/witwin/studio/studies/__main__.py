"""Process entry of a Study Run.

    python -m witwin.studio.studies --project <dir> --study <study_id> --out <dir>
        [--resume-from <checkpoint file or run folder>] [--check-gradient]

Studio starts this through its Runs system; it works the same from a shell.
It reads ``studies/<id>.toml``, looks its kind up in the kind registry
(``_kinds``) and calls that kind's ``run``; the kind prints ``partial`` and
``progress`` lines in the ``witwin_run`` format (see ``optimize/_report.py``).
A kind with ``runner = "script"`` (train) is not run here: Studio runs its
script directly. A package's kind returns the ``result.json`` content
itself; ``study_id``, ``kind`` and ``stopped_by`` (``finished``) are added
when it leaves them out. An optimize Study reports:

- gradient method: per step one ``partial`` (the ``StepRecord`` dict) and one
  ``progress`` (fraction of ``min(max_iters, budget.max_evals)``);
- other methods: one ``partial`` per batch or per 250 ms
  (``{batch, records, summary?}``, ``PartialBuffer``) and a ``progress`` as
  each evaluation finishes, also inside a batch (``BatchDriver.progress``).
  A resumed run first sends the evaluations it continues as one partial.

A dataset Study (``_dataset.py``) reports like a black-box run and writes
its samples into ``dataset.dir``; ``result.json`` then also has
``dataset = {dir, samples, shards, skipped, complete}``.

Every evaluation is appended to ``<out>/evaluations.jsonl`` as it finishes.
At the end it writes ``<out>/result.json`` (``OptimizationResult.to_dict``,
version 2). A gradient run also writes ``<out>/checkpoint.pt`` (when
``checkpoint_every`` > 0) and ``<out>/tensors/`` (``_gradient``); any other
run writes ``<out>/checkpoint.json`` (``_batch``). ``--resume-from``
continues the run that wrote a checkpoint.

``--check-gradient`` runs ``check_gradient`` instead of the Study: one
``progress`` per evaluation, then one ``partial`` ``{"gradient_check":
GradientCheck.to_dict()}`` (or ``{"gradient_check": null, "error": {...}}``),
and the same payload in ``<out>/gradient_check.json``.

Stopping: SIGTERM, SIGBREAK (Windows, Ctrl+Break) and the file ``<out>/STOP``
end the run after the current step; Ctrl+C (KeyboardInterrupt) ends it at
once. All of them write the file with ``stopped_by = "stopped"``. A hard kill
(``Popen.kill``, TerminateProcess on Windows) cannot be caught and writes no
file.

Workers (``budget.parallel > 1``, black-box methods; _evaluators/pool.py):
after a stop, points in flight get ``DRAIN_GRACE_S`` (5 s) to finish, then
their workers are terminated, inside the ProjectServer's 10 s ``STOP_GRACE``.
Ctrl+C terminates every worker at once. Workers ignore SIGINT and SIGBREAK
(the console sends them to the whole process group; this process decides).
After a hard kill of this process, an idle worker sees its pipe close and
exits; a busy one exits when its current evaluation ends.

Exit code: 0 when the run ended by ``max_iters``, ``tol``, ``budget``,
``converged`` or a stop; 1 on an error, which the file describes in ``error``.
"""
from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import tempfile
import traceback
from pathlib import Path
from types import FrameType
from typing import Any, Sequence

from .._project import open_project
from ..optimize._records import StopReason
from ..optimize._report import Reporter
from ..optimize._result import RESULT_VERSION
from ._builtin_kinds import run_id, scene_of
from ._errors import ErrorCode, StudyError
from ._kinds import SCRIPT_RUNNER, RunContext, get_kind
from ._model import Study, StudyKind

RESULT_FILE = "result.json"
CHECK_FILE = "gradient_check.json"
STOP_FILE = "STOP"


class _StopRequest:
    """True once a stop signal arrived or the STOP file exists; ``run`` asks it before each step."""

    def __init__(self, stop_file: Path) -> None:
        self._stop_file = stop_file
        self._signalled = False
        for name in ("SIGTERM", "SIGBREAK"):
            if hasattr(signal, name):
                signal.signal(getattr(signal, name), self._on_signal)

    def _on_signal(self, signum: int, frame: FrameType | None) -> None:
        self._signalled = True

    def __call__(self) -> bool:
        return self._signalled or self._stop_file.exists()


def main(argv: Sequence[str] | None = None) -> int:
    """Run one Study and write ``result.json``; returns the exit code."""
    parser = argparse.ArgumentParser(prog="python -m witwin.studio.studies",
                                     description="Run one Study of a Project.")
    parser.add_argument("--project", required=True, help="Project folder (holds witwin.toml)")
    parser.add_argument("--study", required=True, help="Study id (the name of studies/<id>.toml)")
    parser.add_argument("--out", required=True, help="Folder for result.json")
    parser.add_argument("--resume-from", default=None,
                        help="checkpoint.pt or checkpoint.json (or the folder of the run that wrote it) to continue")
    parser.add_argument("--check-gradient", action="store_true",
                        help="Compare the gradient with finite differences instead of optimizing")
    args = parser.parse_args(argv)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    if args.check_gradient:
        return _check(args.project, args.study, out)
    payload = _run(args.project, args.study, out, _StopRequest(out / STOP_FILE),
                   resume_from=args.resume_from)
    _write_json(out / RESULT_FILE, payload)
    summary = f"study {args.study}: stopped_by={payload['stopped_by']}"
    if "evaluation_count" in payload:  # an optimize or dataset Run (OptimizationResult)
        best = payload.get("best") or {}
        summary += f", evaluations={payload['evaluation_count']}, best loss={best.get('loss')}"
    print(summary, flush=True)
    return 1 if payload["stopped_by"] == StopReason.ERROR else 0


# The content of result.json; never raises (a failure is described in the payload).
def _run(project_dir: str, study_id: str, out: Path,
         stop: _StopRequest, resume_from: str | None = None) -> dict[str, Any]:
    study: Study | None = None
    try:
        project = _open(project_dir)
        study = _study(project, study_id)
        context = RunContext(project=project, study=study, out=out, run_id=run_id(out), reporter=Reporter(),
                             should_stop=stop, resume_from=resume_from)
        payload = dict(get_kind(study.kind).run(context))
        payload.setdefault("study_id", study.id)
        payload.setdefault("stopped_by", "finished")
        if study.kind not in set(StudyKind):
            payload.setdefault("kind", str(study.kind))
        return payload
    except StudyError as exc:
        return _failed(study_id, study, exc)
    except KeyboardInterrupt:
        return _failed(study_id, study, None)
    except Exception as exc:  # noqa: BLE001 - process boundary: always leave a result file
        traceback.print_exc()
        return _failed(study_id, study, StudyError(ErrorCode.INTERNAL, f"{type(exc).__name__}: {exc}"))


# Gradient check of one Study; writes gradient_check.json and returns the exit code.
def _check(project_dir: str, study_id: str, out: Path) -> int:
    from ..optimize._gradcheck import check_gradient

    reporter = Reporter()

    def on_progress(done: int, total: int) -> None:
        reporter.progress(done / total, f"evaluation {done}/{total}")

    try:
        project = _open(project_dir)
        study = _study(project, study_id)
        if study.kind != StudyKind.OPTIMIZE:
            raise StudyError(ErrorCode.INVALID_STUDY, f"Study '{study_id}' is a {study.kind} Study; "
                                                      "only optimize Studies have a gradient")
        check = check_gradient(scene_of(project, study), study, project_root=project.root,
                               on_progress=on_progress)
        payload: dict[str, Any] = {"gradient_check": check.to_dict()}
    except StudyError as exc:
        payload = {"gradient_check": None, "error": exc.to_dict()}
    except Exception as exc:  # noqa: BLE001 - process boundary: always leave a result file
        traceback.print_exc()
        payload = {"gradient_check": None,
                   "error": StudyError(ErrorCode.INTERNAL, f"{type(exc).__name__}: {exc}").to_dict()}
    reporter.partial(payload)
    _write_json(out / CHECK_FILE, payload)
    check_dict = payload["gradient_check"]
    if check_dict is None:
        print(f"gradient check {study_id}: {payload['error']['message']}", flush=True)
        return 1
    print(f"gradient check {study_id}: {check_dict['evaluations']} evaluations, "
          f"max relative error {check_dict['max_rel_error']:.3g}", flush=True)
    return 0


def _open(project_dir: str) -> Any:
    try:
        return open_project(project_dir)
    except FileNotFoundError as exc:
        raise StudyError(ErrorCode.PROJECT_NOT_FOUND, str(exc)) from None


def _study(project: Any, study_id: str) -> Study:
    study = project.studies.get(study_id)
    if getattr(get_kind(study.kind), "runner", None) == SCRIPT_RUNNER:
        raise StudyError(ErrorCode.INVALID_STUDY,
                         f"Study '{study_id}' is a {study.kind} Study; run its script ({study.script}) instead")
    return study


# Payload of a run that ended before its first evaluation: an error, or Ctrl+C while loading.
# ``kind`` is the method kind of an optimize or dataset Study (OptimizationResult's
# field), the Study kind of a package's kind.
def _failed(study_id: str, study: Study | None, error: StudyError | None) -> dict[str, Any]:
    builtin = study is not None and study.kind in set(StudyKind)
    kind = (study.method.kind if builtin else str(study.kind)) if study else None
    method = str(study.method.get("optimizer") or kind) if builtin else None
    payload: dict[str, Any] = {
        "version": RESULT_VERSION, "study_id": study_id, "scene_id": study.scene if study else None,
        "kind": kind, "method": method,
        "direction": str(study.direction) if study else None,
        "stopped_by": str(StopReason.ERROR if error else StopReason.STOPPED),
        "seed": study.seed if study else None, "variables": [], "param_ids": {},
        "best": None, "last": None, "summary": {}, "evaluation_count": 0, "failed_count": 0,
        "steps": [],
    }
    if error is not None:
        payload["error"] = error.to_dict()
    return payload


# Write JSON atomically, so a reader never sees half a file.
def _write_json(path: Path, payload: dict[str, Any]) -> None:
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
        json.dump(payload, f, indent=2)
    os.replace(tmp, path)


if __name__ == "__main__":
    sys.exit(main())
