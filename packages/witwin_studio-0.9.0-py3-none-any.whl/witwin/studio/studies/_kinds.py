"""The Study kind registry: built-in optimize, dataset and train, plus the ``witwin.study_kinds`` group.

A kind says which record keys a Study of it has, how they are checked and how
``python -m witwin.studio.studies`` runs it. A package adds one with an entry
point named after the kind::

    [project.entry-points."witwin.study_kinds"]
    sensitivity = "my_pkg.kinds:SENSITIVITY"

The object it names is a ``StudyKindDef`` (a subclass or an instance), or any
object with its attributes. Code that runs in the ProjectServer may also call
``register_kind(defn)`` (a Plugin's ``activate``); both land in the same
registry, so Studio and a headless script see the same kinds.

Rules:

- The entry point name must equal ``defn.kind``: a record read looks up only
  the entry point of the kind it names, so reading a Study never imports the
  other packages' kinds.
- A kind whose name is already registered (a built-in or another package's)
  is skipped and listed in ``kind_problems()``, unless it sets
  ``replaces = True`` (plan 5.7: a replacement is always explicit).
- A record of a kind no installed package registers does not load
  (``invalid_study``); ``StudyStore.problems()`` lists it, so the file is
  kept and shown with the reason.

Keys: every kind has ``id``, ``name``, ``kind`` and ``resources``. The others
are the kind's own, named by ``keys`` (by default the properties of
``record_schema``). A third-party kind's keys are checked against
``record_schema`` (``optimize._schema.check_settings``) and kept in
``Study.settings``; the Studies page draws its form from the same schema
unless a Plugin registers an editor in ``studies.kind.editor``.
"""
from __future__ import annotations

import logging
import sys
import threading
from dataclasses import dataclass
from importlib import metadata
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Mapping

from ._errors import ErrorCode, StudyError, invalid

if TYPE_CHECKING:
    from ..optimize._report import Reporter
    from ._model import Study

ENTRY_POINT_GROUP = "witwin.study_kinds"
BUILTIN_SOURCE = "witwin-studio"
# How Studio starts a Run of a kind (plugins_builtin/studies/runner.py):
# "process" runs ``python -m witwin.studio.studies`` (the kind's ``run``),
# "script" runs the Study's own Project script (the train kind).
PROCESS_RUNNER = "process"
SCRIPT_RUNNER = "script"

logger = logging.getLogger("witwin.studio")

__all__ = [
    "BUILTIN_SOURCE", "ENTRY_POINT_GROUP", "PROCESS_RUNNER", "RegisteredKind", "RunContext",
    "SCRIPT_RUNNER", "StudyKindDef", "get_kind", "kind_problems", "list_kinds", "register_kind",
    "registered_kinds",
]


@dataclass(frozen=True)
class RunContext:
    """What a kind's ``run`` gets from ``python -m witwin.studio.studies``.

    ``project`` is the open ``witwin.studio.Project``; ``out`` the Run folder
    (``result.json`` and any file the kind writes go there); ``run_id`` the
    Studio Run id, else the folder name. ``reporter`` writes the
    ``progress`` and ``partial`` lines Studio shows while the Run runs.
    ``should_stop()`` turns true after Stop (SIGTERM, SIGBREAK or the file
    ``<out>/STOP``); a kind should check it between steps and return.
    ``resume_from`` is the ``--resume-from`` argument, or None.
    """
    project: Any
    study: "Study"
    out: Path
    run_id: str
    reporter: "Reporter"
    should_stop: Callable[[], bool]
    resume_from: str | None = None


class StudyKindDef:
    """One Study kind. Subclass it and set the class attributes, then override ``run``.

    ``kind``: the record's ``kind`` value, a name like ``sensitivity`` or
    ``my_pkg.sweep``. ``title`` and ``description`` are what the New Study
    dialog shows. ``record_schema`` is a JSON Schema object of the kind's own
    record keys (``optimize._schema`` lists the supported keys). ``icon`` is
    a lucide icon name for the kind's card. ``default_gpus`` is
    ``resources.gpus`` when the record does not set it. ``runner`` is
    ``PROCESS_RUNNER`` for a kind that runs in ``python -m
    witwin.studio.studies``. ``starter`` holds record keys a new Study of
    the kind starts with (``study.create``). ``replaces = True`` replaces a
    kind of the same name that is already registered.
    """

    kind: str = ""
    title: str = ""
    description: str = ""
    icon: str = ""
    record_schema: Mapping[str, Any] = {}
    default_gpus: int = 0
    runner: str = PROCESS_RUNNER
    starter: Mapping[str, Any] = {}
    replaces: bool = False

    @property
    def keys(self) -> frozenset[str]:
        """The record keys this kind reads besides ``id``, ``name``, ``kind`` and ``resources``."""
        return frozenset((self.record_schema or {}).get("properties") or {})

    def parse(self, data: Mapping[str, Any], study_id: str, *, require_objective: bool) -> dict[str, Any]:
        """``Study`` fields from the record's own keys (``data`` holds only those). Raises ``invalid_study``."""
        from ..optimize._schema import check_settings

        return {"settings": check_settings(self.record_schema or {}, data, "study")}

    def record(self, study: "Study") -> dict[str, Any]:
        """The record's own keys of ``study`` (the inverse of ``parse``)."""
        from ._model import _plain

        return _plain(dict(study.settings))

    def check(self, study: "Study", project_root: Path) -> None:
        """Raise ``StudyError`` when ``study`` cannot run in the Project; called before a Run starts."""

    def run(self, ctx: RunContext) -> Mapping[str, Any]:
        """Run the Study; return the content of ``result.json``.

        Studio reads ``stopped_by`` (default ``finished``; ``stopped`` after
        Stop, ``error`` with ``error = {code, message}`` on failure) and keeps
        the rest as the Run's Result. Raise ``StudyError`` to fail the Run
        with that code.
        """
        raise StudyError(ErrorCode.INVALID_STUDY,
                         f"a {self.kind} Study does not run in python -m witwin.studio.studies")


@dataclass(frozen=True)
class RegisteredKind:
    definition: Any  # a StudyKindDef, or an object with its attributes
    source: str  # BUILTIN_SOURCE, the distribution name, else the entry point value / "register_kind"
    builtin: bool


_lock = threading.Lock()
# kind -> registration made by register_kind() (in this process).
_explicit: dict[str, RegisteredKind] = {}
# Entry points of one sys.path, scanned once: their names, what loading each
# gave (None: not usable) and why some were not used.
_path_key: tuple[str, ...] | None = None
_points: list[metadata.EntryPoint] = []
_loaded: dict[str, RegisteredKind | None] = {}
_problems: list[str] = []


def register_kind(definition: Any, *, source: str = "register_kind") -> Callable[[], None]:
    """Add a kind in this process; returns a function that removes it again.

    Raises ``ValueError`` for an object without ``kind`` / ``title`` and for a
    name already registered unless the definition sets ``replaces = True``.
    """
    _require_shape(definition)
    kind = str(definition.kind)
    entries, _ = _entry_kinds(only=kind)
    with _lock:
        taken = kind in _builtins() or kind in _explicit or kind in entries
        if taken and not getattr(definition, "replaces", False):
            raise ValueError(f"Study kind '{kind}' is already registered; set replaces = True to replace it")
        previous = _explicit.get(kind)
        entry = RegisteredKind(definition, source, builtin=False)
        _explicit[kind] = entry

    def unregister() -> None:
        with _lock:
            if _explicit.get(kind) is entry:
                if previous is None:
                    _explicit.pop(kind, None)
                else:
                    _explicit[kind] = previous

    return unregister


def get_kind(kind: str) -> Any:
    """The definition of ``kind``; raises ``invalid_study`` when no installed package registers it."""
    found = _lookup(str(kind))
    if found is None:
        raise invalid(f"no installed package registers the Study kind {kind!r}")
    return found.definition


def registered_kinds() -> list[RegisteredKind]:
    """Every kind, built-in names first (a replacement in a built-in's place), then the others by name.

    Loads every ``witwin.study_kinds`` entry point.
    """
    entries, _ = _entry_kinds(load_all=True)
    with _lock:
        explicit = dict(_explicit)
    out: list[RegisteredKind] = []
    for kind, builtin in _builtins().items():
        out.append(explicit.get(kind) or entries.get(kind) or builtin)
    rest = {**entries, **explicit}
    for kind in sorted(rest):
        if kind not in _builtins():
            out.append(rest[kind])
    return out


def kind_problems() -> list[str]:
    """Why some ``witwin.study_kinds`` entry points were not used (broken, misnamed, a name already taken)."""
    _, problems = _entry_kinds(load_all=True)
    return list(problems)


def list_kinds() -> list[dict[str, Any]]:
    """Every kind as ``{kind, title, description, icon, record_schema, runner, source, builtin}``."""
    rows = []
    for item in registered_kinds():
        d = item.definition
        rows.append({
            "kind": str(d.kind), "title": str(d.title),
            "description": str(getattr(d, "description", "") or ""),
            "icon": str(getattr(d, "icon", "") or ""),
            "record_schema": dict(getattr(d, "record_schema", None) or {}),
            "runner": str(getattr(d, "runner", PROCESS_RUNNER) or PROCESS_RUNNER),
            "source": item.source, "builtin": item.builtin,
        })
    return rows


def keys_of(definition: Any) -> frozenset[str]:
    """``definition.keys``, also for a duck-typed object that only has ``record_schema``."""
    keys = getattr(definition, "keys", None)
    if isinstance(keys, (set, frozenset, list, tuple)):
        return frozenset(keys)
    return frozenset((getattr(definition, "record_schema", None) or {}).get("properties") or {})


# ---- lookup -----------------------------------------------------------------------

def _lookup(kind: str) -> RegisteredKind | None:
    with _lock:
        explicit = _explicit.get(kind)
    if explicit is not None:
        return explicit
    entries, _ = _entry_kinds(only=kind)
    return entries.get(kind) or _builtins().get(kind)


def _builtins() -> dict[str, RegisteredKind]:
    from ._builtin_kinds import BUILTIN_KINDS

    return {kind: RegisteredKind(definition, BUILTIN_SOURCE, builtin=True)
            for kind, definition in BUILTIN_KINDS.items()}


def _entry_kinds(*, load_all: bool = False, only: str | None = None) -> tuple[dict[str, RegisteredKind], list[str]]:
    """Entry point kinds of the current ``sys.path``; loads ``only``'s entry point, or every one.

    The group is scanned once per ``sys.path`` and each entry point loaded at
    most once, so a record read after the first costs a dict lookup.
    """
    global _path_key, _points
    key = tuple(sys.path)
    with _lock:
        if _path_key != key:
            _path_key, _points = key, _scan()
            _loaded.clear()
            _problems.clear()
        wanted = [entry for entry in _points
                  if entry.name not in _loaded and (load_all or entry.name == only)]
    for entry in wanted:
        result = _load(entry)
        with _lock:
            _loaded.setdefault(entry.name, result)
    with _lock:
        found = {str(r.definition.kind): r for r in _loaded.values() if r is not None}
        return found, list(_problems)


def _scan() -> list[metadata.EntryPoint]:
    try:
        return list(metadata.entry_points(group=ENTRY_POINT_GROUP))
    except Exception as exc:  # noqa: BLE001 - a broken environment must not stop record reads
        logger.warning("could not read %s entry points: %s", ENTRY_POINT_GROUP, exc)
        return []


def _problem(message: str) -> None:
    logger.warning("%s", message)
    with _lock:
        _problems.append(message)


def _load(entry: metadata.EntryPoint) -> RegisteredKind | None:
    label = f"{entry.name} = {entry.value}"
    try:
        definition = entry.load()
        if isinstance(definition, type):
            definition = definition()
        _require_shape(definition)
    except Exception as exc:  # noqa: BLE001 - a broken package must not hide the other kinds
        _problem(f"study kind entry point {label} not loaded: {exc}")
        return None
    kind = str(definition.kind)
    if kind != entry.name:
        _problem(f"study kind entry point {label} ignored: its name must equal its kind '{kind}'")
        return None
    if kind in _builtins() and not getattr(definition, "replaces", False):
        _problem(f"study kind entry point {label} ignored: '{kind}' is a built-in kind; "
                 "set replaces = True to replace it")
        return None
    source = entry.dist.name if getattr(entry, "dist", None) is not None else entry.value
    return RegisteredKind(definition, source, builtin=False)


def _require_shape(definition: Any) -> None:
    kind = getattr(definition, "kind", None)
    if not isinstance(kind, str) or not all(part.isidentifier() for part in kind.split(".")):
        raise ValueError(f"a Study kind needs a kind name like 'sensitivity', not {kind!r}")
    if not getattr(definition, "title", None):
        raise ValueError(f"Study kind '{kind}' needs a title")


def _reset_for_tests() -> None:
    """Forget entry points and ``register_kind`` calls (tests only)."""
    global _path_key
    with _lock:
        _explicit.clear()
        _path_key = None
        _loaded.clear()
        _problems.clear()
