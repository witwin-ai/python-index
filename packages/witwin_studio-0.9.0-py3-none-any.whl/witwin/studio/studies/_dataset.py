"""Run a dataset Study: sample the Scene's parameters and export one sample per point.

The points come from the Study's method through ``BatchDriver``, the same
driver black-box optimize runs use, so budget, workers, failed points and
resume work the same way. Only ``explore`` methods are allowed (a dataset
has no loss to search on). The export function stages each sample
(``datasets._writer.SampleExport``) and ``DatasetWriter`` packs them into
``witwin.dataset.v1`` shards in ``dataset.dir``.

Before writing, ``.gitattributes`` gets the line that routes
``datasets/**/shards/**`` to Git LFS. A Project inside a git work tree
without a working git-lfs is refused (``lfs_unavailable``); outside git
nothing is checked.
"""
from __future__ import annotations

import dataclasses
import hashlib
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from .. import _git
from ..datasets._format import lfs_pattern_for
from ..datasets._writer import DROPPED_METRIC, DatasetWriter
from ._errors import ErrorCode, StudyError, invalid
from ._model import Study, StudyKind

if TYPE_CHECKING:
    from .._scene import Scene
    from ..optimize._records import EvalRecord
    from ..optimize._result import OptimizationResult

# Staged samples of a dataset Study, until a shard holds them; under the Project root.
STAGING_DIR = ".witwin/cache/datasets"


def staging_dir(project_root: Path, study_id: str) -> Path:
    """Where a dataset Study's Runs stage samples: ``.witwin/cache/datasets/<id>/staging``."""
    return Path(project_root) / STAGING_DIR / study_id / "staging"


def check_dataset(scene: "Scene", study: Study, project_root: Path) -> None:
    """Raise the ``StudyError`` ``run_dataset`` would raise before its first sample.

    The method must be an ``explore`` method; the variables are checked as for
    an optimize run; the Project needs a working git-lfs when it is a git
    repository. Runs no Project script.
    """
    from ..optimize._runner import check_study

    _require_explore(study)
    problem = _git.lfs_problem(Path(project_root))
    if problem is not None:
        raise StudyError(ErrorCode.LFS_UNAVAILABLE, f"datasets are stored with Git LFS: {problem}")
    check_study(scene, as_optimize(study), project_root=project_root)


def as_optimize(study: Study) -> Study:
    """The dataset Study as the optimize Study ``BatchDriver`` runs: the export is the objective."""
    if study.kind is not StudyKind.DATASET:
        raise invalid(f"study {study.id} is a {study.kind} Study, not dataset")
    return dataclasses.replace(study, kind=StudyKind.OPTIMIZE, objective=study.export, tensors={})


def run_dataset(scene: "Scene", study: Study, *, project_root: Path, run_id: str,
                output_dir: Path, resume_from: Path | str | None = None,
                on_evaluation: Callable[["EvalRecord"], None] | None = None,
                on_batch: Any = None, should_stop: Callable[[], bool] | None = None,
                on_driver: Callable[[Any], None] | None = None,
                on_progress: Any = None) -> tuple["OptimizationResult", dict[str, Any]]:
    """Run ``study`` and write its dataset; returns the run's result and the manifest.

    ``resume_from`` continues the Run that left that checkpoint: the shards
    it wrote stay, staged samples are packed, and the driver skips the
    points already evaluated. Without it the dataset folder starts over.
    Callbacks are those of ``optimize.run``. Raises ``StudyError`` as
    ``check_dataset`` and ``optimize.run`` do before the first sample.
    """
    from ..optimize._batch import EVALUATIONS_FILE, BatchDriver
    from ..optimize._objectives import resolve
    from ..optimize._report import EvaluationsLog
    from ..optimize._strategies import resolve as resolve_method

    root = Path(project_root)
    check_dataset(scene, study, root)
    settings = study.dataset
    assert settings is not None  # from_dict sets it for every dataset Study
    if _git.git_executable() is not None and _git.work_tree_root(root) is not None:
        _git.lfs_track(root, [lfs_pattern_for(settings.dir)])
    optimize = as_optimize(study)
    method = resolve_method(study.method.kind)
    fn = resolve(study.export, root)
    staging = staging_dir(root, study.id)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    driver = BatchDriver(scene, optimize, fn, root, method, project_dir=root, output_dir=output_dir,
                         resume_from=resume_from, sample_dir=staging)
    writer = DatasetWriter(root / settings.dir, staging, shard_size=settings.shard_size,
                           splits=settings.splits, variables=driver.space.names, seed=driver.setup.seed,
                           source={"study": study.id, "run_id": run_id, "scene": study.scene,
                                   "scene_sha256": _scene_hash(scene)},
                           resume=resume_from is not None)
    if on_driver is not None:
        on_driver(driver)
    log = EvaluationsLog(output_dir / EVALUATIONS_FILE)

    def record(evaluation: "EvalRecord") -> None:
        log.write(evaluation)
        if evaluation.status == "ok" and not evaluation.metrics.get(DROPPED_METRIC):
            writer.collect(evaluation.index)
        if on_evaluation is not None:
            on_evaluation(evaluation)

    try:
        result = driver.loop(record, on_batch, should_stop, on_progress)
    finally:
        log.close()
    result.evaluations_file = EVALUATIONS_FILE
    manifest = writer.close(complete=str(result.stopped_by) not in ("error", "stopped"))
    return result, manifest


def _require_explore(study: Study) -> None:
    from ..optimize._strategies import resolve as resolve_method
    from ..optimize._strategies.base import Family

    method = resolve_method(study.method.kind)
    if Family(method.family) is not Family.EXPLORE:
        raise invalid(f"a dataset Study samples with an Explore method (sweep, custom sweep, "
                      f"Monte Carlo); {method.title} searches for a best point")


# sha256 of the saved Scene file, so a dataset says which Scene version made it.
def _scene_hash(scene: "Scene") -> str | None:
    path = getattr(scene, "path", None)
    if path is None or not Path(path).is_file():
        return None
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
