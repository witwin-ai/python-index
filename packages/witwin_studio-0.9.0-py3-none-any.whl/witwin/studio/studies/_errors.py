"""Error codes of Studies (``witwin.studio.studies``) and the methods that run them."""
from __future__ import annotations

from enum import StrEnum


class ErrorCode(StrEnum):
    """Stable codes of ``StudyError``; they travel to the frontend, never rename one."""
    INVALID_STUDY = "invalid_study"              # a record field is missing or out of range
    STUDY_NOT_FOUND = "study_not_found"          # no studies/<id>.toml
    STUDY_EXISTS = "study_exists"                # add: studies/<id>.toml is already there
    PROJECT_NOT_FOUND = "project_not_found"      # process entry: no witwin.toml in that folder
    SCENE_NOT_FOUND = "scene_not_found"          # the Study's scene is not a saved Scene of the Project
    NO_VARIABLES = "no_variables"                # an optimize or dataset Study lists no variable
    VARIABLE_NOT_FOUND = "variable_not_found"    # a variable names no parameter of the Scene
    VARIABLE_NOT_FREE = "variable_not_free"      # a variable's formula reads other parameters
    BOUNDS_MISSING = "bounds_missing"            # the method needs lower and upper on every variable
    METHOD_NOT_FOUND = "method_not_found"        # no installed method has that kind
    METHOD_UNAVAILABLE = "method_unavailable"    # the method is listed but not implemented yet
    DEPENDENCY_MISSING = "dependency_missing"    # the method needs a package that is not installed
    OBJECTIVE_NOT_FOUND = "objective_not_found"  # script file, function or plugin id missing
    OBJECTIVE_FAILED = "objective_failed"        # the objective (or a dataset export) raised
    OBJECTIVE_NOT_DIFFERENTIABLE = "objective_not_differentiable"  # loss has no grad_fn
    OBJECTIVE_NOT_SCALAR = "objective_not_scalar"  # loss is not a single number
    OBJECTIVE_NOT_FINITE = "objective_not_finite"  # loss is NaN or infinite
    SCRIPT_NOT_FOUND = "script_not_found"        # train: the script is not a file in the Project
    LFS_UNAVAILABLE = "lfs_unavailable"          # dataset: the Project is a git repo without git-lfs
    TORCH_MISSING = "torch_missing"              # torch is not installed
    TENSORS_UNSUPPORTED = "tensors_unsupported"  # the Study has tensor variables; only gradient runs them
    CHECKPOINT_INVALID = "checkpoint_invalid"    # resume: no checkpoint, or it does not fit the Study
    INTERNAL = "internal"                        # process entry: an unexpected exception (a bug)


class StudyError(Exception):
    """A Study that cannot run, or a run that failed; ``code`` is an ``ErrorCode``.

    ``data`` carries details for the panel, e.g. ``{"variables": [...]}`` for
    ``bounds_missing``.
    """

    # Builds the error; message is plain English for display.
    def __init__(self, code: ErrorCode, message: str, **data: object) -> None:
        super().__init__(message)
        self.code = ErrorCode(code)
        self.message = message
        self.data = data

    # JSON-ready form, the ``error`` of a Run's result file.
    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"code": str(self.code), "message": self.message}
        if self.data:
            out["data"] = dict(self.data)
        return out


# StudyError(invalid_study) with ``message``.
def invalid(message: str) -> StudyError:
    return StudyError(ErrorCode.INVALID_STUDY, message)
