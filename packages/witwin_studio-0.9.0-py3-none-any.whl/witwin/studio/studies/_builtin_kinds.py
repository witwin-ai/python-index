"""The three built-in Study kinds: optimize, dataset and train (``_kinds`` registers them).

They join the registry like any package's kind; what is special about them is
only that their keys become typed ``Study`` fields instead of
``Study.settings``. ``optimize`` and ``dataset`` run in ``python -m
witwin.studio.studies`` (``run`` below); ``train`` runs its own Project
script, which Studio starts directly (``runner = "script"``).
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Mapping

from ._errors import ErrorCode, StudyError
from ._kinds import SCRIPT_RUNNER, RunContext, StudyKindDef
from ._model import (
    GRADIENT_KIND,
    ObjectiveRef,
    Study,
    StudyKind,
    _plain,
    _sampled_fields,
    _train_fields,
)

_SAMPLED_KEYS = frozenset({"scene", "variables", "method", "budget", "seed", "on_error"})


def _object(description: str) -> dict[str, Any]:
    return {"type": "object", "description": description}


def _string(description: str) -> dict[str, Any]:
    return {"type": "string", "description": description}


# Schema rows the Studies page and the Agent read; the checks themselves are in _model.
_SAMPLED_SCHEMA = {
    "scene": _string("Scene whose parameters the Study varies."),
    "variables": _object("Parameter name -> {lower?, upper?, step?, scale?, <method settings>}."),
    "method": _object("{kind, **settings}; the settings follow the method's settings_schema."),
    "budget": _object("{max_evals?, max_time_s?, parallel?}."),
    "seed": {"type": "integer", "minimum": 0, "description": "Seed of random methods; unset draws one per Run."},
    "on_error": {"type": "string", "enum": ["skip", "stop"], "description": "What a failed evaluation does."},
}


class _SampledKind(StudyKindDef):
    """optimize and dataset: vary Scene parameters with a method of ``witwin.studio.optimize``."""

    default_method = GRADIENT_KIND

    def parse(self, data: Mapping[str, Any], study_id: str, *, require_objective: bool) -> dict[str, Any]:
        return _sampled_fields(data, StudyKind(self.kind), study_id, require_objective)

    def record(self, study: Study) -> dict[str, Any]:
        record: dict[str, Any] = {"scene": study.scene}
        record.update(self._own_record(study))
        record["method"] = study.method.to_dict()
        budget = study.budget.to_dict()
        if budget:
            record["budget"] = budget
        if study.seed is not None:
            record["seed"] = study.seed
        record["on_error"] = str(study.on_error)
        if study.variables:
            record["variables"] = {name: _plain(settings) for name, settings in study.variables.items()}
        if study.tensors:
            record["tensors"] = {name: _plain(settings) for name, settings in study.tensors.items()}
        return record

    def _own_record(self, study: Study) -> dict[str, Any]:
        return {}

    def check(self, study: Study, project_root: Path) -> None:
        """Refuse a Run before it starts: its function or saved Scene does not fit.

        The objective (optimize) or export (dataset) must exist, then the saved
        Scene is checked as the Run will read it (the method, the variables).
        Runs no objective and no Project script.
        """
        root = Path(project_root)
        check_function(self._function(study), root)
        self._check_scene(scene_of_root(root, study), study, root)

    def _function(self, study: Study) -> ObjectiveRef | None:
        raise NotImplementedError

    def _check_scene(self, scene: Any, study: Study, root: Path) -> None:
        raise NotImplementedError

    def run(self, ctx: RunContext) -> Mapping[str, Any]:
        """Run the Study's method; returns ``OptimizationResult.to_dict()`` (dataset: plus ``dataset``)."""
        from ..optimize._batch import EVALUATIONS_FILE
        from ..optimize._records import EvalRecord, StepRecord
        from ..optimize._report import PartialBuffer
        from ..optimize._runner import run
        from ._dataset import run_dataset

        study, reporter = ctx.study, ctx.reporter
        buffer = PartialBuffer(reporter)
        driver: Any = None

        def on_step(record: StepRecord) -> None:
            total = int(study.method.settings["max_iters"])
            if study.budget.max_evals is not None:
                total = min(total, study.budget.max_evals)
            last = driver.start_step + total
            reporter.partial(record.to_dict())
            reporter.progress(driver.progress, f"step {record.step}/{last} loss {record.loss:.6g}")

        def on_evaluation(record: EvalRecord) -> None:
            if study.method.kind == GRADIENT_KIND:
                return  # on_step reports gradient steps
            buffer.add(record)

        def on_progress(index: int, outcome: Any) -> None:
            loss = "failed" if outcome.loss is None else f"loss {outcome.loss:.6g}"
            reporter.progress(driver.progress, f"evaluation {index} {loss}")

        def on_batch(batch: int, records: list[EvalRecord], summary: dict[str, Any]) -> None:
            buffer.end_batch(batch, summary)

        def keep_driver(found: Any) -> None:
            nonlocal driver
            driver = found

        scene = scene_of(ctx.project, study)
        project_root = ctx.project.root
        if study.kind == StudyKind.DATASET:
            try:
                result, manifest = run_dataset(
                    scene, study, project_root=project_root, run_id=ctx.run_id, output_dir=ctx.out,
                    resume_from=ctx.resume_from, on_evaluation=on_evaluation, on_batch=on_batch,
                    should_stop=ctx.should_stop, on_driver=keep_driver, on_progress=on_progress)
            finally:
                buffer.flush()
            payload = result.to_dict()
            payload["dataset"] = {"dir": study.dataset.dir, "samples": manifest["samples"],
                                  "shards": len(manifest["shards"]), "skipped": manifest.get("skipped", 0),
                                  "complete": manifest["complete"]}
            return payload
        try:
            result = run(scene, study, project_root=project_root, on_step=on_step,
                         should_stop=ctx.should_stop, on_evaluation=on_evaluation, on_batch=on_batch,
                         evaluations_file=ctx.out / EVALUATIONS_FILE, on_driver=keep_driver,
                         output_dir=ctx.out, resume_from=ctx.resume_from, on_progress=on_progress)
        finally:
            buffer.flush()
        return result.to_dict()


class OptimizeKind(_SampledKind):
    kind = StudyKind.OPTIMIZE
    title = "Optimize"
    description = "Vary Scene parameters to minimize or maximize an objective."
    icon = "target"
    keys = _SAMPLED_KEYS | {"direction", "objective", "tensors"}
    record_schema = {"type": "object", "properties": {
        **_SAMPLED_SCHEMA,
        "direction": {"type": "string", "enum": ["minimize", "maximize"]},
        "objective": _object("{kind: 'script', path, function} or {kind: 'plugin', id, args}."),
        "tensors": _object("Tensor design variables: id -> {shape, init, value, lower, upper, label, transforms}."),
    }}
    starter = {"objective": {"kind": "script", "path": "scripts/objective.py", "function": "objective"}}
    default_method = GRADIENT_KIND

    def _own_record(self, study: Study) -> dict[str, Any]:
        record: dict[str, Any] = {"direction": str(study.direction)}
        if study.objective is not None:
            record["objective"] = study.objective.to_dict()
        return record

    def _function(self, study: Study) -> ObjectiveRef | None:
        return study.objective

    def _check_scene(self, scene: Any, study: Study, root: Path) -> None:
        # Read at call time, so a test or Plugin that patches it is honoured.
        from .. import optimize

        optimize.check_study(scene, study, project_root=root)


class DatasetKind(_SampledKind):
    kind = StudyKind.DATASET
    title = "Dataset"
    description = "Sample Scene parameters and export one sample per point into a dataset folder."
    icon = "database"
    keys = _SAMPLED_KEYS | {"export", "dataset"}
    record_schema = {"type": "object", "properties": {
        **_SAMPLED_SCHEMA,
        "export": _object("The function that turns one sample into arrays: {kind: 'script', path, function}."),
        "dataset": _object("{dir, shard_size, splits}."),
    }}
    starter = {"export": {"kind": "script", "path": "scripts/export.py", "function": "export"}}
    default_method = "monte_carlo"

    def _own_record(self, study: Study) -> dict[str, Any]:
        return {"export": study.export.to_dict() if study.export is not None else None,
                "dataset": study.dataset.to_dict() if study.dataset is not None else None}

    def _function(self, study: Study) -> ObjectiveRef | None:
        return study.export

    def _check_scene(self, scene: Any, study: Study, root: Path) -> None:
        from ._dataset import check_dataset

        check_dataset(scene, study, root)


class TrainKind(StudyKindDef):
    kind = StudyKind.TRAIN
    title = "Train"
    description = "Run a Project script that trains a model and logs its metrics."
    icon = "brain"
    keys = frozenset({"script", "args", "inputs", "metric"})
    record_schema = {"type": "object", "properties": {
        "script": _string("Training script, relative to the Project."),
        "args": _object("Script arguments: --name value and ws.config()."),
        "inputs": _object("Name -> Project path the script reads (a dataset)."),
        "metric": _object("{name, direction}: the logged metric that ranks the Runs."),
    }}
    default_gpus = 1
    runner = SCRIPT_RUNNER
    starter = {"script": "scripts/train.py"}

    def parse(self, data: Mapping[str, Any], study_id: str, *, require_objective: bool) -> dict[str, Any]:
        return _train_fields(data)

    def record(self, study: Study) -> dict[str, Any]:
        record: dict[str, Any] = {"script": study.script}
        if study.args:
            record["args"] = _plain(study.args)
        if study.inputs:
            record["inputs"] = dict(study.inputs)
        if study.metric is not None:
            record["metric"] = study.metric.to_dict()
        return record

    def run(self, ctx: RunContext) -> Mapping[str, Any]:
        raise StudyError(ErrorCode.INVALID_STUDY,
                         f"Study '{ctx.study.id}' is a train Study; run its script ({ctx.study.script}) instead")


def scene_of(project: Any, study: Study) -> Any:
    """The saved Scene ``study.scene`` names; raises ``scene_not_found``."""
    try:
        return project.scene(study.scene)
    except KeyError:
        raise StudyError(ErrorCode.SCENE_NOT_FOUND,
                         f"no saved scene '{study.scene}' in {project.root}") from None


def scene_of_root(root: Path, study: Study) -> Any:
    """The saved Scene ``study.scene`` of the Project at ``root``; raises ``scene_not_found``."""
    from .. import open_project  # witwin.studio imports this module

    return scene_of(open_project(root), study)


def check_function(function: ObjectiveRef | None, root: Path) -> None:
    """Raise ``objective_not_found`` unless the script file is in the Project or a Plugin registers the id."""
    if function is None:
        raise StudyError(ErrorCode.OBJECTIVE_NOT_FOUND, "the Study names no objective")
    if function.kind == "plugin":
        from .. import optimize

        if function.id not in {row["id"] for row in optimize.list_objectives()}:
            raise StudyError(ErrorCode.OBJECTIVE_NOT_FOUND,
                             f"no installed plugin registers the objective '{function.id}'",
                             objective_id=function.id)
        return
    path = function.path or ""
    target = (root.resolve() / path).resolve()
    if not path or not target.is_file() or not target.is_relative_to(root.resolve()):
        raise StudyError(ErrorCode.OBJECTIVE_NOT_FOUND, f"script '{path}' is not a file in the Project", path=path)


def run_id(out: Any) -> str:
    """The Studio Run id (``WITWIN_RUN_ID``), else the Run folder's name."""
    return os.environ.get("WITWIN_RUN_ID") or getattr(out, "name", "")


# kind -> definition, in the order the New Study dialog shows them.
BUILTIN_KINDS: dict[str, StudyKindDef] = {
    StudyKind.OPTIMIZE: OptimizeKind(),
    StudyKind.DATASET: DatasetKind(),
    StudyKind.TRAIN: TrainKind(),
}
