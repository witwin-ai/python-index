"""Result record files: ``<project>/.witwin/results/history/v<N>.json``.

One committed Results-panel version per file, written by the ProjectServer's
Results feature and read back on startup. ``witwin_server.persistence`` calls
these helpers so the file naming and JSON shape have one owner (decision D11).
Visible ``<project>/results/`` is only an export target; it is never read here.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional

HISTORY_PARTS = (".witwin", "results", "history")
BLOBS_PARTS = (".witwin", "results", "blobs")

# Exactly ``v<number>.json``, so a stray file such as ``velocity.json`` in the
# history folder is never loaded or deleted as a version.
_VERSION_FILE = re.compile(r"v\d+\.json")

_KNOWN_KEYS = ("version", "message", "plots", "timestamp", "scene_id", "tag", "tag_color")


def history_dir(project_root: Path) -> Path:
    return Path(project_root).joinpath(*HISTORY_PARTS)


def version_file(results_dir: Path, version: int) -> Path:
    return Path(results_dir) / f"v{int(version)}.json"


def version_files(results_dir: Path) -> List[Path]:
    results_dir = Path(results_dir)
    if not results_dir.exists():
        return []
    return [path for path in results_dir.glob("v*.json")
            if path.is_file() and _VERSION_FILE.fullmatch(path.name)]


def write_record(results_dir: Path, data: Dict[str, Any]) -> Optional[Path]:
    """Write one version record; returns None (writes nothing) without ``version``."""
    version = data.get("version")
    if version is None:
        return None
    results_dir = Path(results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    path = version_file(results_dir, version)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return path


def read_history(
    results_dirs: Iterable[Path],
    on_error: Optional[Callable[[Path, Exception], None]] = None,
) -> Dict[int, Dict[str, Any]]:
    """All version records keyed by version, oldest first.

    ``results_dirs`` is read in order and a later folder wins for the same
    version. An unreadable file is skipped and reported to ``on_error``.
    """
    history: Dict[int, Dict[str, Any]] = {}
    for results_dir in results_dirs:
        for path in version_files(results_dir):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                version = data.get("version")
                if version is not None:
                    history[int(version)] = data
            except (OSError, ValueError) as exc:
                if on_error is not None:
                    on_error(path, exc)
    return dict(sorted(history.items()))


def delete_version(results_dirs: Iterable[Path], version: int) -> bool:
    deleted = False
    for results_dir in results_dirs:
        path = version_file(results_dir, version)
        if path.exists():
            path.unlink()
            deleted = True
    return deleted


@dataclass
class ResultRecord:
    """One committed Results-panel version.

    ``plots`` holds the serialized plot entries exactly as the Results panel
    stores them. Keys this class does not model are kept in ``extra`` and
    written back unchanged.
    """

    version: int
    message: str = ""
    plots: List[Dict[str, Any]] = field(default_factory=list)
    timestamp: Optional[str] = None
    scene_id: Optional[str] = None
    tag: Optional[str] = None
    tag_color: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ResultRecord":
        return cls(
            version=int(data["version"]),
            message=str(data.get("message") or ""),
            plots=list(data.get("plots") or []),
            timestamp=data.get("timestamp"),
            scene_id=data.get("scene_id"),
            tag=data.get("tag"),
            tag_color=data.get("tag_color"),
            extra={k: v for k, v in data.items() if k not in _KNOWN_KEYS},
        )

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "version": self.version,
            "message": self.message,
            "plots": list(self.plots),
            "timestamp": self.timestamp,
            "scene_id": self.scene_id,
        }
        # The server writes tag fields only for tagged commits; keep that shape.
        if self.tag:
            data["tag"] = self.tag
            data["tag_color"] = self.tag_color
        data.update(self.extra)
        return data


# --------------------------------------------------------------------------- #
# Writing records from code (witwin.result.v1, dev_docs/witwin-result-v1.md)
# --------------------------------------------------------------------------- #
SCHEMA = "witwin.result.v1"


def next_version(project_root: Path) -> int:
    """One more than the highest version in ``.witwin/results/history``.

    The ProjectServer numbers its commits the same way at startup. While a
    server is running it owns the numbering, so code writes through it instead
    (``witwin.studio.solver`` attaches when ``.witwin/runtime/server.json`` is live).
    """
    history = read_history((history_dir(project_root),))
    return (max(history) if history else 0) + 1


def text_plot(content: str, *, title: Optional[str] = None, format: str = "markdown") -> Dict[str, Any]:
    """A Results-panel text entry, the shape ``Figure.text`` produces in the server."""
    from datetime import datetime

    entry: Dict[str, Any] = {
        "type": "text",
        "data": {"content": content, "format": format},
        "timestamp": datetime.now().isoformat(),
    }
    if title:
        entry["title"] = title
    return entry
