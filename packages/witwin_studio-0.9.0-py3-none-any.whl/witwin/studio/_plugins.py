"""Plugins installed in a Project's Python environment, found statically.

A Project with a ``pyproject.toml`` is a Python codebase (decision D11). Its
Plugins are pip distributions that declare their root through a
``witwin.plugins`` entry point. This module finds them without importing
anything and without starting the Project interpreter: it reads
``*.dist-info/entry_points.txt``, PEP 610 ``direct_url.json``, setuptools'
editable finder files and ``.pth`` lines. The ProjectServer's ``environment``
Plugin source (``witwin_server.plugins.environment``) and headless solves
(``witwin.studio.solver.client``) both use it.
"""
from __future__ import annotations

import ast
import configparser
import json
import logging
import os
import re
import site
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional
from urllib.parse import unquote, urlparse

from ._environment import PROJECT_PYTHON_ENV, project_venv, venv_interpreter

logger = logging.getLogger("witwin.studio.plugins")

ENTRY_POINT_GROUP = "witwin.plugins"
MANIFEST_FILENAME = "witwin.toml"
_venv_python = venv_interpreter


@dataclass(frozen=True)
class EnvironmentPlugin:
    """One ``witwin.plugins`` entry point found in the Project environment."""

    plugin_id: str
    module: str
    root: Path
    distribution: str
    version: str


# One resolver for every launcher, owned by witwin.studio so headless solves
# agree with the ProjectServer (Scripts, Runs, ${project:python} children).
def is_python_project(project_dir: Path) -> bool:
    """A Project opts into the ``environment`` source by having ``pyproject.toml``.

    Folders with only ``witwin.toml`` stay in legacy mode (Plugins from
    ``lock.json`` and local paths), as section 4 of the design requires.
    """
    return (Path(project_dir) / "pyproject.toml").is_file()


def _site_packages_for_interpreter(python: Path) -> list[Path]:
    """Site directories of an interpreter, derived from its file layout."""
    python = Path(python)
    bases = [python.parent, python.parent.parent]
    found: list[Path] = []
    for base in bases:
        if os.name == "nt":
            candidates = [base / "Lib" / "site-packages"]
        else:
            candidates = sorted((base / "lib").glob("python3*/site-packages"))
        found.extend(item for item in candidates if item.is_dir())
    return found


def environment_site_dirs(project_dir: Path) -> list[Path]:
    """Site directories of the Project environment, most specific first."""
    explicit = os.environ.get(PROJECT_PYTHON_ENV, "").strip()
    if explicit and Path(explicit).is_file():
        return _dedupe(_site_packages_for_interpreter(Path(explicit)))
    venv = project_venv(Path(project_dir))
    if venv is not None:
        return _dedupe(_site_packages_for_interpreter(_venv_python(venv)))
    # No Project environment: the ProjectServer's own interpreter is the
    # "configured one" (the Python Environment dialog picks it).
    dirs = [Path(item) for item in site.getsitepackages()]
    user_site = site.getusersitepackages()
    if user_site:
        dirs.append(Path(user_site))
    return _dedupe([item for item in dirs if item.is_dir()])


def _dedupe(paths: Iterable[Path]) -> list[Path]:
    seen: set[str] = set()
    out: list[Path] = []
    for path in paths:
        key = os.path.normcase(str(path.resolve()))
        if key not in seen:
            seen.add(key)
            out.append(path)
    return out


def _read_entry_points(dist_info: Path) -> dict[str, str]:
    path = dist_info / "entry_points.txt"
    if not path.is_file():
        return {}
    parser = configparser.ConfigParser(delimiters=("=",), interpolation=None)
    parser.optionxform = str  # Plugin ids are case-sensitive.
    try:
        parser.read_string(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, configparser.Error):
        return {}
    if not parser.has_section(ENTRY_POINT_GROUP):
        return {}
    return {name.strip(): value.strip() for name, value in parser.items(ENTRY_POINT_GROUP)}


def _dist_name_version(dist_info: Path) -> tuple[str, str]:
    stem = dist_info.name[: -len(".dist-info")]
    name, _, version = stem.partition("-")
    return name, version


def _editable_project_dir(dist_info: Path) -> Optional[Path]:
    """The source tree of an editable install, from PEP 610 ``direct_url.json``."""
    path = dist_info / "direct_url.json"
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not (data.get("dir_info") or {}).get("editable"):
        return None
    url = urlparse(str(data.get("url") or ""))
    if url.scheme != "file":
        return None
    raw = unquote(url.path)
    # file:///E:/x -> "/E:/x" on Windows.
    if os.name == "nt" and len(raw) > 2 and raw[0] == "/" and raw[2] == ":":
        raw = raw[1:]
    if url.netloc and url.netloc != "localhost":
        raw = f"//{url.netloc}{raw}"
    return Path(raw)


def _setuptools_editable_mapping(site_dir: Path) -> dict[str, str]:
    """``MAPPING`` literals from setuptools' ``__editable___*_finder.py`` files.

    Parsed with ``ast.literal_eval``; the finder module is never executed.
    """
    mapping: dict[str, str] = {}
    for finder in site_dir.glob("__editable___*_finder.py"):
        try:
            tree = ast.parse(finder.read_text(encoding="utf-8"))
        except (OSError, SyntaxError, UnicodeDecodeError):
            continue
        for node in tree.body:
            target = None
            if isinstance(node, ast.Assign) and len(node.targets) == 1:
                target = node.targets[0]
            elif isinstance(node, ast.AnnAssign):
                target = node.target
            if isinstance(target, ast.Name) and target.id == "MAPPING" and node.value is not None:
                try:
                    value = ast.literal_eval(node.value)
                except ValueError:
                    continue
                if isinstance(value, dict):
                    mapping.update({str(k): str(v) for k, v in value.items()})
    return mapping


def _pth_paths(site_dir: Path) -> list[Path]:
    """Plain directory lines of ``.pth`` files (uv, hatch and flit editables)."""
    paths: list[Path] = []
    for pth in site_dir.glob("*.pth"):
        try:
            lines = pth.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError):
            continue
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("import "):
                continue
            candidate = Path(line)
            if not candidate.is_absolute():
                candidate = site_dir / candidate
            paths.append(candidate)
    return paths


def _is_plugin_root(path: Path) -> bool:
    return (path / MANIFEST_FILENAME).is_file()


def _resolve_root(
    module: str,
    site_dir: Path,
    dist_info: Path,
    editable_mapping: dict[str, str],
    pth_paths: list[Path],
) -> Optional[Path]:
    parts = module.split(".")
    candidates: list[Path] = [site_dir.joinpath(*parts)]
    top = parts[0]
    if top in editable_mapping:
        candidates.append(Path(editable_mapping[top]).joinpath(*parts[1:]))
    project = _editable_project_dir(dist_info)
    if project is not None:
        candidates += [project.joinpath(*parts), project / "src" / Path(*parts)]
        if len(parts) == 1:
            # Flat Plugin repos: the repository root is the package itself.
            candidates.append(project)
    candidates += [base.joinpath(*parts) for base in pth_paths]
    for candidate in candidates:
        if _is_plugin_root(candidate):
            return candidate
    return None


def discover_environment_plugins(project_dir: Path, *, require_pyproject: bool = True) -> list[EnvironmentPlugin]:
    """All ``witwin.plugins`` entry points installed in the Project environment.

    Returns nothing for a Project without ``pyproject.toml`` unless
    ``require_pyproject`` is False (headless solves look regardless). Unresolvable entry
    points are logged and skipped; one broken distribution never hides others.
    """
    project_dir = Path(project_dir)
    if require_pyproject and not is_python_project(project_dir):
        return []
    plugins: list[EnvironmentPlugin] = []
    seen_ids: set[str] = set()
    for site_dir in environment_site_dirs(project_dir):
        editable_mapping = _setuptools_editable_mapping(site_dir)
        pth_paths = _pth_paths(site_dir)
        for dist_info in sorted(site_dir.glob("*.dist-info"), key=lambda p: p.name.lower()):
            entry_points = _read_entry_points(dist_info)
            if not entry_points:
                continue
            distribution, version = _dist_name_version(dist_info)
            for plugin_id, target in entry_points.items():
                module = target.split(":", 1)[0].strip()
                if not plugin_id or not module or plugin_id in seen_ids:
                    continue
                root = _resolve_root(module, site_dir, dist_info, editable_mapping, pth_paths)
                if root is None:
                    logger.warning(
                        f"witwin.plugins entry point {plugin_id} = {target} in {distribution} "
                        f"has no {MANIFEST_FILENAME}; skipped"
                    )
                    continue
                seen_ids.add(plugin_id)
                plugins.append(EnvironmentPlugin(plugin_id, module, root, distribution, version))
    return plugins


def environment_has_distribution(project_dir: Path, requirement: str) -> bool:
    """True when the Project environment has a distribution for ``requirement``.

    Only the name is compared (no version or extras): this answers "will the
    solver child find it", and ``uv sync`` already enforced the specifier.
    """
    name = _normalize(re.split(r"[\s\[<>=!~;]", requirement.strip(), maxsplit=1)[0])
    if not name:
        return False
    for site_dir in environment_site_dirs(Path(project_dir)):
        for dist_info in site_dir.glob("*.dist-info"):
            if _normalize(_dist_name_version(dist_info)[0]) == name:
                return True
    return False


def _normalize(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()
