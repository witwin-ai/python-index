"""Slug ids for scenes and scene objects (SCENE_DESIGN.md §13), and short ids.

The single slug allocator. ``witwin_server.core.ids`` re-exports these, so the
editor and ``witwin.studio`` give a new object the same id for the same name.
Slugs are frozen on creation: renaming an object changes its display name only.

``short_id`` lives here too because a script run without Studio names its own
Run (``witwin.studio.tracking``) and that id must look like one the server gives.
"""
from __future__ import annotations

import re
import secrets
from typing import Iterable

# Lowercase alphanumerics + underscore. ``:`` and ``/`` are reserved for
# synthetic ids (``ref:<inst>/<target>``) and paths (§14.4).
_SLUG_RE = re.compile(r"[^a-z0-9_]+")
_DEDUP_RE = re.compile(r"^(?P<base>.*?)(?:_(?P<n>\d+))?$")


def slugify(text: str, *, fallback: str = "entity") -> str:
    """Turn an arbitrary display name into a bare slug.

    ``"Reflector Dish"`` -> ``"reflector_dish"``. Collapses runs of disallowed
    characters into a single underscore, trims leading/trailing underscores, and
    falls back to ``fallback`` when nothing usable remains (e.g. a CJK-only
    name, which the ``[a-z0-9_]`` set cannot represent).
    """
    base = _SLUG_RE.sub("_", (text or "").strip().lower())
    base = base.strip("_")
    # A leading digit is legal in TOML bare keys but reads awkwardly as an id;
    # keep it simple and only guard the empty case.
    return base or fallback


def unique_slug(desired: str, existing: Iterable[str], *, fallback: str = "entity") -> str:
    """Return a slug derived from ``desired`` that is not already in ``existing``.

    The first object named "Dish" becomes ``dish``; a second becomes ``dish_2``,
    a third ``dish_3`` (§13.1). If ``desired`` already ends in ``_<n>`` the
    numbering continues from there rather than appending a second suffix.
    """
    taken = set(existing)
    slug = slugify(desired, fallback=fallback)
    if slug not in taken:
        return slug

    m = _DEDUP_RE.match(slug)
    base = m.group("base") if m else slug
    base = base or fallback
    n = int(m.group("n")) + 1 if (m and m.group("n")) else 2
    while True:
        candidate = f"{base}_{n}"
        if candidate not in taken:
            return candidate
        n += 1


# Lowercase Crockford Base32 alphabet (excludes ``i``, ``l``, ``o``, ``u``).
_CROCKFORD32 = "0123456789abcdefghjkmnpqrstvwxyz"


def _base32_crockford_lower(b: bytes, *, length: int) -> str:
    """Encode bytes as lowercase Crockford Base32, left-padded to ``length``."""
    n = int.from_bytes(b, "big")
    chars: list[str] = []
    for _ in range(length):
        chars.append(_CROCKFORD32[n & 0x1F])
        n >>= 5
    chars.reverse()
    return "".join(chars)


def short_id(prefix: str, n: int = 6) -> str:
    """Tier-2 id ``{prefix}_{n Crockford base32 chars}`` (dev_docs/ID_DESIGN.md §6).

    For ids the agent sees inside one Project or Session (runs, todos, ...):
    6 chars (32**6, about 10**9) is safe up to about 10**4 ids per scope.
    """
    return f"{prefix}_{_base32_crockford_lower(secrets.token_bytes((5 * n + 7) // 8), length=n)}"
