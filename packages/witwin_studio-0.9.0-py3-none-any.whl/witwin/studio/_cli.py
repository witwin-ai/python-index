"""The ``witwin`` command: work with a Project from a terminal, without the editor.

    witwin init [PATH] [--name NAME]   make PATH a Project and a Python project
    witwin check [PATH]                validate the Project files (exit 1 on errors)
    witwin run SCRIPT [ARGS...]        run a Script with the Project on sys.path
    witwin open [PATH]                 open the Project in WiTwin Studio
    witwin add SPEC [--project PATH]   add a Plugin from the witwin index, a git URL
                                       or a folder, then sync the environment
    witwin solve SOLVER [--scene ID]   run a Plugin solver headless and record a Result
                                       (attaches to a running ProjectServer if any)
    witwin workflow list               list the Workflows in tasks/
    witwin template list [--plugin-root ID=PATH]
                                       list Project templates and verify their content
    witwin template create ID --parent DIR [--name NAME]
                                       make a new Project folder from a template
    witwin workflow run ID [--param K=V]
                                       run a Workflow (in the running ProjectServer if
                                       any, else here; agent steps need the server)
    witwin gallery create ID --version N --dest DIR [--name NAME]
                                       make a new Project from a Gallery item
    witwin gallery fetch ID --version N
                                       download a Gallery item to ~/.witwin/gallery-cache

Other installed packages add subcommands through the ``witwin.cli`` entry-point
group: ``witwin-server`` adds ``host``, ``login``, ``logout`` and ``whoami``.

PATH defaults to the nearest folder at or above the current one that holds
``witwin.toml`` (``init`` defaults to the current folder).
"""
from __future__ import annotations

import argparse
import json
import os
import runpy
import shutil
import subprocess
import sys
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

from . import wtscene
from ._git import git_state
from ._gitignore import missing_required_patterns, read_gitignore
from ._manifest import MANIFEST_NAME, ensure_witwin_project, read_project_table, read_witwin_project
from ._scaffold import PYPROJECT, PYTHON_IGNORE_PATTERNS, STUDIO_DISTRIBUTION, python_project_status, scaffold_project

# Studio reads this variable at startup and opens that Project
# (studio/electron/main.ts). A running Studio keeps its own Project: the second
# instance only brings the window forward.
START_PROJECT_ENV = "WITWIN_START_PROJECT"
STUDIO_EXE_ENV = "WITWIN_STUDIO_EXE"


def find_project_root(start: Path) -> Optional[Path]:
    start = start.resolve()
    for folder in (start, *start.parents):
        if (folder / MANIFEST_NAME).is_file():
            return folder
    return None


def _project_arg(path: Optional[str]) -> Path:
    if path:
        root = Path(path).resolve()
        if not (root / MANIFEST_NAME).is_file():
            raise SystemExit(f"error: not a WiTwin Project (no {MANIFEST_NAME}): {root}")
        return root
    root = find_project_root(Path.cwd())
    if root is None:
        raise SystemExit(f"error: no {MANIFEST_NAME} in {Path.cwd()} or any parent folder")
    return root


# --------------------------------------------------------------------------- #
# init
# --------------------------------------------------------------------------- #
def cmd_init(args: argparse.Namespace) -> int:
    root = Path(args.path or ".").resolve()
    # Only a Project made from nothing starts as a git repository; running
    # `witwin init` in a folder with content leaves git to the user.
    fresh = not root.exists() or (root.is_dir() and not any(root.iterdir()))
    # Write the Python files below, after the name is set, so they carry it.
    ensure_witwin_project(root, scaffold_new=False)
    if args.name:
        from ._manifest import set_project_name

        set_project_name(root, args.name)
    result = scaffold_project(root, name=args.name, init_git=fresh)
    for name in result.written:
        print(f"created  {name}")
    for name in result.updated:
        print(f"updated  {name}")
    if result.git is not None:
        print(f"git      {result.git.summary()}")
    for problem in result.problems:
        print(f"warning: {problem}", file=sys.stderr)
    if not result.changed:
        print(f"{root} is already a Python project")
    return 0


# --------------------------------------------------------------------------- #
# check
# --------------------------------------------------------------------------- #
def check_project(root: Path) -> List[Tuple[str, str]]:
    """``(level, message)`` findings; level is ``error`` or ``warning``."""
    findings: List[Tuple[str, str]] = []
    try:
        read_witwin_project(root)
    except (OSError, ValueError) as exc:
        return [("error", f"{MANIFEST_NAME}: {exc}")]

    scene_ids: dict[str, Path] = {}
    scenes_dir = root / "scenes"
    for path in sorted(scenes_dir.rglob("*.wtscene")) if scenes_dir.is_dir() else []:
        rel = path.relative_to(root).as_posix()
        try:
            doc = wtscene.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001 - report every unreadable scene
            findings.append(("error", f"{rel}: cannot be read ({exc})"))
            continue
        scene_id = doc.get("scene_id")
        if scene_id in scene_ids:
            findings.append(("warning", f"{rel}: scene id {scene_id!r} is also used by "
                                        f"{scene_ids[scene_id].relative_to(root).as_posix()}; Studio uses the first"))
        else:
            scene_ids[scene_id] = path
        for oid, obj in doc.get("objects", {}).items():
            parent = obj.get("parent_id") or "root"
            if parent != "root" and parent not in doc["objects"]:
                findings.append(("warning", f"{rel}: entity {oid!r} has missing parent {parent!r}"))

    main = str(read_project_table(root).get("main_scene") or "").strip()
    if main and main not in scene_ids:
        findings.append(("warning", f"{MANIFEST_NAME}: main_scene {main!r} has no scene file"))

    status = python_project_status(root)
    if not status["pyproject"]:
        findings.append(("warning", f"no {PYPROJECT}: run `witwin init` to make this a Python project"))
    elif not status["studio_dependency"]:
        findings.append(("warning", f"{PYPROJECT} does not depend on {STUDIO_DISTRIBUTION}"))
    for problem in status["problems"]:
        findings.append(("error" if "not valid TOML" in problem else "warning", problem))
    content, present = read_gitignore(root)
    missing = missing_required_patterns(content, PYTHON_IGNORE_PATTERNS) if present else list(PYTHON_IGNORE_PATTERNS)
    if missing:
        findings.append(("warning", f".gitignore does not ignore {', '.join(missing)}"))
    return findings


def cmd_check(args: argparse.Namespace) -> int:
    root = _project_arg(args.path)
    findings = check_project(root)
    for level, message in findings:
        print(f"{level}: {message}")
    errors = sum(1 for level, _ in findings if level == "error")
    # Information, not a finding: a Project outside git is valid.
    print(f"git: {git_state(root)}")
    if not findings:
        print(f"{root}: OK")
    return 1 if errors else 0


# --------------------------------------------------------------------------- #
# run
# --------------------------------------------------------------------------- #
def cmd_run(args: argparse.Namespace) -> int:
    script = Path(args.script).resolve()
    if not script.is_file():
        raise SystemExit(f"error: script not found: {args.script}")
    root = _project_arg(args.project) if args.project else (find_project_root(script.parent) or find_project_root(Path.cwd()))
    if root is None:
        raise SystemExit(f"error: {script} is not inside a WiTwin Project")
    # Like `python script.py`, the script's folder comes first; then the Project
    # root and src/, so a Script can import the Project's own modules.
    for entry in reversed([str(script.parent), str(root), str(root / "src")]):
        if entry not in sys.path:
            sys.path.insert(0, entry)
    os.chdir(root)
    sys.argv = [str(script), *args.args]
    runpy.run_path(str(script), run_name="__main__")
    return 0


# --------------------------------------------------------------------------- #
# open
# --------------------------------------------------------------------------- #
def studio_executable() -> Optional[Path]:
    override = os.environ.get(STUDIO_EXE_ENV)
    if override:
        return Path(override)
    candidates: List[Path] = []
    if sys.platform == "win32":
        local = os.environ.get("LOCALAPPDATA")
        if local:
            candidates.append(Path(local) / "Programs" / "WiTwin Studio" / "WiTwin Studio.exe")
    elif sys.platform == "darwin":
        candidates.append(Path("/Applications/WiTwin Studio.app/Contents/MacOS/WiTwin Studio"))
    else:
        found = shutil.which("witwin-studio")
        if found:
            candidates.append(Path(found))
    return next((path for path in candidates if path.is_file()), None)


def cmd_open(args: argparse.Namespace) -> int:
    root = _project_arg(args.path)
    exe = studio_executable()
    if exe is None:
        print(f"error: WiTwin Studio was not found; set {STUDIO_EXE_ENV} to its executable", file=sys.stderr)
        return 1
    env = dict(os.environ, **{START_PROJECT_ENV: str(root)})
    kwargs: dict = {"env": env, "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if sys.platform == "win32":
        kwargs["creationflags"] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen([str(exe)], **kwargs)
    print(f"opening {root} in WiTwin Studio")
    return 0


# --------------------------------------------------------------------------- #
# add
# --------------------------------------------------------------------------- #
def cmd_add(args: argparse.Namespace) -> int:
    from ._dependencies import WITWIN_INDEX_URL, add_plugin

    root = _project_arg(args.project)
    # uv prints box-drawing characters; a legacy console code page (GBK,
    # cp1252) must not turn them into a failed install.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")

    def emit(line: str) -> None:
        print(json.dumps({"event": "line", "text": line}) if args.json else line, flush=True)

    result = add_plugin(
        root, args.spec,
        tag=args.tag, rev=args.rev, branch=args.branch, editable=not args.no_editable,
        index_url=args.index_url or WITWIN_INDEX_URL, uv=args.uv, python=args.python,
        sync=not args.no_sync, on_line=emit,
    )
    if args.json:
        print(json.dumps({
            "event": "result", "ok": result.ok, "handled": result.handled,
            "requirement": result.requirement, "pinned": result.pinned, "error": result.error,
        }), flush=True)
    elif result.ok:
        print(f"added {result.requirement or args.spec} to {root / PYPROJECT}")
    else:
        print(f"error: {result.error}", file=sys.stderr)
    return 0 if result.ok else 1


# --------------------------------------------------------------------------- #
# template
# --------------------------------------------------------------------------- #
def _template_sources(args: argparse.Namespace):
    """Sources from ``--spec`` (JSON file, ``-`` for stdin) plus ``--plugin-root ID=PATH``."""
    from ._templates import TemplateError, load_spec

    spec: dict = {}
    if args.spec:
        text = sys.stdin.read() if args.spec == "-" else Path(args.spec).read_text(encoding="utf-8")
        try:
            spec = json.loads(text) if text.strip() else {}
        except ValueError as exc:
            raise TemplateError(f"--spec is not JSON: {exc}") from None
        if not isinstance(spec, dict):
            raise TemplateError("--spec must be a JSON object")
    plugins = dict(spec.get("plugins") or {})
    for item in args.plugin_root or []:
        plugin_id, sep, root = item.partition("=")
        if not sep or not plugin_id or not root:
            raise TemplateError(f"--plugin-root wants ID=PATH, got {item!r}")
        plugins.setdefault(plugin_id, root)
    return load_spec({**spec, "plugins": plugins})


def cmd_template_list(args: argparse.Namespace) -> int:
    from ._templates import TemplateError, describe_sources

    try:
        records = describe_sources(_template_sources(args))
    except (TemplateError, OSError) as exc:
        return _template_error(args, str(exc))
    if args.json:
        print(json.dumps({"ok": True, "templates": records}))
        return 0
    if not records:
        print("no templates (pass --plugin-root ID=PATH for each Plugin)")
    for record in records:
        state = "ready" if record["status"] == "ready" else f"invalid: {record['error']}"
        owner = f" ({record['plugin_id']})" if record["plugin_id"] else ""
        print(f"{record['id']}{owner}: {record['title']} - {state}")
    return 0


def cmd_template_create(args: argparse.Namespace) -> int:
    from ._templates import TemplateError, create_project

    try:
        sources = _template_sources(args)
        source = sources.get(args.template)
        if source is None:
            raise TemplateError(f"Unknown project template: {args.template}")
        created = create_project(source, Path(args.parent).expanduser(), name=args.name)
    except (TemplateError, OSError) as exc:
        return _template_error(args, str(exc))
    if args.json:
        print(json.dumps({
            "ok": True, "path": str(created.path), "name": created.name, "id": created.project_id,
            "template_id": created.template_id, "template_version": created.template_version,
            "recommended_plugins": created.recommended_plugins,
        }))
    else:
        print(f"created {created.path} from template {created.template_id}")
    return 0


def _template_error(args: argparse.Namespace, message: str) -> int:
    if args.json:
        print(json.dumps({"ok": False, "error": message}))
    else:
        print(f"error: {message}", file=sys.stderr)
    return 1


# --------------------------------------------------------------------------- #
# gallery
# --------------------------------------------------------------------------- #
def _gallery_result(args: argparse.Namespace, payload: dict, text: str) -> int:
    if args.json:
        print(json.dumps(payload))
    else:
        print(text)
    return 0


def _gallery_error(args: argparse.Namespace, exc) -> int:
    # Contract 13.6: exit code non-zero and {"error": {"reason", "message"}} on stdout.
    if args.json:
        print(json.dumps(exc.to_wire()))
    else:
        print(f"error: {exc.message} ({exc.reason})", file=sys.stderr)
    return 1


def cmd_gallery_create(args: argparse.Namespace) -> int:
    from ._gallery import GalleryError, create_project

    try:
        path = create_project(args.item, args.version, Path(args.dest), name=args.name)
    except GalleryError as exc:
        return _gallery_error(args, exc)
    return _gallery_result(args, {"projectPath": str(path)}, f"created {path}")


def cmd_gallery_fetch(args: argparse.Namespace) -> int:
    from ._gallery import GalleryError, fetch_item

    try:
        path = fetch_item(args.item, args.version)
    except GalleryError as exc:
        return _gallery_error(args, exc)
    return _gallery_result(args, {"path": str(path)}, str(path))


# --------------------------------------------------------------------------- #
# platform
# --------------------------------------------------------------------------- #
def cmd_platform(args: argparse.Namespace) -> int:
    """Show (or with --write, set) how the Project lines up with the cloud platform."""
    from . import _platform

    root = _project_arg(args.path)
    if not (root / PYPROJECT).is_file():
        print(f"error: {root} has no {PYPROJECT}; run `witwin init` first", file=sys.stderr)
        return 1
    if args.write and _platform.apply_to_project(root):
        print(f"wrote the cloud platform constraints to {root / PYPROJECT}; run `uv lock` next")
    mismatches = _platform.project_mismatches(root)
    report = {
        "python": _platform.platform_python(),
        "constraints": _platform.has_constraints(root),
        "locked": mismatches is not None,
        "mismatches": [vars(item) for item in mismatches or []],
    }
    large = [item for item in mismatches or [] if item.large]
    if args.json:
        print(json.dumps(report))
        return 0 if not large else 1
    print(f"cloud platform: Python {report['python']}")
    if not report["constraints"]:
        print("  constraints: missing (run `witwin platform --write`)")
    if mismatches is None:
        print("  uv.lock: missing (run `uv lock`)")
    for item in large:
        print(f"  {item.name}: locked {item.locked}, cloud has {item.platform}; a cloud machine downloads it")
    small = [item.name for item in mismatches or [] if not item.large]
    if small:
        names = ", ".join(small[:5]) + (", ..." if len(small) > 5 else "")
        print(f"  {len(small)} small packages differ ({names}); a cloud machine downloads them")
    if mismatches is not None and not large:
        print("  the large platform packages match; cloud machines do not download them")
    return 0 if not large else 1


# --------------------------------------------------------------------------- #
# solve
# --------------------------------------------------------------------------- #
def _parse_value(raw: str):
    try:
        return json.loads(raw)
    except ValueError:
        return raw


def _solve_config(args: argparse.Namespace) -> dict:
    config: dict = {}
    if args.config:
        path = Path(args.config)
        text = path.read_text(encoding="utf-8")
        if path.suffix.lower() == ".json":
            config = json.loads(text)
        else:
            import tomllib

            config = tomllib.loads(text)
    for item in args.set or []:
        key, sep, value = item.partition("=")
        if not sep or not key:
            raise SystemExit(f"error: --set expects KEY=VALUE, got {item!r}")
        target = config
        *parents, leaf = key.split(".")
        for part in parents:
            target = target.setdefault(part, {})
        target[leaf] = _parse_value(value)
    return config


def cmd_solve(args: argparse.Namespace) -> int:
    from .solver.client import SolverError, main_progress_printer

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    project = open_project_for_cli(args.project)
    plugin_paths = [Path(p) for p in args.plugin_path or []]
    if args.list:
        for spec in project.solvers(plugin_paths=plugin_paths):
            print(f"{spec.solver_id}\t{spec.title}\t{spec.plugin_id}")
        return 0
    if not args.solver:
        raise SystemExit("error: name a solver, or pass --list")
    attach = True if args.attach else (False if args.no_attach else None)
    run = project.solve(
        args.solver, scene=args.scene, config=_solve_config(args), record=not args.no_record,
        attach=attach, plugin_paths=plugin_paths,
        on_progress=None if args.json else main_progress_printer(),
        on_log=None if (args.json or args.quiet) else (lambda line: print(line, file=sys.stderr)),
    )
    try:
        outputs = run.result()
    except SolverError as exc:
        if args.json:
            print(json.dumps({"ok": False, "runId": run.id, "error": {"code": exc.code, "message": exc.message}}))
        else:
            print(f"\nerror: {exc.code}: {exc.message}", file=sys.stderr)
        return 1
    finally:
        run.close()
    summary = {
        "ok": True, "runId": run.id, "solverId": run.solver_id, "scene": run.scene_id,
        "attached": run.attached, "resultVersion": run.result_version, "outputs": outputs,
    }
    if args.json:
        print(json.dumps(summary, default=str))
    else:
        print(file=sys.stderr)
        print(json.dumps(summary, indent=2, default=str))
    return 0


# --------------------------------------------------------------------------- #
# workflow
# --------------------------------------------------------------------------- #
# Exit codes of `witwin workflow run`: a step failed or the run was cancelled,
# or the file / param values could not be used.
EXIT_STEP_FAILED = 1
EXIT_BAD_INPUT = 2
WORKFLOW_POLL_SECONDS = 1.0


def _workflow_values(items: Optional[Sequence[str]]) -> dict:
    values: dict = {}
    for item in items or []:
        key, sep, value = item.partition("=")
        if not sep or not key:
            raise SystemExit(f"error: --param expects KEY=VALUE, got {item!r}")
        values[key] = value
    return values


def cmd_workflow_list(args: argparse.Namespace) -> int:
    from . import workflows

    root = _project_arg(args.project)
    found, broken = workflows.list_workflows(root)
    if args.json:
        print(json.dumps({"workflows": [w.to_dict() for w in found], "problems": broken}, default=str))
        return 0
    for workflow in found:
        params = " ".join(f"{p.id}={p.default}" if p.default is not None else p.id for p in workflow.params)
        print(f"{workflow.id}	{workflow.title}	{len(workflow.steps)} steps	{params}")
    for item in broken:
        print(f"error: {item['path']}: {'; '.join(item['problems'])}", file=sys.stderr)
    return 0


def _print_record_changes(record: dict, shown: dict) -> None:
    """One line per step or matrix instance whose state changed; parallel steps interleave."""
    for step in record.get("steps") or []:
        units = [(f"{step['id']}[{i['key']}]", f"{step.get('label') or step['kind']} ({i.get('label') or i['key']})", i)
                 for i in step.get("instances") or []] or [(step["id"], step.get("label") or step["kind"], step)]
        for key, label, entry in units:
            state = entry.get("status")
            if shown.get(key) == state or state == "pending":
                continue
            shown[key] = state
            line = f"[{state}] {key}: {label}"
            if entry.get("error"):
                line += f" ({entry['error']})"
            print(line, file=sys.stderr)


def _run_workflow_attached(server, workflow_id: str, values: dict) -> dict:
    import time
    import urllib.request

    from .solver.client import _post

    reply = _post(server, "/v1/workflow/start", {"workflowId": workflow_id, "params": values})
    run_id = reply["workflowRunId"]
    shown: dict = {}
    while True:
        request = urllib.request.Request(f"{server.url}/v1/workflow/runs/{run_id}", headers=server.headers())
        with urllib.request.urlopen(request, timeout=30) as response:
            record = json.loads(response.read().decode("utf-8"))
        _print_record_changes(record, shown)
        if record.get("status") != "running":
            return record
        time.sleep(WORKFLOW_POLL_SECONDS)


def cmd_workflow_run(args: argparse.Namespace) -> int:
    from . import workflows
    from ._discovery import running_server
    from .solver.client import SolverError

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    project = open_project_for_cli(args.project)
    values = _workflow_values(args.param)
    server = running_server(project.root) if not args.no_attach else None
    try:
        if server is not None:
            record = _run_workflow_attached(server, args.workflow, values)
        else:
            shown: dict = {}
            record = workflows.run_workflow(project, args.workflow, values,
                                            on_event=lambda r: _print_record_changes(r, shown))
    except workflows.WorkflowError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_BAD_INPUT
    except SolverError as exc:
        print(f"error: {exc.code}: {exc.message}", file=sys.stderr)
        return EXIT_BAD_INPUT if exc.code in ("invalid_workflow", "unknown_workflow") else EXIT_STEP_FAILED
    if args.json:
        print(json.dumps(record, default=str))
    else:
        print(f"{record['id']}: {record['status']}", file=sys.stderr)
    return 0 if record.get("status") == "succeeded" else EXIT_STEP_FAILED


def open_project_for_cli(path: Optional[str]):
    from ._project import open_project

    return open_project(_project_arg(path))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="witwin", description="Work with a WiTwin Studio Project without the editor.")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="make a folder a Project and a Python project")
    init.add_argument("path", nargs="?", help="folder (default: current folder)")
    init.add_argument("--name", help="Project display name")
    init.set_defaults(func=cmd_init)

    check = sub.add_parser("check", help="validate the Project files")
    check.add_argument("path", nargs="?", help="Project folder (default: nearest witwin.toml)")
    check.set_defaults(func=cmd_check)

    run = sub.add_parser("run", help="run a Script with the Project on sys.path")
    run.add_argument("--project", help="Project folder (default: the one holding the script)")
    run.add_argument("script", help="Python file to run")
    run.add_argument("args", nargs=argparse.REMAINDER, help="arguments passed to the script")
    run.set_defaults(func=cmd_run)

    open_ = sub.add_parser("open", help="open the Project in WiTwin Studio")
    open_.add_argument("path", nargs="?", help="Project folder (default: nearest witwin.toml)")
    open_.set_defaults(func=cmd_open)

    add = sub.add_parser(
        "add",
        help="add a Plugin (witwin index, git URL or folder; never PyPI) and sync the environment",
    )
    add.add_argument("spec", help='requirement ("wt-radar>=0.3"), git URL ("git+https://...") or a folder')
    add.add_argument("--project", help="Project folder (default: nearest witwin.toml)")
    ref = add.add_mutually_exclusive_group()
    ref.add_argument("--tag", help="git tag")
    ref.add_argument("--rev", help="git commit")
    ref.add_argument("--branch", help="git branch")
    add.add_argument("--no-editable", action="store_true", help="install a folder as a regular package")
    add.add_argument("--index-url", help="witwin index URL (default: the published one)")
    add.add_argument("--uv", help="uv executable (default: WITWIN_UV, the uv package, then PATH)")
    add.add_argument("--python", help="interpreter for a new .venv")
    add.add_argument("--no-sync", action="store_true", help="edit pyproject.toml and uv.lock only")
    add.add_argument("--json", action="store_true", help="JSON lines on stdout (Studio reads them)")
    add.set_defaults(func=cmd_add)

    platform = sub.add_parser("platform", help="compare the Project's lock with the cloud platform")
    platform.add_argument("path", nargs="?", help="Project folder (default: nearest witwin.toml)")
    platform.add_argument("--write", action="store_true", help="write the platform constraints into pyproject.toml")
    platform.add_argument("--json", action="store_true", help="one JSON object on stdout")
    platform.set_defaults(func=cmd_platform)

    solve = sub.add_parser("solve", help="run a Plugin solver headless and record a Result")
    solve.add_argument("solver", nargs="?", help="solver id, e.g. witwin.radar.simulate")
    solve.add_argument("--project", help="Project folder (default: nearest witwin.toml)")
    solve.add_argument("--scene", help="scene id (default: the main scene)")
    solve.add_argument("--config", help="solver config file (.toml or .json)")
    solve.add_argument("--set", action="append", metavar="KEY=VALUE",
                       help="set one config value (JSON or text; dotted keys nest); repeatable")
    solve.add_argument("--plugin-path", action="append", help="extra local Plugin folder; repeatable")
    mode = solve.add_mutually_exclusive_group()
    mode.add_argument("--attach", action="store_true", help="require a running ProjectServer")
    mode.add_argument("--no-attach", action="store_true", help="never use a running ProjectServer")
    solve.add_argument("--no-record", action="store_true", help="do not write a Result")
    solve.add_argument("--list", action="store_true", help="list the solvers this Project can run")
    solve.add_argument("--json", action="store_true", help="one JSON object on stdout")
    solve.add_argument("--quiet", action="store_true", help="hide solver log lines")
    solve.set_defaults(func=cmd_solve)

    workflow = sub.add_parser("workflow", help="list or run the Workflows saved in tasks/")
    workflow_sub = workflow.add_subparsers(dest="workflow_command", required=True)
    wf_list = workflow_sub.add_parser("list", help="list the Workflows and the files that fail to load")
    wf_list.add_argument("--project", help="Project folder (default: nearest witwin.toml)")
    wf_list.add_argument("--json", action="store_true", help="one JSON object on stdout")
    wf_list.set_defaults(func=cmd_workflow_list)
    wf_run = workflow_sub.add_parser("run", help="run a Workflow; exit 1 when a step fails, 2 on bad input")
    wf_run.add_argument("workflow", help="Workflow id (the file name in tasks/ without .toml)")
    wf_run.add_argument("--project", help="Project folder (default: nearest witwin.toml)")
    wf_run.add_argument("--param", action="append", metavar="KEY=VALUE", help="set one param; repeatable")
    wf_run.add_argument("--no-attach", action="store_true", help="never use a running ProjectServer")
    wf_run.add_argument("--json", action="store_true", help="the finished run record as JSON on stdout")
    wf_run.set_defaults(func=cmd_workflow_run)
    template = sub.add_parser("template", help="list Project templates or make a Project from one")
    template_sub = template.add_subparsers(dest="template_command", required=True)
    for name, func, help_text in (
        ("list", cmd_template_list, "list the templates and verify their content"),
        ("create", cmd_template_create, "make a new Project folder from a template"),
    ):
        command = template_sub.add_parser(name, help=help_text)
        if name == "create":
            command.add_argument("template", help="template id")
            command.add_argument("--parent", required=True, help="folder the new Project folder goes in")
            command.add_argument("--name", help="Project name (default: the template's)")
        command.add_argument("--plugin-root", action="append", metavar="ID=PATH",
                             help="a Plugin folder whose [[contributes.templates]] to read; repeatable")
        command.add_argument("--spec", help='JSON {"plugins": {id: path}, "registry": [...], "bundled_root": path}; - reads stdin')
        command.add_argument("--json", action="store_true", help="one JSON object on stdout")
        command.set_defaults(func=func)
    gallery = sub.add_parser("gallery", help="make a Project from a Gallery item, or download one")
    gallery_sub = gallery.add_subparsers(dest="gallery_command", required=True)
    for name, func, help_text in (
        ("create", cmd_gallery_create, "make a new Project from a Gallery item (first commit included)"),
        ("fetch", cmd_gallery_fetch, "download a Gallery item to ~/.witwin/gallery-cache, without git"),
    ):
        command = gallery_sub.add_parser(name, help=help_text)
        command.add_argument("item", help="Gallery item id")
        command.add_argument("--version", type=int, required=True, help="item version")
        if name == "create":
            command.add_argument("--dest", required=True,
                                 help="new Project folder; an existing non-empty folder gets a <name> folder inside")
            command.add_argument("--name", help="Project name (default: the item id)")
        command.add_argument("--json", action="store_true", help="one JSON object on stdout")
        command.set_defaults(func=func)
    return parser


# Subcommands from other installed packages. Each entry point is a callable
# taking the remaining argv and returning an exit code. Loading by name keeps
# this package free of witwin_server imports.
CLI_ENTRY_POINT_GROUP = "witwin.cli"
# Built-in names win over an entry point of the same name.
BUILTIN_COMMANDS = frozenset({"init", "check", "run", "open", "add", "platform", "solve", "workflow", "template", "gallery"})


def _plugin_command(name: str):
    from importlib.metadata import entry_points

    for entry in entry_points(group=CLI_ENTRY_POINT_GROUP):
        if entry.name == name:
            return entry.load()
    return None


def main(argv: Optional[Sequence[str]] = None) -> int:
    raw = list(sys.argv[1:] if argv is None else argv)
    if raw and not raw[0].startswith("-") and raw[0] not in BUILTIN_COMMANDS:
        command = _plugin_command(raw[0])
        if command is not None:
            return int(command(raw[1:]) or 0)
    args = build_parser().parse_args(raw)
    return int(args.func(args) or 0)


if __name__ == "__main__":
    raise SystemExit(main())
