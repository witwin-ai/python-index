"""Channel library prefabs — drag-to-create scene building blocks.

Registers a ``Channel`` library category with the four core building blocks plus a demo:

- **Channel Scene (Demo)** — a ground plane + wall, a **Tx**, an **Rx**, a **RadioMap**
  (returned), and a **Path Solver**. Drag it in, press **Solve** on the RadioMap for a
  2D radiomap, or **Solve Paths** on the Path Solver for the Tx<->Rx rays (needs CUDA).
- **Tx** / **Rx** — transmitter / point receiver endpoints (antenna defined inline).
- **RadioMap** — a 2D field that is its own receiver grid + solver + result viewer.
- **Path Solver** — point-to-point path solve; auto-finds the Tx/Rx in the scene.

Each prefab carries components straight from the registry (no platform ``Scene`` is
built, so dropping never needs CUDA). The factory adds any extra objects to the drop
scene and returns the primary one.
"""
import inspect as _inspect
from pathlib import Path as _Path

from witwin_server.api import Library, SceneObject


_PREVIEWS = _Path(__file__).resolve().parent / "previews" / "library"


def _preview(item_id):
    """The Library card image for an item, as keyword arguments.

    Images are renders from Studio's `scripts/template-previews/library_items.py`.
    Empty when the file is missing or Studio's `register_item` has no `preview`
    parameter yet (older Studio), so the card falls back to the item's icon.
    """
    path = _PREVIEWS / f"{item_id}.webp"
    if not path.is_file() or "preview" not in _inspect.signature(Library.register_item).parameters:
        return {}
    return {"preview": str(path)}

_CATEGORY = "channel"


def _tx_object(name, position):
    from .components.endpoints import TxComponent

    obj = SceneObject(name=name, mesh_type="Empty")
    obj.add_component(TxComponent())
    obj.get_component("Transform").position = list(position)
    return obj


def _rx_object(name, position):
    from .components.endpoints import RxComponent

    obj = SceneObject(name=name, mesh_type="Empty")
    obj.add_component(RxComponent())
    obj.get_component("Transform").position = list(position)
    return obj


def _radiomap_object(name):
    from .components.radiomap import RadioMapComponent

    obj = SceneObject(name=name, mesh_type="Empty")
    obj.add_component(RadioMapComponent())
    return obj


def _pathsolver_object(name):
    from .components.pathsolver import PathSolverComponent

    obj = SceneObject(name=name, mesh_type="Empty")
    obj.add_component(PathSolverComponent())
    return obj


def _ground_object():
    from witwin_server.api import PlatformGeometryComponent

    from .components.materials import MaterialPresetComponent

    obj = SceneObject(name="Channel Ground", mesh_type="Cube")
    transform = obj.get_component("Transform")
    transform.scale = [20.0, 0.2, 20.0]
    geom = obj.add_component(PlatformGeometryComponent())
    geom.kind = "box"
    geom.size = [20.0, 0.2, 20.0]
    preset = obj.add_component(MaterialPresetComponent())
    preset.preset = "concrete"
    return obj


# --- library factories (context.scene gets the extras; return the primary obj) ---

def _make_demo(ctx):
    """Solvable demo: ground + Tx + Rx + Path Solver (extras) and a RadioMap (returned)."""
    ctx.scene.add_object(_ground_object())
    ctx.scene.add_object(_tx_object("Tx", (-5.0, 3.0, 0.0)))   # Y is up/height
    ctx.scene.add_object(_rx_object("Rx", (8.0, 1.5, 0.0)))
    ctx.scene.add_object(_pathsolver_object("Path Solver"))
    # At the Rx height, not y=0: y=0 is inside the 0.2 m ground slab, where every
    # sample is occluded and the map comes out empty. The drop keeps this offset.
    radiomap = _radiomap_object("RadioMap")
    radiomap.get_component("Transform").position = [0.0, 1.5, 0.0]
    return radiomap


def _make_tx(ctx):
    return _tx_object(ctx.name, (0.0, 2.0, 0.0))


def _make_rx(ctx):
    return _rx_object(ctx.name, (5.0, 1.5, 0.0))


def _make_radiomap(ctx):
    return _radiomap_object(ctx.name)


def _make_pathsolver(ctx):
    return _pathsolver_object(ctx.name)


def register() -> None:
    """Register the Channel library category + prefab items."""
    Library.register_category(_CATEGORY, "Channel", icon="radio", order=21)
    Library.register_item("channel_demo", "Channel Scene (Demo)", _CATEGORY,
                          icon="sparkles", object_type="empty", factory=_make_demo,
                          description="Tx + Rx + RadioMap over a ground plane; Solve for a radiomap", **_preview("channel_demo"))
    Library.register_item("channel_tx", "Tx", _CATEGORY,
                          icon="radio", object_type="empty", factory=_make_tx,
                          description="Channel transmitter endpoint (antenna inline)", **_preview("channel_tx"))
    Library.register_item("channel_rx", "Rx", _CATEGORY,
                          icon="antenna", object_type="empty", factory=_make_rx,
                          description="Channel point receiver endpoint (antenna inline)", **_preview("channel_rx"))
    Library.register_item("channel_radiomap", "RadioMap", _CATEGORY,
                          icon="grid", object_type="empty", factory=_make_radiomap,
                          description="2D radiomap field: receiver grid + solver + result viewer", **_preview("channel_radiomap"))
    Library.register_item("channel_pathsolver", "Path Solver", _CATEGORY,
                          icon="route", object_type="empty", factory=_make_pathsolver,
                          description="Point-to-point path solve; auto-finds the Tx/Rx", **_preview("channel_pathsolver"))


register()
