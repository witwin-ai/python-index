"""Project templates: verify a template's content and make a Project from it.

A template is a directory copied as-is into a new Project plus a content
manifest (``schemaVersion``, ``templateId``, ``templateVersion``, ``files`` with
byte sizes and sha256, ``treeSha256``) whose own sha256 is pinned where the
template is declared. Every read verifies every file against that pin, so the
pinned digest, not the folder it comes from, is what makes the content
trusted. The manifest is built by ``studio/scripts/build-template-manifest.mjs``.

Templates are declared in two places:

- ``[[contributes.templates]]`` in a Plugin's ``witwin.toml`` (content under
  the Plugin root);
- Studio's older registry, ``studio/electron/project/bundledExamples.json``
  (content in the App's examples resource, or a Plugin's ``examples/``).

This module is the one implementation of these rules. Studio desktop runs it
through ``witwin template list|create`` (``studio/electron/project/
templateCli.ts``); the ProjectServer calls ``apply_template`` to fill a new
hosted Project (``project.template.apply``). Card titles, icons and which
Plugin owns a card are display data and stay in Studio
(``studio/src/core/desktop/templateCatalog.ts``).
"""
from __future__ import annotations

import base64
import datetime as _dt
import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
import unicodedata
import uuid
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

import tomlkit

from ._manifest import MANIFEST_FORMAT_VERSION, MANIFEST_NAME


class TemplateError(ValueError):
    """The template cannot be used; the message says why, for a card's Tooltip."""


SHA256 = re.compile(r"^[a-f0-9]{64}$")
TEMPLATE_ID = re.compile(r"^[a-z0-9][a-z0-9.-]{0,63}$")
PLUGIN_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
FORMAT_VERSION = re.compile(r"^\d+\.\d+$")
_RESERVED = re.compile(r"^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$", re.IGNORECASE)
_BAD_CHARS = re.compile(r'[<>:"|?*\0]')

# A Project is also an ordinary Python codebase (dev_docs/project-as-python-
# codebase.md), so templates may ship Python sources and the two dotfiles a
# Python project carries. They are still pinned by sha256 like every file.
ALLOWED_EXTENSIONS = frozenset({".glb", ".wtimport", ".wtscene", ".toml", ".json", ".md", ".txt", ".py"})
# Allowed by exact name: PurePosixPath(".gitignore").suffix is "".
ALLOWED_NAMES = frozenset({".gitignore", ".python-version"})
# Runtime or machine-local state, never template content.
FORBIDDEN_PARTS = frozenset({".witwin", "results", "plugins", ".venv", "__pycache__"})
# Bytecode folders that an installer writes next to installed sources: pip
# compiles every .py of a wheel, so a template inside an installed Plugin
# (the cloud machine image, a pip-installed Project environment) always has
# scripts/__pycache__/. The source walk skips them; they are never declared
# and never copied, so the exact-file-set check still covers all content.
INSTALLER_BYTECODE_DIRS = frozenset({"__pycache__"})

# What a registry entry must ship unless it names its own list. A Plugin
# contribution only has to be a Project, so it requires witwin.toml alone.
REGISTRY_REQUIRED_FILES = (
    "witwin.toml",
    "scenes/main.wtscene",
    "README.md",
    "THIRD_PARTY_NOTICES.md",
    "LICENSES/CC0-1.0.txt",
)
CONTRIBUTION_REQUIRED_FILES = ("witwin.toml",)

MAX_FILES = 1000
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_TOTAL_BYTES = 32 * 1024 * 1024
PREVIEW_MAX_BYTES = 4 * 1024 * 1024
PREVIEW_TYPES = {".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg"}

DEFAULT_ICON = "layout-template"
STAGING_PREFIX = ".witwin-template-"
FALLBACK_PROJECT_NAME = "WiTwin Starter Project"

# What a Project made from nothing holds before anyone edits it: the manifest,
# the Python files ``_scaffold`` writes, and one empty main Scene. Only such a
# Project may be filled from a template (``apply_template``).
BLANK_PROJECT_FILES = frozenset({
    MANIFEST_NAME, "pyproject.toml", "README.md", ".gitignore", ".gitattributes",
})
# ``.venv`` is an environment, not content: a cloud machine links it to its base
# environment before the Project opens (witwin_server_control/machine_setup.py),
# and a template never ships one.
BLANK_PROJECT_HIDDEN = frozenset({".git", ".witwin", ".venv"})


# --------------------------------------------------------------------- model

@dataclass(frozen=True)
class TemplateDefinition:
    """Where a template's content is and the digest that pins it."""

    template_id: str
    template_version: str
    display_name: str
    relative_dir: str
    content_manifest_file: str
    content_manifest_sha256: str
    description: str = ""
    # "bundled": the App's examples resource; "plugin": a Plugin package.
    source: str = "bundled"
    plugin_id: Optional[str] = None
    default_project_name: str = ""
    # None: REGISTRY_REQUIRED_FILES.
    required_files: Optional[Sequence[str]] = None

    @classmethod
    def from_registry(cls, entry: Mapping[str, Any]) -> "TemplateDefinition":
        """A ``bundledExamples.json`` entry (camelCase keys)."""
        try:
            return cls(
                template_id=str(entry["templateId"]),
                template_version=str(entry["templateVersion"]),
                display_name=str(entry.get("displayName") or entry["templateId"]),
                description=str(entry.get("description") or ""),
                source=str(entry.get("source") or "bundled"),
                plugin_id=entry.get("pluginId"),
                relative_dir=str(entry["relativeDir"]),
                content_manifest_file=str(entry["contentManifestFile"]),
                content_manifest_sha256=str(entry["contentManifestSha256"]),
                default_project_name=str(entry.get("defaultProjectName") or entry.get("displayName") or ""),
                required_files=entry.get("requiredFiles"),
            )
        except KeyError as exc:
            raise TemplateError(f"Invalid template registry entry: missing {exc.args[0]}") from None


@dataclass(frozen=True)
class TemplateSource:
    """A declared template: its definition, the folder it is relative to, and display hints."""

    definition: TemplateDefinition
    root: Path
    title: str
    description: str = ""
    icon: str = DEFAULT_ICON
    plugin_id: Optional[str] = None
    plugin_root: Optional[Path] = None
    preview_path: Optional[Path] = None


@dataclass(frozen=True)
class VerifiedTemplate:
    """Content that passed every check; ``manifest`` is the parsed content manifest."""

    source_root: Path
    manifest: Dict[str, Any]

    @property
    def files(self) -> List[Dict[str, Any]]:
        return list(self.manifest["files"])

    @property
    def tree_sha256(self) -> str:
        return str(self.manifest["treeSha256"])

    @property
    def recommended_plugins(self) -> List[str]:
        return list(self.manifest["recommendedPlugins"])


@dataclass
class CreatedProject:
    """What ``create_project`` made."""

    path: Path
    name: str
    project_id: str
    template_id: str
    template_version: str
    recommended_plugins: List[str] = field(default_factory=list)


@dataclass
class AppliedTemplate:
    """What ``apply_template`` wrote into an existing blank Project."""

    template_id: str
    template_version: str
    written: List[str] = field(default_factory=list)
    removed: List[str] = field(default_factory=list)
    main_scene: Optional[str] = None
    recommended_plugins: List[str] = field(default_factory=list)


# ----------------------------------------------------------------- discovery

def parse_contributions(text: str) -> List[Dict[str, Any]]:
    """The ``[[contributes.templates]]`` entries of a Plugin manifest.

    Entries missing a required key (``id``, ``title``, ``version``, ``dir``,
    ``manifest``, ``sha256``) are skipped, as is a manifest that is not TOML.
    """
    import tomllib

    try:
        doc = tomllib.loads(text)
    except tomllib.TOMLDecodeError:
        return []
    contributes = doc.get("contributes")
    entries = contributes.get("templates") if isinstance(contributes, dict) else None
    if not isinstance(entries, list):
        return []
    required = ("id", "title", "version", "dir", "manifest", "sha256")
    found: List[Dict[str, Any]] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        if not all(isinstance(entry.get(key), str) and entry.get(key) for key in required):
            continue
        found.append({key: value for key, value in entry.items() if isinstance(value, str)})
    return found


def read_contributions(plugin_root: Path | str) -> List[Dict[str, Any]]:
    try:
        return parse_contributions((Path(plugin_root) / MANIFEST_NAME).read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError):
        return []


def _plugin_path(plugin_root: Path, relative: str) -> Path:
    return plugin_root.joinpath(*relative.split("/")).resolve()


def collect_sources(
    plugin_roots: Mapping[str, Path | str],
    *,
    registry: Iterable[Mapping[str, Any] | TemplateDefinition] = (),
    bundled_root: Optional[Path | str] = None,
) -> Dict[str, TemplateSource]:
    """Every declared template by id: Plugin contributions first, then the registry.

    ``plugin_roots`` maps Plugin id to its root folder, in precedence order.
    A registry entry owned by a Plugin needs that Plugin (its content lives in
    the Plugin's ``examples/``); a bundled entry needs ``bundled_root``.
    """
    sources: Dict[str, TemplateSource] = {}
    roots = {plugin_id: Path(root) for plugin_id, root in plugin_roots.items()}
    for plugin_id, root in roots.items():
        for entry in read_contributions(root):
            template_id = entry["id"]
            if template_id in sources:
                continue
            preview = entry.get("preview")
            sources[template_id] = TemplateSource(
                definition=TemplateDefinition(
                    template_id=template_id,
                    template_version=entry["version"],
                    display_name=entry["title"],
                    description=entry.get("description", ""),
                    source="plugin",
                    plugin_id=plugin_id,
                    relative_dir=entry["dir"],
                    content_manifest_file=entry["manifest"],
                    content_manifest_sha256=entry["sha256"],
                    default_project_name=entry["title"],
                    required_files=CONTRIBUTION_REQUIRED_FILES,
                ),
                root=root,
                title=entry["title"],
                description=entry.get("description", ""),
                icon=entry.get("icon") or DEFAULT_ICON,
                plugin_id=plugin_id,
                plugin_root=root,
                preview_path=_plugin_path(root, preview) if preview else None,
            )
    for item in registry:
        definition = item if isinstance(item, TemplateDefinition) else TemplateDefinition.from_registry(item)
        if definition.template_id in sources:
            continue
        if definition.source == "plugin":
            plugin_root = roots.get(definition.plugin_id or "")
            if plugin_root is None:
                continue
            root = plugin_root / "examples"
        elif bundled_root is not None:
            root = Path(bundled_root)
            plugin_root = None
        else:
            continue
        sources[definition.template_id] = TemplateSource(
            definition=definition,
            root=root,
            title=definition.display_name,
            description=definition.description,
            plugin_id=definition.plugin_id,
            plugin_root=plugin_root,
        )
    return sources


def preview_data_url(plugin_root: Optional[Path], preview_path: Optional[Path]) -> Optional[str]:
    """A Plugin's preview image as a data URL; None when missing, outside the Plugin, of another type or too large.

    Display only, so it is not pinned like the content. The renderer cannot
    read Plugin folders, hence the data URL.
    """
    if plugin_root is None or preview_path is None:
        return None
    media_type = PREVIEW_TYPES.get(preview_path.suffix.lower())
    if not media_type or not _contained(Path(plugin_root).resolve(), preview_path.resolve()):
        return None
    try:
        info = preview_path.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > PREVIEW_MAX_BYTES:
            return None
        return f"data:{media_type};base64,{base64.b64encode(preview_path.read_bytes()).decode('ascii')}"
    except OSError:
        return None


# --------------------------------------------------------------- validation

def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _contained(root: Path, candidate: Path) -> bool:
    """True when ``candidate`` is strictly inside ``root`` (both resolved)."""
    try:
        relative = candidate.relative_to(root)
    except ValueError:
        return False
    return str(relative) not in ("", ".")


def _portable_parts(relative: str) -> List[str]:
    if (not relative or "\\" in relative or relative.startswith("/")
            or re.match(r"^[A-Za-z]:", relative)):
        raise TemplateError(f"Invalid template path: {relative}")
    parts = relative.split("/")
    for part in parts:
        if not part or part in (".", "..") or _BAD_CHARS.search(part) or part[-1] in ". ":
            raise TemplateError(f"Invalid template path: {relative}")
        if _RESERVED.match(part):
            raise TemplateError(f"Windows-reserved template path: {relative}")
        if part.lower() in FORBIDDEN_PARTS:
            raise TemplateError(f"Runtime content is forbidden in templates: {relative}")
    return parts


def _portable_file(relative: str) -> List[str]:
    parts = _portable_parts(relative)
    if parts[-1] not in ALLOWED_NAMES and PurePosixPath(relative).suffix.lower() not in ALLOWED_EXTENSIONS:
        raise TemplateError(f"Unsupported template file type: {relative}")
    return parts


def _is_reparse(path: Path) -> bool:
    """Symlink, or on Windows any reparse point (a junction is not ``islink`` before 3.12)."""
    info = os.lstat(path)
    if stat.S_ISLNK(info.st_mode):
        return True
    attributes = getattr(info, "st_file_attributes", 0)
    return bool(attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))


def _checked_file(root_real: Path, relative: str) -> Path:
    """The real path of a regular file inside ``root_real``, with no link on the way."""
    parts = _portable_file(relative)
    current = root_real
    for part in parts:
        current = current / part
        try:
            if _is_reparse(current):
                raise TemplateError(f"Template cannot contain a symlink or junction: {relative}")
        except FileNotFoundError:
            raise TemplateError(f"Template is missing {relative}") from None
    real = current.resolve()
    if not _contained(root_real, real):
        raise TemplateError(f"Template path escapes its folder: {relative}")
    if not real.is_file():
        raise TemplateError(f"Template content is not a regular file: {relative}")
    return real


def _regular_files(root_real: Path, current: Optional[Path] = None, prefix: str = "") -> List[str]:
    current = current or root_real
    found: List[str] = []
    for entry in sorted(os.scandir(current), key=lambda item: item.name):
        relative = f"{prefix}/{entry.name}" if prefix else entry.name
        if entry.name.lower() in INSTALLER_BYTECODE_DIRS and entry.is_dir(follow_symlinks=False):
            continue
        _portable_parts(relative)
        absolute = Path(entry.path)
        if _is_reparse(absolute):
            raise TemplateError(f"Template cannot contain a symlink or junction: {relative}")
        mode = os.lstat(absolute).st_mode
        if stat.S_ISDIR(mode):
            found.extend(_regular_files(root_real, absolute, relative))
        elif stat.S_ISREG(mode):
            _portable_file(relative)
            if not _contained(root_real, absolute.resolve()):
                raise TemplateError(f"Template path escapes its folder: {relative}")
            found.append(relative)
        else:
            raise TemplateError(f"Template contains an unsupported filesystem entry: {relative}")
    return found


def _is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _check_definition(definition: TemplateDefinition) -> None:
    if (not TEMPLATE_ID.match(definition.template_id)
            or not SHA256.match(definition.content_manifest_sha256)
            or definition.source not in ("bundled", "plugin")
            or (definition.source == "plugin" and not PLUGIN_ID.match(definition.plugin_id or ""))
            or (definition.source != "plugin" and definition.plugin_id is not None)):
        raise TemplateError("Invalid template declaration")


def _check_manifest(manifest: Any, definition: TemplateDefinition) -> None:
    ok = (
        isinstance(manifest, dict)
        and manifest.get("schemaVersion") == 1 and _is_int(manifest.get("schemaVersion"))
        and manifest.get("templateId") == definition.template_id
        and manifest.get("templateVersion") == definition.template_version
        and isinstance(manifest.get("files"), list)
        and isinstance(manifest.get("recommendedPlugins"), list)
        and 0 < len(manifest["files"]) <= MAX_FILES
        and isinstance(manifest.get("projectFormatVersion"), str)
        and FORMAT_VERSION.match(manifest["projectFormatVersion"]) is not None
        and _is_int(manifest.get("minProtocol")) and manifest["minProtocol"] >= 1
        and all(isinstance(item, str) and PLUGIN_ID.match(item) for item in manifest["recommendedPlugins"])
        and len(set(manifest["recommendedPlugins"])) == len(manifest["recommendedPlugins"])
        and _is_int(manifest.get("totalBytes")) and 0 < manifest["totalBytes"] <= MAX_TOTAL_BYTES
        and isinstance(manifest.get("treeSha256"), str) and SHA256.match(manifest["treeSha256"]) is not None
    )
    if not ok:
        raise TemplateError("Invalid template manifest")
    folded: set[str] = set()
    total = 0
    for item in manifest["files"]:
        path = item.get("path") if isinstance(item, dict) else None
        if not isinstance(path, str):
            raise TemplateError("Invalid template manifest entry")
        _portable_file(path)
        key = unicodedata.normalize("NFC", path).lower()
        size = item.get("bytes")
        if (key in folded or not _is_int(size) or not 0 <= size <= MAX_FILE_BYTES
                or not isinstance(item.get("sha256"), str) or not SHA256.match(item["sha256"])):
            raise TemplateError(f"Invalid template manifest entry: {path}")
        folded.add(key)
        total += size
    if total != manifest["totalBytes"]:
        raise TemplateError("Template byte total mismatch")
    tree = _digest("".join(f"{f['path']}\0{f['bytes']}\0{f['sha256']}\n" for f in manifest["files"]).encode("utf-8"))
    if tree != manifest["treeSha256"]:
        raise TemplateError("Template tree checksum mismatch")
    required = definition.required_files if definition.required_files is not None else REGISTRY_REQUIRED_FILES
    paths = {f["path"] for f in manifest["files"]}
    for name in required:
        if name not in paths:
            raise TemplateError(f"Template is missing {name}")


def verify(definition: TemplateDefinition, root: Path | str) -> VerifiedTemplate:
    """Check a template's content against its pinned digest; raises TemplateError with the reason.

    Checks, in order: the declaration; that the content folder is inside
    ``root``; the content manifest's sha256; the manifest's fields, limits
    and tree digest; the required files; that the folder holds exactly the
    declared files (no links, no runtime folders, only allowed file types);
    and every file's size and sha256.
    """
    _check_definition(definition)
    try:
        root_real = Path(root).resolve(strict=True)
        source_root = root_real.joinpath(*definition.relative_dir.split("/")).resolve(strict=True)
    except (OSError, RuntimeError):
        raise TemplateError("Template content folder is missing") from None
    if not _contained(root_real, source_root):
        raise TemplateError("Template content is outside its trusted folder")
    manifest_path = _checked_file(source_root, definition.content_manifest_file)
    manifest_bytes = manifest_path.read_bytes()
    if _digest(manifest_bytes) != definition.content_manifest_sha256:
        raise TemplateError("Template manifest checksum mismatch")
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise TemplateError("Invalid template manifest") from None
    _check_manifest(manifest, definition)
    declared = {f["path"] for f in manifest["files"]} | {definition.content_manifest_file}
    actual = _regular_files(source_root)
    undeclared = [name for name in actual if name not in declared]
    absent = sorted(name for name in declared if name not in actual)
    if undeclared or absent or len(actual) != len(declared):
        raise TemplateError(
            "Template file set mismatch "
            f"(undeclared: {', '.join(undeclared) or 'none'}; missing: {', '.join(absent) or 'none'})"
        )
    for item in manifest["files"]:
        data = _checked_file(source_root, item["path"]).read_bytes()
        if len(data) != item["bytes"] or _digest(data) != item["sha256"]:
            raise TemplateError(f"Template content checksum mismatch: {item['path']}")
    return VerifiedTemplate(source_root=source_root, manifest=manifest)


def _read_verified(verified: VerifiedTemplate, item: Mapping[str, Any]) -> bytes:
    """A file's bytes, checked again: the folder may have changed since ``verify``."""
    data = _checked_file(verified.source_root, item["path"]).read_bytes()
    if len(data) != item["bytes"] or _digest(data) != item["sha256"]:
        raise TemplateError(f"Template content checksum mismatch: {item['path']}")
    return data


# ------------------------------------------------------------------ creation

def _now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat().replace("+00:00", "Z")


def safe_directory_name(name: str) -> str:
    """A folder name for ``name`` that every OS accepts (at most 100 characters)."""
    clean = re.sub(r'[\x00-\x1f<>:"/\\|?*]', "_", name or "").strip().rstrip(". ")
    if not clean or clean in (".", "..") or _RESERVED.match(clean):
        clean = FALLBACK_PROJECT_NAME
    return clean[:100].rstrip(". ") or FALLBACK_PROJECT_NAME


def _write_template_manifest(
    folder: Path,
    *,
    project_id: str,
    name: str,
    created: str,
    definition: TemplateDefinition,
    tree_sha256: str,
    keep: Optional[Mapping[str, Any]] = None,
) -> None:
    """Stamp the copied ``witwin.toml`` as a new Project made from this template.

    Every other key and table of the template's manifest is kept. ``keep`` holds
    ``[project]`` values of the Project being filled that win over the template's.
    """
    manifest = folder / MANIFEST_NAME
    try:
        doc = tomlkit.parse(manifest.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 - any parse error makes the template unusable
        raise TemplateError(f"Template witwin.toml is not valid TOML: {exc}") from None
    project: Any = doc.get("project")
    if not isinstance(project, dict):
        project = tomlkit.table()
        doc["project"] = project
    now = _now()
    project["id"] = project_id
    project["name"] = name
    if not str(project.get("format_version") or "").strip():
        project["format_version"] = MANIFEST_FORMAT_VERSION
    project["created"] = created
    project["modified"] = now
    for key, value in (keep or {}).items():
        if value not in (None, ""):
            project[key] = value
    project["template_id"] = definition.template_id
    project["template_version"] = definition.template_version
    project["template_content_hash"] = tree_sha256
    manifest.write_text(tomlkit.dumps(doc), encoding="utf-8", newline="\n")


def _write_new(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "xb") as handle:
        handle.write(data)


def create_project(
    source: TemplateSource,
    parent_dir: Path | str,
    *,
    name: Optional[str] = None,
    project_id: Optional[str] = None,
) -> CreatedProject:
    """Copy a verified template into a new folder under ``parent_dir``.

    The folder is named after ``name`` (default: the template's project name),
    with " 2", " 3"... when it exists; the Project's name carries the same
    suffix. Files are staged in a private folder and moved into place with one
    rename, so a failure leaves no half-made Project. The Python project files
    the template lacks are not written here: Studio leaves the scaffold marker
    and the ProjectServer writes them on first start.
    """
    definition = source.definition
    verified = verify(definition, source.root)
    base_name = (name or definition.default_project_name or source.title or definition.template_id).strip()
    parent = Path(parent_dir)
    parent.mkdir(parents=True, exist_ok=True)
    parent_real = parent.resolve()
    staging = Path(tempfile.mkdtemp(prefix=STAGING_PREFIX, dir=parent_real))
    committed = False
    try:
        for item in verified.files:
            data = _read_verified(verified, item)
            destination = staging.joinpath(*item["path"].split("/"))
            _write_new(destination, data)
            if _digest(destination.read_bytes()) != item["sha256"]:
                raise TemplateError(f"Copied template file failed verification: {item['path']}")
        new_id = project_id or str(uuid.uuid4())
        created = _now()
        base = safe_directory_name(base_name)
        suffix = 1
        while True:
            final = parent_real / (base if suffix == 1 else f"{base} {suffix}")
            project_name = base_name if suffix == 1 else f"{base_name} {suffix}"
            if final.exists():
                suffix += 1
                continue
            _write_template_manifest(
                staging, project_id=new_id, name=project_name, created=created,
                definition=definition, tree_sha256=verified.tree_sha256,
            )
            lock = Path(f"{final}.witwin-create.lock")
            try:
                fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            except FileExistsError:
                suffix += 1
                continue
            try:
                if final.exists():
                    suffix += 1
                    continue
                os.rename(staging, final)
                committed = True
                return CreatedProject(
                    path=final,
                    name=project_name,
                    project_id=new_id,
                    template_id=definition.template_id,
                    template_version=definition.template_version,
                    recommended_plugins=verified.recommended_plugins,
                )
            except OSError:
                if final.exists():
                    suffix += 1
                    continue
                raise
            finally:
                os.close(fd)
                lock.unlink(missing_ok=True)
    finally:
        if not committed and staging.exists():
            _remove_staging(parent_real, staging)


def _remove_staging(parent_real: Path, staging: Path) -> None:
    if not _contained(parent_real, staging.resolve()) or not staging.name.startswith(STAGING_PREFIX):
        raise TemplateError("Refusing to remove an untrusted template staging folder")
    # Never recurse through a link another process put in its place.
    if _is_reparse(staging):
        staging.unlink()
        return
    shutil.rmtree(staging, ignore_errors=True)


def blank_project_problem(project_dir: Path | str) -> Optional[str]:
    """Why ``project_dir`` is not a blank new Project, or None when it is.

    Blank means only what a Project made from nothing holds: the manifest, the
    Python files and ``.gitattributes`` the scaffold writes, and at most one
    Scene file directly under ``scenes/``. The caller also checks that Scene
    is empty (the ProjectServer has it loaded).
    """
    root = Path(project_dir)
    for entry in root.iterdir():
        if entry.name in BLANK_PROJECT_HIDDEN or entry.name in BLANK_PROJECT_FILES:
            continue
        if entry.name == "scenes" and entry.is_dir() and not _is_reparse(entry):
            scenes = list(entry.iterdir())
            if len(scenes) > 1 or any(not s.is_file() or s.suffix != ".wtscene" for s in scenes):
                return "the Project already has Scenes"
            continue
        return f"the Project already has {entry.name}"
    return None


def apply_template(source: TemplateSource, project_dir: Path | str) -> AppliedTemplate:
    """Fill a blank new Project with a template's content; the hosted counterpart of ``create_project``.

    A hosted Project is created empty before its sandbox exists, so its
    content cannot be copied in beforehand: the ProjectServer calls this once
    the Project is open (``project.template.apply``). Template files replace
    the scaffold's files of the same name; the empty Scene the server made is
    removed when the template brings its own Scenes. ``witwin.toml`` comes
    from the template but keeps the Project's id, name and creation time, so
    Control and the Projects list still know it. Raises TemplateError when the
    Project is not blank or the content fails verification.
    """
    from ._manifest import read_project_table

    root = Path(project_dir).resolve()
    problem = blank_project_problem(root)
    if problem:
        raise TemplateError(f"A template can only fill a new Project: {problem}")
    definition = source.definition
    verified = verify(definition, source.root)
    current = read_project_table(root)
    keep = {key: current.get(key) for key in ("id", "name", "created")}
    template_paths = {item["path"] for item in verified.files}

    result = AppliedTemplate(
        template_id=definition.template_id,
        template_version=definition.template_version,
        recommended_plugins=verified.recommended_plugins,
    )
    # Read everything first, so a file that fails its check leaves the Project untouched.
    payload = [(item["path"], _read_verified(verified, item)) for item in verified.files]
    old_scenes = sorted((root / "scenes").glob("*.wtscene")) if (root / "scenes").is_dir() else []
    brings_scenes = any(path.startswith("scenes/") and path.endswith(".wtscene") for path in template_paths)
    for relative, data in payload:
        destination = root.joinpath(*relative.split("/"))
        if destination.exists() and _is_reparse(destination):
            raise TemplateError(f"Refusing to replace a link in the Project: {relative}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        result.written.append(relative)
    if brings_scenes:
        for scene in old_scenes:
            relative = scene.relative_to(root).as_posix()
            if relative not in template_paths:
                scene.unlink(missing_ok=True)
                result.removed.append(relative)
    _write_template_manifest(
        root,
        project_id=str(keep["id"] or uuid.uuid4()),
        name=str(keep["name"] or definition.default_project_name),
        created=str(keep["created"] or _now()),
        definition=definition,
        tree_sha256=verified.tree_sha256,
    )
    try:
        main = str(read_project_table(root).get("main_scene") or "").strip()
    except ValueError:
        main = ""
    result.main_scene = main or None
    return result


# ---------------------------------------------------------------- reporting

def describe_sources(sources: Mapping[str, TemplateSource]) -> List[Dict[str, Any]]:
    """One record per template, verified, for Studio's cards (snake_case keys).

    ``status`` is ``ready`` or ``invalid``; ``error`` says why an invalid one
    failed.
    """
    records: List[Dict[str, Any]] = []
    for template_id, source in sources.items():
        record: Dict[str, Any] = {
            "id": template_id,
            "title": source.title,
            "description": source.description,
            "icon": source.icon,
            "plugin_id": source.plugin_id,
            "version": source.definition.template_version,
            "status": "ready",
            "error": None,
            "recommended_plugins": [],
            "preview_data_url": preview_data_url(source.plugin_root, source.preview_path),
        }
        try:
            record["recommended_plugins"] = verify(source.definition, source.root).recommended_plugins
        except (TemplateError, OSError) as exc:
            record["status"] = "invalid"
            record["error"] = str(exc)
        records.append(record)
    return records


def load_spec(spec: Mapping[str, Any]) -> Dict[str, TemplateSource]:
    """Sources from a JSON spec: ``{"plugins": {id: root}, "registry": [...], "bundled_root": path}``.

    This is what Studio desktop sends to ``witwin template`` on stdin: the
    Plugin roots it resolved and its registry file.
    """
    plugins = spec.get("plugins") or {}
    if not isinstance(plugins, dict):
        raise TemplateError("plugins must map Plugin id to folder")
    registry = spec.get("registry") or []
    if not isinstance(registry, list):
        raise TemplateError("registry must be a list")
    return collect_sources(
        {str(key): Path(str(value)) for key, value in plugins.items()},
        registry=registry,
        bundled_root=spec.get("bundled_root") or None,
    )
