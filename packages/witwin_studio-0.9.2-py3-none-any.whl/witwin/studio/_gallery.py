"""Make a Project from a Gallery item, or fetch one for a desktop trial view.

A Gallery item version is a ``snap.Manifest`` (path -> sha256, size, mode; the
format of ``witwin_server/core/compute/snapshot.py``) plus one public,
immutable blob per content hash under ``blobBaseUrl/<sha[:2]>/<sha>``. This
module downloads the files the manifest lists, checks every byte against its
sha256 and size, and either:

- ``create_project``: writes a new Project folder, stamps a new id and name
  into ``witwin.toml``, adds what a Python Project lacks (``_scaffold``) and
  makes the first commit ``Create project from gallery <itemId>@<version>``
  (``_git``); or
- ``fetch_item``: fills ``~/.witwin/gallery-cache/<itemId>/<version>/`` for a
  temporary desktop view, without git. A cache that still matches the
  manifest is used as it is.

The CLI is ``witwin gallery create|fetch`` (contract 13.6 of
``dev_docs/gallery-plan.md``). Authentication is ``WITWIN_ACCESS_TOKEN`` (Electron
sets it from the signed-in account); the API is ``WITWIN_API_URL``, default
``https://api.witwin.ai``.

It parses the manifest itself: the SDK must not import ``witwin_server``.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Callable, Dict, Optional

DEFAULT_API_URL = "https://api.witwin.ai"
API_URL_ENV = "WITWIN_API_URL"
ACCESS_TOKEN_ENV = "WITWIN_ACCESS_TOKEN"
# snapshot.MANIFEST_VERSION; a newer manifest is refused rather than misread.
MANIFEST_VERSION = 1
CACHE_DIR_NAME = "gallery-cache"
STAGING_PREFIX = ".witwin-gallery-"
# Seconds per HTTP request. Large blobs stream, so this bounds a stall, not a download.
HTTP_TIMEOUT = 60
_CHUNK = 1024 * 1024

# Reasons on stdout as {"error": {"reason", "message"}}. The API's own reasons
# (gallery_item_not_found, ...) pass through unchanged.
REASON_UNAUTHORIZED = "unauthorized"
REASON_NETWORK = "network_error"
REASON_BAD_MANIFEST = "invalid_manifest"
REASON_VERIFY = "verification_failed"
REASON_DEST = "dest_not_empty"
REASON_IO = "io_error"


class GalleryError(RuntimeError):
    def __init__(self, reason: str, message: str) -> None:
        super().__init__(message)
        self.reason = reason
        self.message = message

    def to_wire(self) -> Dict[str, Dict[str, str]]:
        return {"error": {"reason": self.reason, "message": self.message}}


@dataclass(frozen=True)
class GalleryFile:
    sha256: str
    size: int
    mode: int = 0o644


@dataclass(frozen=True)
class GalleryVersion:
    item_id: str
    version: int
    files: Dict[str, GalleryFile]
    blob_base_url: str

    def blob_url(self, sha: str) -> str:
        return f"{self.blob_base_url.rstrip('/')}/{sha[:2]}/{sha}"


# --------------------------------------------------------------------------- #
# manifest
# --------------------------------------------------------------------------- #
def _safe_path(path: str) -> str:
    pure = PurePosixPath(path)
    if (
        not path or "\\" in path or pure.is_absolute() or not pure.parts
        or any(part in ("", ".", "..") for part in pure.parts)
        or ":" in pure.parts[0]
    ):
        raise GalleryError(REASON_BAD_MANIFEST, f"unsafe path in the manifest: {path!r}")
    # .git and .witwin are never published (gallery-plan 7.1); refuse them so
    # a bad manifest cannot plant hooks or plugin trust records.
    if pure.parts[0] in (".git", ".witwin"):
        raise GalleryError(REASON_BAD_MANIFEST, f"the manifest lists a private path: {path!r}")
    return pure.as_posix()


def parse_manifest(text: str) -> Dict[str, GalleryFile]:
    """``{relative path: GalleryFile}`` from a ``snap.Manifest`` JSON string."""
    try:
        data = json.loads(text)
    except (TypeError, ValueError) as exc:
        raise GalleryError(REASON_BAD_MANIFEST, f"the manifest is not JSON: {exc}") from None
    if not isinstance(data, dict) or data.get("version") != MANIFEST_VERSION:
        raise GalleryError(REASON_BAD_MANIFEST, "unsupported manifest version")
    raw_files = data.get("files")
    if not isinstance(raw_files, dict):
        raise GalleryError(REASON_BAD_MANIFEST, "the manifest has no files")
    files: Dict[str, GalleryFile] = {}
    for path, raw in raw_files.items():
        clean = _safe_path(str(path))
        try:
            sha = str(raw["sha256"])
            size = int(raw["size"])
            mode = int(raw.get("mode", 0o644)) & 0o777
        except (KeyError, TypeError, ValueError):
            raise GalleryError(REASON_BAD_MANIFEST, f"bad entry for {path!r}") from None
        if len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha) or size < 0:
            raise GalleryError(REASON_BAD_MANIFEST, f"bad sha256 or size for {path!r}")
        files[clean] = GalleryFile(sha, size, mode)
    return files


# --------------------------------------------------------------------------- #
# HTTP
# --------------------------------------------------------------------------- #
Fetch = Callable[[str, Dict[str, str]], bytes]
Download = Callable[[str, Path], None]


def api_url() -> str:
    return (os.environ.get(API_URL_ENV) or DEFAULT_API_URL).rstrip("/")


def _http_error(exc: urllib.error.HTTPError) -> GalleryError:
    try:
        body = json.loads(exc.read().decode("utf-8"))
        detail = body.get("detail") if isinstance(body, dict) else None
        if isinstance(detail, dict) and detail.get("reason"):
            return GalleryError(str(detail["reason"]), str(detail.get("message") or detail["reason"]))
    except (ValueError, OSError, UnicodeDecodeError):
        pass
    if exc.code in (401, 403):
        return GalleryError(REASON_UNAUTHORIZED, f"the Gallery API refused the request ({exc.code}); sign in again")
    if exc.code == 404:
        return GalleryError("gallery_item_not_found", "the Gallery item or version does not exist")
    return GalleryError(REASON_NETWORK, f"the Gallery API answered {exc.code}")


def _user_agent() -> str:
    from . import __version__

    return f"witwin-studio/{__version__}"


def _fetch(url: str, headers: Dict[str, str]) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": _user_agent(), **headers})
    try:
        with urllib.request.urlopen(request, timeout=HTTP_TIMEOUT) as response:  # noqa: S310 - https API URL
            return response.read()
    except urllib.error.HTTPError as exc:
        raise _http_error(exc) from None
    except (urllib.error.URLError, OSError) as exc:
        raise GalleryError(REASON_NETWORK, f"cannot reach {url}: {exc}") from None


def _download(url: str, path: Path) -> None:
    # Cloudflare's r2.dev answers 403 to urllib's default "Python-urllib/3.x"
    # User-Agent, so every blob download failed until the request named itself.
    request = urllib.request.Request(url, headers={"User-Agent": _user_agent()})
    try:
        with urllib.request.urlopen(request, timeout=HTTP_TIMEOUT) as response, path.open("wb") as handle:  # noqa: S310
            shutil.copyfileobj(response, handle, _CHUNK)
    except urllib.error.HTTPError as exc:
        raise GalleryError(REASON_NETWORK, f"download of {url} failed with {exc.code}") from None
    except (urllib.error.URLError, OSError) as exc:
        raise GalleryError(REASON_NETWORK, f"download of {url} failed: {exc}") from None


def fetch_version(item_id: str, version: int, *, fetch: Optional[Fetch] = None) -> GalleryVersion:
    """Read a published version's manifest from homepage-api (contract 13.2)."""
    token = os.environ.get(ACCESS_TOKEN_ENV, "").strip()
    if not token:
        raise GalleryError(REASON_UNAUTHORIZED, f"{ACCESS_TOKEN_ENV} is not set; sign in to WiTwin")
    quoted = urllib.parse.quote(item_id, safe="")
    url = f"{api_url()}/api/v1/gallery/items/{quoted}/versions/{int(version)}/manifest"
    body = (fetch or _fetch)(url, {"Authorization": f"Bearer {token}", "Accept": "application/json"})
    try:
        data = json.loads(body.decode("utf-8"))
        manifest_text = str(data["manifest"])
        blob_base_url = str(data["blobBaseUrl"])
    except (ValueError, KeyError, TypeError, UnicodeDecodeError, AttributeError):
        raise GalleryError(REASON_BAD_MANIFEST, "the Gallery API returned no manifest") from None
    if not blob_base_url.startswith(("https://", "http://")):
        raise GalleryError(REASON_BAD_MANIFEST, "blobBaseUrl is not an http(s) URL")
    return GalleryVersion(item_id, int(version), parse_manifest(manifest_text), blob_base_url)


# --------------------------------------------------------------------------- #
# files
# --------------------------------------------------------------------------- #
def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(_CHUNK), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _matches(path: Path, entry: GalleryFile) -> bool:
    try:
        return path.is_file() and not path.is_symlink() and path.stat().st_size == entry.size and _sha256(path) == entry.sha256
    except OSError:
        return False


def download_files(gallery: GalleryVersion, folder: Path, *, download: Optional[Download] = None) -> None:
    """Write every manifest file under ``folder``; each content is fetched once and verified."""
    download = download or _download
    blobs = folder / f"{STAGING_PREFIX}blobs"
    blobs.mkdir(parents=True, exist_ok=True)
    try:
        fetched: Dict[str, Path] = {}
        for relative, entry in sorted(gallery.files.items()):
            blob = fetched.get(entry.sha256)
            if blob is None:
                blob = blobs / entry.sha256
                download(gallery.blob_url(entry.sha256), blob)
                if not blob.is_file() or blob.stat().st_size != entry.size or _sha256(blob) != entry.sha256:
                    raise GalleryError(REASON_VERIFY, f"{relative} does not match its sha256 in the manifest")
                fetched[entry.sha256] = blob
            target = folder.joinpath(*relative.split("/"))
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(blob, target)
            if entry.mode & 0o111 and os.name != "nt":
                target.chmod(0o755)
    finally:
        shutil.rmtree(blobs, ignore_errors=True)


def _stamp_manifest(folder: Path, *, name: str, item_id: str, version: int) -> None:
    """Give the copied ``witwin.toml`` a new Project id and the chosen name.

    Every other key is kept. ``gallery_item`` / ``gallery_version`` say where
    the content came from, as ``template_id`` does for a template.
    """
    import datetime as _dt

    import tomlkit

    from ._manifest import MANIFEST_FORMAT_VERSION, MANIFEST_NAME

    manifest = folder / MANIFEST_NAME
    if not manifest.is_file():
        raise GalleryError(REASON_BAD_MANIFEST, "the Gallery item has no witwin.toml")
    try:
        doc = tomlkit.parse(manifest.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 - any parse error makes the item unusable
        raise GalleryError(REASON_BAD_MANIFEST, f"witwin.toml is not valid TOML: {exc}") from None
    project = doc.get("project")
    if not isinstance(project, dict):
        project = tomlkit.table()
        doc["project"] = project
    now = _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    project["id"] = str(uuid.uuid4())
    project["name"] = name
    if not str(project.get("format_version") or "").strip():
        project["format_version"] = MANIFEST_FORMAT_VERSION
    project["created"] = now
    project["modified"] = now
    project["gallery_item"] = item_id
    project["gallery_version"] = int(version)
    manifest.write_text(tomlkit.dumps(doc), encoding="utf-8", newline="\n")


def _target_folder(dest: Path, name: str) -> Path:
    """``dest`` itself when it is missing or empty, else a new ``<dest>/<name>`` folder.

    Both readings of ``--dest`` work: the Project folder, or the folder new
    Projects go in (as ``witwin template create --parent``).
    """
    from ._templates import safe_directory_name

    if not dest.exists() or (dest.is_dir() and not any(dest.iterdir())):
        return dest
    if not dest.is_dir():
        raise GalleryError(REASON_DEST, f"{dest} is a file")
    base = safe_directory_name(name)
    suffix = 1
    while True:
        candidate = dest / (base if suffix == 1 else f"{base} {suffix}")
        if not candidate.exists():
            return candidate
        suffix += 1


def create_project(
    item_id: str,
    version: int,
    dest: Path | str,
    *,
    name: Optional[str] = None,
    gallery: Optional[GalleryVersion] = None,
    fetch: Optional[Fetch] = None,
    download: Optional[Download] = None,
) -> Path:
    """Make a new Project from a Gallery version; returns its folder.

    Files are staged next to the target and moved into place with one rename,
    so a failure leaves no half-made Project.
    """
    from . import _git, _scaffold

    gallery = gallery or fetch_version(item_id, version, fetch=fetch)
    project_name = (name or "").strip() or item_id
    target = _target_folder(Path(dest).expanduser().resolve(), project_name)
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=STAGING_PREFIX, dir=target.parent))
    try:
        download_files(gallery, staging, download=download)
        _stamp_manifest(staging, name=project_name, item_id=item_id, version=gallery.version)
        _scaffold.scaffold_project(staging, name=project_name)
        if target.exists():
            target.rmdir()  # empty, checked by _target_folder
        os.rename(staging, target)
    except OSError as exc:
        raise GalleryError(REASON_IO, f"could not write the Project: {exc}") from None
    finally:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
    _git.ensure_gitattributes(target)
    _git.init_project_repo(target, message=_git.gallery_commit_message(item_id, gallery.version))
    return target


def cache_root() -> Path:
    return Path.home() / ".witwin" / CACHE_DIR_NAME


def fetch_item(
    item_id: str,
    version: int,
    *,
    root: Optional[Path] = None,
    gallery: Optional[GalleryVersion] = None,
    fetch: Optional[Fetch] = None,
    download: Optional[Download] = None,
) -> Path:
    """Download a version to the trial cache; reuse it when every file still matches."""
    gallery = gallery or fetch_version(item_id, version, fetch=fetch)
    base = (root or cache_root()) / _cache_segment(item_id)
    folder = base / str(gallery.version)
    if folder.is_dir() and all(
        _matches(folder.joinpath(*relative.split("/")), entry) for relative, entry in gallery.files.items()
    ):
        return folder
    base.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=STAGING_PREFIX, dir=base))
    try:
        download_files(gallery, staging, download=download)
        if folder.exists():
            shutil.rmtree(folder)
        os.rename(staging, folder)
    except OSError as exc:
        raise GalleryError(REASON_IO, f"could not write the cache: {exc}") from None
    finally:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
    return folder


def _cache_segment(item_id: str) -> str:
    clean = item_id.strip()
    if not clean or clean in (".", "..") or any(c in clean for c in '/\\:*?"<>|') or clean != os.path.basename(clean):
        raise GalleryError("gallery_item_not_found", f"invalid Gallery item id {item_id!r}")
    return clean
