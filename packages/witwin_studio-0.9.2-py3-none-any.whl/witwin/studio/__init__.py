"""Open and edit WiTwin Studio Projects from Python, without the editor.

    import witwin.studio as ws

    project = ws.open_project(".")
    scene = project.scene()                    # the main scene
    cube = scene.add("Cube", type="builtin.mesh", position=(0, 0, 1))
    cube.components.add("RadarConfig", frequency=77e9)
    scene.parameters["w"] = "2.5"              # a parameter (a formula or a number)
    cube.bind("Transform.scale", "w", unit="um", index=0)   # stores 2.5e-6 m
    scene.animation.set_keyframes(cube, "position", [(0, [0, 0, 1]), (2, [4, 0, 1])])  # Timeline keys
    scene.add_mesh("plate", (vertices, faces), unit="mm", material="PEC")  # any Python geometry
    # models/<name>.py: CONFIG + PARAMS = {"w": ws.param(40, unit="mm")} + build(ctx); ws.preview(build)
    scene.save()

    for record in project.results.list():
        print(record.version, record.message)

The names in ``__all__`` are the public, versioned surface; it is frozen by
``tests/test_api_surface.py``. Modules whose names start with ``_`` are
internal. Public submodules: ``witwin.studio.wtscene`` (the scene file codec),
``witwin.studio.units`` (unit tables) and ``witwin.studio.formula`` (the
Formula Graph engine; ``witwin.studio.formula.torch_backend.TorchBackend`` for
differentiable evaluation, which imports torch only when used) and
``witwin.studio.studies`` (the Project's Studies, ``studies/<id>.toml``, and
the ``python -m witwin.studio.studies`` process entry), ``witwin.studio.optimize``
(optimization methods, objectives and the runner of an optimize Study),
``witwin.studio.geometry`` (meshes from numpy / trimesh / manifold3d /
build123d / CadQuery, ``Body``, anchors and validation) and
``witwin.studio.meshbin`` (the ``.meshbin`` codec; imports numpy) and
``witwin.studio.views`` (Result views for Studio's Result View panel) and
``witwin.studio.tracking`` (``log`` / ``config`` / ``checkpoint`` / ``summary``
for training metrics, also exported here). Design:
``dev_docs/project-as-python-codebase.md``, ``dev_docs/backend/FORMULA_GRAPH.md``.
"""
from __future__ import annotations

from ._project import Project, ResultStore, SceneInfo, open_project
from ._results import ResultRecord
from . import formula, geometry, optimize, studies, units
from .geometry import Anchor, Body, GeometryValidationError, Handle, Param, ValidationReport, anchor, handle, param, preview
from ._scene import Components, Entity, Parameters, Scene, SceneConflictError, Transform
from ._animation import Animation
from .formula import BindingTarget, FormulaError
from .wtscene import FORMAT as SCENE_FORMAT
# Metric logging for training scripts (dev_docs/studies-plan.md §6): ws.log(...).
from .tracking import checkpoint, config, log, summary

__version__ = "0.9.2"

__all__ = [
    "Anchor",
    "Animation",
    "BindingTarget",
    "Body",
    "Components",
    "Entity",
    "FormulaError",
    "GeometryValidationError",
    "Handle",
    "Param",
    "Parameters",
    "Project",
    "ResultRecord",
    "ResultStore",
    "SCENE_FORMAT",
    "Scene",
    "SceneConflictError",
    "SceneInfo",
    "Transform",
    "ValidationReport",
    "__version__",
    "anchor",
    "checkpoint",
    "config",
    "handle",
    "log",
    "open_project",
    "param",
    "preview",
    "summary",
]
