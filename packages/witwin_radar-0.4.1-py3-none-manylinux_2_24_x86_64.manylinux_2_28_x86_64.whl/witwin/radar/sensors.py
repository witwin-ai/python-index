"""Radar sensor descriptions, antenna patterns, and native row weighting.

This concept-axis module owns the complete sensor response chain: typed array
and power contracts, freeze-time pattern interpolation, the native per-row
weight operator, and the round-trip pattern stage.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass, replace
from typing import Any

import torch

from .cuda import native_ops as _ops
from .paths import RadarPathBatch
from .policy import SPEED_OF_LIGHT_M_PER_S, first_order_only, refuse_derivative

DEFAULT_DIPOLE_ANGLES_DEG = tuple(float(angle) for angle in range(-90, 91))


def half_wave_dipole_power_cut(angle_deg: float) -> float:
    """Normalized half-wave dipole power gain versus off-boresight angle."""
    angle_rad = math.radians(angle_deg)
    cos_angle = math.cos(angle_rad)
    if abs(cos_angle) < 1e-8:
        return 0.0

    field = math.cos(0.5 * math.pi * math.sin(angle_rad)) / cos_angle
    return max(field * field, 0.0)


DEFAULT_DIPOLE_VALUES = tuple(half_wave_dipole_power_cut(angle) for angle in DEFAULT_DIPOLE_ANGLES_DEG)


#: The two supported pattern kinds. ``separable`` is a product of two
#: one-dimensional cuts; ``map`` is a bilinear two-dimensional table. The
#: kernel's integer selector mirrors this order.
PATTERN_KIND_SEPARABLE = "separable"
PATTERN_KIND_MAP = "map"
PATTERN_KINDS = (PATTERN_KIND_SEPARABLE, PATTERN_KIND_MAP)

#: The kernel's ``pattern_kind`` argument. An integer crosses the ABI because a
#: string would cost an allocation and a comparison per launch to say something
#: the spec already validated once.
PATTERN_KIND_CODE = {PATTERN_KIND_SEPARABLE: 0, PATTERN_KIND_MAP: 1}


def _float_tensor(values: Sequence[Any], *, device: torch.device, name: str, shape: tuple[int, ...]) -> torch.Tensor:
    tensor = torch.as_tensor(values, dtype=torch.float32, device=device).contiguous()
    if tuple(tensor.shape) != shape:
        raise ValueError(f"{name} must have shape {shape}, got {tuple(tensor.shape)}")
    return tensor


@dataclass(frozen=True, slots=True)
class SensorArraySpec:
    """Element offsets and the wavelength that turns them into metres.

    ``tx_loc`` and ``rx_loc`` are in units of HALF A WAVELENGTH, which is the
    unit the radar configuration has always used, and ``element_spacing_m``
    turns them into metres. Keeping the offsets in half-wavelengths is what lets
    the same array description mean the same beam pattern at a different carrier
    - the array is defined by its electrical size, not by its physical one.
    """

    num_tx: int
    num_rx: int
    tx_loc: tuple[tuple[float, float, float], ...]
    rx_loc: tuple[tuple[float, float, float], ...]
    reference_frequency_hz: float

    def __post_init__(self) -> None:
        if self.num_tx < 1:
            raise ValueError("num_tx must be positive")
        if self.num_rx < 1:
            raise ValueError("num_rx must be positive")
        if not self.reference_frequency_hz > 0.0:
            raise ValueError(
                "reference_frequency_hz must be positive; it is what turns a half-wavelength element offset into metres"
            )
        if len(self.tx_loc) != self.num_tx:
            raise ValueError(f"tx_loc must hold exactly num_tx={self.num_tx} offsets, got {len(self.tx_loc)}")
        if len(self.rx_loc) != self.num_rx:
            raise ValueError(f"rx_loc must hold exactly num_rx={self.num_rx} offsets, got {len(self.rx_loc)}")
        for name, rows in (("tx_loc", self.tx_loc), ("rx_loc", self.rx_loc)):
            for index, row in enumerate(rows):
                if len(row) != 3:
                    raise ValueError(f"{name}[{index}] must be a 3-element offset")

    @property
    def wavelength_m(self) -> float:
        return SPEED_OF_LIGHT_M_PER_S / self.reference_frequency_hz

    @property
    def element_spacing_m(self) -> float:
        """``c0 / f_c / 2``: what one unit of ``tx_loc`` is worth in metres."""

        return self.wavelength_m / 2.0

    @property
    def sensor_pair_count(self) -> int:
        """The virtual array size, ``num_tx * num_rx``."""

        return self.num_tx * self.num_rx

    def local_offsets_m(self, *, device: torch.device | str = "cpu") -> tuple[torch.Tensor, torch.Tensor]:
        """The element offsets in metres, still in the radar's LOCAL frame.

        Placing them in the world needs a pose, which belongs to the radar and
        not to its array. This spec describes the array; it does not know where
        the radar is pointing.
        """

        target = torch.device(device)
        spacing = self.element_spacing_m
        tx = _float_tensor(self.tx_loc, device=target, name="tx_loc", shape=(self.num_tx, 3))
        rx = _float_tensor(self.rx_loc, device=target, name="rx_loc", shape=(self.num_rx, 3))
        return (tx * spacing).contiguous(), (rx * spacing).contiguous()


@dataclass(frozen=True, slots=True)
class Pattern:
    """A tabulated POWER gain versus the two off-boresight angles.

    Build one with :meth:`isotropic`, :meth:`dipole`, :meth:`separable` or
    :meth:`table` rather than by naming the fields; the four of them are the
    whole public surface and the fields are the storage they share.

    Angles are in degrees and gains are normalised linear POWER gain, at most
    one.

    The table is a CONSTANT. The direction into it is differentiable, and the
    interpolation is piecewise linear, so the gain has an exact
    almost-everywhere derivative that the native kernel carries. A knot and the
    two support edges are genuine non-differentiabilities and the kernel returns
    the almost-everywhere value there.

    The angles are the same two the pattern helpers use: with a direction
    expressed in the radar's LOCAL frame, ``x = atan2(v_x, -v_z)`` and
    ``y = atan2(v_y, -v_z)``, both in degrees. Outside the tabulated support the
    gain is exactly zero rather than the nearest tabulated value, which is a
    modelling choice (an antenna that does not radiate behind itself) rather
    than an extrapolation accident.
    """

    kind: str
    #: Off-boresight angles of the x axis, degrees, strictly increasing.
    x_angles: tuple[float, ...]
    #: Off-boresight angles of the y axis, degrees, strictly increasing.
    y_angles: tuple[float, ...]
    #: Separable kind: one normalised power gain per x angle.
    x_gain: tuple[float, ...] | None = None
    #: Separable kind: one normalised power gain per y angle.
    y_gain: tuple[float, ...] | None = None
    #: Table kind: ``gain[y][x]``, normalised power gain.
    gain: tuple[tuple[float, ...], ...] | None = None

    def __post_init__(self) -> None:
        if self.kind not in PATTERN_KINDS:
            raise ValueError(f"kind must be one of {list(PATTERN_KINDS)}, got {self.kind!r}")
        if len(self.x_angles) < 2 or len(self.y_angles) < 2:
            raise ValueError("both pattern axes need at least two samples")
        for name, axis in (("x_angles", self.x_angles), ("y_angles", self.y_angles)):
            if any(later <= earlier for earlier, later in zip(axis, axis[1:], strict=False)):
                raise ValueError(f"{name} must be strictly increasing")
        if self.kind == PATTERN_KIND_SEPARABLE:
            if self.x_gain is None or self.y_gain is None:
                raise ValueError("a separable pattern needs x_gain and y_gain")
            if len(self.x_gain) != len(self.x_angles):
                raise ValueError("x_gain must hold one value per x axis sample")
            if len(self.y_gain) != len(self.y_angles):
                raise ValueError("y_gain must hold one value per y axis sample")
            rows: tuple[tuple[float, ...], ...] = (self.x_gain, self.y_gain)
        else:
            if self.gain is None:
                raise ValueError("a table pattern needs gain")
            if len(self.gain) != len(self.y_angles):
                raise ValueError("gain must hold one row per y axis sample")
            for row in self.gain:
                if len(row) != len(self.x_angles):
                    raise ValueError("each gain row needs one entry per x sample")
            rows = self.gain
        for row in rows:
            if any(value < 0.0 for value in row):
                raise ValueError("a power gain must be non-negative")

    @property
    def kind_code(self) -> int:
        return PATTERN_KIND_CODE[self.kind]

    @classmethod
    def isotropic(cls) -> Pattern:
        """Unit power gain in every direction: the stage as a proven no-op.

        Both axes span the whole range ``atan2`` can produce, so no direction
        falls outside the support and takes the zero-outside branch, and both
        values are ``1.0`` at each knot, so the interpolation returns exactly
        ``1.0``. This is the default for a radar that declares no pattern: an
        unchosen dipole attenuates every off-boresight return by a number
        nobody asked for.
        """

        return cls(
            kind=PATTERN_KIND_SEPARABLE,
            x_angles=(-180.0, 180.0),
            y_angles=(-180.0, 180.0),
            x_gain=(1.0, 1.0),
            y_gain=(1.0, 1.0),
        )

    @classmethod
    def dipole(cls) -> Pattern:
        """A half-wave dipole cut in both planes, over -90..90 degrees."""

        return cls(
            kind=PATTERN_KIND_SEPARABLE,
            x_angles=tuple(DEFAULT_DIPOLE_ANGLES_DEG),
            y_angles=tuple(DEFAULT_DIPOLE_ANGLES_DEG),
            x_gain=tuple(DEFAULT_DIPOLE_VALUES),
            y_gain=tuple(DEFAULT_DIPOLE_VALUES),
        )

    @classmethod
    def separable(cls, x_angles, x_gain, y_angles, y_gain) -> Pattern:
        """A pattern whose two-dimensional gain is the product of two cuts."""

        return cls(
            kind=PATTERN_KIND_SEPARABLE,
            x_angles=tuple(float(v) for v in x_angles),
            y_angles=tuple(float(v) for v in y_angles),
            x_gain=tuple(float(v) for v in x_gain),
            y_gain=tuple(float(v) for v in y_gain),
        )

    @classmethod
    def table(cls, x_angles, y_angles, gain) -> Pattern:
        """A pattern tabulated on the full ``(y, x)`` grid."""

        return cls(
            kind=PATTERN_KIND_MAP,
            x_angles=tuple(float(v) for v in x_angles),
            y_angles=tuple(float(v) for v in y_angles),
            gain=tuple(tuple(float(v) for v in row) for row in gain),
        )

    def tables(
        self, *, device: torch.device | str = "cpu"
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """The five resident tensors the kernel indexes, built once per frame set.

        The unused table for this kind is a one-element placeholder rather than
        an empty tensor: an empty CUDA tensor may carry a null data pointer, and
        a null pointer that is never dereferenced is still a pointer the ABI
        check has to reason about.
        """

        target = torch.device(device)
        num_x = len(self.x_angles)
        num_y = len(self.y_angles)
        x_axis = _float_tensor(self.x_angles, device=target, name="x_angles", shape=(num_x,))
        y_axis = _float_tensor(self.y_angles, device=target, name="y_angles", shape=(num_y,))
        placeholder = torch.zeros(1, dtype=torch.float32, device=target)
        if self.kind == PATTERN_KIND_SEPARABLE:
            x_gain = _float_tensor(self.x_gain, device=target, name="x_gain", shape=(num_x,))
            y_gain = _float_tensor(self.y_gain, device=target, name="y_gain", shape=(num_y,))
            return x_axis, y_axis, x_gain, y_gain, placeholder
        gain = _float_tensor(self.gain, device=target, name="gain", shape=(num_y, num_x)).reshape(-1)
        return x_axis, y_axis, placeholder, placeholder, gain.contiguous()


def watts_from_dbm(power_dbm: float) -> float:
    """``1e-3 * 10^(dBm/10)``: the ONE place transmit power becomes watts.

    The result fills a source endpoint's ``powers_w`` and reaches physics
    through that field and no other. There is deliberately no transmit voltage
    gain anywhere: a ``sqrt(P R)`` gain on a weight that already carries
    ``sqrt(P)`` counts the power twice and leaves the result in sqrt(W ohm)
    while the weight is in sqrt(W).
    """

    return 1e-3 * (10.0 ** (float(power_dbm) / 10.0))


#: A row that interacts at a site, which is every row the two-way join
#: publishes. The kernel's selector also knows a direct transmitter-to-receiver
#: row (code 1), whose length is ``|rx - tx|`` with no site term and therefore
#: no antenna angle; no production route builds one.
ROW_KIND_VIA = 0

#: Why the frozen tensors of the sensor-weight family refuse a derivative. They
#: are constants of the array and of the frame's row set - velocities, the
#: fixed leg length, the pattern frame and the pattern tables - and the native
#: operator has no gradient or tangent slot for any of them, so a marked one
#: would run the whole frame and return ``None``. Refused at CONSTRUCTION,
#: before ``validate`` and before any launch. ``pattern_gain`` is the
#: counter-example: a published OUTPUT that is ``mark_non_differentiable``,
#: which is a declaration rather than a silence.
_FROZEN_REASON = (
    "it is a frozen geometric constant of the array rather than a differentiable "
    "input, and the native sensor-weight operator has no gradient or tangent slot "
    "for it. The differentiable inputs here are tx_pos, rx_pos, site_in, site_out, "
    "intensity and the complex weight. A VELOCITY additionally has no leaf "
    "semantics under ADR-038: it is a forward-AD tangent direction that "
    "witwin.radar.propagation puts in the tangent slot of a position, so "
    "d(loss)/d(velocity) does not exist in either mode."
)


def _require(name: str, tensor: object, *, dtype: torch.dtype, shape: tuple[int, ...]):
    if not isinstance(tensor, torch.Tensor):
        raise TypeError(f"{name} must be a torch.Tensor, got {type(tensor).__name__}")
    if tensor.dtype != dtype:
        raise TypeError(f"{name} must use {dtype}, got {tensor.dtype}")
    if tuple(tensor.shape) != shape:
        raise ValueError(f"{name} must have shape {shape}, got {tuple(tensor.shape)}")
    if not tensor.is_contiguous():
        raise ValueError(
            f"{name} must be contiguous; the kernel indexes it linearly and this "
            "contract will not hide a copy on the hot path"
        )
    return tensor


@dataclass(frozen=True, slots=True)
class SensorWeightGeometry:
    """The constant part of one frame's row set.

    Every field here is a CONSTANT with respect to the derivative; the four
    position tensors are passed separately to the autograd entry so that they
    can carry a tangent or a gradient. ``__post_init__`` refuses a float tensor
    here that carries ``requires_grad`` or a forward tangent, naming the field,
    before :meth:`validate` and before any launch. The index tensors are
    deliberately not checked: they are ``int64`` / ``int32`` and cannot carry a
    derivative for autograd to lose.
    """

    num_tx: int
    num_rx: int
    tx_velocity: torch.Tensor
    rx_velocity: torch.Tensor
    site_velocity: torch.Tensor
    fixed_length_m: torch.Tensor
    tx_index: torch.Tensor
    rx_index: torch.Tensor
    row_kind: torch.Tensor
    pattern_frame: torch.Tensor

    #: The float tensors this owner declares constant, in declaration order.
    #: Named as data so that a field added to the dataclass without a decision
    #: about its derivative is visible as a gap rather than as silence.
    FROZEN_FIELDS = ("tx_velocity", "rx_velocity", "site_velocity", "fixed_length_m", "pattern_frame")

    def __post_init__(self) -> None:
        frozen = {name: getattr(self, name) for name in SensorWeightGeometry.FROZEN_FIELDS}
        refuse_derivative("witwin.radar.sensors.SensorWeightGeometry", _FROZEN_REASON, **frozen)

    @property
    def path_count(self) -> int:
        return int(self.fixed_length_m.shape[0])

    def validate(self) -> None:
        rows = self.path_count
        _require("tx_velocity", self.tx_velocity, dtype=torch.float32, shape=(self.num_tx, 3))
        _require("rx_velocity", self.rx_velocity, dtype=torch.float32, shape=(self.num_rx, 3))
        _require("site_velocity", self.site_velocity, dtype=torch.float32, shape=(rows, 3))
        _require("fixed_length_m", self.fixed_length_m, dtype=torch.float32, shape=(rows,))
        _require("tx_index", self.tx_index, dtype=torch.int64, shape=(rows,))
        _require("rx_index", self.rx_index, dtype=torch.int64, shape=(rows,))
        _require("row_kind", self.row_kind, dtype=torch.int32, shape=(rows,))
        _require("pattern_frame", self.pattern_frame, dtype=torch.float32, shape=(3, 3))


@dataclass(frozen=True, slots=True)
class SensorWeightPlan:
    """The scalars and the resident pattern tables one launch needs.

    The tables are a resident LOOKUP - a measured or synthesised antenna
    pattern, sampled on a fixed angular grid - and the kernel interpolates
    them. They are not differentiable inputs of the operator, so a marked
    table is refused here for the same reason the geometry's constants are.
    The pattern's contribution to the derivative is real and is carried by the
    WEIGHT, through the positions that decide which angle is looked up.
    """

    pattern_kind: int
    tables: tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]
    c0: float

    def __post_init__(self) -> None:
        tables = {f"tables[{index}]": table for index, table in enumerate(self.tables)}
        refuse_derivative("witwin.radar.sensors.SensorWeightPlan", _FROZEN_REASON, **tables)

    @classmethod
    def build(
        cls, pattern: Pattern, *, c0: float = SPEED_OF_LIGHT_M_PER_S, device: torch.device | str = "cuda"
    ) -> SensorWeightPlan:
        return cls(pattern_kind=pattern.kind_code, tables=pattern.tables(device=device), c0=float(c0))

    def kernel_tail(self, geometry: SensorWeightGeometry) -> tuple:
        """The trailing scalar arguments, in the order all three operators take.

        Written once because the three signatures agree by construction, and a
        divergence between them would be a silently different weight in the
        gradient than in the primal.
        """

        return (geometry.num_tx, geometry.num_rx, self.pattern_kind, self.c0)


@dataclass(frozen=True, slots=True)
class SensorWeightResult:
    """What one launch produced. Data only; the owner above constructs it."""

    weight: torch.Tensor
    total_delay_s: torch.Tensor
    delay_rate: torch.Tensor
    pattern_gain: torch.Tensor

    @classmethod
    def from_components(
        cls,
        out_re: torch.Tensor,
        out_im: torch.Tensor,
        total_delay_s: torch.Tensor,
        delay_rate: torch.Tensor,
        pattern_gain: torch.Tensor,
    ) -> SensorWeightResult:
        return cls(
            weight=torch.complex(out_re, out_im),
            total_delay_s=total_delay_s,
            delay_rate=delay_rate,
            pattern_gain=pattern_gain,
        )


def _row_constants(geometry: SensorWeightGeometry) -> tuple:
    """The constant row tensors that sit BEFORE ``intensity`` in every signature."""

    return (geometry.site_velocity, geometry.fixed_length_m, geometry.tx_index, geometry.rx_index, geometry.row_kind)


def _sensor_constants(geometry: SensorWeightGeometry, plan: SensorWeightPlan) -> tuple:
    """The constant sensor tensors that sit AFTER the weight in every signature."""

    return (geometry.pattern_frame,) + plan.tables


class _SensorWeight(torch.autograd.Function):
    """Autograd bridge for the three native sensor-weight operators."""

    @staticmethod
    def forward(
        tx_pos, rx_pos, site_in, site_out, intensity, weight_re, weight_im, tx_velocity, rx_velocity, geometry, plan
    ):
        rows = int(intensity.shape[0])
        out_re = torch.empty_like(intensity)
        out_im = torch.empty_like(intensity)
        total_delay_s = torch.empty_like(intensity)
        delay_rate = torch.empty_like(intensity)
        pattern_gain = torch.empty_like(intensity)
        _ops().sensor_weight_forward(
            tx_pos,
            rx_pos,
            tx_velocity,
            rx_velocity,
            site_in,
            site_out,
            *_row_constants(geometry),
            intensity,
            weight_re,
            weight_im,
            *_sensor_constants(geometry, plan),
            out_re,
            out_im,
            total_delay_s,
            delay_rate,
            pattern_gain,
            rows,
            *plan.kernel_tail(geometry),
        )
        return out_re, out_im, total_delay_s, delay_rate, pattern_gain

    @staticmethod
    def setup_context(ctx, inputs, output):
        (
            tx_pos,
            rx_pos,
            site_in,
            site_out,
            intensity,
            weight_re,
            weight_im,
            tx_velocity,
            rx_velocity,
            geometry,
            plan,
        ) = inputs
        ctx.geometry = geometry
        ctx.plan = plan
        saved = (tx_pos, rx_pos, site_in, site_out, intensity, weight_re, weight_im, tx_velocity, rx_velocity)
        ctx.save_for_backward(*saved)
        ctx.save_for_forward(*saved)
        # The pattern gain is a diagnostic, not a differentiable product: it is
        # published so a test can pin the interpolation against its Torch
        # oracle, and the weight is where its derivative actually goes.
        ctx.mark_non_differentiable(output[4])

    @staticmethod
    @first_order_only
    def backward(ctx, grad_out_re, grad_out_im, grad_tau_rt, grad_tau_rate, grad_gain):
        (tx_pos, rx_pos, site_in, site_out, intensity, weight_re, weight_im, tx_velocity, rx_velocity) = (
            ctx.saved_tensors
        )
        geometry = ctx.geometry
        plan = ctx.plan
        rows = int(intensity.shape[0])
        zeros = torch.zeros_like(intensity)
        grad_tx_pos = torch.empty_like(tx_pos)
        grad_rx_pos = torch.empty_like(rx_pos)
        grad_site_in = torch.empty_like(site_in)
        grad_site_out = torch.empty_like(site_out)
        grad_intensity = torch.empty_like(intensity)
        grad_weight_re = torch.empty_like(weight_re)
        grad_weight_im = torch.empty_like(weight_im)
        tx_row_scratch = torch.empty_like(site_in)
        rx_row_scratch = torch.empty_like(site_in)
        _ops().sensor_weight_backward(
            tx_pos,
            rx_pos,
            tx_velocity,
            rx_velocity,
            site_in,
            site_out,
            *_row_constants(geometry),
            intensity,
            weight_re,
            weight_im,
            *_sensor_constants(geometry, plan),
            zeros if grad_out_re is None else grad_out_re.contiguous(),
            zeros if grad_out_im is None else grad_out_im.contiguous(),
            zeros if grad_tau_rt is None else grad_tau_rt.contiguous(),
            zeros if grad_tau_rate is None else grad_tau_rate.contiguous(),
            grad_tx_pos,
            grad_rx_pos,
            grad_site_in,
            grad_site_out,
            grad_intensity,
            grad_weight_re,
            grad_weight_im,
            tx_row_scratch,
            rx_row_scratch,
            rows,
            *plan.kernel_tail(geometry),
        )
        return (
            grad_tx_pos,
            grad_rx_pos,
            grad_site_in,
            grad_site_out,
            grad_intensity,
            grad_weight_re,
            grad_weight_im,
            None,
            None,
            None,
            None,
        )

    @staticmethod
    def jvp(
        ctx,
        tan_tx_pos,
        tan_rx_pos,
        tan_site_in,
        tan_site_out,
        tan_intensity,
        tan_weight_re,
        tan_weight_im,
        tan_tx_velocity,
        tan_rx_velocity,
        tan_geometry,
        tan_plan,
    ):
        (tx_pos, rx_pos, site_in, site_out, intensity, weight_re, weight_im, tx_velocity, rx_velocity) = (
            ctx.saved_tensors
        )
        geometry = ctx.geometry
        plan = ctx.plan
        rows = int(intensity.shape[0])
        row_zeros = torch.zeros_like(intensity)
        vector_zeros = torch.zeros_like(site_in)
        tan_tx_pos = torch.zeros_like(tx_pos) if tan_tx_pos is None else tan_tx_pos.contiguous()
        tan_rx_pos = torch.zeros_like(rx_pos) if tan_rx_pos is None else tan_rx_pos.contiguous()
        tan_site_in = vector_zeros if tan_site_in is None else tan_site_in.contiguous()
        tan_site_out = vector_zeros if tan_site_out is None else tan_site_out.contiguous()
        tan_intensity = row_zeros if tan_intensity is None else tan_intensity.contiguous()
        tan_weight_re = row_zeros if tan_weight_re is None else tan_weight_re.contiguous()
        tan_weight_im = row_zeros if tan_weight_im is None else tan_weight_im.contiguous()

        tan_out_re = torch.empty_like(intensity)
        tan_out_im = torch.empty_like(intensity)
        tan_tau_rt = torch.empty_like(intensity)
        tan_tau_rate = torch.empty_like(intensity)
        _ops().sensor_weight_jvp(
            tx_pos,
            rx_pos,
            tx_velocity,
            rx_velocity,
            site_in,
            site_out,
            *_row_constants(geometry),
            intensity,
            weight_re,
            weight_im,
            *_sensor_constants(geometry, plan),
            tan_tx_pos,
            tan_rx_pos,
            tan_site_in,
            tan_site_out,
            tan_intensity,
            tan_weight_re,
            tan_weight_im,
            tan_out_re,
            tan_out_im,
            tan_tau_rt,
            tan_tau_rate,
            rows,
            *plan.kernel_tail(geometry),
        )
        return tan_out_re, tan_out_im, tan_tau_rt, tan_tau_rate, None


def evaluate_sensor_weights(
    *,
    tx_pos: torch.Tensor,
    rx_pos: torch.Tensor,
    site_in: torch.Tensor,
    site_out: torch.Tensor,
    intensity: torch.Tensor,
    weight: torch.Tensor,
    geometry: SensorWeightGeometry,
    plan: SensorWeightPlan,
) -> SensorWeightResult:
    """Apply the sensor description to one frame's rows, natively.

    ``weight`` is complex and is split into its real and imaginary parts with
    Torch's own autograd-aware accessors, so no complex tensor crosses the
    autograd boundary and the conjugate-Wirtinger convention cannot be got wrong
    at the seam. The returned ``total_delay_s`` and ``delay_rate`` are the same
    round-trip quantities the synthesis contract speaks, in seconds and
    dimensionless respectively.
    """

    geometry.validate()
    rows = geometry.path_count
    _require("tx_pos", tx_pos, dtype=torch.float32, shape=(geometry.num_tx, 3))
    _require("rx_pos", rx_pos, dtype=torch.float32, shape=(geometry.num_rx, 3))
    _require("site_in", site_in, dtype=torch.float32, shape=(rows, 3))
    _require("site_out", site_out, dtype=torch.float32, shape=(rows, 3))
    _require("intensity", intensity, dtype=torch.float32, shape=(rows,))
    if weight.dtype != torch.complex64:
        raise TypeError(f"weight must be complex64, got {weight.dtype}")
    if tuple(weight.shape) != (rows,):
        raise ValueError(f"weight must have shape {(rows,)}, got {tuple(weight.shape)}")

    out_re, out_im, total_delay_s, delay_rate, pattern_gain = _SensorWeight.apply(
        tx_pos,
        rx_pos,
        site_in,
        site_out,
        intensity,
        weight.real.contiguous(),
        weight.imag.contiguous(),
        geometry.tx_velocity,
        geometry.rx_velocity,
        geometry,
        plan,
    )
    return SensorWeightResult.from_components(out_re, out_im, total_delay_s, delay_rate, pattern_gain)


def _pattern_plan(pattern: Pattern, *, device: torch.device) -> SensorWeightPlan:
    if not isinstance(pattern, Pattern):
        raise TypeError(
            f"a sensor weight needs a witwin.radar.Pattern, got {type(pattern).__name__}; "
            "the radar's own is radar.pattern, and Pattern.isotropic() is the no-op"
        )
    return SensorWeightPlan.build(pattern, c0=SPEED_OF_LIGHT_M_PER_S, device=device)


@dataclass(frozen=True, slots=True, eq=False)
class RoundTripPatternStage:
    """One frozen topology's antenna-pattern application.

    Every tensor here is a CONSTANT of the frozen join: which transmitter and
    receiver each composed row belongs to, which site it visits, and the two
    zero-filled descriptions for the geometry quantities this route does not model
    (velocities and a fixed leg length). They are
    allocated once, at :meth:`freeze`, so a frame costs one gather and one
    launch.

    The velocities are zero and that is a statement rather than a placeholder:
    the delay and the delay rate this family computes are DISCARDED here.
    Channel owns the round-trip delay and the two-way join owns its rate, and
    recomputing either from the array geometry would put a second owner on a
    number the batch already carries. Only the weight is consumed.
    """

    num_tx: int
    num_rx: int
    row_count: int
    site_count: int
    tx_index: torch.Tensor
    rx_index: torch.Tensor
    row_kind: torch.Tensor
    zero_rows: torch.Tensor
    zero_vectors: torch.Tensor
    unit_intensity: torch.Tensor
    tx_velocity: torch.Tensor
    rx_velocity: torch.Tensor
    pattern_frame: torch.Tensor
    plan: SensorWeightPlan

    @classmethod
    def freeze(cls, radar, composer, *, site_ids, pattern: Pattern) -> RoundTripPatternStage:
        """Build the constant tables for one frozen :class:`TwoWayComposer`.

        ``site_ids`` is the binding's host tuple of stable site IDs. It is
        checked against the composer's site count here rather than read back
        from the device column ``topology.site_id``: the host tuple is already
        there, and the device column is not.
        """

        array = radar.system_config.sensors.array
        num_tx = int(array.num_tx)
        num_rx = int(array.num_rx)
        pair_index = composer.sensor_pair_index
        device = pair_index.device
        if composer.sensor_pair_count != num_tx * num_rx:
            raise ValueError(
                f"this join spans {composer.sensor_pair_count} sensor pairs but "
                f"the array is {num_tx} x {num_rx}; the pattern stage looks a "
                "transmitter and a receiver up by pair rank and the two must be "
                "the same front end"
            )
        if len(site_ids) != composer.site_count:
            raise ValueError(
                f"the binding declares {len(site_ids)} sites but this join was frozen against {composer.site_count}"
            )
        rows = int(composer.path_count)
        # PAIR_RANK_LAYOUT is sink major - pair = rx_rank * num_tx + tx_rank -
        # so the transmitter is the REMAINDER and the receiver is the quotient.
        # Getting these two the wrong way round steers every pattern lookup at
        # the wrong element and still produces a plausible cube.
        tx_index = torch.remainder(pair_index, num_tx).contiguous()
        rx_index = torch.div(pair_index, num_tx, rounding_mode="floor").contiguous()
        zero_rows = torch.zeros(rows, dtype=torch.float32, device=device)
        return cls(
            num_tx=num_tx,
            num_rx=num_rx,
            row_count=rows,
            site_count=int(composer.site_count),
            tx_index=tx_index,
            rx_index=rx_index,
            row_kind=torch.full((rows,), ROW_KIND_VIA, dtype=torch.int32, device=device),
            zero_rows=zero_rows,
            zero_vectors=torch.zeros(rows, 3, dtype=torch.float32, device=device),
            unit_intensity=torch.ones(rows, dtype=torch.float32, device=device),
            tx_velocity=torch.zeros(num_tx, 3, dtype=torch.float32, device=device),
            rx_velocity=torch.zeros(num_rx, 3, dtype=torch.float32, device=device),
            # A local direction is ``v @ world_from_local``, so the pattern-frame
            # components are dot products with that matrix's COLUMNS. The kernel
            # takes those columns as its rows; the transpose IS the frame change.
            pattern_frame=radar._world_from_local_matrix(device=device, dtype=torch.float32)[1]
            .transpose(0, 1)
            .contiguous(),
            plan=_pattern_plan(pattern, device=device),
        )

    def _geometry(self) -> SensorWeightGeometry:
        return SensorWeightGeometry(
            num_tx=self.num_tx,
            num_rx=self.num_rx,
            tx_velocity=self.tx_velocity,
            rx_velocity=self.rx_velocity,
            site_velocity=self.zero_vectors,
            fixed_length_m=self.zero_rows,
            tx_index=self.tx_index,
            rx_index=self.rx_index,
            row_kind=self.row_kind,
            pattern_frame=self.pattern_frame,
        )

    def _for_slots(self, count: int) -> RoundTripPatternStage:
        """Replicate routing for slot-major endpoints, sharing antenna tables."""

        slot = torch.arange(count, device=self.tx_index.device, dtype=torch.int64)[:, None]
        return replace(
            self,
            num_tx=self.num_tx * count,
            num_rx=self.num_rx * count,
            row_count=self.row_count * count,
            tx_index=(self.tx_index[None, :] + slot * self.num_tx).reshape(-1),
            rx_index=(self.rx_index[None, :] + slot * self.num_rx).reshape(-1),
            row_kind=self.row_kind.repeat(count),
            zero_rows=self.zero_rows.repeat(count),
            zero_vectors=self.zero_vectors.repeat(count, 1),
            unit_intensity=self.unit_intensity.repeat(count),
            tx_velocity=self.tx_velocity.repeat(count, 1),
            rx_velocity=self.rx_velocity.repeat(count, 1),
        )

    def apply(
        self,
        paths: RadarPathBatch,
        *,
        tx_pos: torch.Tensor,
        rx_pos: torch.Tensor,
        tx_targets_m: torch.Tensor,
        rx_targets_m: torch.Tensor,
    ) -> RadarPathBatch:
        """Publish ``paths`` with the transmit and receive pattern gains applied.

        ``tx_targets_m`` and ``rx_targets_m`` are per-composed-row points on
        the first and last propagation segments. For a reflected leg these are
        interaction points, not the scatter site. Gathering Channel's live
        geometry preserves derivatives through reflection points.

        Everything except the weight passes through untouched - the same
        objects, not copies - so row identity, row order, storage aliasing,
        dtype, device and the delay's gradient state all survive.
        """

        if not isinstance(paths, RadarPathBatch):
            raise TypeError(f"the antenna-pattern stage consumes a RadarPathBatch, got {type(paths).__name__}")
        if paths.weight_includes_antenna_pattern:
            raise ValueError(
                "these rows already record weight_includes_antenna_pattern; "
                "applying the array pattern twice squares its gain and is "
                "invisible in any magnitude plot, so it is refused here rather "
                "than counted"
            )
        if paths.path_count != self.row_count:
            raise ValueError(
                f"these rows carry {paths.path_count} paths but this stage was "
                f"frozen against {self.row_count}; the batch does not belong to "
                "this frozen topology"
            )
        geometry = self._geometry()
        weight = evaluate_sensor_weights(
            tx_pos=tx_pos,
            rx_pos=rx_pos,
            site_in=tx_targets_m,
            site_out=rx_targets_m,
            intensity=self.unit_intensity,
            weight=paths.complex_transfer_ref,
            geometry=geometry,
            plan=self.plan,
        ).weight
        return RadarPathBatch(
            sensor_pair_count=paths.sensor_pair_count,
            path_count=paths.path_count,
            sensor_pair_index=paths.sensor_pair_index,
            pair_offsets=paths.pair_offsets,
            total_delay_s=paths.total_delay_s,
            delay_rate=paths.delay_rate,
            complex_transfer_ref=weight,
            reference_frequency_hz=paths.reference_frequency_hz,
            row_valid=paths.row_valid,
            topology=paths.topology,
            weight_includes_antenna_pattern=True,
        )


__all__ = ["Pattern"]
