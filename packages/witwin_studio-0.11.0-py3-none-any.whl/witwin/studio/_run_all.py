"""``[project].run_all``: the Workflow or Study that Studio's Run all button starts.

Design: ``dev_docs/gallery-plan.md`` §14. A Project (a Gallery item, a
template, any Project) names one file in ``witwin.toml``::

    [project]
    run_all = "tasks/pipeline.toml"   # or "studies/<id>.toml"

The value is a Project-relative path, not a bare id, so a reader of
``witwin.toml`` sees which kind of file it is and where. Nothing runs when a
Project opens; Studio only shows the button, and the user's click starts it.

``read_run_all`` checks the shape of the value only. ``run_all_problems``
also loads the file it names, for ``witwin check`` and the ProjectServer.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from ._manifest import MANIFEST_NAME, read_project_table

KEY = "run_all"

# Folder -> kind. The folders are ``workflows.FOLDER`` and ``studies.FOLDER``;
# written out here so reading witwin.toml does not import either module.
_KINDS = {"tasks": "workflow", "studies": "study"}
_SUFFIX = ".toml"


@dataclass(frozen=True)
class RunAll:
    kind: str
    """``workflow`` or ``study``."""
    id: str
    """The Workflow id or Study id: the file name without ``.toml``."""
    path: str
    """``tasks/<id>.toml`` or ``studies/<id>.toml``, with ``/``."""


def parse_run_all(value: object) -> RunAll:
    """The entry ``value`` names; raises ValueError when it is not ``tasks/<id>.toml`` or ``studies/<id>.toml``."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{KEY} must be a path such as \"tasks/<id>.toml\"")
    text = value.strip().replace("\\", "/")
    folder, _, name = text.partition("/")
    kind = _KINDS.get(folder)
    if kind is None or "/" in name or not name.endswith(_SUFFIX):
        raise ValueError(f"{KEY} = {value!r}: expected \"tasks/<id>.toml\" or \"studies/<id>.toml\"")
    item_id = name[: -len(_SUFFIX)]
    if not _id_pattern(kind).fullmatch(item_id):
        raise ValueError(f"{KEY} = {value!r}: {item_id!r} is not a {'Workflow' if kind == 'workflow' else 'Study'} id")
    return RunAll(kind=kind, id=item_id, path=f"{folder}/{name}")


def read_run_all(project_dir: Path | str) -> Optional[RunAll]:
    """``[project].run_all`` of the Project; None when the key is absent or empty. Raises ValueError when malformed."""
    value = read_project_table(project_dir).get(KEY)
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    return parse_run_all(value)


def run_all_problems(project_dir: Path | str) -> List[str]:
    """Why Run all cannot start: a bad value, a missing file or one that does not load. Empty when fine or absent."""
    root = Path(project_dir)
    try:
        entry = read_run_all(root)
    except ValueError as exc:
        return [f"{MANIFEST_NAME}: {exc}"]
    if entry is None:
        return []
    if not (root / entry.path).is_file():
        return [f"{MANIFEST_NAME}: {KEY} names {entry.path}, which does not exist"]
    if entry.kind == "workflow":
        from . import workflows

        try:
            workflows.load_workflow(root / entry.path)
        except workflows.WorkflowError as exc:
            return [f"{entry.path}: {problem}" for problem in exc.problems]
        return []
    from .studies import StudyError, StudyStore

    try:
        StudyStore(root).get(entry.id)
    except StudyError as exc:
        return [f"{entry.path}: {exc}"]
    return []


def _id_pattern(kind: str):
    # The id rules of each folder's own loader, so a value this accepts is one it can open.
    if kind == "workflow":
        from .workflows import _ID_RE

        return _ID_RE
    from .studies._model import STUDY_ID_PATTERN

    return STUDY_ID_PATTERN
