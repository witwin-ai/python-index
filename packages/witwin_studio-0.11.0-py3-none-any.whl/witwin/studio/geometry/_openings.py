"""Walls with door and window openings, and mesh booleans.

The 2026-11-08 eval asked for a house. The Agent spent 26 code calls making
openings with trimesh and manifold3d by trial and error and never placed the
house. ``wall`` makes the common case (a straight wall with rectangular
openings) in numpy alone; ``boolean`` wraps manifold3d for every other cut.

``wall`` cuts the face into a grid at every opening edge, keeps the cells
outside the openings, and closes them with side faces where a kept cell
meets an opening or the outer edge. Every vertex sits on the grid, so the
mesh has no T-junctions and is watertight.
"""
from __future__ import annotations

from typing import Any, Dict, List, Sequence, Tuple

import numpy as np

from ._convert import MeshData, to_mesh

__all__ = ["boolean", "wall"]

# (along the wall, through it, up) -> model axes; Z is up in a model file.
_WALL_AXES = {"x": (0, 1, 2), "y": (1, 0, 2)}


def wall(length: float, height: float, thickness: float, openings: Sequence[Sequence[float]] = (), *,
         origin: Sequence[float] = (0.0, 0.0, 0.0), axis: str = "x") -> MeshData:
    """A straight wall with rectangular openings, as one watertight mesh (Z up).

    The wall starts at ``origin`` (the middle of its thickness, at its foot)
    and runs ``length`` along ``axis`` (``"x"`` or ``"y"``), ``height`` up z.
    Each opening is ``(start, bottom, width, height)``: ``start`` along the
    wall from ``origin``, ``bottom`` above the foot (0 for a door). Openings
    must lie inside the wall and must not overlap.
    """
    if axis not in _WALL_AXES:
        raise ValueError(f"wall axis must be 'x' or 'y', got {axis!r}")
    if not (length > 0 and height > 0 and thickness > 0):
        raise ValueError("wall length, height and thickness must be positive")
    holes = []
    for item in openings:
        if len(item) != 4:
            raise ValueError(f"an opening is (start, bottom, width, height), got {item!r}")
        s, b, w, h = (float(v) for v in item)
        if w <= 0 or h <= 0:
            raise ValueError(f"opening {item!r} has no size")
        if s < 0 or b < 0 or s + w > length + 1e-12 or b + h > height + 1e-12:
            raise ValueError(f"opening {item!r} is not inside the {length} x {height} wall")
        holes.append((s, b, s + w, b + h))
    for i, a in enumerate(holes):
        for c in holes[i + 1:]:
            if a[0] < c[2] and c[0] < a[2] and a[1] < c[3] and c[1] < a[3]:
                raise ValueError(f"openings {a} and {c} overlap")

    us = np.unique(np.r_[0.0, float(length), [v for h in holes for v in (h[0], h[2])]])
    ws = np.unique(np.r_[0.0, float(height), [v for h in holes for v in (h[1], h[3])]])
    nu, nw = len(us) - 1, len(ws) - 1
    filled = np.ones((nu, nw), dtype=bool)
    cu, cw = 0.5 * (us[:-1] + us[1:]), 0.5 * (ws[:-1] + ws[1:])
    for s, b, e, t in holes:
        filled[np.ix_((cu > s) & (cu < e), (cw > b) & (cw < t))] = False

    index: Dict[Tuple[int, int, int], int] = {}
    points: List[Tuple[float, float, float]] = []
    half = 0.5 * float(thickness)

    def vid(i: int, j: int, side: int) -> int:
        key = (i, j, side)
        if key not in index:
            index[key] = len(points)
            points.append((us[i], half if side else -half, ws[j]))
        return index[key]

    tris: List[Tuple[int, int, int]] = []

    def quad(corners: Sequence[int], normal: Sequence[float]) -> None:
        a, b, c, d = corners
        pa, pb, pc = (np.asarray(points[k]) for k in (a, b, c))
        if float(np.dot(np.cross(pb - pa, pc - pa), normal)) < 0:
            a, b, c, d = d, c, b, a
        tris.extend([(a, b, c), (a, c, d)])

    for i in range(nu):
        for j in range(nw):
            if not filled[i, j]:
                continue
            for side, n in ((0, -1.0), (1, 1.0)):  # the two faces of the wall
                quad([vid(i, j, side), vid(i + 1, j, side), vid(i + 1, j + 1, side), vid(i, j + 1, side)], (0, n, 0))
            # Side faces where this cell meets an opening or the outer edge.
            if i == 0 or not filled[i - 1, j]:
                quad([vid(i, j, 0), vid(i, j + 1, 0), vid(i, j + 1, 1), vid(i, j, 1)], (-1, 0, 0))
            if i == nu - 1 or not filled[i + 1, j]:
                quad([vid(i + 1, j, 0), vid(i + 1, j + 1, 0), vid(i + 1, j + 1, 1), vid(i + 1, j, 1)], (1, 0, 0))
            if j == 0 or not filled[i, j - 1]:
                quad([vid(i, j, 0), vid(i + 1, j, 0), vid(i + 1, j, 1), vid(i, j, 1)], (0, 0, -1))
            if j == nw - 1 or not filled[i, j + 1]:
                quad([vid(i, j + 1, 0), vid(i + 1, j + 1, 0), vid(i + 1, j + 1, 1), vid(i, j + 1, 1)], (0, 0, 1))

    local = np.asarray(points, dtype=float)
    out = np.empty_like(local)
    for source, target in enumerate(_WALL_AXES[axis]):
        out[:, target] = local[:, source]
    faces = np.asarray(tris, dtype=np.int64)
    if axis == "y":  # swapping two axes mirrors the mesh: turn the faces back outward
        faces = faces[:, ::-1]
    return MeshData(out + np.asarray(origin, dtype=float), faces)


def boolean(a: Any, b: Any, op: str = "difference") -> MeshData:
    """``a`` minus, plus or intersected with ``b`` (``op``: difference, union, intersection).

    ``a`` and ``b`` are anything ``to_mesh`` accepts (``MeshData``, ``(vertices,
    faces)``, ``ws.Body`` meshes, build123d shapes); ``b`` may be a list, which
    is merged first. Both must be closed (watertight) meshes. Needs the
    ``manifold3d`` package; for a wall with doors and windows ``wall`` needs
    nothing.
    """
    try:
        import manifold3d
    except ImportError as exc:
        raise ImportError("geometry.boolean needs the manifold3d package (uv add manifold3d); a wall with "
                          "rectangular openings needs only geometry.wall") from exc
    ops = {"difference": lambda x, y: x - y, "union": lambda x, y: x + y, "intersection": lambda x, y: x ^ y}
    if op not in ops:
        raise ValueError(f"op must be one of {sorted(ops)}, got {op!r}")

    def solid(obj: Any, what: str) -> Any:
        mesh = to_mesh(obj)
        m = manifold3d.Manifold(manifold3d.Mesh64(vert_properties=np.asarray(mesh.vertices, dtype=np.float64),
                                                  tri_verts=np.asarray(mesh.faces, dtype=np.uint64)))
        if m.status() != manifold3d.Error.NoError:
            raise ValueError(f"{what} is not a closed, watertight mesh ({m.status()}); a boolean needs solids")
        return m

    first = solid(a, "a")
    others = list(b) if isinstance(b, list) and b else [b]
    tool = solid(others[0], "b")
    for k, extra in enumerate(others[1:], 1):
        tool = tool + solid(extra, f"b[{k}]")
    result = ops[op](first, tool).to_mesh64()
    return MeshData(np.asarray(result.vert_properties, dtype=np.float64)[:, :3],
                    np.asarray(result.tri_verts, dtype=np.int64))
