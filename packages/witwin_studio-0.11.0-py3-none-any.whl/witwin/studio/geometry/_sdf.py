"""Signed-distance shapes with smooth blends, meshed by surface nets (numpy only).

For forms that flow into each other: a joint housing that grows out of an
arm, a handle that blends into a mug, a fillet between a drone's body and its
arms. Combine primitives, then mesh once:

    from witwin.studio.geometry import sdf

    shell = sdf.union(sdf.capsule((0, 0, 0), (0, 0, 0.4), 0.06),
                      sdf.sphere(0.09, center=(0, 0, 0.4)), k=0.03)   # 3 cm blend
    body = shell.mesh(resolution=96)                                   # MeshData, watertight

A shape is an ``SDF``: a function from points ``(N, 3)`` to signed distances
(negative inside) plus a bounding box, so ``mesh`` knows where to look.
``|`` is union, ``-`` subtraction, ``&`` intersection (all sharp); ``union``,
``subtract`` and ``intersect`` take ``k``, the blend radius in the model unit.
Smooth blends use the polynomial smooth minimum (Inigo Quilez), which keeps
the result within ``k / 4`` of a true distance.

Meshing samples a grid of ``resolution`` cells along the longest side, so
features thinner than about two cells disappear: raise ``resolution`` or
mesh the thin part separately. Distances of ``box``, ``ellipsoid`` and blends
are not exact, which only shifts vertices within a cell.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional, Sequence, Tuple

import numpy as np

from ._convert import MeshData
from ._sweep import _outward

__all__ = ["SDF", "box", "capsule", "cylinder", "ellipsoid", "intersect", "mesh", "sphere", "subtract",
           "torus", "union"]

Bounds = Tuple[np.ndarray, np.ndarray]
# Grid cells along the longest side when mesh() is given neither step nor
# resolution: about 1.5 % of the size; a sphere comes out near 10k triangles.
DEFAULT_RESOLUTION = 64
# Points evaluated per call of the distance function: bounds memory to a
# few hundred MB of temporaries for a 256^3 grid.
_CHUNK = 1 << 18


@dataclass
class SDF:
    """A signed distance function ``fn(points) -> distances`` with its bounding box ``(lo, hi)``."""

    fn: Callable[[np.ndarray], np.ndarray]
    bounds: Bounds

    def __call__(self, points: np.ndarray) -> np.ndarray:
        return self.fn(np.asarray(points, dtype=float))

    def __or__(self, other: "SDF") -> "SDF":
        return union(self, other)

    def __sub__(self, other: "SDF") -> "SDF":
        return subtract(self, other)

    def __and__(self, other: "SDF") -> "SDF":
        return intersect(self, other)

    def translate(self, offset: Sequence[float]) -> "SDF":
        d = np.asarray(offset, dtype=float)
        return SDF(lambda p: self.fn(p - d), (self.bounds[0] + d, self.bounds[1] + d))

    def mesh(self, *, resolution: Optional[int] = None, step: Optional[float] = None) -> MeshData:
        return mesh(self, resolution=resolution, step=step)


def _vec(value: Sequence[float], what: str) -> np.ndarray:
    v = np.asarray(value, dtype=float)
    if v.shape != (3,) or not np.all(np.isfinite(v)):
        raise ValueError(f"{what} must be three finite numbers, got {value!r}")
    return v


# ---------------------------------------------------------------- primitives
def sphere(radius: float, *, center: Sequence[float] = (0.0, 0.0, 0.0)) -> SDF:
    c = _vec(center, "center")
    r = float(radius)
    if not r > 0:
        raise ValueError(f"sphere radius must be positive, got {radius!r}")
    return SDF(lambda p: np.linalg.norm(p - c, axis=1) - r, (c - r, c + r))


def box(size: Sequence[float], *, radius: float = 0.0, center: Sequence[float] = (0.0, 0.0, 0.0)) -> SDF:
    """A box of ``size`` with edges rounded to ``radius`` (exact distance)."""
    half = _vec(size, "size") / 2.0
    if not np.all(half > 0):
        raise ValueError(f"box size must be positive, got {size!r}")
    c = _vec(center, "center")
    r = min(max(float(radius), 0.0), float(half.min()))
    inner = half - r

    def fn(p):
        q = np.abs(p - c) - inner
        return np.linalg.norm(np.maximum(q, 0.0), axis=1) + np.minimum(q.max(axis=1), 0.0) - r

    return SDF(fn, (c - half, c + half))


def capsule(a: Sequence[float], b: Sequence[float], radius: float) -> SDF:
    """A round-ended rod from ``a`` to ``b``: arms, legs, struts, handles."""
    pa, pb = _vec(a, "a"), _vec(b, "b")
    r = float(radius)
    if not r > 0:
        raise ValueError(f"capsule radius must be positive, got {radius!r}")
    ab = pb - pa
    denom = float(ab @ ab) or 1.0

    def fn(p):
        ap = p - pa
        h = np.clip(ap @ ab / denom, 0.0, 1.0)
        return np.linalg.norm(ap - h[:, None] * ab, axis=1) - r

    return SDF(fn, (np.minimum(pa, pb) - r, np.maximum(pa, pb) + r))


def cylinder(radius: float, height: float, *, center: Sequence[float] = (0.0, 0.0, 0.0), axis: str = "z") -> SDF:
    """A flat-ended cylinder along ``axis`` (exact distance)."""
    i = {"x": 0, "y": 1, "z": 2}.get(axis)
    if i is None:
        raise ValueError(f"cylinder axis must be 'x', 'y' or 'z', got {axis!r}")
    c = _vec(center, "center")
    r, h = float(radius), float(height) / 2.0
    if not (r > 0 and h > 0):
        raise ValueError("cylinder radius and height must be positive")
    others = [j for j in range(3) if j != i]

    def fn(p):
        q = p - c
        d = np.c_[np.linalg.norm(q[:, others], axis=1) - r, np.abs(q[:, i]) - h]
        return np.minimum(d.max(axis=1), 0.0) + np.linalg.norm(np.maximum(d, 0.0), axis=1)

    ext = np.full(3, r)
    ext[i] = h
    return SDF(fn, (c - ext, c + ext))


def ellipsoid(radii: Sequence[float], *, center: Sequence[float] = (0.0, 0.0, 0.0)) -> SDF:
    """An ellipsoid with semi-axes ``radii`` (bound distance, exact on the surface)."""
    rr = _vec(radii, "radii")
    if not np.all(rr > 0):
        raise ValueError(f"ellipsoid radii must be positive, got {radii!r}")
    c = _vec(center, "center")

    def fn(p):
        q = p - c
        k0 = np.linalg.norm(q / rr, axis=1)
        k1 = np.linalg.norm(q / (rr * rr), axis=1)
        return k0 * (k0 - 1.0) / np.where(k1 > 0, k1, 1.0)

    return SDF(fn, (c - rr, c + rr))


def torus(major: float, minor: float, *, center: Sequence[float] = (0.0, 0.0, 0.0)) -> SDF:
    """A ring around the z axis: ``major`` to the tube centre, tube radius ``minor``."""
    c = _vec(center, "center")
    big, small = float(major), float(minor)
    if not (big > 0 and small > 0):
        raise ValueError("torus radii must be positive")

    def fn(p):
        q = p - c
        return np.hypot(np.hypot(q[:, 0], q[:, 1]) - big, q[:, 2]) - small

    ext = np.array([big + small, big + small, small])
    return SDF(fn, (c - ext, c + ext))


# ---------------------------------------------------------------- operations
def _smin(a: np.ndarray, b: np.ndarray, k: float) -> np.ndarray:
    if k <= 0:
        return np.minimum(a, b)
    h = np.clip(0.5 + 0.5 * (b - a) / k, 0.0, 1.0)
    return b + (a - b) * h - k * h * (1.0 - h)


def union(*shapes: SDF, k: float = 0.0) -> SDF:
    """All ``shapes`` together; ``k > 0`` fills the joints with a smooth blend of about that radius."""
    if not shapes:
        raise ValueError("union needs at least one shape")
    kk = float(k)

    def fn(p):
        d = shapes[0](p)
        for s in shapes[1:]:
            d = _smin(d, s(p), kk)
        return d

    lo = np.min([s.bounds[0] for s in shapes], axis=0) - kk
    hi = np.max([s.bounds[1] for s in shapes], axis=0) + kk
    return SDF(fn, (lo, hi))


def subtract(shape: SDF, *cutters: SDF, k: float = 0.0) -> SDF:
    """``shape`` with ``cutters`` removed; ``k > 0`` rounds the cut edges."""
    kk = float(k)

    def fn(p):
        d = shape(p)
        for s in cutters:
            d = -_smin(-d, s(p), kk)
        return d

    return SDF(fn, shape.bounds)


def intersect(*shapes: SDF, k: float = 0.0) -> SDF:
    """Only where all ``shapes`` overlap; ``k > 0`` rounds the new edges."""
    if not shapes:
        raise ValueError("intersect needs at least one shape")
    kk = float(k)

    def fn(p):
        d = shapes[0](p)
        for s in shapes[1:]:
            d = -_smin(-d, -s(p), kk)
        return d

    lo = np.max([s.bounds[0] for s in shapes], axis=0)
    hi = np.min([s.bounds[1] for s in shapes], axis=0)
    if np.any(hi <= lo):
        raise ValueError("intersect: the shapes' bounding boxes do not overlap")
    return SDF(fn, (lo, hi))


# -------------------------------------------------------------------- meshing
def _evaluate(shape: SDF, axes: Sequence[np.ndarray]) -> np.ndarray:
    nx, ny, nz = (len(a) for a in axes)
    grid = np.empty(nx * ny * nz)
    gx, gy = np.meshgrid(axes[0], axes[1], indexing="ij")
    plane = np.c_[gx.reshape(-1), gy.reshape(-1)]
    per = max(_CHUNK // len(plane), 1)
    for start in range(0, nz, per):
        zs = axes[2][start:start + per]
        pts = np.c_[np.tile(plane, (len(zs), 1)), np.repeat(zs, len(plane))]
        values = np.asarray(shape(pts), dtype=float)
        # Points come z-major here; the grid is (x, y, z) in C order.
        grid_part = values.reshape(len(zs), nx, ny).transpose(1, 2, 0)
        grid.reshape(nx, ny, nz)[:, :, start:start + len(zs)] = grid_part
    return grid.reshape(nx, ny, nz)


def mesh(shape: SDF, *, resolution: Optional[int] = None, step: Optional[float] = None) -> MeshData:
    """The surface ``shape == 0`` as a watertight ``MeshData`` (naive surface nets).

    ``step`` is the grid spacing in the model unit; otherwise ``resolution``
    cells span the longest side (default 64). The grid gets two cells of
    margin so the surface closes.
    """
    lo, hi = (np.asarray(b, dtype=float) for b in shape.bounds)
    extent = float((hi - lo).max())
    if not extent > 0:
        raise ValueError("the shape has an empty bounding box")
    if step is None:
        res = int(resolution or DEFAULT_RESOLUTION)
        if not 8 <= res <= 512:
            raise ValueError(f"mesh resolution must be 8..512, got {resolution!r}")
        h = extent / res
    else:
        h = float(step)
        if not h > 0 or extent / h > 512:
            raise ValueError(f"mesh step must be positive and give at most 512 cells, got {step!r}")
    # The grid starts 0.37 cells off the box: faces of boxes and planes at
    # round coordinates then fall between nodes instead of on them, where
    # the clamp below would pull them in by a tenth of a cell.
    axes = [np.arange(lo[i] - 1.63 * h, hi[i] + 2 * h + 0.5 * h, h) for i in range(3)]
    d = _evaluate(shape, axes)
    inside = d < 0
    nx, ny, nz = d.shape
    cells = (nx - 1, ny - 1, nz - 1)
    acc = np.zeros(cells + (3,))
    cnt = np.zeros(cells)
    origin = np.array([a[0] for a in axes])

    # Every grid edge whose ends differ in sign crosses the surface once;
    # its crossing point is shared by the (up to) four cells around the edge.
    edges = []
    for axis in range(3):
        sl0 = [slice(None)] * 3
        sl1 = [slice(None)] * 3
        sl0[axis], sl1[axis] = slice(0, -1), slice(1, None)
        d0, d1 = d[tuple(sl0)], d[tuple(sl1)]
        crossing = inside[tuple(sl0)] != inside[tuple(sl1)]
        idx = np.argwhere(crossing)
        if not len(idx):
            edges.append((idx, np.zeros(0, dtype=bool)))
            continue
        a0, a1 = d0[crossing], d1[crossing]
        # Kept off the grid nodes: when the surface passes exactly through a
        # node, every cell around it would get that node as its vertex, and
        # the quads between them collapse to zero area. 10 % of a cell moves a
        # vertex less than the grid already blurs the surface.
        t = np.clip(a0 / (a0 - a1), 0.1, 0.9)
        point = origin + idx * h
        point[:, axis] += t * h
        u, v = (axis + 1) % 3, (axis + 2) % 3
        for du in (0, 1):
            for dv in (0, 1):
                c = idx.copy()
                c[:, u] -= du
                c[:, v] -= dv
                ok = (c[:, u] >= 0) & (c[:, v] >= 0) & (c[:, u] < cells[u]) & (c[:, v] < cells[v]) \
                    & (c[:, axis] < cells[axis])
                np.add.at(acc, tuple(c[ok].T), point[ok])
                np.add.at(cnt, tuple(c[ok].T), 1.0)
        edges.append((idx, inside[tuple(sl0)][crossing]))

    active = cnt > 0
    vertex_id = np.full(cells, -1, dtype=np.int64)
    vertex_id[active] = np.arange(int(active.sum()))
    vertices = acc[active] / cnt[active][:, None]

    quads = []
    for axis, (idx, inside_low) in enumerate(edges):
        if not len(idx):
            continue
        u, v = (axis + 1) % 3, (axis + 2) % 3
        # The four cells around the edge, counter-clockwise in the (u, v)
        # plane seen from +axis; with the inside at the low end the surface
        # faces +axis, so that order winds outward.
        ring = []
        for du, dv in ((1, 1), (0, 1), (0, 0), (1, 0)):
            c = idx.copy()
            c[:, u] -= du
            c[:, v] -= dv
            ring.append(c)
        ok = np.ones(len(idx), dtype=bool)
        for c in ring:
            ok &= (c[:, u] >= 0) & (c[:, v] >= 0) & (c[:, u] < cells[u]) & (c[:, v] < cells[v]) \
                & (c[:, axis] < cells[axis])
        ids = np.stack([vertex_id[tuple(c[ok].T)] for c in ring], axis=1)
        flip = ~inside_low[ok]
        ids[flip] = ids[flip][:, ::-1]
        quads.append(ids)
    if not quads:
        raise ValueError("the shape has no surface inside its bounds (is it empty?)")
    q = np.vstack(quads)
    q = q[np.all(q >= 0, axis=1)]
    # Split each (non-planar) quad along the diagonal whose smaller triangle
    # is larger. On a flat face three cell vertices can line up; the shorter
    # diagonal would then leave a zero-area triangle, which the validator flags.
    p = vertices

    def area(i, j, k):
        return np.linalg.norm(np.cross(p[q[:, j]] - p[q[:, i]], p[q[:, k]] - p[q[:, i]]), axis=1)

    by02 = np.minimum(area(0, 1, 2), area(0, 2, 3)) >= np.minimum(area(0, 1, 3), area(1, 2, 3))
    tris = np.vstack([q[by02][:, [0, 1, 2]], q[by02][:, [0, 2, 3]],
                      q[~by02][:, [0, 1, 3]], q[~by02][:, [1, 2, 3]]])
    return _outward(vertices, tris)
