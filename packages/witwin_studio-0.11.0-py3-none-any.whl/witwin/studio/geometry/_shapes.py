"""Shaped solids in numpy: lofted sections, rounded boxes and subdivision surfaces.

Most real objects are not boxes: a car body, a drone arm, a chair back or a
bottle is a run of cross-sections. These helpers build such forms so a model
file does not fall back to stacking cubes.

    from witwin.studio import geometry as g

    body = g.loft([g.superellipse(1.70, 0.55, 3.5), g.superellipse(1.80, 1.10, 4),
                   g.superellipse(1.60, 0.70, 3)], stations=[0, 2.0, 4.4], axis="x")
    case = g.rounded_box((0.30, 0.20, 0.08), radius=0.015)
    blob = g.subdivide(*g.box_cage((1, 1, 1)), levels=2)

Lengths are in the caller's unit; angles in degrees. Every solid comes back
as a watertight ``MeshData`` whose triangles face outward, like ``sweep`` and
``revolve`` (``_sweep.py``).

Axes. ``loft(..., axis=)`` places a 2D profile ``(u, v)`` in the plane across
the axis by a cyclic map, so the profile keeps its handedness: axis ``x`` puts
``(u, v)`` on ``(y, z)``, axis ``y`` on ``(z, x)``, axis ``z`` on ``(x, y)``.
In a Z-up model file a car along x therefore takes profiles of
``(width, height)``; a vase along z takes ``(x, y)`` outlines.

numpy only; loaded on first use like ``_sweep.py``.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from ._convert import MeshData
from ._sweep import _outward, _profile, triangulate_polygon

__all__ = ["airfoil", "box_cage", "loft", "resample_profile", "rounded_box", "rounded_rect", "subdivide",
           "superellipse"]

_AXES = {"x": (0, 1, 2), "y": (1, 2, 0), "z": (2, 0, 1)}  # (station, u, v) -> coordinate index
# Catmull-Clark multiplies the face count by about 4 per level; 5 levels of a
# 100-face cage is ~100k quads, already more than a model needs.
MAX_SUBDIVISION_LEVELS = 5


# ------------------------------------------------------------------ sections
def superellipse(width: float, height: float, n: float = 4.0, *, n_bottom: Optional[float] = None,
                 center: Sequence[float] = (0.0, 0.0), points: int = 64) -> np.ndarray:
    """A closed ``|u/a|^n + |v/b|^n = 1`` outline, counter-clockwise: ``(points, 2)``.

    ``n = 2`` is an ellipse; larger ``n`` squares it off (4 is a rounded
    rectangle, 10 is nearly a box with small round corners). ``n_bottom``
    gives the lower half its own exponent: a car or boat section is rounder
    on top (``n=3``) and flatter below (``n_bottom=8``). ``center`` shifts the
    outline, e.g. ``(0, 0.5)`` so a section sits on ``v = 0``.
    """
    if not (width > 0 and height > 0):
        raise ValueError(f"superellipse needs a positive width and height, got {width!r} x {height!r}")
    if not n > 0 or (n_bottom is not None and not n_bottom > 0):
        raise ValueError("superellipse exponents must be positive")
    count = int(points)
    if count < 8:
        raise ValueError(f"superellipse needs at least 8 points, got {points!r}")
    t = np.linspace(0.0, 2.0 * math.pi, count, endpoint=False)
    c, s = np.cos(t), np.sin(t)
    top = 2.0 / float(n)
    bottom = 2.0 / float(n_bottom if n_bottom is not None else n)
    exp = np.where(s >= 0, top, bottom)
    u = 0.5 * width * np.sign(c) * np.abs(c) ** exp
    v = 0.5 * height * np.sign(s) * np.abs(s) ** exp
    return np.c_[u + center[0], v + center[1]]


def rounded_rect(width: float, height: float, radius: float, *, center: Sequence[float] = (0.0, 0.0),
                 segments: int = 8) -> np.ndarray:
    """A ``width`` x ``height`` rectangle with circular corners of ``radius``, counter-clockwise.

    ``radius`` is clamped to half the shorter side; ``segments`` points per corner.
    """
    if not (width > 0 and height > 0):
        raise ValueError(f"rounded_rect needs a positive width and height, got {width!r} x {height!r}")
    r = min(max(float(radius), 0.0), 0.5 * min(width, height))
    w, h = 0.5 * width - r, 0.5 * height - r
    if r <= 0:
        out = np.array([[-w, -h], [w, -h], [w, h], [-w, h]], dtype=float)
    else:
        seg = max(int(segments), 1)
        corners = [(w, -h, -90.0), (w, h, 0.0), (-w, h, 90.0), (-w, -h, 180.0)]
        pts = []
        for cx, cy, start in corners:
            a = np.radians(start + np.linspace(0.0, 90.0, seg + 1))
            pts.append(np.c_[cx + r * np.cos(a), cy + r * np.sin(a)])
        out = np.vstack(pts)
        # A corner of radius == half the side meets the next one: drop the duplicates.
        keep = np.r_[True, np.linalg.norm(np.diff(out, axis=0), axis=1) > 1e-12 * max(width, height)]
        out = out[keep]
        if np.linalg.norm(out[0] - out[-1]) <= 1e-12 * max(width, height):
            out = out[:-1]
    return out + np.asarray(center, dtype=float)


def airfoil(code: str = "0012", chord: float = 1.0, *, points: int = 60) -> np.ndarray:
    """A NACA 4-digit section (``"2412"``, ``"0012"``), leading edge at u = 0, counter-clockwise.

    The trailing edge is closed (the 1 - 0.1036 x^4 term). Use it for
    propeller blades, wings and fins: loft a few of these with shrinking
    chords along the span.
    """
    digits = str(code).strip()
    if len(digits) != 4 or not digits.isdigit():
        raise ValueError(f"airfoil takes a NACA 4-digit code such as '2412', got {code!r}")
    m, p, t = int(digits[0]) / 100.0, int(digits[1]) / 10.0, int(digits[2:]) / 100.0
    if t <= 0:
        raise ValueError("airfoil thickness (last two digits) must be positive")
    half = max(int(points) // 2, 8)
    beta = np.linspace(0.0, math.pi, half + 1)
    x = 0.5 * (1.0 - np.cos(beta))  # cosine spacing: more points at the nose
    yt = 5.0 * t * (0.2969 * np.sqrt(x) - 0.1260 * x - 0.3516 * x**2 + 0.2843 * x**3 - 0.1036 * x**4)
    if m > 0 and 0 < p < 1:
        yc = np.where(x < p, m / p**2 * (2 * p * x - x**2), m / (1 - p) ** 2 * (1 - 2 * p + 2 * p * x - x**2))
        dyc = np.where(x < p, 2 * m / p**2 * (p - x), 2 * m / (1 - p) ** 2 * (p - x))
    else:
        yc, dyc = np.zeros_like(x), np.zeros_like(x)
    th = np.arctan(dyc)
    upper = np.c_[x - yt * np.sin(th), yc + yt * np.cos(th)]
    lower = np.c_[x + yt * np.sin(th), yc - yt * np.cos(th)]
    # Trailing edge -> upper surface -> nose -> lower surface; the two
    # trailing-edge points coincide, so one is dropped.
    outline = np.vstack([upper[::-1], lower[1:-1]])
    return _profile(outline * float(chord))


def resample_profile(profile: Any, points: int) -> np.ndarray:
    """``points`` samples evenly spaced by arc length, counter-clockwise, starting where the outline crosses +u.

    ``loft`` calls it so sections with different point counts line up: point
    k of every section sits at the same fraction of the way round, measured
    from the outline's rightmost direction.
    """
    p = _profile(profile)
    count = int(points)
    if count < 3:
        raise ValueError(f"resample_profile needs at least 3 points, got {points!r}")
    centre = p.mean(axis=0)
    angle = np.arctan2(p[:, 1] - centre[1], p[:, 0] - centre[0])
    p = np.roll(p, -int(np.argmin(np.abs(angle))), axis=0)
    closed = np.vstack([p, p[:1]])
    seg = np.linalg.norm(np.diff(closed, axis=0), axis=1)
    s = np.r_[0.0, np.cumsum(seg)]
    target = np.linspace(0.0, s[-1], count, endpoint=False)
    return np.c_[np.interp(target, s, closed[:, 0]), np.interp(target, s, closed[:, 1])]


# ---------------------------------------------------------------------- loft
def _catmull_rom(tracks: np.ndarray, samples: int) -> np.ndarray:
    """Uniform Catmull-Rom through ``tracks`` (K, ...) with ``samples`` steps per span; ends clamped."""
    k = len(tracks)
    padded = np.concatenate([tracks[:1], tracks, tracks[-1:]])
    out = [tracks[0]]
    for i in range(k - 1):
        p0, p1, p2, p3 = padded[i], padded[i + 1], padded[i + 2], padded[i + 3]
        for step in range(1, samples + 1):
            t = step / samples
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t
                              + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3))
    return np.stack(out)


def loft(sections: Sequence[Any], *, stations: Optional[Sequence[float]] = None, axis: str = "x",
         points: Optional[int] = None, smooth: bool = True, samples: int = 8, caps: bool = True,
         closed: bool = False) -> MeshData:
    """Join cross-sections into one solid: a car body, a fuselage, a blade, a bottle.

    Two forms:

    - 2D profiles plus ``stations``: each ``(M, 2)`` profile sits across
      ``axis`` at its station (``axis`` x maps profile ``(u, v)`` to ``(y, z)``;
      see the module note). Profiles may differ in point count; they are
      resampled to ``points`` (default: the largest count) by arc length.
    - 3D loops, no ``stations``: each section is an ``(M, 3)`` closed loop
      already in place; all loops need the same point count, in the same
      order around.

    ``smooth`` runs a Catmull-Rom curve through matching points of the
    sections (``samples`` rings per gap), so a few sections give a smooth
    body instead of straight facets between them; ``smooth=False`` joins
    neighbouring sections with straight walls. ``caps`` closes both ends
    flat (2D profiles: an exact triangulation; 3D loops: a fan from the
    centre, which needs roughly convex end loops). ``closed=True`` joins the
    last section back to the first (a ring) and puts no caps.
    """
    if len(sections) < 2:
        raise ValueError("loft needs at least 2 sections")
    if stations is not None:
        if len(stations) != len(sections):
            raise ValueError(f"loft got {len(sections)} sections but {len(stations)} stations")
        if axis not in _AXES:
            raise ValueError(f"loft axis must be 'x', 'y' or 'z', got {axis!r}")
        profiles = [_profile(s) for s in sections]
        count = int(points) if points else max(len(p) for p in profiles)
        flat = np.stack([resample_profile(p, count) for p in profiles])  # (K, M, 2)
        st = np.asarray(stations, dtype=float)
        if not np.all(np.diff(st) > 0):
            raise ValueError("loft stations must increase strictly")
        if smooth and len(sections) > 2:
            flat = _catmull_rom(flat, int(samples))
            st = np.interp(np.linspace(0, len(st) - 1, len(flat)), np.arange(len(st)), st)
        order = _AXES[axis]
        rings = np.zeros(flat.shape[:2] + (3,))
        rings[..., order[0]] = st[:, None]
        rings[..., order[1]] = flat[..., 0]
        rings[..., order[2]] = flat[..., 1]
        cap_2d: Optional[Tuple[np.ndarray, np.ndarray]] = (flat[0], flat[-1])
    else:
        loops = [np.asarray(s, dtype=float) for s in sections]
        if any(l.ndim != 2 or l.shape[1] != 3 for l in loops):
            raise ValueError("loft without stations takes (M, 3) loops; pass stations= for 2D profiles")
        if len({len(l) for l in loops}) != 1 or len(loops[0]) < 3:
            raise ValueError("3D loft loops need the same number of points (at least 3)")
        rings = np.stack(loops)
        if smooth and len(loops) > 2:
            rings = _catmull_rom(rings, int(samples))
        cap_2d = None
    k, m = rings.shape[:2]
    vertices = rings.reshape(-1, 3)
    idx = np.arange(k * m).reshape(k, m)
    spans = k if closed else k - 1
    a = idx[np.arange(spans)]
    b = idx[(np.arange(spans) + 1) % k]
    a1, b1 = np.roll(a, -1, axis=1), np.roll(b, -1, axis=1)
    faces = [np.stack([a, a1, b1], -1).reshape(-1, 3), np.stack([a, b1, b], -1).reshape(-1, 3)]
    if caps and not closed:
        if cap_2d is not None:
            first, last = triangulate_polygon(cap_2d[0]), triangulate_polygon(cap_2d[1])
            faces += [first[:, ::-1], last + (k - 1) * m]
        else:
            centres = np.stack([rings[0].mean(axis=0), rings[-1].mean(axis=0)])
            c0, c1 = len(vertices), len(vertices) + 1
            vertices = np.vstack([vertices, centres])
            j = np.arange(m)
            faces += [np.c_[np.full(m, c0), (j + 1) % m, j], np.c_[np.full(m, c1), (k - 1) * m + j,
                                                                    (k - 1) * m + (j + 1) % m]]
    mesh = _outward(vertices, np.vstack(faces))
    # The winding of the side walls follows the profile direction; _outward
    # flips everything at once, so a mirrored map (which no axis uses) would
    # still come out right.
    return mesh


# --------------------------------------------------------------- rounded box
def rounded_box(size: Sequence[float], radius: float, *, segments: int = 4,
                center: Sequence[float] = (0.0, 0.0, 0.0)) -> MeshData:
    """A box of ``size`` (x, y, z) with every edge and corner rounded to ``radius``; watertight.

    Use it instead of a plain box for any made object: housings, cabinets,
    batteries, buttons, a car's bumper. ``radius`` is clamped to half the
    shortest side; ``segments`` is the number of steps over each 90 degree
    rounding.
    """
    half = np.asarray(size, dtype=float) / 2.0
    if half.shape != (3,) or not np.all(half > 0):
        raise ValueError(f"rounded_box size must be three positive lengths, got {size!r}")
    r = min(max(float(radius), 0.0), float(half.min()))
    inner = half - r
    seg = max(int(segments), 1)
    # Grid lines per axis: the two flat-face edges at +-inner, then rounding
    # steps placed so the arc angle grows evenly: g = inner + r * tan(theta),
    # theta in [0, 45 deg] on each face, the other 45 degrees coming from the
    # neighbouring face.
    steps = max(seg // 2, 1)
    theta = np.linspace(0.0, math.pi / 4, steps + 1)
    lines = []
    for i in range(3):
        outer = inner[i] + r * np.tan(theta)
        lines.append(np.unique(np.r_[-outer[::-1], outer]))
    vertices: List[np.ndarray] = []
    faces: List[np.ndarray] = []
    count = 0
    for axis in range(3):
        u_axis, v_axis = (axis + 1) % 3, (axis + 2) % 3
        u, v = np.meshgrid(lines[u_axis], lines[v_axis], indexing="ij")
        for sign in (-1.0, 1.0):
            grid = np.zeros(u.shape + (3,))
            grid[..., axis] = sign * (inner[axis] + r * math.tan(math.pi / 4)) if r > 0 else sign * half[axis]
            grid[..., u_axis] = u
            grid[..., v_axis] = v
            pts = grid.reshape(-1, 3)
            core = np.clip(pts, -inner, inner)
            offset = pts - core
            norm = np.linalg.norm(offset, axis=1, keepdims=True)
            pts = core + r * offset / np.where(norm > 0, norm, 1.0) if r > 0 else pts
            nu, nv = u.shape
            ids = count + np.arange(nu * nv).reshape(nu, nv)
            q = np.stack([ids[:-1, :-1], ids[1:, :-1], ids[1:, 1:], ids[:-1, 1:]], -1).reshape(-1, 4)
            if sign < 0:
                q = q[:, ::-1]
            faces.append(np.r_[q[:, [0, 1, 2]], q[:, [0, 2, 3]]])
            vertices.append(pts)
            count += nu * nv
    return _weld(np.vstack(vertices) + np.asarray(center, dtype=float), np.vstack(faces))


def _weld(vertices: np.ndarray, faces: np.ndarray) -> MeshData:
    """Merge coincident vertices (face seams), drop collapsed triangles, wind outward."""
    scale = float(np.ptp(vertices, axis=0).max()) or 1.0
    key = np.round(vertices / (1e-9 * scale)).astype(np.int64)
    _, first, inverse = np.unique(key, axis=0, return_index=True, return_inverse=True)
    inverse = inverse.reshape(-1)
    f = inverse[faces]
    keep = (f[:, 0] != f[:, 1]) & (f[:, 1] != f[:, 2]) & (f[:, 0] != f[:, 2])
    f = f[keep]
    # Two faces that collapse onto the same three vertices with opposite
    # winding cancel out (zero-area slivers along a fully rounded edge).
    sorted_f = np.sort(f, axis=1)
    _, unique_idx, counts = np.unique(sorted_f, axis=0, return_index=True, return_counts=True)
    f = f[np.sort(unique_idx[counts == 1])]
    return _outward(vertices[first], f)


# --------------------------------------------------------- subdivision surface
def box_cage(size: Sequence[float], segments: Sequence[int] = (1, 1, 1), *,
             center: Sequence[float] = (0.0, 0.0, 0.0)) -> Tuple[np.ndarray, List[List[int]]]:
    """A box of quads as a subdivision cage: ``(vertices, quads)``.

    Move cage vertices (``vertices[i] += ...``) to shape the form, then
    ``subdivide(vertices, quads, levels=2)`` turns it into a smooth surface
    that stays inside the cage: a seat cushion, a helmet, a fuselage nose.
    ``segments`` splits each side so there are vertices to move.
    """
    half = np.asarray(size, dtype=float) / 2.0
    n = [max(int(s), 1) for s in segments]
    if half.shape != (3,) or not np.all(half > 0):
        raise ValueError(f"box_cage size must be three positive lengths, got {size!r}")
    lines = [np.linspace(-half[i], half[i], n[i] + 1) for i in range(3)]
    vertices, faces, count = [], [], 0
    for axis in range(3):
        u_axis, v_axis = (axis + 1) % 3, (axis + 2) % 3
        u, v = np.meshgrid(lines[u_axis], lines[v_axis], indexing="ij")
        for sign in (-1.0, 1.0):
            grid = np.zeros(u.shape + (3,))
            grid[..., axis] = sign * half[axis]
            grid[..., u_axis], grid[..., v_axis] = u, v
            nu, nv = u.shape
            ids = count + np.arange(nu * nv).reshape(nu, nv)
            q = np.stack([ids[:-1, :-1], ids[1:, :-1], ids[1:, 1:], ids[:-1, 1:]], -1).reshape(-1, 4)
            faces.append(q[:, ::-1] if sign < 0 else q)
            vertices.append(grid.reshape(-1, 3))
            count += nu * nv
    v = np.vstack(vertices)
    scale = float(np.ptp(v, axis=0).max())
    key = np.round(v / (1e-9 * scale)).astype(np.int64)
    _, first, inverse = np.unique(key, axis=0, return_index=True, return_inverse=True)
    inverse = inverse.reshape(-1)
    quads = [list(map(int, inverse[q])) for q in np.vstack(faces)]
    return v[first] + np.asarray(center, dtype=float), quads


def _cc_step(vertices: np.ndarray, faces: List[List[int]]) -> Tuple[np.ndarray, List[List[int]]]:
    """One Catmull-Clark step on a polygon mesh; returns all-quad faces. Open edges use the boundary rules."""
    nv = len(vertices)
    face_points = np.array([vertices[f].mean(axis=0) for f in faces])
    edge_faces: Dict[Tuple[int, int], List[int]] = {}
    for fi, f in enumerate(faces):
        for i in range(len(f)):
            a, b = f[i], f[(i + 1) % len(f)]
            edge_faces.setdefault((a, b) if a < b else (b, a), []).append(fi)
    edges = list(edge_faces)
    edge_index = {e: i for i, e in enumerate(edges)}
    e = np.array(edges, dtype=np.int64)
    mid = 0.5 * (vertices[e[:, 0]] + vertices[e[:, 1]])
    boundary = np.array([len(edge_faces[k]) != 2 for k in edges])
    two = [edge_faces[k] for k in edges]
    edge_points = mid.copy()
    inner = ~boundary
    if inner.any():
        fa = np.array([fs[0] for fs, b in zip(two, boundary) if not b])
        fb = np.array([fs[1] for fs, b in zip(two, boundary) if not b])
        edge_points[inner] = 0.5 * (mid[inner] + 0.5 * (face_points[fa] + face_points[fb]))

    # Interior vertex: (F + 2R + (n - 3) P) / n with F the mean of adjacent
    # face points, R the mean of adjacent edge midpoints, n the valence.
    f_sum, f_cnt = np.zeros((nv, 3)), np.zeros(nv)
    for fi, f in enumerate(faces):
        np.add.at(f_sum, f, face_points[fi])
        np.add.at(f_cnt, f, 1.0)
    r_sum, valence = np.zeros((nv, 3)), np.zeros(nv)
    np.add.at(r_sum, e[:, 0], mid)
    np.add.at(r_sum, e[:, 1], mid)
    np.add.at(valence, e[:, 0], 1.0)
    np.add.at(valence, e[:, 1], 1.0)
    on_boundary = np.zeros(nv, dtype=bool)
    on_boundary[e[boundary].reshape(-1)] = True
    n = np.maximum(valence, 1.0)[:, None]
    new = (f_sum / np.maximum(f_cnt, 1.0)[:, None] + 2.0 * r_sum / n + (n - 3.0) * vertices) / n
    if on_boundary.any():
        # Boundary vertex: 3/4 itself + 1/8 each boundary neighbour (a cubic B-spline along the rim).
        b_sum, b_cnt = np.zeros((nv, 3)), np.zeros(nv)
        be = e[boundary]
        np.add.at(b_sum, be[:, 0], vertices[be[:, 1]])
        np.add.at(b_sum, be[:, 1], vertices[be[:, 0]])
        np.add.at(b_cnt, be[:, 0], 1.0)
        np.add.at(b_cnt, be[:, 1], 1.0)
        rim = on_boundary & (b_cnt == 2)
        new[rim] = 0.75 * vertices[rim] + 0.125 * b_sum[rim]
        corner = on_boundary & (b_cnt != 2)
        new[corner] = vertices[corner]  # a corner or non-manifold point stays put
    out_v = np.vstack([new, edge_points, face_points])
    e_off, f_off = nv, nv + len(edges)
    out_f: List[List[int]] = []
    for fi, f in enumerate(faces):
        k = len(f)
        for i in range(k):
            a, b, prev = f[i], f[(i + 1) % k], f[i - 1]
            ea = edge_index[(a, b) if a < b else (b, a)]
            ep = edge_index[(prev, a) if prev < a else (a, prev)]
            out_f.append([a, e_off + ea, f_off + fi, e_off + ep])
    return out_v, out_f


def subdivide(vertices: Any, faces: Any = None, *, levels: int = 2) -> MeshData:
    """Catmull-Clark subdivision: a coarse cage of quads (or any polygons) becomes a smooth surface.

    Accepts ``(vertices, faces)`` with faces as a list of index lists (quads
    from ``box_cage``, triangles, mixed) or a ``MeshData``. The result is
    smooth, lies inside the cage and keeps its overall shape; a closed cage
    gives a watertight solid. Two levels are enough for display; each level
    multiplies the face count by about four (at most 5 levels).
    """
    if isinstance(vertices, MeshData):
        verts, polys = vertices.vertices, [list(map(int, f)) for f in vertices.faces]
    else:
        if faces is None:
            raise ValueError("subdivide needs faces: subdivide(vertices, faces) or subdivide(mesh_data)")
        verts = vertices
        polys = [list(map(int, f)) for f in faces]
    v = np.asarray(verts, dtype=float)
    if v.ndim != 2 or v.shape[1] != 3:
        raise ValueError(f"subdivide vertices must be (N, 3), got shape {v.shape}")
    if any(len(f) < 3 for f in polys):
        raise ValueError("every subdivide face needs at least 3 vertices")
    lv = int(levels)
    if not 0 <= lv <= MAX_SUBDIVISION_LEVELS:
        raise ValueError(f"subdivide levels must be 0..{MAX_SUBDIVISION_LEVELS}, got {levels!r}")
    for _ in range(lv):
        v, polys = _cc_step(v, polys)
    tris = []
    for f in polys:
        for i in range(1, len(f) - 1):
            tris.append((f[0], f[i], f[i + 1]))
    return _outward(v, np.array(tris, dtype=np.int64))
