"""Text checks of an assembled object, for a model that cannot see renders.

``check_assembly`` answers the questions a glance at a render would: does
anything float, are parts stacked on top of each other, is the object just
unchanged boxes and cylinders, and what does its outline look like from the
front, side and top. The Agent's default model takes no images, so this is
how it finds a robot arm whose upper half hovers over its base.

Parts are world-space triangle meshes (Scene frame: Y up, metres). Contact is
judged on axis-aligned bounding boxes, so a part touching a rotated thin part
may count as touching when it is a little away; floating parts are never
missed, which is the error that matters here.

numpy only; ``scene.check_assembly`` (studio.modeling) and the intent eval
(``server/tests/intent_eval/analyze.py``) both call it.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import numpy as np

__all__ = ["AssemblyPart", "PRIMITIVE_TYPES", "check_assembly"]

# Mesh types Studio makes from a size alone (MeshComponent.mesh_type).
PRIMITIVE_TYPES = frozenset({"Cube", "Sphere", "Cylinder", "Plane", "Cone", "Torus", "Capsule"})
# Above this share of unchanged primitives (with at least this many parts)
# the result suggests rebuilding the main forms.
BLOCKY_SHARE = 0.6
BLOCKY_MIN_PARTS = 5
# Characters per outline row and rows; a terminal cell is about twice as tall
# as wide, so columns are half as wide in the model as rows are tall.
SILHOUETTE_COLS = 48
SILHOUETTE_ROWS = 18
# Surface samples per outline; enough to fill every cell of a 48 x 18 grid.
_SAMPLES = 60_000
# Views as (right axis, up axis, axis looked along), Scene frame, matching
# scene.render: front looks down -Z, right looks down -X, top looks down -Y.
_VIEWS = {"front": (0, 1, 2), "right": (2, 1, 0), "top": (0, 2, 1)}
_RIGHT_SIGN = {"front": 1.0, "right": -1.0, "top": 1.0}
_UP_SIGN = {"front": 1.0, "right": 1.0, "top": -1.0}


@dataclass
class AssemblyPart:
    name: str
    vertices: Any  # (N, 3) world, metres, Y up
    faces: Any  # (M, 3)
    object_id: Optional[str] = None
    primitive: Optional[str] = None  # a PRIMITIVE_TYPES name when unchanged from Studio's shape


def _components(n: int, edges: List[tuple]) -> List[int]:
    parent = list(range(n))

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for a, b in edges:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
    return [find(i) for i in range(n)]


def _box_gap(lo_a, hi_a, lo_b, hi_b) -> float:
    """Distance between two boxes (0 when they touch or overlap)."""
    d = np.maximum(0.0, np.maximum(lo_a - hi_b, lo_b - hi_a))
    return float(np.linalg.norm(d))


def _area(part: AssemblyPart) -> float:
    if not len(part.faces):
        return 0.0
    t = np.asarray(part.vertices, dtype=float)[np.asarray(part.faces, dtype=np.int64)]
    return 0.5 * float(np.linalg.norm(np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0]), axis=1).sum())


def _touch_move(lo_a, hi_a, lo_b, hi_b) -> np.ndarray:
    """Shortest shift of box A that makes it touch box B (0 on axes where they already overlap)."""
    return np.where(lo_a > hi_b, hi_b - lo_a, np.where(hi_a < lo_b, lo_b - hi_a, 0.0))


def _sample_surface(parts: Sequence[AssemblyPart], count: int) -> np.ndarray:
    tris = [np.asarray(p.vertices, dtype=float)[np.asarray(p.faces, dtype=np.int64)] for p in parts if len(p.faces)]
    if not tris:
        return np.zeros((0, 3))
    t = np.concatenate(tris)
    area = 0.5 * np.linalg.norm(np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0]), axis=1)
    total = float(area.sum())
    rng = np.random.default_rng(0)  # same outline for the same Scene
    if total <= 0:
        return t.reshape(-1, 3)
    pick = rng.choice(len(t), size=count, p=area / total)
    r1, r2 = rng.random(count), rng.random(count)
    flip = r1 + r2 > 1
    r1[flip], r2[flip] = 1 - r1[flip], 1 - r2[flip]
    tt = t[pick]
    pts = tt[:, 0] + r1[:, None] * (tt[:, 1] - tt[:, 0]) + r2[:, None] * (tt[:, 2] - tt[:, 0])
    return np.vstack([pts, t.reshape(-1, 3)])  # vertices too, so thin parts always show


def _silhouette(points: np.ndarray, view: str) -> Dict[str, Any]:
    right, up, _ = _VIEWS[view]
    u = points[:, right] * _RIGHT_SIGN[view]
    v = points[:, up] * _UP_SIGN[view]
    width, height = float(np.ptp(u)), float(np.ptp(v))
    # One scale for both axes, a column half a row's height in the model,
    # chosen so the wider of the two directions fills its side of the grid.
    cell_w = max(width / SILHOUETTE_COLS, height / (2 * SILHOUETTE_ROWS), 1e-12)
    cell_h = 2 * cell_w
    cols = max(1, min(SILHOUETTE_COLS, int(np.ceil(width / cell_w)) or 1))
    rows = max(1, min(SILHOUETTE_ROWS, int(np.ceil(height / cell_h)) or 1))
    ci = np.clip(((u - u.min()) / cell_w).astype(int), 0, cols - 1)
    ri = np.clip(((v.max() - v) / cell_h).astype(int), 0, rows - 1)
    grid = np.zeros((rows, cols), dtype=bool)
    grid[ri, ci] = True
    mirrored = grid[:, ::-1]
    symmetry = float((grid & mirrored).sum() / max(grid.sum(), 1))
    return {"width": round(width, 4), "height": round(height, 4),
            "fill": round(float(grid.mean()), 3), "mirror_symmetry": round(symmetry, 3),
            "outline": ["".join("#" if c else "." for c in row) for row in grid]}


def check_assembly(parts: Sequence[AssemblyPart], *, tolerance: Optional[float] = None,
                   ground: Optional[float] = None, silhouettes: bool = True) -> Dict[str, Any]:
    """Floating parts, stacked duplicates, primitive share and outlines of ``parts``.

    ``tolerance`` (metres) is the gap that still counts as touching; default
    0.5 % of the assembly's size, at least 1 mm. Touching parts form groups;
    the group with the most surface area is the main one. ``ground`` is the
    support height; default the main group's lowest point. A part floats
    when its group is not the main one and does not stand on the ground.

    Why not the lowest point of all parts: a drone's camera that hangs below
    the skids and does not touch the body would become the only grounded
    group, and the whole drone would be reported floating instead of the
    camera (2026-11-08 eval).
    """
    parts = [p for p in parts if len(np.asarray(p.vertices))]
    if not parts:
        return {"parts": 0, "issues": [], "next": "No mesh parts to check."}
    lo = np.array([np.asarray(p.vertices, dtype=float).min(axis=0) for p in parts])
    hi = np.array([np.asarray(p.vertices, dtype=float).max(axis=0) for p in parts])
    a_lo, a_hi = lo.min(axis=0), hi.max(axis=0)
    size = float(np.linalg.norm(a_hi - a_lo))
    tol = float(tolerance) if tolerance is not None else max(0.005 * size, 1e-3)
    n = len(parts)

    edges, coincident = [], []
    vol = np.prod(np.maximum(hi - lo, 1e-12), axis=1)
    for i in range(n):
        # Boxes that overlap or come within tol of part i (vectorised over j > i).
        j = np.arange(i + 1, n)
        if not len(j):
            continue
        gap = np.maximum(0.0, np.maximum(lo[i] - hi[j], lo[j] - hi[i]))
        near = np.linalg.norm(gap, axis=1) <= tol
        for k in j[near]:
            edges.append((i, int(k)))
            inter = np.prod(np.maximum(0.0, np.minimum(hi[i], hi[k]) - np.maximum(lo[i], lo[k])))
            if inter >= 0.9 * vol[i] and inter >= 0.9 * vol[k]:
                coincident.append((i, int(k)))
    comp = _components(n, edges)
    area: Dict[int, float] = {}
    for i, p in enumerate(parts):
        area[comp[i]] = area.get(comp[i], 0.0) + _area(p)
    main = max(area, key=lambda c: (area[c], -min(lo[i, 1] for i in range(n) if comp[i] == c)))
    main_floor = float(min(lo[i, 1] for i in range(n) if comp[i] == main))
    floor = float(ground) if ground is not None else main_floor
    # A group stands when its lowest point is on the ground, not above it and
    # not below it (a part hanging under the feet does not hold the object up).
    group_floor = {c: float(min(lo[i, 1] for i in range(n) if comp[i] == c)) for c in set(comp)}
    grounded = {c for c, y in group_floor.items() if abs(y - floor) <= tol}
    if ground is None:
        grounded.add(main)
    issues: List[Dict[str, Any]] = []
    floating = [i for i in range(n) if comp[i] not in grounded]
    supported = [m for m in range(n) if comp[m] in grounded]
    # One move per detached group: the parts of a group touch each other, so
    # they move together. The move is the shortest shift that makes the pair
    # (group part, supported part) with the smallest gap touch; the Agent
    # applies it in the model file or with scene.update_transform.
    moves: Dict[int, Dict[str, Any]] = {}
    for c in sorted({comp[i] for i in floating}):
        members = [i for i in floating if comp[i] == c]
        if not supported:
            continue
        i, m = min(((i, m) for i in members for m in supported),
                   key=lambda pair: _box_gap(lo[pair[0]], hi[pair[0]], lo[pair[1]], hi[pair[1]]))
        d = _touch_move(lo[i], hi[i], lo[m], hi[m])
        moves[c] = {"parts": [parts[k].name for k in members], "onto": parts[m].name, "from": parts[i].name,
                    "move": [round(float(x), 4) + 0.0 for x in d],
                    # Scene (x, y, z) Y up is (x, -z, y) in a Z-up model file.
                    "move_z_up": [round(float(x), 4) + 0.0 for x in (d[0], -d[2], d[1])]}
    for i in floating:
        nearest = min(supported, key=lambda m: _box_gap(lo[i], hi[i], lo[m], hi[m])) if supported else None
        issue = {
            "kind": "floating", "part": parts[i].name, "objectId": parts[i].object_id,
            "height_above_ground": round(float(lo[i, 1] - floor), 4),
            "nearest": parts[nearest].name if nearest is not None else None,
            "gap_to_nearest": round(_box_gap(lo[i], hi[i], lo[nearest], hi[nearest]), 4) if nearest is not None else None,
        }
        if comp[i] in moves:
            issue["group_move"] = moves[comp[i]]["move"]
        issues.append(issue)
    for i, k in coincident:
        issues.append({"kind": "coincident", "parts": [parts[i].name, parts[k].name],
                       "objectIds": [parts[i].object_id, parts[k].object_id],
                       "message": "the two parts fill nearly the same box: a duplicate, or one hidden inside the other"})

    primitives: Dict[str, int] = {}
    for p in parts:
        if p.primitive:
            primitives[p.primitive] = primitives.get(p.primitive, 0) + 1
    primitive_count = sum(primitives.values())
    share = primitive_count / n
    out: Dict[str, Any] = {
        "parts": n, "size": [round(float(x), 4) for x in a_hi - a_lo], "ground": round(floor, 4),
        "tolerance": round(tol, 5), "groups": len(set(comp)),
        "primitive_parts": primitive_count, "primitive_share": round(share, 3), "primitives": primitives,
        "floating": len(floating), "issues": issues,
    }
    if moves:
        out["fixes"] = [moves[c] for c in sorted(moves)]
    advice = []
    if floating:
        advice.append(f"{len(floating)} part(s) float in {len(moves) or 1} detached group(s). Each entry of "
                      "fixes moves one group so it touches the part it should sit on: add move (Scene, Y up, "
                      "metres) to every part of the group, or move_z_up in a Z-up model file. Or join the "
                      "group with a connecting part.")
    if n >= BLOCKY_MIN_PARTS and share >= BLOCKY_SHARE:
        advice.append(f"{primitive_count} of {n} parts are plain {', '.join(sorted(primitives))}: the object will "
                      "read as stacked blocks. Rebuild the main forms as shaped meshes in a model file "
                      "(witwin.studio.geometry loft / revolve / sweep / rounded_box / subdivide / sdf; "
                      "skills.get modeling).")
    if advice:
        out["next"] = " ".join(advice)
    if silhouettes:
        pts = _sample_surface(parts, _SAMPLES)
        out["silhouettes"] = {view: _silhouette(pts, view) for view in _VIEWS}
    return out
