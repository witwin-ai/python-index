"""Atomic file writes: a reader or a crash never sees half a file.

``write_text`` / ``write_bytes`` write a temporary file in the target's folder,
flush and fsync it, then ``os.replace`` it over the target. A crash at any
point leaves either the old file or the new one, never a truncated mix.

``private=True`` is for files that hold secrets (``.witwin/runtime/server.json``
holds the server's bearer token): mode 0600 on POSIX; on Windows a protected
DACL that grants only the file's owner and SYSTEM. The temporary file gets
these permissions before any byte is written, and the rename keeps them.
"""
from __future__ import annotations

import os
import secrets
import stat
import sys
import time
from pathlib import Path

# os.replace fails on Windows while another process (an editor, a virus
# scanner, the indexer) holds the target open without FILE_SHARE_DELETE.
# Such locks last milliseconds, so a few short retries ride them out; a longer
# lock still raises, and the old file stays intact.
_REPLACE_RETRIES = 5
_REPLACE_DELAY_SEC = 0.02


def write_text(path: Path | str, text: str, *, private: bool = False) -> None:
    """Write ``text`` as UTF-8 with LF line endings (no newline translation)."""
    write_bytes(path, text.encode("utf-8"), private=private)


def write_bytes(path: Path | str, data: bytes, *, private: bool = False) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(f".{target.name}.{secrets.token_hex(4)}.tmp")
    # 0o666 lets the umask decide, as open(path, "w") would.
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0),
                 0o600 if private else 0o666)
    try:
        if private and sys.platform == "win32":
            restrict_to_owner(tmp)
        elif not private:
            _copy_mode(target, tmp)
        with os.fdopen(fd, "wb") as handle:
            fd = -1
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        _replace(tmp, target)
    except BaseException:
        if fd >= 0:
            os.close(fd)
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    _fsync_dir(target.parent)


def _copy_mode(source: Path, dest: Path) -> None:
    """Keep the permissions of the file being replaced (POSIX only)."""
    if sys.platform == "win32":
        return
    try:
        os.chmod(dest, stat.S_IMODE(source.stat().st_mode))
    except OSError:
        pass


def _replace(tmp: Path, target: Path) -> None:
    for attempt in range(_REPLACE_RETRIES):
        try:
            os.replace(tmp, target)
            return
        except PermissionError:
            if sys.platform != "win32" or attempt == _REPLACE_RETRIES - 1:
                raise
            time.sleep(_REPLACE_DELAY_SEC * (attempt + 1))


def _fsync_dir(folder: Path) -> None:
    """Make the rename itself durable (POSIX; Windows has no directory fsync)."""
    if sys.platform == "win32":
        return
    try:
        fd = os.open(folder, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def restrict_to_owner(path: Path | str) -> bool:
    """Limit ``path`` to its owner (and SYSTEM). True when the limit is in place.

    POSIX: mode 0600. Windows: a protected DACL ``D:P(A;;FA;;;OW)(A;;FA;;;SY)``,
    set through advapi32 with ctypes, so no new dependency and no ``icacls``
    process on the server's start path. ``OW`` (Owner Rights) follows the
    file's owner, which is the user who created it. Best effort: a file system
    without ACLs (FAT, some network shares) keeps its defaults and this
    returns False.
    """
    if sys.platform != "win32":
        try:
            os.chmod(path, 0o600)
            return True
        except OSError:
            return False
    import ctypes
    from ctypes import wintypes

    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    convert = advapi32.ConvertStringSecurityDescriptorToSecurityDescriptorW
    convert.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p),
                        ctypes.POINTER(wintypes.ULONG)]
    convert.restype = wintypes.BOOL
    set_security = advapi32.SetFileSecurityW
    set_security.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_void_p]
    set_security.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    sddl_revision_1 = 1
    dacl_security_information = 0x4
    protected_dacl_security_information = 0x80000000
    descriptor = ctypes.c_void_p()
    if not convert("D:P(A;;FA;;;OW)(A;;FA;;;SY)", sddl_revision_1, ctypes.byref(descriptor), None):
        return False
    try:
        return bool(set_security(
            str(path), dacl_security_information | protected_dacl_security_information, descriptor,
        ))
    finally:
        kernel32.LocalFree(descriptor)
