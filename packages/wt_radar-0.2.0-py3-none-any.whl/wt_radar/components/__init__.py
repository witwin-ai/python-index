"""Radar 0.5 Studio component registration."""
from .radar import RadarComponent

__all__ = ["RadarComponent"]
