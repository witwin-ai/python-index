# Radar acceptance

## Radar 0.5 headless acceptance

Last run: 2026-11-13, wt_radar 0.2.0

- Runtime: `witwin-radar 0.5.0`, `witwin-channel 0.6.0`, `witwin 0.4.6`, torch 2.10.0 cu128
- GPU: NVIDIA GeForce RTX 5080 (sm_120)
- Path: the Plugin's solver child (`solver_host.py`) started by `witwin.studio`,
  the scene sent as a scene ref, results read back through the solver's queries

### Static: Radar Sim template, Run Static Snapshot

- Project: a copy of `templates/radar-sim` 1.3.0 (`project.solve("witwin.radar.simulate")`)
- Target point 6.077 m from the sensor; range bin 0.0429 m
- Range profile and range-Doppler finite; target peak at 6.096 m (one bin), zero velocity
- Strongest return 6.182 m: the target car's cabin, part of the room
- Room: 12 single-bounce paths from 4 material slots, model `radar05_environment_single_bounce`
- Point cloud: 241 detections; points at the target range include (0.95, 6.02, 0.0) m
  in the radar frame for the target at (0.90, 6.00, -0.35) m
- With the isotropic antenna of template 1.2.0, the road straight under the
  sensor (0.99 m) was 38.6 dB above the target; template 1.3.0 gives the
  sensor a patch-like pattern, which puts it 48 dB below

### Moving: a walking skinned figure

- A torso, head, two legs and two arms skinned to five bones; the pelvis walks
  toward the radar at 1.0 m/s from 4.9 m, the limbs swing +-25 degrees at 1 Hz
- Floor, back wall; default 3 x 4 TI configuration, 128 chirps, 256 samples
- 10 frames at 10 FPS, cube `[10, 3, 4, 128, 256]`, all finite, nonzero
- Skin: 72 facets, `radar05_mesh_targets_physical_optics`, 72 scattering
  sites, default wet skin; 48/48 tracked sites active; 24 room paths
- Strongest moving return (zero-Doppler bins removed): 1.014 m/s (true 1.0,
  bin 0.078 m/s) at the torso's range within 0.07 m in 9 of 10 frames; at
  t = 0.5 s, when the limbs pass vertical at full angular speed, a leg return
  at -0.23 m/s is stronger
- Solver child time for the 10 frames: about 55 s

## Radar 0.4 acceptance (history)

Last run: 2026-09-19

- Branch: `codex/radar-result-ui-bridge`
- Scene: `cat_radar_demo_20260831_01`
- Runtime: official `witwin-radar 0.4.0`, `witwin-channel 0.5.0`, `witwin 0.4.0`
- GPU: NVIDIA GeForce RTX 4090 Laptop GPU
- Frames: 40/40 finite and nonzero, Studio time `0.0..3.9 s`
- Cube shape: `[40, 3, 4, 128, 256]`
- Dynamic target sites: 24 anatomically prioritized active sites from 44 available bone sites
- Dynamic target propagation: LOS-only, target multipath disabled, `max_depth=0`
- Dynamic target motion sampling: `chirp` (measured default)
- Static room: 37 meshes/material slots, 1890 triangles
- Environment reflection paths: 60
- Environment model: `radar04_native_single_bounce`, `max_depth=1`
- Solve + fast stored export: 56.156 s (compressed sparse-skin run: 59.735 s; 5.99% lower)
- Adaptive 44-site comparison: 123.547 s, 63.3% slower than 44-site chirp on this scene
- Adaptive/chirp difference: complex relative L2 0.0903%, magnitude relative L2 0.0631%, complex correlation 0.9999996, power ratio 0.9999995
- Target path rows: 288/frame (44-site reference: 528/frame; previous target-multipath mean: 14,080.8/frame)
- Export: `C:\WiTwin\projects\witwin-scratch\results\radar-animation\official-radar-0.4-semantic-24-fast-export-20260919.npz`
- SHA-256: `C3ED8C660E138F4CE521FB3CDFDD5C80F44C86FA2953B6986D8407C955F798E8`
- Saved-result reload: passed with matching shape, times, versions, and environment metadata
- Target motion sampling alone: 13.243 s full-mesh reference versus 1.708 s sparse/memoized, with bit-exact positions and velocities
- Sparse-skin export SHA-256 is identical to the pre-optimization semantic-24 export
- Fast export: 0.134 s and 120.16 MiB versus compressed 3.324 s and 111.63 MiB; all seven saved arrays/metadata fields are bit-exact after reload
- Semantic-24 versus 44-site whole-cube complex relative L2: 2.864%
- Semantic-24 dynamic-only difference after slow-time mean removal: complex relative L2 77.20%, Range-Doppler magnitude relative L2 50.49%, power ratio 0.8498
- Semantic-24 dynamic Range-Doppler peak matched the 44-site reference in 4/40 frames; this records the intentional target-model change
- Repository tests: 278 passed

## Studio Agent natural-language acceptance

The Studio live Agent harness was run against the current checkout through the
real configured provider, Workbench controller, Home Simulation confirmation
action, ProjectServer, and the plugin paths below. Both runs used fresh isolated
test Projects; the user's `witwin-scratch` Project was not mutated.

### Fresh positive measurement

- Prompt: `Record the existing cat motion from 0 to 5 seconds at 10 FPS. Do not change the animation.`
- Evidence: `C:\WiTwin\test-runs\wt-radar-agent-fresh-run-20260919\report.json`
- Plugin under test: `C:\WiTwin\plugins\wt_radar`
- Agent plan: preserve the existing Timeline, measure `0..5 s` at `10 FPS`, and do not export NPZ
- Confirmation path: compiled Home Simulation Run action using the exact pending plan
- Result: pipeline `succeeded`, completion `verified`, native GPU result independently verified
- Frames/cube: 50/50 nonzero frames, `[50, 3, 4, 128, 256]`
- Dynamic target: 24/24 active sites, LOS-only, chirp motion sampling, target multipath disabled
- Static room: 37 material slots and 60 coherent native single-bounce reflection paths
- Physics runtime: `witwin 0.4.0`, `witwin-radar 0.4.0`, `witwin-channel 0.5.0`, CUDA
- Motion preservation: passed; the complete authored Timeline remained unchanged
- Replay: persistent 50-frame payload created and integrity-verified
- Agent turn plus confirmed execution: 116.073 s
- Confirmed pipeline: 97.892 s; GPU submission step, including its synchronous simulation, completed in 79.995 s after preflight

The model also requested Replay although the sentence only asked for a recording.
The native measurement is valid, but this is recorded as an Agent intent-routing
overreach outside the Radar physics implementation.

### Genesis human to Radar 0.4.1

- Prompt 1: `In the current furnished room, add one human who walks forward naturally and turns slightly. Make about two seconds of animation and use baked transform playback. Do not create a cat or dog, and do not change the furniture. Do this now.`
- Prompt 2: `Now place one Radar automatically so it faces that generated person. Record the person from 0 to 1 second at 4 FPS using the real GPU Radar 0.4 pipeline, verify the measurement, and prepare synchronized replay. Keep the human animation unchanged, do not export an NPZ, and finish the work now.`
- Evidence: `C:\WiTwin\test-runs\human-radar-agent-20261011-f\report.json`
- Isolated review Project: `C:\WiTwin\test-runs\human-radar-agent-20261011-f\harness-e2e-b5aaa190-27fb-4ae9-b1d8-cf57bea52654`
- Agent result: one generated SMPL human (`walking_human`), one automatically placed Radar (`agent_radar`), durable verified receipt, and synchronized replay payload
- Human playback: 40 source frames at 20 FPS, 1.95 seconds, 26 baked Transform tracks, 1,040 baked keyframes, 24-bone skinned mesh
- Radar result: 4/4 finite nonzero CUDA frames at `0, 0.25, 0.5, 0.75 s`; cube shape `[4, 3, 4, 128, 256]`
- Runtime: `witwin-radar 0.4.1`, `witwin-channel 0.5.0`, `witwin 0.4.0`; NVIDIA GeForce RTX 4090 Laptop GPU
- Target model: `studio_visible_skinned_surface_sites_v2`; 24 declared sites, 3 interval-visible stable sites, no zero-fill or dropped active sites
- Motion evidence: 0.7831 m position extent, 3 moving sites, 4 dynamic delay-rate frames, and 4 coupled dynamic-return frames
- Room response: 28 material slots and 60 coherent native single-bounce reflection paths
- Replay: durable operation status `replay_ready`; the 0.4.1 submission atomically verified and prepared replay, so no redundant replay mutation was required
- Export: intentionally omitted, matching the natural-language request
- Harness verdict: passed every end-to-end assertion through the real configured provider, Workbench tool routing, ProjectServer, Genesis, Humanoid, and Radar plugins

### Stale-result safety check

- Prompt: `Prepare replay and NPZ from the last successful recording.`
- Evidence: `C:\WiTwin\test-runs\wt-radar-agent-result-reuse-20260919\report.json`
- Calls: `witwin.radar.inspect_pipeline`, then `witwin.radar.prepare_replay`
- Result: the Agent found the saved payload but correctly refused reuse because
  the durable native result fingerprint was stale after Scene inputs changed;
  it did not claim success or export an invalid NPZ.

Reproduction command from this repository:

```powershell
$env:PYTHONPATH='C:\WiTwin\plugins'
C:\Users\WQZ\AppData\Local\anaconda3\envs\witwin2\python.exe tools\accept_scene.py `
  C:\WiTwin\projects\witwin-scratch `
  cat_radar_demo_20260831_01 `
  --output C:\WiTwin\projects\witwin-scratch\results\radar-animation\<new-name>.npz
```

The command uses Studio's normal project-mesh and SkinnedMesh hydration paths,
then invokes the same `animation_request`, `solve_animation`, and
`export_animation` functions used by the component workflow. It returns nonzero
if any frame is nonfinite/zero, the semantic target does not contain exactly 24
active sites, no environment reflection/material is present, target multipath
is enabled, target motion is not chirp-sampled, or the reflection depth is not
exactly one.
