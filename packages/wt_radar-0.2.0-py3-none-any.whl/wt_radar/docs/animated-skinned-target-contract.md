# Animated skinned target contract (Studio -> WT Radar 0.5)

Status: implemented and validated

This document defines the integration boundary for an animated human or animal
authored in Studio and measured by WT Radar 0.5. It is an adapter contract,
not a Radar physics or signal-processing algorithm.

## Ownership

- The animation producer (Genesis, Motion Matching, or another Studio plugin)
  owns the hydrated `SkinnedMesh`, bone hierarchy, and baked Timeline tracks.
- Studio owns component serialization, linear-blend skinning transforms, and
  Timeline evaluation.
- WT Radar owns Timeline sampling of the whole skin, the skin's material,
  deterministic tracked-site selection, world-space velocity estimation, and
  conversion to a Radar 0.5 `MeshTargets` record over a deforming Core
  structure.
- `witwin-radar >=0.5,<0.6` owns the facet scattering model, target
  propagation, waveform synthesis, and Radar processing.
  `witwin-channel >=0.6,<0.7` owns path discovery.

No target-side `RadarScattererComponent` is required. The stable boundary is
the existing Studio `SkinnedMesh` plus baked `Transform` tracks. New projects
declare one or more targets through `animation_targets_json`; the legacy
`snapshot_target_id` remains a supported single-target fallback.

The canonical Agent/tool declaration is:

```json
{
  "targets": [
    {"object_id": "human"},
    {"object_id": "dog"}
  ]
}
```

Target IDs must be unique and each object must own a hydrated `SkinnedMesh`.
When `site_budget` is omitted, typed `SMPLBody` targets resolve from the Radar
component's editable `human_target_site_budget` (720 by default) and registered
`AnimalActor` targets resolve from `animal_target_site_budget` (360 by default).
Untyped skinned meshes use `target_site_budget` (24 by default). An explicit
per-target `site_budget` in the declaration always wins. Every budget remains
editable in the 1..2400 range and is consumed by the backend simulation: it is
both the number of tracked sites and the most scattering sites Radar may merge
the skin's facets into (`MeshTargets(max_sites=...)`).

## Producer requirements

The selected target object must provide a hydrated `SkinnedMesh` containing:

- finite bind-pose vertices and triangle faces;
- one or more `bone_ids` resolving to Scene objects with `Transform`;
- four bone indices and four finite, non-negative weights per vertex;
- per-vertex weights summing to one within the Studio tolerance;
- one finite 4x4 inverse-bind matrix per bone; and
- consistent `parent_id` and `Transform.parent` hierarchy representations.

Motion must be baked into the Scene Timeline:

- at least one target or bone `Transform` track is required;
- supported fields are `position`, `rotation`, and `scale`;
- values are finite three-vectors with strictly increasing key times;
- interpolation is `LINEAR`; and
- the requested measurement interval is contained in the clip duration.

An animation plugin may retain source motion metadata, but Radar consumes only
the baked Studio transforms. A controller track must not compete with those
transforms during measurement.

## Consumer behavior

The skin scatters from its facets. For every measured Studio frame the
adapter skins every vertex (Studio's linear-blend skinning, the same law as
below) and hands Radar each actor as one Core structure deformed between
frames at the sampled vertex velocities. Radar's `MeshTargets` turns every
front-facing facet into a physical-optics scatterer: its return follows from
its area, its orientation to both legs and the structure's material, and the
skin occludes itself and the room. The material is the actor's Studio
`Material` (ITU materials evaluated at the radar's frequency); an actor
without one, such as an SMPL body, scatters as wet skin (relative
permittivity 6.4, conductivity 42 S/m). There is no cross section to declare.

`StudioSkinSampler` validates each actor's complete contract. The
`MultiTargetSkinSampler` then presents their tracked sites as one combined
set. The tracked sites do not scatter; they carry the kinematic and
visibility evidence (positions, velocities, interval visibility). The
adapter:

1. chooses one representative bind-pose surface vertex for each influenced
   bone;
2. uses deterministic surface coverage for budgets above the anatomical bone
   anchors, up to 2400 sites per actor;
3. selects sites deterministically by anatomical priority and bind-pose spatial
   coverage;
4. evaluates Studio's linear-blend skinning in world coordinates at each
   requested time;
5. derives velocity from the same rendered world positions using a finite
   difference of at most 1 ms, with a right-hand derivative at Timeline knots;
   and
6. preserves stable site identity across the entire requested interval.

Every actor's skin goes into one official Radar 0.5 moving-target call.
Human and dog returns therefore coexist coherently in the same physical solve;
they are not simulated separately or combined as images. WT Radar does not
replace propagation, scattering, waveform, or DSP algorithms.

Automatic placement samples the joint trajectories of every declared target,
aims at their angular envelope, excludes all target meshes from static sensor
collision checks, and accepts a pose only after the combined native topology
preflight passes.

## Failure semantics

The adapter fails closed before native simulation when the target is missing,
the skin is not hydrated, influences or inverse binds are invalid, a bone or
parent cannot be resolved, tracks are unsupported or non-linear, Timeline
application is stale, sampled geometry is non-finite, or the interval is out of
range. It does not use rigid, identity, zero-return, or dropped-site fallbacks.

Tracked sites without native inbound and outbound paths for the complete
interval are reported by topology preflight, and a measurement with no visible
tracked site is refused before synthesis. Active sites retain stable IDs. A
hidden facet is not an error: the scene occludes it and it adds nothing.

## Version and compatibility policy

This contract targets:

- WT Radar plugin 0.2;
- `witwin-radar >=0.5,<0.6` (validated with 0.5.0);
- `witwin-channel >=0.6,<0.7`;
- `witwin >=0.4.6,<0.5` (Core dynamic scenes and structure deformations); and
- the Studio `SkinnedMesh` and baked Timeline APIs.

Any incompatible change to the skin payload, transform hierarchy, interpolation
semantics, site identity, or Radar moving-target input requires a new contract
revision and conformance tests. A version-number-only check is not sufficient.

## Conformance evidence

Automated conformance tests cover legacy single-target loading, human-and-dog
list normalization, editable typed defaults (720 for `SMPLBody`, 360 for
`AnimalActor`), explicit per-target overrides, combined positions and
velocities, joint automatic placement, and combined native-preflight requests.
A full native GPU measurement is still required to claim end-to-end physical
acceptance for a specific Scene and sensor placement.

