"""Studio skinned actors as Radar 0.5 mesh targets.

A skinned actor is a surface, so it scatters from its facets: each target's
whole skin becomes one Core structure, deformed over time by Studio's own
skinning, and :class:`witwin.radar.MeshTargets` makes every facet a
physical-optics scatterer (R-ADR-042). Radar computes each facet's return from
its area, its orientation to both legs and its structure's material; there is
no cross section to declare. The skin stays in the scene, so the body shadows
its own back and limbs (self-occlusion) like any other geometry.

What this module adds is only the Studio side: the skin's world vertices at the
measured Studio frames, the material, and stable structure IDs. The facet
model, its occlusion, its merging into at most ``site_budget`` sites and the
waveform all belong to Radar.
"""
from __future__ import annotations

import bisect
import dataclasses

import numpy as np
import torch

#: Skin structures are numbered after the room's (``studio_geometry`` uses 10_000 + n).
SKIN_STRUCTURE_ID_BASE = 20_000
#: The scattering model this module publishes, for result evidence.
SCATTERING_MODEL = "radar05_mesh_targets_physical_optics"
#: A target without a Studio Material scatters as wet skin: relative permittivity
#: and conductivity (S/m) of skin near 77 GHz, the value Radar's targets guide
#: uses for an SMPL body. It is a half-space: at 42 S/m the wave does not get
#: through a skin layer, so what lies under it does not matter.
DEFAULT_SKIN = {"eps_r": 6.4, "sigma_e": 42.0}
DEFAULT_SKIN_SOURCE = "default_wet_skin_77ghz"


@dataclasses.dataclass(frozen=True)
class SkinWorld:
    """The scattering world of one measurement: the room plus every target's skin."""

    world: object
    targets: object
    structure_ids: tuple[int, ...]
    evidence: dict


class FrameDeformation:
    """Core ``Deformation``: skin vertices between Studio frames, at constant velocity.

    Frame ``k`` holds the skinned world vertices ``V_k`` and their velocities
    ``W_k`` (Studio's finite difference, ``StudioSkinSampler.sample``). At time
    ``t`` the vertices are ``V_k + W_k (t - t_k)`` for the last frame with
    ``t_k <= t``, the same law the tracked sites follow, so the facets carry
    the skin's Doppler and micro-Doppler within each radar frame.
    """

    def __init__(self, times, positions, velocities, *, device):
        self.times = [float(value) for value in times]
        self.positions = torch.as_tensor(np.asarray(positions), dtype=torch.float32, device=device)
        self.velocities = torch.as_tensor(np.asarray(velocities), dtype=torch.float32, device=device)
        if (self.positions.ndim != 3 or self.positions.shape != self.velocities.shape
                or self.positions.shape[0] != len(self.times) or self.positions.shape[2] != 3):
            raise ValueError("Skin deformation needs (frames, vertices, 3) positions and velocities.")

    def at(self, time_s):
        from witwin.core.dynamics import DeformationState

        value = float(time_s)
        index = max(bisect.bisect_right(self.times, value) - 1, 0)
        vertices = self.positions[index] + self.velocities[index] * (value - self.times[index])
        return DeformationState(vertices=vertices.contiguous())


def target_material(target, structure_id, frequency_hz):
    """The skin's Core material: the target's Studio Material, or wet skin without one."""
    import witwin.core as wc
    from witwin_server.api import MaterialMap
    from .itu_frequency import itu_material_at

    material = target.get_component("Material")
    if material is None:
        return wc.PhysicalMaterial(name="skin", material_id=structure_id + 100_000,
                                   **DEFAULT_SKIN), DEFAULT_SKIN_SOURCE
    physical = MaterialMap.to_platform(material, material_id=structure_id + 100_000)
    evaluated = (itu_material_at(material.material_name, physical.eps_r, physical.sigma_e, frequency_hz)
                 if frequency_hz is not None else None)
    if evaluated is not None:
        physical = dataclasses.replace(physical, eps_r=evaluated[0], sigma_e=evaluated[1])
    return physical, "studio_material"


def skin_world(room, sampler, times, meshes, *, frequency_hz, device, site_budget, moving=True):
    """The room plus every target's skin, and the mesh targets that make the skins scatter.

    ``meshes[k][i]`` is target ``i``'s ``(positions, velocities)`` at
    ``times[k]`` (``MultiTargetSkinSampler.sample_meshes``). ``moving=False``
    freezes the skin at ``times[0]`` (a frozen static capture): the world is
    then a plain Core scene, so Radar evaluates it once per frame.
    """
    import witwin.core as wc
    from witwin.core.dynamics import DynamicScene
    from witwin.radar import MeshTargets

    if not meshes or len(meshes) != len(times):
        raise ValueError("Skin sampling needs one mesh sample per measured frame.")
    structures, deformations, evidence = list(room.structures), {}, []
    for index, (target, skin) in enumerate(zip(sampler.targets, sampler.samplers)):
        structure_id = SKIN_STRUCTURE_ID_BASE + index
        positions = np.stack([frame[index][0] for frame in meshes])
        velocities = np.stack([frame[index][1] for frame in meshes])
        material, source = target_material(target, structure_id, frequency_hz)
        geometry = wc.Mesh(torch.tensor(positions[0], dtype=torch.float32), torch.from_numpy(skin.mesh_faces),
                           recenter=False, fill_mode="surface", topology_diagnostics=False)
        structures.append(wc.Structure(
            geometry, material, name=str(target.name), structure_id=structure_id,
            material_id=structure_id + 100_000, assignment_id=structure_id + 200_000,
            surface_id=structure_id + 300_000, metadata={"studio_object_id": str(target.id)}))
        if moving:
            deformations[structure_id] = FrameDeformation(times, positions, velocities, device=device)
        evidence.append({
            "object_id": str(target.id),
            "structure_id": structure_id,
            "vertex_count": int(positions.shape[1]),
            "face_count": int(len(skin.mesh_faces)),
            "material_source": source,
            "eps_r": _real_or_pair(material.eps_r),
            "sigma_e": float(material.sigma_e),
        })
    scene = wc.Scene(structures=tuple(structures))
    world = DynamicScene(scene, structure_deformations=deformations) if deformations else scene
    structure_ids = tuple(item["structure_id"] for item in evidence)
    targets = MeshTargets(structure_ids=structure_ids, max_sites=int(site_budget))
    return SkinWorld(world, targets, structure_ids, {
        "model": SCATTERING_MODEL,
        "max_sites": int(site_budget),
        "skins": evidence,
    })


def scatter_site_count(radar, skin, time_s):
    """How many sites Radar merged the skins' facets into (at most the budget)."""
    from witwin.radar.labels import ground_truth

    labels = ground_truth(radar, skin.world, skin.targets, times=(float(time_s),))
    return int(labels.site_id.shape[0])


def _real_or_pair(value):
    value = complex(value)
    return value.real if value.imag == 0.0 else [value.real, value.imag]


__all__ = [
    "DEFAULT_SKIN",
    "FrameDeformation",
    "SCATTERING_MODEL",
    "SKIN_STRUCTURE_ID_BASE",
    "SkinWorld",
    "scatter_site_count",
    "skin_world",
    "target_material",
]
