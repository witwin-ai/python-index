"""Narrow WiTwin Radar 0.5 boundary used by the Studio adapters.

Studio keeps the TI-style component fields (MHz/us, kSPS and microseconds),
while Radar owns their conversion through :meth:`Radar.from_dict`. Keeping that
conversion here keeps the snapshot and animation paths off Radar's internals.

One Studio field differs from Radar 0.5's flat configuration: the antenna
pattern. Studio stores linear gain values whose peak is the element's gain;
Radar 0.5 takes a table normalised to a peak of 1 plus that peak as ``gain``
(dBi). :func:`radar_pattern_block` and :func:`studio_pattern_values` convert
between the two without changing the pattern.
"""
from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from typing import Any


RADAR_CONFIG_KEYS = (
    "num_tx",
    "num_rx",
    "fc",
    "slope",
    "power",
    "adc_samples",
    "adc_start_time",
    "sample_rate",
    "idle_time",
    "ramp_end_time",
    "chirp_per_frame",
    "tx_loc",
    "rx_loc",
    "antenna_pattern",
    "output_domain",
)


def flat_config(config: Mapping[str, Any]) -> dict[str, Any]:
    """Return only the public Radar flat FMCW interchange fields, in Radar 0.5's form."""

    out = {
        key: value
        for key in RADAR_CONFIG_KEYS
        if key in config and value_is_present(value := config[key])
    }
    if "antenna_pattern" in out:
        out["antenna_pattern"] = radar_pattern_block(out["antenna_pattern"])
    return out


def value_is_present(value: Any) -> bool:
    """Keep false-y numeric values while omitting optional ``None`` blocks."""

    return value is not None


def radar_pattern_block(pattern: Mapping[str, Any]) -> dict[str, Any]:
    """A Studio antenna pattern (linear gain, peak = element gain) as Radar 0.5's block.

    Each table is divided by its own peak and the peaks move into ``gain``
    (dBi); for a separable pattern the two cut peaks multiply, as the cuts do.
    A table already normalised passes through with ``gain`` 0 dBi. A table
    with no positive value has no peak to normalise by and is refused.
    """

    if "gain" in pattern:
        return dict(pattern)
    out = dict(pattern)
    if str(pattern.get("kind", "separable")) == "separable":
        x_values = [float(value) for value in pattern["x_values"]]
        y_values = [float(value) for value in pattern["y_values"]]
        x_peak, y_peak = _peak(x_values, "x_values"), _peak(y_values, "y_values")
        out["x_values"] = [value / x_peak for value in x_values]
        out["y_values"] = [value / y_peak for value in y_values]
        peak = x_peak * y_peak
    else:
        rows = [[float(value) for value in row] for row in pattern["values"]]
        peak = _peak([value for row in rows for value in row], "values")
        out["values"] = [[value / peak for value in row] for row in rows]
    out["gain"] = 10.0 * math.log10(peak)
    return out


def studio_pattern_values(pattern: Any) -> dict[str, Any]:
    """Radar 0.5's typed ``Pattern`` back to Studio's linear-gain fields.

    The inverse of :func:`radar_pattern_block`: the absolute gain goes back
    into the values (onto the x cut of a separable pattern).
    """

    peak = 10.0 ** (float(pattern.gain) / 10.0)
    if pattern.kind == "map":
        return {"values": [[float(value) * peak for value in row] for row in pattern.gain_table]}
    return {
        "x_values": [float(value) * peak for value in pattern.x_gain],
        "y_values": [float(value) for value in pattern.y_gain],
    }


def _peak(values: Sequence[float], name: str) -> float:
    peak = max(values, default=0.0)
    if not math.isfinite(peak) or peak <= 0.0:
        raise ValueError(f"Antenna pattern {name} needs a positive finite peak gain, got {peak!r}.")
    return peak


def build_radar(
    config: Mapping[str, Any],
    *,
    position: Sequence[float],
    look_at: Sequence[float],
    up: Sequence[float],
    polarization: str | Sequence[float] = "up",
    device: str = "cuda",
):
    """Construct the immutable Radar 0.5 instrument from Studio state."""
    from .runtime_contract import require_supported_runtime

    require_supported_runtime()

    from witwin.radar import Radar

    return Radar.from_dict(
        flat_config(config),
        position=tuple(float(value) for value in position),
        look_at=tuple(float(value) for value in look_at),
        up=tuple(float(value) for value in up),
        polarization=(
            polarization
            if isinstance(polarization, str)
            else tuple(float(value) for value in polarization)
        ),
        device=device,
    )
