"""Studio-to-Radar 0.5 request, simulation, result, and replay adapters."""
