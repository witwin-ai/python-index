"""The static room's own return, from Radar 0.5's environment route.

Radar 0.5 composes site-less transmitter -> environment -> receiver rows itself
(``environment=True``), so this module only asks for them once per capture and
keeps the target rows out: Channel discovers the reflections, the room's Core
materials set their response, and Radar synthesizes the echo. No RF or DSP is
implemented here.
"""
from dataclasses import dataclass

import torch

from .runtime_contract import require_supported_runtime


#: Room returns are single-bounce specular reflections, like the target legs.
ENVIRONMENT_MODEL = "radar05_environment_single_bounce"
ENVIRONMENT_MAX_DEPTH = 1
#: Distance, m, and stable ID of the placeholder site; see ``room_echo``.
_ANCHOR_DISTANCE_M = 1.0
_ANCHOR_ID = 1
#: The class the room rows fall in under ``room_echo``'s declaration.
_ROOM_CLASS = "direct_leakage"


@dataclass(frozen=True)
class EnvironmentClutterResult:
    """One static raw Radar frame of the room alone, and evidence about its paths."""

    cube: torch.Tensor
    reflected_path_count: int
    material_slot_count: int
    max_depth: int = ENVIRONMENT_MAX_DEPTH
    # Producer axes of this cube, for a capture with no target synthesis.
    axes: object = None

    def evidence(self):
        return {
            "model": ENVIRONMENT_MODEL,
            "max_depth": self.max_depth,
            "reflected_path_count": self.reflected_path_count,
            "material_slot_count": self.material_slot_count,
            "coherent_with_target": True,
        }


def add_environment_to_fmcw_result(radar, target_cube, environment):
    """Coherently add the static room return to a target cube.

    Synthesis is linear in the composed rows, so the room echo and the target
    echo sum to the echo of both. That holds only before a nonlinear receive
    stage; the Studio adapter refuses every receive-chain option, so a radar
    that has one is refused here rather than combined after an AGC or ADC.
    """
    if radar.frontend is not None:
        raise NotImplementedError(
            "Static environment returns must be combined before a configured "
            "Radar receive frontend; the Studio Radar adapter does not "
            "support that frontend yet."
        )
    if radar.waveform.output not in ("spectrum", "beat"):
        raise ValueError(f"Unsupported FMCW output domain: {radar.waveform.output!r}")
    clutter_cube = environment.cube
    if clutter_cube.shape != target_cube.shape:
        raise ValueError(
            "Environment and target Radar cubes disagree: "
            f"{tuple(clutter_cube.shape)} != {tuple(target_cube.shape)}"
        )
    return target_cube + clutter_cube.to(target_cube.device)


def room_echo(radar, world, *, time_s=0.0):
    """Synthesize the static room's single-bounce return, without any target.

    Radar's verbs need a target record and refuse an empty one, so one
    placeholder point sits on the boresight and every row through it is made
    inert. The default component declaration cannot do that: it files a site
    row that bounced off a wall as environment clutter too. Declaring the
    placeholder a target and no material as clutter leaves the site-less rows,
    and with ``coupling`` off every site-less row is a transmitter -> room ->
    receiver reflection (the declaration names that class ``direct_leakage``,
    "site-less and touching no declared clutter"). The room does not move, so
    one static observation stands for every frame of the capture.
    """
    require_supported_runtime()
    from witwin.radar import Motion, PointTargets
    from witwin.radar.paths import ComponentDeclaration

    position = torch.as_tensor(radar.position, dtype=torch.float64)
    forward = torch.as_tensor(radar.look_at, dtype=torch.float64) - position
    anchor = position + _ANCHOR_DISTANCE_M * forward / torch.linalg.vector_norm(forward)
    paths = radar.trace(
        world,
        PointTargets(positions=[tuple(float(value) for value in anchor)], rcs=1.0, ids=(_ANCHOR_ID,)),
        times=(float(time_s),),
        los=True,
        reflections=ENVIRONMENT_MAX_DEPTH,
        environment=True,
        motion=Motion.static(),
    )
    declaration = ComponentDeclaration(target_site_ids=frozenset({_ANCHOR_ID}))
    index = paths.component_index(declaration=declaration)
    counts = dict(zip(index.names, (int(value) for value in index.counts)))
    echo = radar.echo(paths.select(_ROOM_CLASS, declaration))
    processed = echo.frame(0).processing_cube()
    cube = processed.data
    if cube.device.type != "cuda" or not bool(torch.isfinite(cube).all()):
        raise RuntimeError("Native single-bounce environment cube is missing or nonfinite.")
    materials = {int(structure.material_id) for structure in getattr(world, "structures", ())}
    return EnvironmentClutterResult(
        cube=cube,
        reflected_path_count=counts.get(_ROOM_CLASS, 0),
        material_slot_count=len(materials),
        axes=processed.axes,
    )


__all__ = [
    "add_environment_to_fmcw_result",
    "ENVIRONMENT_MODEL",
    "EnvironmentClutterResult",
    "room_echo",
]
