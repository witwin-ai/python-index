"""Backend adapter subpackage."""
