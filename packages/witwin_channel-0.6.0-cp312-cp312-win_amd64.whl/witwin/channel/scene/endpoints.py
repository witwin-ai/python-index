# Copyright Xingyu Chen.
# Endpoint geometry, antenna response, and the scene-leaf AD seam.

"""Endpoint geometry, antenna response, and the scene-leaf AD seam."""

from __future__ import annotations

from collections.abc import Generator, Mapping, Sequence
from dataclasses import dataclass, field
import math
from typing import TYPE_CHECKING, Any, cast

import torch

from witwin.core import (
    AntennaPattern as _CoreAntennaPattern,
    AntennaState,
    ReceiverGrid as CoreReceiverGrid,
    Scene,
    SceneSnapshot,
    antenna_orientation_matrix,
    quat_from_euler,
    quat_multiply,
)

from witwin.channel.runtime import is_transform_wrapped_tensor

if TYPE_CHECKING:
    from witwin.core import RigidMotion

    from witwin.channel.scene.compiler import CompiledScene, _RuntimeStructure


_C0 = 299_792_458.0


def _vector3(name: str, value: torch.Tensor) -> torch.Tensor:
    if value.shape != (3,):
        raise ValueError(f"{name} must have shape (3,)")
    value = value.to(dtype=torch.float32).contiguous()
    if not bool(torch.isfinite(value).all()):
        raise ValueError(f"{name} must be finite")
    return value


def orientation_matrix(orientation: torch.Tensor) -> torch.Tensor:
    """Return the local-to-world yaw/pitch/roll rotation matrix.

    The orientation vector is ``(yaw, pitch, roll)`` in radians and uses the
    intrinsic Z-Y-X convention.
    """

    if orientation.shape == (4,):
        from witwin.core.math import quat_to_rotation_matrix

        return quat_to_rotation_matrix(orientation).to(dtype=torch.float32)
    yaw, pitch, roll = _vector3("orientation", orientation).unbind()
    cy, sy = torch.cos(yaw), torch.sin(yaw)
    cp, sp = torch.cos(pitch), torch.sin(pitch)
    cr, sr = torch.cos(roll), torch.sin(roll)
    return torch.stack(
        (
            torch.stack((cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr)),
            torch.stack((sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr)),
            torch.stack((-sp, cp * sr, cp * cr)),
        )
    ).to(dtype=torch.float32)


def pattern_field_response(
    pattern: _CoreAntennaPattern, local_direction: torch.Tensor,
) -> torch.Tensor:
    """Evaluate one canonical Core antenna pattern in the endpoint-local frame."""

    if not isinstance(pattern, _CoreAntennaPattern):
        raise TypeError("pattern must be a witwin.core.AntennaPattern")
    if local_direction.shape[-1] != 3:
        raise ValueError("local_direction must have a vec3 tail")
    direction = local_direction.to(dtype=torch.float32)
    direction = direction / torch.linalg.vector_norm(
        direction, dim=-1, keepdim=True
    ).clamp_min(torch.finfo(torch.float32).tiny)
    if pattern.kind == "custom":
        assert pattern.custom is not None
        response = pattern.custom(direction)
        if response.shape != direction.shape[:-1]:
            raise ValueError("custom pattern response must match direction batch shape")
        return response.to(device=direction.device, dtype=torch.complex64)
    if pattern.kind == "vertical":
        response = torch.sqrt(
            torch.clamp(1.0 - direction[..., 2].square(), min=0.0)
        )
    elif pattern.kind == "horizontal":
        response = torch.sqrt(
            torch.clamp(1.0 - direction[..., 0].square(), min=0.0)
        )
    else:
        response = torch.ones(direction.shape[:-1], device=direction.device)
    return response.to(dtype=torch.complex64)


def steering_vector(
    array: _AntennaArrayView, direction: torch.Tensor, *, frequency_hz: float,
    orientation: torch.Tensor | None = None,
) -> torch.Tensor:
    """Return ``exp(+j k r·u)`` under the package's ``exp(-j k d)`` convention."""

    if isinstance(frequency_hz, torch.Tensor):
        # Synthetic-array steering is evaluated at the primal frequency; its
        # frequency derivative is exactly zero for single-element centre
        # arrays and detached otherwise (material and frequency derivatives fixed-array contract).
        frequency_hz = float(frequency_hz.detach())
    if frequency_hz <= 0.0:
        raise ValueError("frequency_hz must be positive")
    if direction.shape[-1] != 3:
        raise ValueError("direction must have a vec3 tail")
    device = direction.device
    positions = array.positions.to(device=device)
    if orientation is not None:
        rotation = orientation_matrix(orientation).to(device=device)
        positions = positions @ rotation.T
    return steering_from_positions(positions, direction, frequency_hz=frequency_hz)


def steering_from_positions(
    positions: torch.Tensor, direction: torch.Tensor, *, frequency_hz: float,
) -> torch.Tensor:
    """``exp(+j k r·u)`` for world-frame element offsets ``positions`` of shape ``(A, 3)``."""

    unit = direction.to(dtype=torch.float32)
    unit = unit / torch.linalg.vector_norm(unit, dim=-1, keepdim=True).clamp_min(
        torch.finfo(torch.float32).tiny
    )
    phase = (2.0 * math.pi * float(frequency_hz) / _C0) * torch.einsum(
        "...c,ac->...a", unit, positions
    )
    return torch.exp(1.0j * phase).to(torch.complex64)


def apply_precoding_combining(
    coefficients: torch.Tensor, *, tx_weights: torch.Tensor, rx_weights: torch.Tensor,
) -> torch.Tensor:
    """Combine ``(..., rx_ant, tx_ant)`` channel coefficients into one stream."""

    if coefficients.ndim < 2:
        raise ValueError("coefficients must have rx_ant and tx_ant tail dimensions")
    if tx_weights.shape != (coefficients.shape[-1],):
        raise ValueError("tx_weights must match tx_ant")
    if rx_weights.shape != (coefficients.shape[-2],):
        raise ValueError("rx_weights must match rx_ant")
    tx = tx_weights.to(device=coefficients.device, dtype=torch.complex64)
    rx = rx_weights.to(device=coefficients.device, dtype=torch.complex64)
    return torch.einsum("...rt,t,r->...", coefficients, tx, rx.conj())


def apply_endpoint_weights(
    coefficients: torch.Tensor, *, tx_weights: torch.Tensor, rx_weights: torch.Tensor,
) -> torch.Tensor:
    """Combine ``(rx, rx_ant, tx, tx_ant, ...)`` endpoint channels.

    The leading endpoint and antenna dimensions match :class:`PathResult`.
    Any trailing signal dimensions (path, time, frequency, or tap) are
    preserved. Receiver weights follow the usual conjugating convention.
    """

    if coefficients.ndim < 4:
        raise ValueError(
            "coefficients must have (rx, rx_ant, tx, tx_ant, ...) dimensions"
        )
    expected_tx = (coefficients.shape[2], coefficients.shape[3])
    expected_rx = (coefficients.shape[0], coefficients.shape[1])
    if tx_weights.shape != expected_tx:
        raise ValueError(f"tx_weights must have shape {expected_tx}")
    if rx_weights.shape != expected_rx:
        raise ValueError(f"rx_weights must have shape {expected_rx}")
    tx = tx_weights.to(device=coefficients.device, dtype=torch.complex64)
    rx = rx_weights.to(device=coefficients.device, dtype=torch.complex64)
    tail = (1,) * (coefficients.ndim - 4)
    weighted = coefficients * tx.reshape(1, 1, *expected_tx, *tail)
    weighted = weighted * rx.conj().reshape(*expected_rx, 1, 1, *tail)
    return weighted.sum(dim=3).sum(dim=1)


def validate_scalar_endpoint_features(
    transmitters: Sequence[_TransmitterView | _ReceiverPointView | _ReceiverGridView],
    receivers: Sequence[_TransmitterView | _ReceiverPointView | _ReceiverGridView], *, solver: str,
) -> None:
    """Reject endpoint features that a scalar/power solver cannot consume."""

    for endpoint in (*tuple(transmitters), *tuple(receivers)):
        antennas = getattr(endpoint, "num_antennas", None)
        if (endpoint.array.num_antennas if antennas is None else antennas) != 1:
            raise ValueError(f"{solver} does not support antenna arrays")
        if endpoint.pattern.kind != "isotropic":
            raise ValueError(
                f"{solver} does not support directional antenna patterns"
            )
        weights = (
            endpoint.precoding
            if hasattr(endpoint, "precoding")
            else endpoint.combining
        )
        if weights is not None:
            raise ValueError(f"{solver} does not support precoding or combining")


@dataclass(frozen=True, slots=True)
class _AntennaArrayView:
    positions: torch.Tensor

    @property
    def num_antennas(self) -> int:
        return int(self.positions.shape[0])

    def world_positions(self, origin: torch.Tensor, orientation: torch.Tensor) -> torch.Tensor:
        rotation = antenna_orientation_matrix(
            orientation, reference=self.positions
        )
        return origin.to(device=self.positions.device) + self.positions @ rotation.T


@dataclass(frozen=True, slots=True)
class _EndpointView:
    source: AntennaState
    position_override: torch.Tensor | None = None
    orientation_override: torch.Tensor | None = None
    single_element: bool = False

    @property
    def position(self) -> torch.Tensor:
        return (
            self.source.position
            if self.position_override is None
            else self.position_override
        )

    @property
    def orientation(self) -> torch.Tensor:
        orientation = (
            self.source.orientation
            if self.orientation_override is None
            else self.orientation_override
        )
        if orientation is None:
            return self.position.new_zeros((3,))
        return orientation

    @property
    def polarization(self) -> torch.Tensor:
        polarization = self.source.polarization
        if polarization is None:
            default = (
                (1.0, 0.0, 0.0)
                if self.source.pattern.kind == "horizontal"
                else (0.0, 0.0, 1.0)
            )
            polarization = self.position.new_tensor(default)
        norm = torch.linalg.vector_norm(polarization)
        if polarization.device.type == "cpu" and (
            not bool(torch.isfinite(norm)) or float(norm) <= 0.0
        ):
            raise ValueError("polarization must be finite and non-zero")
        rotation = antenna_orientation_matrix(
            self.orientation, reference=polarization
        )
        return (rotation @ (polarization / norm)).contiguous()

    @property
    def pattern(self) -> _CoreAntennaPattern:
        return self.source.pattern

    @property
    def num_antennas(self) -> int:
        positions = self.source.element_positions
        if positions is None or self.single_element:
            return 1
        return int(positions.shape[0])

    @property
    def array(self) -> _AntennaArrayView:
        positions = self.source.element_positions
        if positions is None or self.single_element:
            positions = self.position.new_zeros((1, 3))
        return _AntennaArrayView(positions)

    @property
    def synthetic_array(self) -> bool:
        return cast(bool, self.source.synthetic_array)


@dataclass(frozen=True, slots=True)
class _TransmitterView(_EndpointView):
    @property
    def power_w(self) -> float | torch.Tensor:
        return 1.0 if self.source.power_w is None else self.source.power_w

    @property
    def precoding(self) -> torch.Tensor | None:
        return self.source.weights


@dataclass(frozen=True, slots=True)
class _ReceiverPointView(_EndpointView):
    @property
    def combining(self) -> torch.Tensor | None:
        return self.source.weights


@dataclass(frozen=True, slots=True)
class _ReceiverGridView(_EndpointView):
    source: CoreReceiverGrid
    x_axis_override: torch.Tensor | None = None
    y_axis_override: torch.Tensor | None = None

    @property
    def origin(self) -> torch.Tensor:
        return self.position

    @property
    def x_axis(self) -> torch.Tensor:
        return (
            self.source.x_axis
            if self.x_axis_override is None
            else self.x_axis_override
        )

    @property
    def y_axis(self) -> torch.Tensor:
        return (
            self.source.y_axis
            if self.y_axis_override is None
            else self.y_axis_override
        )

    @property
    def shape(self) -> tuple[int, int]:
        return cast("tuple[int, int]", self.source.shape)

    @property
    def spacing(self) -> tuple[float, float]:
        spacing = self.source.spacing
        return (float(spacing[0]), float(spacing[1]))

    @property
    def combining(self) -> torch.Tensor | None:
        return self.source.weights


@dataclass(frozen=True, slots=True)
class SolverScene:
    """Internal solver binding over one immutable ``CompiledScene``."""

    compiled: CompiledScene
    structures: tuple[_RuntimeStructure, ...]
    transmitters: tuple[_TransmitterView, ...]
    receivers: tuple[_ReceiverPointView | _ReceiverGridView, ...]
    frequency: float | torch.Tensor
    metadata: Mapping[str, Any]
    endpoint_store: EndpointStore | None = None
    # The store built on first use and the endpoint token it is cached under. Not an
    # init field, so ``dataclasses.replace`` gives a re-bound scene a fresh slot.
    _bound: dict[str, Any] = field(default_factory=dict, init=False, repr=False, compare=False)


def _as_quaternion(orientation: torch.Tensor) -> torch.Tensor:
    if orientation.shape == (4,):
        return orientation
    yaw, pitch, roll = orientation.unbind()
    return quat_from_euler(
        roll,
        pitch,
        yaw,
        device=orientation.device,
        dtype=orientation.dtype,
    )


def _endpoint_views(
    scene_or_snapshot: Scene | SceneSnapshot,
) -> tuple[_TransmitterView | _ReceiverPointView | _ReceiverGridView, ...]:
    states: tuple[tuple[AntennaState, RigidMotion | None], ...]
    if isinstance(scene_or_snapshot, Scene):
        states = tuple((endpoint, None) for endpoint in scene_or_snapshot.endpoints)
    else:
        states = tuple(
            (state.antenna, state.rigid_motion)
            for state in scene_or_snapshot.endpoints
        )
    views: list[_TransmitterView | _ReceiverPointView | _ReceiverGridView] = []
    for endpoint, motion in states:
        position = endpoint.position
        orientation = endpoint.orientation
        grid_x_axis = endpoint.x_axis if isinstance(endpoint, CoreReceiverGrid) else None
        grid_y_axis = endpoint.y_axis if isinstance(endpoint, CoreReceiverGrid) else None
        if motion is not None:
            if motion.translation is not None:
                position = position + motion.translation
            if motion.rotation is not None:
                motion_rotation = _as_quaternion(motion.rotation)
                motion_matrix = antenna_orientation_matrix(
                    motion.rotation,
                    reference=position,
                )
                if orientation is None:
                    orientation = motion_rotation
                else:
                    orientation = quat_multiply(
                        motion_rotation, _as_quaternion(orientation)
                    )
                if grid_x_axis is not None:
                    grid_x_axis = motion_matrix @ grid_x_axis
                    grid_y_axis = motion_matrix @ grid_y_axis
        if endpoint.role == "tx":
            views.append(
                _TransmitterView(
                    endpoint,
                    position_override=position,
                    orientation_override=orientation,
                )
            )
        elif isinstance(endpoint, CoreReceiverGrid):
            views.append(
                _ReceiverGridView(
                    endpoint,
                    position_override=position,
                    orientation_override=orientation,
                    x_axis_override=grid_x_axis,
                    y_axis_override=grid_y_axis,
                )
            )
        else:
            views.append(
                _ReceiverPointView(
                    endpoint,
                    position_override=position,
                    orientation_override=orientation,
                )
            )
    return tuple(views)


def _require_host_constant(name: str, value: object) -> None:
    if not isinstance(value, torch.Tensor):
        return
    if value.device.type != "cpu" or value.requires_grad:
        raise RuntimeError(
            f"{name} requires the tensor-native endpoint ABI; the current "
            "native scalar boundary accepts only constant CPU tensors"
        )


def _validate_scalar_endpoint_boundary(views: tuple[_EndpointView, ...]) -> None:
    """Reject only grid leaves still consumed by the scalar grid ABI."""

    for index, view in enumerate(views):
        if isinstance(view, _ReceiverGridView):
            prefix = f"endpoint[{index}]"
            _require_host_constant(f"{prefix}.position", view.position)
            _require_host_constant(f"{prefix}.x_axis", view.x_axis)
            _require_host_constant(f"{prefix}.y_axis", view.y_axis)
            _require_host_constant(f"{prefix}.spacing", view.source.spacing)


def _host_values(value: object) -> torch.Tensor | None:
    """Host view of an endpoint scalar or tensor, or None when reading it would sync a device."""

    if isinstance(value, torch.Tensor):
        return value.detach() if value.device.type == "cpu" else None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return torch.tensor(float(value), dtype=torch.float64)
    if isinstance(value, (tuple, list)):
        return torch.tensor([float(item) for item in value], dtype=torch.float64)
    return None


def _require_finite(label: str, name: str, value: object) -> None:
    host = _host_values(value)
    if host is not None and not bool(torch.isfinite(host).all()):
        raise ValueError(f"{label} {name} must be finite, got {host.tolist()}")


def _require_host_range(label: str, name: str, value: object, positive: bool, legal: str) -> None:
    host = _host_values(value)
    if host is None:
        return
    in_range = (host > 0.0) if positive else (host >= 0.0)
    if not bool((in_range & torch.isfinite(host)).all()):
        raise ValueError(f"{label} {name} must be {legal}, got {host.tolist()}")


def _endpoint_label(view: _EndpointView) -> str:
    if view.source.role == "tx":
        kind = "transmitter"
    elif isinstance(view, _ReceiverGridView):
        kind = "ReceiverGrid"
    else:
        kind = "receiver"
    return f"{kind} {int(view.source.antenna_id)}"


def _validate_one_endpoint(view: _EndpointView) -> None:
    label = _endpoint_label(view)
    grid = isinstance(view, _ReceiverGridView)
    _require_finite(label, "origin" if grid else "position", view.position)
    _require_finite(label, "orientation", view.orientation)
    if isinstance(view, _ReceiverGridView):
        _require_finite(label, "x_axis", view.x_axis)
        _require_finite(label, "y_axis", view.y_axis)
        _require_host_range(
            label, "spacing entries", view.source.spacing, True, "finite and positive"
        )
    if isinstance(view, _TransmitterView):
        _require_host_range(label, "power_w", view.power_w, False, "finite and non-negative")


_FAR_FIELD_FRACTION = 1.0 / (4.0 * math.pi)
# Eight to sixteen float32 ulps of a coordinate, per metre of its magnitude.
COORDINATE_RESOLUTION = 2.0**-20
_GRID_SCAN_CELLS = 1 << 20


def coincidence_tolerance_m(frequency_hz: float, magnitude_m: float) -> float:
    """Endpoint separation below which free-space propagation is undefined.

    The larger of wavelength / (4 pi), inside which the isotropic free-space path
    gain (wavelength / (4 pi d))^2 exceeds one, and ``COORDINATE_RESOLUTION``
    times the largest coordinate magnitude ``magnitude_m``, below which a
    float32 distance cannot be told from zero.
    """

    return max(_C0 / float(frequency_hz) * _FAR_FIELD_FRACTION, COORDINATE_RESOLUTION * magnitude_m)


def _format_point(value: torch.Tensor) -> str:
    return "(" + ", ".join(f"{float(item):.6g}" for item in value) + ")"


def _coincidence_message(
    receiver: str, at: torch.Tensor, transmitter: _TransmitterView, origin: torch.Tensor,
    distance: float, tolerance: float, frequency_hz: float,
    remedy: str = "Move the receiver or transmitter apart",
) -> str:
    return (
        f"{receiver} at {_format_point(at)} coincides with transmitter "
        f"{int(transmitter.source.antenna_id)} at {_format_point(origin)}: the distance "
        f"{distance:.3g} m is below the coincidence tolerance {tolerance:.3g} m (the larger of "
        f"wavelength/(4*pi) at {frequency_hz:.6g} Hz and the float32 coordinate resolution), "
        f"where free-space propagation is undefined. {remedy}"
    )


def _grid_scan(
    origin: torch.Tensor, steps: torch.Tensor, rows: torch.Tensor, cols: torch.Tensor,
    point: torch.Tensor, tolerance: float,
) -> tuple[int, tuple[int, int, float] | None]:
    """Count the samples of a ``rows x cols`` block within ``tolerance``; return the nearest."""

    count = 0
    nearest: tuple[int, int, float] | None = None
    chunk = max(1, _GRID_SCAN_CELLS // max(int(cols.numel()), 1))
    for start in range(0, int(rows.numel()), chunk):
        block = rows[start : start + chunk]
        cells = (
            origin
            + block[:, None, None].to(origin.dtype) * steps[0]
            + cols[None, :, None].to(origin.dtype) * steps[1]
        )
        distance = torch.linalg.vector_norm(cells - point, dim=-1)
        inside = distance <= tolerance
        count += int(inside.sum())
        if bool(inside.any()):
            flat = int(torch.argmin(distance))
            row, col = divmod(flat, int(cols.numel()))
            value = float(distance.reshape(-1)[flat])
            if nearest is None or value < nearest[2]:
                nearest = (int(block[row]), int(cols[col]), value)
    return count, nearest


def _grid_samples_near(
    origin: torch.Tensor, steps: torch.Tensor, shape: tuple[int, int], point: torch.Tensor,
    tolerance: float,
) -> tuple[int, tuple[int, int, float] | None]:
    """Grid samples ``origin + row * steps[0] + col * steps[1]`` within ``tolerance`` of ``point``.

    Solved analytically: the in-plane least-squares coordinates of ``point`` and
    the tolerance ellipse bound a small index box, and only that box is scanned.
    """

    extents = (int(shape[0]), int(shape[1]))
    if extents[0] <= 0 or extents[1] <= 0:
        return 0, None
    active = [axis for axis in (0, 1) if extents[axis] > 1]
    offset = point - origin
    coordinates = [0.0, 0.0]
    half_width = [0.0, 0.0]
    residual = offset
    if active:
        basis = steps[active]
        gram = basis @ basis.T
        scale = float(torch.prod(torch.diagonal(gram)))
        if not scale > 0.0 or float(torch.linalg.det(gram)) <= 1.0e-12 * scale:
            return _grid_scan(
                origin, steps, torch.arange(extents[0]), torch.arange(extents[1]), point,
                tolerance,
            )
        solution = torch.linalg.solve(gram, basis @ offset)
        residual = offset - solution @ basis
        inverse = torch.linalg.inv(gram)
        for slot, axis in enumerate(active):
            coordinates[axis] = float(solution[slot])
            half_width[axis] = float(inverse[slot, slot])
    out_of_plane = float(residual @ residual)
    if out_of_plane > tolerance * tolerance:
        return 0, None
    in_plane = tolerance * tolerance - out_of_plane
    ranges = []
    for axis in (0, 1):
        half = math.sqrt(in_plane * half_width[axis])
        low = max(0, math.ceil(coordinates[axis] - half - 1.0e-9))
        high = min(extents[axis] - 1, math.floor(coordinates[axis] + half + 1.0e-9))
        if low > high:
            return 0, None
        ranges.append(torch.arange(low, high + 1))
    return _grid_scan(origin, steps, ranges[0], ranges[1], point, tolerance)


def _refuse_point_receiver(
    label: str, at: torch.Tensor, transmitters: list[tuple[_TransmitterView, torch.Tensor]],
    frequency_hz: float,
) -> None:
    for transmitter, origin in transmitters:
        distance = float(torch.linalg.vector_norm(at - origin))
        magnitude = float(torch.maximum(at.abs().max(), origin.abs().max()))
        tolerance = coincidence_tolerance_m(frequency_hz, magnitude)
        if distance <= tolerance:
            raise ValueError(
                _coincidence_message(
                    label, at, transmitter, origin, distance, tolerance, frequency_hz
                )
            )


def _refuse_grid_receiver(
    receiver: _ReceiverGridView, origin_at: torch.Tensor,
    transmitters: list[tuple[_TransmitterView, torch.Tensor]], frequency_hz: float,
) -> None:
    axes = [_host_values(receiver.x_axis), _host_values(receiver.y_axis)]
    spacing = _host_values(receiver.source.spacing)
    if axes[0] is None or axes[1] is None or spacing is None:
        return
    spacing = spacing.to(torch.float64)
    steps = torch.stack(
        (axes[0].to(torch.float64) * spacing[0], axes[1].to(torch.float64) * spacing[1])
    )
    rows, cols = receiver.shape
    reach = origin_at.abs() + max(rows - 1, 0) * steps[0].abs() + max(cols - 1, 0) * steps[1].abs()
    for transmitter, origin in transmitters:
        magnitude = float(torch.maximum(reach.max(), origin.abs().max()))
        tolerance = coincidence_tolerance_m(frequency_hz, magnitude)
        count, nearest = _grid_samples_near(origin_at, steps, (rows, cols), origin, tolerance)
        if nearest is None:
            continue
        row, col, distance = nearest
        cell = origin_at + row * steps[0] + col * steps[1]
        others = f"; {count - 1} more cell(s) of the grid are as close" if count > 1 else ""
        raise ValueError(
            _coincidence_message(
                f"{_endpoint_label(receiver)} cell (row {row}, column {col})", cell, transmitter,
                origin, distance, tolerance, frequency_hz,
                "Move the transmitter or shift the grid origin so no sample lies this "
                f"close{others}",
            )
        )


def refuse_coincident_endpoints(views: tuple[_EndpointView, ...], frequency_hz: float) -> None:
    """Refuse a receiver sample within the coincidence tolerance of a transmitter.

    Point receivers and every ``ReceiverGrid`` sample are checked on the host
    without materializing a grid. CUDA-resident coordinates are not read, since
    that would synchronize the device on every solve.
    """

    transmitters = []
    for view in views:
        origin = _host_values(view.position) if isinstance(view, _TransmitterView) else None
        if origin is not None:
            transmitters.append((cast(_TransmitterView, view), origin.to(torch.float64)))
    for receiver in views if transmitters else ():
        at = None if isinstance(receiver, _TransmitterView) else _host_values(receiver.position)
        if at is None:
            continue
        if isinstance(receiver, _ReceiverGridView):
            _refuse_grid_receiver(receiver, at.to(torch.float64), transmitters, frequency_hz)
        else:
            _refuse_point_receiver(
                _endpoint_label(receiver), at.to(torch.float64), transmitters, frequency_hz
            )


def _validate_endpoint_values(views: tuple[_EndpointView, ...], frequency_hz: float) -> None:
    """Refuse non-finite endpoint data and coincident endpoints before any native work.

    Host-resident values are checked here; reading a CUDA-resident value would
    synchronize the device on every solve, so those are left to the caller.
    """

    for view in views:
        _validate_one_endpoint(view)
    refuse_coincident_endpoints(views, frequency_hz)


def require_single_receiver_layout(
    views: Sequence[_EndpointView], *, solver: str,
    grid_only_components: frozenset[str] = frozenset(),
) -> None:
    """Refuse receiver layouts a Monte Carlo solver does not accumulate, before native work.

    The Monte Carlo solvers accumulate either one ``ReceiverGrid`` or point receivers.
    ``grid_only_components`` names requested components the solver computes only
    on a grid; with point receivers they would silently read zero.
    """

    receivers = [view for view in views if view.source.role != "tx"]
    grids = sum(isinstance(view, _ReceiverGridView) for view in receivers)
    points = len(receivers) - grids
    if grids > 1 or (grids and points):
        raise ValueError(
            f"{solver} accepts either exactly one ReceiverGrid or only point receivers; "
            f"the scene has {grids} ReceiverGrid(s) and {points} point receiver(s). "
            "Solve each grid separately, or use witwin.channel.radiomap.Coherent"
        )
    if points and grid_only_components:
        raise ValueError(
            f"{solver} computes {sorted(grid_only_components)} only on a ReceiverGrid; "
            f"with point receivers request components={{'los'}} or use "
            "witwin.channel.radiomap.Coherent, witwin.channel.path or "
            "witwin.channel.experimental.bdpt"
        )


FUNCTORCH_MESSAGE = (
    "witwin.channel does not run under torch.func transforms (grad, jvp, vjp, vmap): "
    "native kernels need real tensor storage. Use ad_mode='vjp' with torch.autograd, or "
    "ad_mode='jvp' with torch.autograd.forward_ad, and loop or batch the endpoints "
    "instead of vmap"
)


def require_no_functorch_transform(values: Sequence[object]) -> None:
    """Refuse tensors wrapped by ``torch.func`` (``grad``/``jvp``/``vmap``) before native work."""

    for value in values:
        if isinstance(value, torch.Tensor) and is_transform_wrapped_tensor(value):
            raise NotImplementedError(FUNCTORCH_MESSAGE)


# --- Endpoint store -------------------------------------------------------

def _leaf_state(value: object) -> object:
    if isinstance(value, torch.Tensor):
        return (id(value), value._version, value.requires_grad)
    return value


def endpoint_token(scene_or_snapshot: Scene | SceneSnapshot) -> tuple[object, ...]:
    """Host-only identity of every endpoint input a solve reads.

    Each endpoint contributes its object identity plus, for every tensor leaf,
    the tensor identity, mutation ``_version`` and ``requires_grad`` flag
    (snapshot rigid motions likewise). Endpoint objects are frozen, so equal
    tokens mean equal endpoint values. The token reads no tensor data,
    launches nothing and never synchronizes; it keys the cached
    :class:`EndpointStore` and is meant to key any endpoint-only cache.
    """

    leaf = _leaf_state
    grid_type = CoreReceiverGrid
    token: list[object] = []
    append = token.append
    pairs: Generator[tuple[AntennaState, RigidMotion | None], None, None]
    if isinstance(scene_or_snapshot, Scene):
        pairs = ((endpoint, None) for endpoint in scene_or_snapshot.endpoints)
    else:
        pairs = (
            (state.antenna, state.rigid_motion) for state in scene_or_snapshot.endpoints
        )
    for endpoint, motion in pairs:
        append(id(endpoint))
        append(leaf(endpoint.position))
        append(leaf(endpoint.orientation))
        append(leaf(endpoint.polarization))
        append(leaf(endpoint.element_positions))
        append(leaf(endpoint.weights))
        append(leaf(endpoint.power_w))
        if type(endpoint) is grid_type:
            append(leaf(endpoint.x_axis))
            append(leaf(endpoint.y_axis))
            append(leaf(endpoint.spacing))
        if motion is not None:
            append((id(motion), leaf(motion.translation), leaf(motion.rotation)))
    return tuple(token)


def _participates_in_ad(value: object) -> bool:
    if not isinstance(value, torch.Tensor):
        return False
    if value.requires_grad:
        return True
    return torch.autograd.forward_ad.unpack_dual(value).tangent is not None


def _endpoint_tensors(view: _EndpointView) -> tuple[object, ...]:
    values: tuple[object, ...] = (
        view.position,
        view.orientation_override if view.orientation_override is not None
        else view.source.orientation,
        view.source.polarization,
        view.source.element_positions,
        view.source.weights,
    )
    if isinstance(view, _TransmitterView):
        values += (view.source.power_w,)
    return values


def _rotation_matrices(orientation: torch.Tensor) -> torch.Tensor:
    """Batched ``witwin.core.antenna_orientation_matrix`` over ``(n, 3)`` or ``(n, 4)``."""

    if orientation.shape[-1] == 4:
        w, x, y, z = orientation.unbind(-1)
        rows = (
            (1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)),
            (2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)),
            (2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)),
        )
    else:
        yaw, pitch, roll = orientation.unbind(-1)
        cy, sy = torch.cos(yaw), torch.sin(yaw)
        cp, sp = torch.cos(pitch), torch.sin(pitch)
        cr, sr = torch.cos(roll), torch.sin(roll)
        rows = (
            (cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr),
            (sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr),
            (-sp, cp * sr, cp * cr),
        )
    return torch.stack([torch.stack(row, dim=-1) for row in rows], dim=-2)


def _rotate(rotation: torch.Tensor, unit: torch.Tensor) -> torch.Tensor:
    """Batched ``rotation @ unit`` summed in the order of the per-vector product it replaces.

    A 3x3 matrix-vector product on the host BLAS sums ``(r1*u1 + r2*u2) + r0*u0``
    and on CUDA ``(r0*u0 + r2*u2) + r1*u1``; the fixed per-device order keeps every
    oriented polarization bit-identical to that product.
    """

    terms = [rotation[..., k] * unit[..., None, k] for k in range(3)]
    if unit.device.type == "cpu":
        return (terms[1] + terms[2]) + terms[0]
    return (terms[0] + terms[2]) + terms[1]


def _world_polarizations(views: Sequence[_EndpointView]) -> torch.Tensor:
    """World-frame unit polarization of every endpoint, in view order, as ``(n, 3)``.

    Endpoints are grouped by device, dtype and orientation kind; each group is one
    batched norm, rotation and product, equal bit for bit to evaluating
    ``_EndpointView.polarization`` one endpoint at a time.
    """

    groups: dict[tuple[object, ...], list[int]] = {}
    polarizations: list[torch.Tensor] = []
    orientations: list[torch.Tensor] = []
    defaults: dict[tuple[object, ...], torch.Tensor] = {}
    for index, view in enumerate(views):
        position = view.position
        polarization = view.source.polarization
        if polarization is None:
            horizontal = view.source.pattern.kind == "horizontal"
            key: tuple[object, ...] = ("polarization", horizontal, position.device, position.dtype)
            polarization = defaults.get(key)
            if polarization is None:
                polarization = position.new_tensor(
                    (1.0, 0.0, 0.0) if horizontal else (0.0, 0.0, 1.0)
                )
                defaults[key] = polarization
        orientation = (
            view.source.orientation
            if view.orientation_override is None
            else view.orientation_override
        )
        if orientation is None:
            key = ("orientation", position.device, position.dtype)
            orientation = defaults.get(key)
            if orientation is None:
                orientation = position.new_zeros((3,))
                defaults[key] = orientation
        polarizations.append(polarization)
        orientations.append(orientation)
        group = (
            polarization.device,
            polarization.dtype,
            orientation.device,
            orientation.dtype,
            int(orientation.shape[0]),
        )
        groups.setdefault(group, []).append(index)
    results: list[torch.Tensor] = []
    order: list[int] = []
    for indices in groups.values():
        polarization = torch.stack([polarizations[index] for index in indices])
        orientation = torch.stack([orientations[index] for index in indices])
        norm = torch.linalg.vector_norm(polarization, dim=-1)
        if polarization.device.type == "cpu" and not bool(
            (torch.isfinite(norm) & (norm > 0.0)).all()
        ):
            raise ValueError("polarization must be finite and non-zero")
        unit = polarization / norm.unsqueeze(-1)
        results.append(_rotate(_rotation_matrices(orientation), unit).contiguous())
        order.extend(indices)
    if len(results) == 1:
        return results[0]
    device = results[0].device
    stacked = torch.cat([value.to(device=device) for value in results])
    inverse = torch.empty(len(order), dtype=torch.long)
    inverse[torch.tensor(order, dtype=torch.long)] = torch.arange(len(order))
    return stacked.index_select(0, inverse.to(device=device))


def _tx_power_values(transmitters: Sequence[_TransmitterView]) -> torch.Tensor:
    powers = [transmitter.power_w for transmitter in transmitters]
    if not any(isinstance(power, torch.Tensor) for power in powers):
        return torch.tensor([float(power) for power in powers], dtype=torch.float32)
    return torch.stack(
        [
            power.reshape(()).to(dtype=torch.float32)
            if isinstance(power, torch.Tensor)
            else torch.tensor(
                float(power), dtype=torch.float32, device=transmitter.position.device
            )
            for transmitter, power in zip(transmitters, powers, strict=True)
        ]
    )


def _upload(parts: Sequence[torch.Tensor], *, device: torch.device) -> list[torch.Tensor]:
    """Move float32 parts to ``device`` with one copy and return views of the result."""

    if not parts:
        return []
    if any(_participates_in_ad(part) for part in parts):
        # Separate copies keep each part's own graph: a shared buffer would put
        # every field on the graph of any differentiable one.
        return [part.to(device=device) for part in parts]
    flat = [part.reshape(-1) for part in parts]
    if all(part.device == flat[0].device for part in flat):
        buffer = torch.cat(flat).to(device=device)
    else:
        buffer = torch.cat([part.to(device=device) for part in flat])
    views: list[torch.Tensor] = []
    offset = 0
    for part in parts:
        count = part.numel()
        views.append(buffer[offset : offset + count].view(part.shape))
        offset += count
    return views


@dataclass(frozen=True, slots=True)
class EndpointStore:
    """Device-resident endpoint tensors of one solver scene, built once per endpoint token.

    Row order follows the scene: transmitters in order; receivers flattened in
    order with a ``ReceiverGrid`` contributing its cells row-major. Grid cell
    positions come from the native grid generator and a grid's polarization is
    one broadcast row, so nothing scales per cell on the host. ``tx_positions``
    and point ``rx_positions_live`` keep any differentiable endpoint leaf on the
    graph through one stack.
    """

    transmitters: tuple[_TransmitterView, ...]
    receivers: tuple[_ReceiverPointView | _ReceiverGridView, ...]
    device: torch.device
    differentiable: bool
    tx_positions: torch.Tensor
    tx_power: torch.Tensor
    tx_polarizations: torch.Tensor
    tx_polarizations_stored: torch.Tensor
    rx_positions: torch.Tensor
    rx_positions_live: torch.Tensor | None
    rx_polarizations: torch.Tensor
    receiver_polarizations: torch.Tensor
    receiver_cell_counts: tuple[int, ...]
    _lazy: dict[str, object]

    @property
    def tx_count(self) -> int:
        return int(self.tx_positions.shape[0])

    @property
    def rx_count(self) -> int:
        return int(self.rx_positions.shape[0])

    def receiver_polarization_rows(self, receiver_index: int) -> torch.Tensor:
        """Broadcast ``(cells, 3)`` float32 polarization of one receiver."""

        return self.receiver_polarizations[receiver_index].expand(
            self.receiver_cell_counts[receiver_index], 3
        )

    def stable_ids(self) -> tuple[torch.Tensor, torch.Tensor]:
        """Device ``int64`` stable antenna ids per transmitter and per flattened receiver row."""

        cached = self._lazy.get("stable_ids")
        if cached is None:
            source = torch.tensor(
                [int(view.source.antenna_id) for view in self.transmitters], dtype=torch.int64
            )
            sink = torch.repeat_interleave(
                torch.tensor(
                    [int(view.source.antenna_id) for view in self.receivers], dtype=torch.int64
                ),
                torch.tensor(self.receiver_cell_counts, dtype=torch.int64),
            )
            cached = (source.to(device=self.device), sink.to(device=self.device))
            self._lazy["stable_ids"] = cached
        return cast("tuple[torch.Tensor, torch.Tensor]", cached)


def _receiver_cells(receiver: object) -> int:
    if isinstance(receiver, ReceiverGrid):
        return int(receiver.shape[0]) * int(receiver.shape[1])
    if isinstance(receiver, ReceiverPoint):
        return 1
    raise TypeError(f"receiver type is not accepted: {type(receiver)!r}")


def _transmitter_parts(
    transmitters: tuple[_TransmitterView, ...],
) -> tuple[list[torch.Tensor], torch.Tensor]:
    """Host float32 positions, powers and polarizations, plus the stored-dtype polarizations."""

    if not transmitters:
        empty = torch.empty((0, 3), dtype=torch.float32)
        return [empty, torch.empty((0,), dtype=torch.float32), empty], empty
    stored = _world_polarizations(transmitters)
    positions = torch.stack([view.position for view in transmitters]).to(torch.float32)
    return [positions, _tx_power_values(transmitters), stored.to(torch.float32)], stored


def _receiver_rows(
    receivers: tuple[_ReceiverPointView | _ReceiverGridView, ...], cell_counts: tuple[int, ...],
    point_positions: torch.Tensor | None, receiver_polarizations: torch.Tensor,
    reference: torch.Tensor,
) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
    """Per-row position and polarization blocks: one per grid, one per run of point receivers."""

    from witwin.channel.scene.compiler import receiver_grid_points

    position_blocks: list[torch.Tensor] = []
    polarization_blocks: list[torch.Tensor] = []
    point_cursor = 0
    index = 0
    while index < len(receivers):
        receiver = receivers[index]
        if isinstance(receiver, ReceiverGrid):
            position_blocks.append(receiver_grid_points(receiver, reference=reference))
            polarization_blocks.append(
                receiver_polarizations[index].expand(cell_counts[index], 3)
            )
            index += 1
            continue
        stop = index
        while stop < len(receivers) and not isinstance(receivers[stop], ReceiverGrid):
            stop += 1
        assert point_positions is not None
        run = stop - index
        position_blocks.append(point_positions[point_cursor : point_cursor + run])
        polarization_blocks.append(receiver_polarizations[index:stop])
        point_cursor += run
        index = stop
    return position_blocks, polarization_blocks


def _join_rows(
    position_blocks: list[torch.Tensor], polarization_blocks: list[torch.Tensor],
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor]:
    if not position_blocks:
        empty = torch.empty((0, 3), device=device, dtype=torch.float32)
        return empty, empty
    if len(position_blocks) == 1:
        return position_blocks[0], polarization_blocks[0]
    from witwin.channel.kernels.topology import path_concat_vec3

    positions = path_concat_vec3([block.detach().contiguous() for block in position_blocks])
    return positions, torch.cat(polarization_blocks)


def build_endpoint_store(
    transmitters: Sequence[_TransmitterView],
    receivers: Sequence[_ReceiverPointView | _ReceiverGridView], *, device: torch.device,
) -> EndpointStore:
    """Stack, orient and upload every endpoint tensor of one scene in batched operations."""

    transmitters = tuple(transmitters)
    receivers = tuple(receivers)
    cell_counts = tuple(_receiver_cells(receiver) for receiver in receivers)
    points = [receiver for receiver in receivers if isinstance(receiver, ReceiverPoint)]
    differentiable = any(
        _participates_in_ad(value)
        for view in (*transmitters, *receivers)
        for value in _endpoint_tensors(view)
    )
    host_parts, tx_stored = _transmitter_parts(transmitters)
    if points:
        host_parts.append(torch.stack([view.position for view in points]).to(torch.float32))
    if receivers:
        host_parts.append(_world_polarizations(receivers).to(torch.float32))
    uploaded = _upload(host_parts, device=device)
    tx_positions, tx_power, tx_polarizations = uploaded[:3]
    point_positions = uploaded[3] if points else None
    receiver_polarizations = (
        uploaded[-1] if receivers else torch.empty((0, 3), device=device, dtype=torch.float32)
    )
    rx_positions, rx_polarizations = _join_rows(
        *_receiver_rows(
            receivers,
            cell_counts,
            point_positions,
            receiver_polarizations,
            tx_positions.detach() if transmitters else torch.empty((0, 3), device=device),
        ),
        device,
    )
    return EndpointStore(
        transmitters=transmitters,
        receivers=receivers,
        device=device,
        differentiable=differentiable,
        tx_positions=tx_positions,
        tx_power=tx_power,
        tx_polarizations=tx_polarizations,
        tx_polarizations_stored=(
            tx_polarizations if tx_stored.dtype == torch.float32 else tx_stored.to(device=device)
        ),
        rx_positions=rx_positions,
        rx_positions_live=(
            point_positions if receivers and len(points) == len(receivers) else None
        ),
        rx_polarizations=rx_polarizations,
        receiver_polarizations=receiver_polarizations,
        receiver_cell_counts=cell_counts,
        _lazy={},
    )


def _store_matches(store: EndpointStore | None, scene: SolverScene, target: torch.device) -> bool:
    return (
        store is not None
        and store.device == target
        and store.transmitters is scene.transmitters
        and store.receivers is scene.receivers
    )


def endpoint_store(scene: SolverScene, *, device: torch.device | None = None) -> EndpointStore:
    """The scene's :class:`EndpointStore`, built on first use and cached per endpoint token.

    A scene from :func:`bind_solver_scene` builds its store here, inside the solve, so
    binding performs no CUDA or tensor work and a solve can refuse its budget first.
    """

    target = torch.device("cuda") if device is None else torch.device(device)
    if target.type == "cuda" and target.index is None:
        target = torch.device("cuda", torch.cuda.current_device())
    store: EndpointStore | None = getattr(scene, "endpoint_store", None)
    if _store_matches(store, scene, target):
        return cast(EndpointStore, store)
    bound: dict[str, Any] | None = getattr(scene, "_bound", None)
    if bound is not None and _store_matches(bound.get("store"), scene, target):
        return cast(EndpointStore, bound["store"])
    store = build_endpoint_store(scene.transmitters, scene.receivers, device=target)
    if bound is not None:
        bound["store"] = store
        token = bound.get("token")
        if token is not None:
            compiled = scene.compiled
            compiled._endpoint_store_cache = None if store.differentiable else (token, store)
    return store


def bind_solver_scene(compiled: CompiledScene) -> SolverScene:
    """Bind ``compiled`` for one solve; host-only, the endpoint store is built on first use."""

    require_no_functorch_transform(
        [getattr(structure, "vertices", None) for structure in compiled.structures]
        + [compiled.reference_frequency_hz]
    )
    token = endpoint_token(compiled.source)
    cached = compiled._endpoint_store_cache
    store: EndpointStore | None
    if cached is not None and cached[0] == token:
        store = cached[1]
        transmitters, receivers = store.transmitters, store.receivers
    else:
        views = _endpoint_views(compiled.source)
        require_no_functorch_transform([view.position for view in views])
        _validate_scalar_endpoint_boundary(views)
        _validate_endpoint_values(views, compiled.materials.frequency_hz)
        transmitters = tuple(view for view in views if isinstance(view, _TransmitterView))
        receivers = tuple(view for view in views if not isinstance(view, _TransmitterView))
        store = None
    scene = SolverScene(
        compiled=compiled,
        structures=compiled.structures,
        transmitters=transmitters,
        receivers=receivers,
        frequency=compiled.reference_frequency_hz,
        metadata=compiled.source.metadata,
        endpoint_store=store,
    )
    scene._bound["token"] = token
    return scene


def require_compiled(scene: SolverScene | CompiledScene) -> CompiledScene:
    # ``compiler`` imports this module for its endpoint tensor exports, so the
    # compiled-scene type is resolved here rather than at module scope. That
    # keeps the scene lifetime one-way at import time: an importer of the
    # endpoint views does not drag in the compiler and everything it compiles
    # against.
    from witwin.channel.scene.compiler import CompiledScene

    if isinstance(scene, SolverScene):
        return scene.compiled
    if isinstance(scene, CompiledScene):
        return scene
    raise TypeError("expected a Channel SolverScene or CompiledScene")


# Internal names used by solver-domain modules. They are intentionally absent
# from the package root.
ReceiverGrid = _ReceiverGridView
ReceiverPoint = _ReceiverPointView
Transmitter = _TransmitterView


@dataclass(frozen=True, slots=True)
class AxisAlignedGridSpec:
    grid: ReceiverGrid
    axis: int
    position: float
    coord0_min: float
    coord0_max: float
    coord1_min: float
    coord1_max: float
    resolution0: int
    resolution1: int
    cell_area: float


def vector3_tuple(value: torch.Tensor) -> tuple[float, float, float]:
    return (float(value[0]), float(value[1]), float(value[2]))


def first_receiver_grid(scene: SolverScene) -> ReceiverGrid | None:
    for receiver in scene.receivers:
        if isinstance(receiver, ReceiverGrid):
            return receiver
    return None


def component_grid_shape(grid: ReceiverGrid) -> tuple[int, int]:
    """Shape ``(rows, cols)`` of one grid's component maps: receiver row-major, like Core."""

    return (grid.shape[0], grid.shape[1])


def _axis_index(values: tuple[float, float, float], *, name: str) -> tuple[int, float]:
    nonzero = [idx for idx, value in enumerate(values) if abs(value) > 1.0e-6]
    if len(nonzero) != 1:
        raise ValueError(f"{name} must be axis-aligned")
    index = nonzero[0]
    value = values[index]
    sign = 1.0 if value > 0.0 else -1.0
    if abs(abs(value) - 1.0) > 1.0e-5:
        raise ValueError(f"{name} must be a unit axis vector")
    return index, sign


def axis_aligned_grid_spec(grid: ReceiverGrid) -> AxisAlignedGridSpec:
    rows, cols = grid.shape
    origin = vector3_tuple(grid.origin)
    axis0, sign0 = _axis_index(
        vector3_tuple(grid.x_axis), name="ReceiverGrid.x_axis"
    )
    axis1, sign1 = _axis_index(
        vector3_tuple(grid.y_axis), name="ReceiverGrid.y_axis"
    )
    if axis0 == axis1:
        raise ValueError("ReceiverGrid axes must be orthogonal")
    axis = ({0, 1, 2} - {axis0, axis1}).pop()
    expected = (1, 2) if axis == 0 else (0, 2) if axis == 1 else (0, 1)
    if (axis0, axis1) != expected:
        raise ValueError("ReceiverGrid axes must match RayD grid coordinate order")

    step0 = float(grid.spacing[0]) * sign0
    step1 = float(grid.spacing[1]) * sign1
    first0 = origin[axis0]
    first1 = origin[axis1]
    last0 = first0 + step0 * float(rows - 1)
    last1 = first1 + step1 * float(cols - 1)
    half0 = abs(float(grid.spacing[0])) * 0.5
    half1 = abs(float(grid.spacing[1])) * 0.5
    coord0_min = min(first0, last0) - half0
    coord0_max = max(first0, last0) + half0
    coord1_min = min(first1, last1) - half1
    coord1_max = max(first1, last1) + half1
    return AxisAlignedGridSpec(
        grid=grid,
        axis=axis,
        position=origin[axis],
        coord0_min=coord0_min,
        coord0_max=coord0_max,
        coord1_min=coord1_min,
        coord1_max=coord1_max,
        resolution0=rows,
        resolution1=cols,
        cell_area=abs((coord0_max - coord0_min) * (coord1_max - coord1_min))
        / float(rows * cols),
    )


def scene_vertex_table(scene: SolverScene | CompiledScene, compiled: CompiledScene) -> torch.Tensor:
    """Live global vertex table matching ``compiled.geometry.vertices``.

    RayD concatenates structure meshes in scene order, so the live table is
    the concatenation of the structure vertex tensors. Returning the live
    tensors (rather than the native export) is what lets mesh-vertex
    gradients exist at all.
    """

    native = compiled.geometry.vertices
    if not scene.structures:
        return native
    vertices = torch.cat(
        [
            structure.vertices.to(device=native.device, dtype=torch.float32)
            for structure in scene.structures
        ],
        dim=0,
    )
    if vertices.shape != native.shape:
        raise RuntimeError(
            "differentiable vertex table does not match the native scene "
            f"table: {tuple(vertices.shape)} vs {tuple(native.shape)}"
        )
    return vertices


def transmitter_positions_ad(
    scene: SolverScene, native: torch.Tensor, *, device: torch.device,
) -> torch.Tensor:
    """Live transmitter positions: one stack of the scene leaves, on the graph when they are."""

    if not scene.transmitters:
        return native
    return endpoint_store(scene, device=device).tx_positions


def receiver_positions_ad(
    scene: SolverScene, native: torch.Tensor, *, device: torch.device,
) -> torch.Tensor:
    """Live receiver positions for point receivers.

    Grid receivers are generated natively from origin/axes/spacing and stay
    detached: a grid exposes no per-receiver position tensor for a user to
    mark requires_grad, so nothing is silently zeroed here.
    """

    if not scene.receivers:
        return native
    live = endpoint_store(scene, device=device).rx_positions_live
    return native if live is None else live


_MATERIAL_AD_FIELDS = (
    "eps_r", "sigma_e", "thickness_m", "gain", "layer_eps_r", "layer_sigma_e", "layer_thickness_m",
)


def reverse_mode_scene_leaves(scene: SolverScene) -> tuple[torch.Tensor, ...]:
    """Every scene tensor a caller can mark ``requires_grad`` for a solve, if it does."""

    candidates: list[object] = [scene.frequency]
    for transmitter in scene.transmitters:
        candidates += [transmitter.position, transmitter.power_w]
    candidates += [
        receiver.position for receiver in scene.receivers if isinstance(receiver, _ReceiverPointView)
    ]
    candidates += [getattr(structure, "vertices", None) for structure in scene.structures]
    materials = scene.compiled.materials
    candidates += [getattr(materials, name, None) for name in _MATERIAL_AD_FIELDS]
    return tuple(
        value
        for value in candidates
        if isinstance(value, torch.Tensor) and value.requires_grad
    )


class _ZeroGradientLink(torch.autograd.Function):
    """Identity on ``output`` whose backward hands every linked leaf an exact zero gradient."""

    @staticmethod
    def forward(ctx: Any, output: torch.Tensor, *leaves: torch.Tensor) -> torch.Tensor:
        ctx.leaf_meta = tuple((leaf.shape, leaf.dtype, leaf.device) for leaf in leaves)
        return output.clone()

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, ...]:
        return (
            grad_output,
            *(torch.zeros(shape, dtype=dtype, device=device) for shape, dtype, device in ctx.leaf_meta),
        )


def link_zero_gradient(output: torch.Tensor, scene: SolverScene) -> torch.Tensor:
    """Keep a reverse-mode result on the graph when no path depends on the live leaves.

    Under ``ad_mode="vjp"`` a solve whose surviving paths do not depend on any
    marked leaf (for example a receiver with no valid path) has an exactly zero
    derivative. Without this the output carries no graph and ``backward()``
    fails with an unrelated autograd error; with it every live leaf receives a
    zero gradient, as the other solvers return.
    """

    if output.requires_grad:
        return output
    leaves = reverse_mode_scene_leaves(scene)
    if not leaves:
        return output
    return _ZeroGradientLink.apply(output, *leaves)


def transmitter_polarizations_f32(scene: SolverScene, *, device: torch.device) -> torch.Tensor:
    """Transmitter polarizations as a contiguous float32 ``(N, 3)`` tensor.

    Row order matches the transmitter order of the logical scene. The vectors
    are unit and oriented by the Core transmitter model; they come from the
    scene's endpoint store, so a solve neither recomputes nor re-uploads them.

    This is NOT :func:`witwin.channel.scene.compiler.transmitter_polarizations_as_stored`,
    which keeps whatever dtype the scene stored. Both are live and each has its
    own callers; the two names record the difference instead of hiding it
    behind one spelling.
    """

    return endpoint_store(scene, device=device).tx_polarizations


def receiver_polarizations_f32(
    scene: SolverScene, *, device: torch.device, grid: ReceiverGrid | None = None,
) -> torch.Tensor:
    """Receiver polarizations as a contiguous float32 ``(N, 3)`` tensor.

    With ``grid``, one grid polarization is broadcast over that grid's points.
    Without it, the scene's receivers are expanded in order: a grid contributes
    one row per point, a point receiver one row. :func:`receiver_polarization_rows`
    returns the same values without materializing the per-cell copy.
    """

    store = endpoint_store(scene, device=device)
    if grid is not None:
        index = next(
            (position for position, receiver in enumerate(store.receivers) if receiver is grid),
            None,
        )
        if index is None:
            return _world_polarizations((grid,)).to(device=device, dtype=torch.float32).expand(
                grid.shape[0] * grid.shape[1], 3
            ).contiguous()
        return store.receiver_polarization_rows(index).contiguous()
    return store.rx_polarizations.contiguous()


def receiver_polarization_rows(scene: SolverScene, *, device: torch.device) -> torch.Tensor:
    """Float32 ``(N, 3)`` receiver polarizations per flattened row; a grid is a broadcast view."""

    return endpoint_store(scene, device=device).rx_polarizations


__all__: list[str] = []
