"""Mesh entities of a Scene document: write, read and check generated meshes.

A generated mesh is an entity of type ``builtin.mesh`` with three components:

- ``Mesh``: ``{"mesh_type": "Custom", "source": {"type": "generated_mesh",
  "storage": "scene_binary", "binary_id": "gen_3", "content_hash": "sha256:..."}}``;
  the triangles live in ``<scene>.binary/gen_3.meshbin`` (``witwin.studio.meshbin``).
  This is the shape the ProjectServer writes when it saves a generated mesh
  (``features/assets/mesh/generated_mesh_persistence.py``) and hydrates on load.
- ``Material``: material name or EM values (``geometry.material_properties``).
- ``GeometryBody``: role, fill, surface thickness, anchors
  (``geometry.body_properties``).

Vertices are stored in meters. The entity's Transform places the mesh.

New payloads wait in ``Scene._pending_meshes`` until ``Scene.save`` writes them
next to the scene file, before the scene text, so a reader that sees the new
text always finds its mesh files.

Internal module: the public entry points are ``Scene.add_mesh``,
``Scene.validate``, ``Entity.set_mesh`` and ``Entity.get_mesh``.
"""
from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

from .geometry import _body as body_mod
from .geometry._body import Anchor, Body, parse_anchors
from .geometry._convert import MeshData, to_parts
from .geometry._frame import anchor_to_scene, check_up, mesh_to_scene
from .geometry._validate import BodyInput, GeometryValidationError, Issue, ValidationReport, validate_inputs
from .units import find_unit

if TYPE_CHECKING:  # pragma: no cover
    from ._scene import Entity, Scene

MESH = "Mesh"
MATERIAL = "Material"
BODY = "GeometryBody"
MESH_ENTITY_TYPE = "builtin.mesh"
SOURCE_TYPE = "generated_mesh"
STORAGE = "scene_binary"
BINARY_PREFIX = "gen"
BINARY_EXT = ".meshbin"


def length_factor(unit: str) -> float:
    """Meters per ``unit`` (``m``, ``mm``, ``um``, ``nm``)."""
    found = find_unit("length", unit) if isinstance(unit, str) else None
    if found is None:
        raise ValueError(f"unknown length unit {unit!r}; use one of m, mm, um, nm")
    return found.multiplier


def binary_dir(scene_path: Path) -> Path:
    """``scenes/x.wtscene`` -> ``scenes/x.binary`` (the ProjectServer's SceneBinaryStore layout)."""
    return Path(scene_path).with_suffix(".binary")


def binary_source(entity_data: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
    """The Mesh source dict when it points at a scene-binary file, else None."""
    for item in entity_data.get("components") or ():
        if item.get("type") == MESH:
            source = (item.get("properties") or {}).get("source")
            if isinstance(source, dict) and source.get("type") == SOURCE_TYPE \
                    and source.get("storage") == STORAGE and isinstance(source.get("binary_id"), str):
                return source
    return None


def referenced_binary_ids(document: Mapping[str, Any]) -> Set[str]:
    out = set()
    for data in (document.get("objects") or {}).values():
        source = binary_source(data)
        if source is not None:
            out.add(source["binary_id"])
    return out


def _allocate_id(taken: Set[str]) -> str:
    n = 1
    while f"{BINARY_PREFIX}_{n}" in taken:
        n += 1
    return f"{BINARY_PREFIX}_{n}"


def _taken_ids(scene: "Scene") -> Set[str]:
    taken = referenced_binary_ids(scene._doc) | set(scene._pending_meshes)
    if scene.path is not None and binary_dir(scene.path).is_dir():
        # Files on disk may belong to the ProjectServer's own unsaved state
        # or to a later save of another copy; never reuse their names.
        taken |= {p.stem for p in binary_dir(scene.path).iterdir() if p.suffix == BINARY_EXT}
    return taken


# --------------------------------------------------------------------------- #
# Transforms (numpy). Same convention as the ProjectServer's Transform
# component: local = T @ R @ S, world = parent_world @ local.
# --------------------------------------------------------------------------- #
def _local_matrix(position: Sequence[float], rotation: Sequence[float], scale: Sequence[float]):
    import numpy as np

    x, y, z, w = (float(v) for v in rotation)
    norm = (x * x + y * y + z * z + w * w) ** 0.5 or 1.0
    x, y, z, w = x / norm, y / norm, z / norm, w / norm
    m = np.eye(4)
    m[:3, :3] = np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ]) @ np.diag([float(s) for s in scale])
    m[:3, 3] = [float(p) for p in position]
    return m


def world_matrix(scene: "Scene", entity_id: Optional[str]):
    """World matrix of an entity (identity for None / the root)."""
    import numpy as np

    m = np.eye(4)
    seen = set()
    while entity_id and entity_id != "root" and entity_id in scene._objects and entity_id not in seen:
        seen.add(entity_id)
        entity = scene.objects[entity_id]
        t = entity.transform
        m = _local_matrix(t.position, t.rotation, t.scale) @ m
        entity_id = scene._objects[entity_id].get("parent_id")
    return m


def _apply(matrix, points):
    import numpy as np

    pts = np.asarray(points, dtype=np.float64).reshape(-1, 3)
    return pts @ matrix[:3, :3].T + matrix[:3, 3]


def _world_anchors(matrix, anchors: Sequence[Anchor]) -> List[Anchor]:
    out = []
    for a in anchors:
        point = _apply(matrix, [a.point])[0]
        out.append(Anchor(a.name, tuple(float(v) for v in point), a.normal, a.kind))  # type: ignore[arg-type]
    return out


# --------------------------------------------------------------------------- #
# Writing
# --------------------------------------------------------------------------- #
class _Part:
    """One body to write: SI mesh plus metadata."""

    def __init__(self, name: str, mesh: MeshData, material: Any, fill: str, role: str, anchors: List[Anchor],
                 surface_thickness: Optional[float] = None):
        self.name = name
        self.mesh = mesh
        self.material = material
        self.fill = fill
        self.role = role
        self.anchors = anchors
        self.surface_thickness = surface_thickness  # meters; None: not given
        self.has_material = material is not None


def _parts(name: str, mesh: Any, *, material: Any, fill: Optional[str], role: Optional[str],
           anchors: Optional[Iterable[Any]], factor: float, surface_thickness: Optional[float] = None,
           defaults: Optional[Mapping[str, Any]] = None, up: Optional[str] = None) -> List[_Part]:
    """Convert the input and resolve metadata: argument, then Body, then ``defaults``.

    ``surface_thickness`` is meters and is not scaled by ``factor``. ``up``
    (argument, then the Body's, then ``"y"``) is the frame the vertices and
    anchors were built in; a ``"z"`` input is turned into the Y-up Scene frame
    here, once (``geometry._frame``).
    """
    defaults = dict(defaults or {})
    if isinstance(mesh, Body):
        base = {"material": mesh.material, "fill": mesh.fill, "role": mesh.role, "anchors": mesh.anchors,
                "surface_thickness": getattr(mesh, "surface_thickness", None), "up": mesh.up}
        converted = [(None, mesh.mesh)]
    else:
        base = {}
        converted = to_parts(mesh)

    def pick(key: str, value: Any, fallback: Any) -> Any:
        if value is not None:
            return value
        if base.get(key) is not None:
            return base[key]
        return defaults.get(key, fallback)

    resolved_material = pick("material", material, None)
    body_mod.material_properties(resolved_material)  # refuse a bad material before anything is written
    resolved_fill = body_mod._check_choice(pick("fill", fill, "solid"), body_mod.FILLS, "fill")
    resolved_role = body_mod._check_choice(pick("role", role, "other"), body_mod.ROLES, "role")
    resolved_up = check_up(pick("up", up, "y"))
    resolved_anchors = [anchor_to_scene(a.scaled(factor), resolved_up)
                        for a in parse_anchors(pick("anchors", anchors, []))]
    resolved_thickness = body_mod.surface_thickness_value(
        pick("surface_thickness", body_mod.surface_thickness_value(surface_thickness), None))
    parts = []
    for part_name, data in converted:
        parts.append(_Part(part_name or name, mesh_to_scene(data.scaled(factor), resolved_up), resolved_material,
                           resolved_fill,
                           resolved_role, resolved_anchors if len(converted) == 1 else [],
                           resolved_thickness))
    if len(converted) > 1 and resolved_anchors:
        # Anchors of a multi-part input belong to no single part; keep them on the first.
        parts[0].anchors = resolved_anchors
    return parts


def _check(parts: Sequence[_Part], matrices: Sequence[Any], factor: float, *, grid: Any,
           max_triangles: Optional[int], object_ids: Sequence[Optional[str]] = ()) -> ValidationReport:
    inputs = []
    for index, (part, matrix) in enumerate(zip(parts, matrices)):
        inputs.append(BodyInput(
            name=part.name, vertices=_apply(matrix, part.mesh.vertices), faces=part.mesh.faces,
            role=part.role, fill=part.fill, has_material=part.has_material,
            anchors=_world_anchors(matrix, part.anchors),
            object_id=object_ids[index] if index < len(object_ids) else None, unit_multiplier=factor,
            surface_thickness=part.surface_thickness))
    return validate_inputs(inputs, grid=grid, max_triangles=max_triangles)


def _encode(mesh: MeshData) -> bytes:
    from . import meshbin

    return meshbin.encode_mesh(mesh.vertices, mesh.faces, normals=mesh.normals)


def _write_components(scene: "Scene", entity: "Entity", part: _Part) -> None:
    from . import meshbin

    payload = _encode(part.mesh)
    binary_id = _allocate_id(_taken_ids(scene))
    scene._pending_meshes[binary_id] = payload
    source = {"type": SOURCE_TYPE, "storage": STORAGE, "binary_id": binary_id,
              "content_hash": meshbin.content_hash_of(payload)}
    components = entity.components
    if MESH in components:
        mesh_props = components[MESH]
        mesh_props["mesh_type"] = "Custom"
        mesh_props["source"] = source
    else:
        components.add(MESH, mesh_type="Custom", source=source)
    material = body_mod.material_properties(part.material)
    if MATERIAL in components:
        components[MATERIAL].update(material)
    else:
        components.add(MATERIAL, **material)
    body = body_mod.body_properties(part.role, part.fill, part.anchors, part.surface_thickness)
    if BODY in components:
        components[BODY].update(body)
    else:
        components.add(BODY, **body)
    entity._data["entity_type"] = MESH_ENTITY_TYPE


def add_mesh(scene: "Scene", name: str, mesh: Any, *, material: Any, fill: Optional[str], role: Optional[str],
             anchors: Optional[Iterable[Any]], parent: Any, unit: str, position: Optional[Sequence[float]],
             rotation: Optional[Sequence[float]], scale: Optional[Sequence[float]], grid: Any,
             max_triangles: Optional[int], force: bool, surface_thickness: Optional[float] = None,
             up: Optional[str] = None) -> "Entity":
    factor = length_factor(unit)
    parts = _parts(name, mesh, material=material, fill=fill, role=role, anchors=anchors, factor=factor,
                   surface_thickness=surface_thickness, up=up)
    parent_id = getattr(parent, "id", parent) or None
    if parent_id is not None and parent_id not in scene._objects:
        raise KeyError(f"parent not in scene: {parent_id}")
    position_si = None if position is None else [float(v) * factor for v in position]
    local = _local_matrix(position_si or (0, 0, 0), rotation or (0, 0, 0, 1), scale or (1, 1, 1))
    top = world_matrix(scene, parent_id) @ local
    # A multi-part input becomes a group (with the transform) holding one
    # child per part at identity, so every part shares the top matrix.
    report = _check(parts, [top] * len(parts), factor, grid=grid, max_triangles=max_triangles)
    if not report.ok and not force:
        raise GeometryValidationError(report)

    if len(parts) == 1:
        entity = scene.add(name, type=MESH_ENTITY_TYPE, parent=parent_id, position=position_si,
                           rotation=rotation, scale=scale)
        _write_components(scene, entity, parts[0])
        ids = [entity.id]
    else:
        entity = scene.add(name, parent=parent_id, position=position_si, rotation=rotation, scale=scale)
        ids = []
        for part in parts:
            child = scene.add(part.name, type=MESH_ENTITY_TYPE, parent=entity.id)
            _write_components(scene, child, part)
            ids.append(child.id)
    for stats, object_id in zip(report.bodies, ids):
        stats.object_id = object_id
    for issue in report.issues:
        if issue.object_id is None and issue.body is not None:
            issue.object_id = next((i for i, p in zip(ids, parts) if p.name == issue.body), None)
    entity.validation = report
    return entity


def _merge_parts(name: str, parts: List[_Part]) -> _Part:
    """One part from several (a trimesh.Scene given where one mesh is needed)."""
    import numpy as np

    if len(parts) == 1:
        return parts[0]
    offsets = np.cumsum([0] + [p.mesh.vertex_count for p in parts[:-1]])
    merged = MeshData(np.concatenate([p.mesh.vertices for p in parts]),
                      np.concatenate([p.mesh.faces + o for p, o in zip(parts, offsets)]))
    first = parts[0]
    return _Part(name, merged, first.material, first.fill, first.role, first.anchors, first.surface_thickness)


def prepare_op_mesh(name: str, mesh: Any, *, material: Any, fill: Optional[str], role: Optional[str],
                    anchors: Optional[Iterable[Any]], unit: str, position: Optional[Sequence[float]],
                    rotation: Optional[Sequence[float]], scale: Optional[Sequence[float]], grid: Any,
                    max_triangles: Optional[int], force: bool, surface_thickness: Optional[float] = None,
                    up: Optional[str] = None) -> Tuple[_Part, Optional[List[float]], ValidationReport]:
    """Convert and check one mesh for a ``create_mesh`` batch op (``witwin_agent``).

    Returns the part in meters, the position in meters and the report; raises
    ``GeometryValidationError`` on errors unless ``force``. Checked in the
    object's own frame: the parent's transform is not known to a script, and
    the ProjectServer checks again in world space.
    """
    factor = length_factor(unit)
    part = _merge_parts(name, _parts(name, mesh, material=material, fill=fill, role=role, anchors=anchors,
                                     factor=factor, surface_thickness=surface_thickness, up=up))
    position_si = None if position is None else [float(v) * factor for v in position]
    matrix = _local_matrix(position_si or (0, 0, 0), rotation or (0, 0, 0, 1), scale or (1, 1, 1))
    report = _check([part], [matrix], factor, grid=grid, max_triangles=max_triangles)
    if not report.ok and not force:
        raise GeometryValidationError(report)
    return part, position_si, report


def _existing_defaults(entity: "Entity") -> Dict[str, Any]:
    components = entity.components
    out: Dict[str, Any] = {}
    if BODY in components:
        props = components[BODY]
        out["fill"] = props.get("fill")
        out["role"] = props.get("role")
        out["anchors"] = body_mod.anchors_from_properties(props) or None
        try:
            out["surface_thickness"] = body_mod.surface_thickness_value(props.get("surface_thickness"))
        except (TypeError, ValueError):
            out["surface_thickness"] = None  # a bad stored value counts as not given
    return out


def set_mesh(entity: "Entity", mesh: Any, *, material: Any, fill: Optional[str], role: Optional[str],
             anchors: Optional[Iterable[Any]], unit: str, grid: Any, max_triangles: Optional[int],
             force: bool, surface_thickness: Optional[float] = None,
             up: Optional[str] = None) -> ValidationReport:
    scene = entity._scene
    factor = length_factor(unit)
    defaults = _existing_defaults(entity)
    if defaults.get("anchors"):
        # Stored anchors are already in meters and in the Scene frame; undo
        # both so the factor and the up rotation applied to the input do not
        # apply to them twice.
        frame = up if up is not None else (mesh.up if isinstance(mesh, Body) else None)
        defaults["anchors"] = [anchor_to_scene(a.scaled(1.0 / factor), frame, source="y")
                               for a in defaults["anchors"]]
    parts = [_merge_parts(entity.name, _parts(entity.name, mesh, material=material, fill=fill, role=role,
                                              anchors=anchors, factor=factor, surface_thickness=surface_thickness,
                                              defaults=defaults, up=up))]
    # A material already on the entity counts as set; set_mesh keeps it.
    parts[0].has_material = parts[0].material is not None or bool(
        entity.components[MATERIAL] if MATERIAL in entity.components else None)
    report = _check(parts, [world_matrix(scene, entity.id)], factor, grid=grid,
                    max_triangles=max_triangles, object_ids=[entity.id])
    if not report.ok and not force:
        raise GeometryValidationError(report)
    old = binary_source(entity._data)
    if old is not None:
        scene._pending_meshes.pop(old["binary_id"], None)
    _write_components(scene, entity, parts[0])
    return report


# --------------------------------------------------------------------------- #
# Reading and checking
# --------------------------------------------------------------------------- #
def read_payload(scene: "Scene", binary_id: str) -> Optional[bytes]:
    if binary_id in scene._pending_meshes:
        return scene._pending_meshes[binary_id]
    if scene.path is None:
        return None
    path = binary_dir(scene.path) / f"{binary_id}{BINARY_EXT}"
    return path.read_bytes() if path.is_file() else None


def get_mesh(entity: "Entity") -> Optional[MeshData]:
    from . import meshbin

    source = binary_source(entity._data)
    if source is None:
        return None
    payload = read_payload(entity._scene, source["binary_id"])
    if payload is None:
        return None
    decoded = meshbin.decode_mesh(payload)
    return MeshData(decoded.positions.astype("float64"), decoded.indices.astype("int64"),
                    None if decoded.normals is None else decoded.normals.astype("float64"))


def validate_scene(scene: "Scene", object_ids: Optional[Iterable[str]], *, grid: Any,
                   max_triangles: Optional[int], domain: Any) -> ValidationReport:
    wanted = None if object_ids is None else list(object_ids)
    inputs: List[BodyInput] = []
    missing: List[Issue] = []
    for oid in (wanted if wanted is not None else list(scene._objects)):
        if oid not in scene._objects:
            raise KeyError(oid)
        entity = scene.objects[oid]
        if binary_source(entity._data) is None:
            continue
        mesh = get_mesh(entity)
        if mesh is None:
            missing.append(Issue("error", "missing_mesh_data", "the mesh file is missing", entity.name, oid))
            continue
        matrix = world_matrix(scene, oid)
        props = entity.components[BODY] if BODY in entity.components else {}
        material = entity.components[MATERIAL] if MATERIAL in entity.components else None
        thickness = props.get("surface_thickness")
        inputs.append(BodyInput(
            name=entity.name, vertices=_apply(matrix, mesh.vertices), faces=mesh.faces,
            role=props.get("role") or "other", fill=props.get("fill") or "solid",
            has_material=bool(material), anchors=_world_anchors(matrix, body_mod.anchors_from_properties(props)),
            object_id=oid, unit_multiplier=None,
            surface_thickness=float(thickness) if isinstance(thickness, (int, float)) else None))
    report = validate_inputs(inputs, grid=grid, max_triangles=max_triangles, domain=domain)
    report.issues[:0] = missing
    return report


# --------------------------------------------------------------------------- #
# Saving
# --------------------------------------------------------------------------- #
def _write_atomic(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(payload)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def flush_binaries(scene: "Scene", target: Path) -> Set[str]:
    """Write pending and carried-over mesh files for ``target``; returns the referenced ids.

    Called by ``Scene.save`` before the scene text is written. Saving to a
    new path copies the mesh files the scene already had.
    """
    referenced = referenced_binary_ids(scene._doc)
    directory = binary_dir(target)
    old_dir = binary_dir(scene.path) if scene.path is not None else None
    for binary_id in sorted(referenced):
        destination = directory / f"{binary_id}{BINARY_EXT}"
        if binary_id in scene._pending_meshes:
            _write_atomic(destination, scene._pending_meshes[binary_id])
        elif old_dir is not None and old_dir != directory and not destination.exists():
            source = old_dir / f"{binary_id}{BINARY_EXT}"
            if source.is_file():
                directory.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
    return referenced


def drop_unreferenced(scene: "Scene", target: Path, referenced: Set[str]) -> None:
    """Delete mesh files this Scene object stopped referencing (replaced or removed).

    Only ids the Scene knew (loaded or written) are candidates, so files of
    other writers in the same folder are left alone. Empty folders go too,
    as the ProjectServer's own garbage collection does.
    """
    directory = binary_dir(target)
    for binary_id in scene._known_binary_ids - referenced:
        path = directory / f"{binary_id}{BINARY_EXT}"
        try:
            path.unlink()
        except FileNotFoundError:
            pass
    try:
        if directory.is_dir() and not any(directory.iterdir()):
            directory.rmdir()
    except OSError:
        pass
