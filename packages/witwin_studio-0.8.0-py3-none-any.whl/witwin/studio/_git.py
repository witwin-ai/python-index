"""Start a fresh Project as a git repository: ``git init``, ``.gitattributes``, one commit.

The scaffold writer (``_scaffold.py``) calls ``init_project_repo`` only for a
Project it creates from nothing: ``witwin init`` or ``ensure_witwin_project`` in
a new or empty folder, and a Project Studio just created (the pending marker).
Opening a folder that already has content, and "Make Python Project" on an
older Project, never start a repository; Studio offers an Initialize button for
those.

The ProjectServer's first start writes ``main_scene`` into witwin.toml and
the empty main Scene. For a Project committed before any server ran, it calls
``fold_into_creation_commit`` so the Project still opens with no changes.

It also owns the Git LFS lines of ``.gitattributes`` (``lfs_tracked``,
``lfs_track``) and the check a dataset writer makes before it writes
(``lfs_problem``): the SDK writes datasets without Studio, and the server's
``features/git/lfs.py`` calls these, so one writer edits those lines.

This module runs the ``git`` command line and nothing else, so the SDK keeps no
dependency on ``witwin_server`` (whose ``features/git`` serves the editor's Git
panel).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from ._environment import hosted

GITATTRIBUTES = ".gitattributes"

# Scene files are TOML that Studio and scripts rewrite; a CRLF checkout on
# Windows would show every line as changed after the next save.
GITATTRIBUTES_LINES = ("*.wtscene text eol=lf",)

DEFAULT_BRANCH = "main"

# Studio sets these from the signed-in WiTwin account when it starts the local
# ProjectServer (studio/electron/python/gitIdentity.ts). They are used only
# when git has no user.name / user.email of its own for the folder.
AUTHOR_NAME_ENV = "WITWIN_GIT_AUTHOR_NAME"
AUTHOR_EMAIL_ENV = "WITWIN_GIT_AUTHOR_EMAIL"

# Variables that would point git at another repository than the folder it is
# run in (they are set while a git hook runs, for example).
_REDIRECT_ENV = ("GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY", "GIT_COMMON_DIR")

# Seconds. A commit that needs a signing passphrase would otherwise block the
# ProjectServer start forever.
_TIMEOUT = 60

SKIP_NO_GIT = "git is not installed"
SKIP_ALREADY_REPO = "the folder is already a git repository"
SKIP_INSIDE_REPO = "the folder is inside another git repository"
NO_IDENTITY = "no git identity (set user.name and user.email, or sign in to WiTwin in Studio)"


@dataclass
class GitInitResult:
    """What ``init_project_repo`` did. ``skipped`` is the reason nothing was done."""

    initialized: bool = False
    committed: bool = False
    branch: Optional[str] = None
    message: Optional[str] = None
    skipped: Optional[str] = None
    # Why there is no commit after a successful init (no identity, commit failed).
    no_commit_reason: Optional[str] = None
    # "config" when git already had an identity, "caller" or "environment" when
    # this call wrote one into the repository's local config.
    identity_source: Optional[str] = None

    def summary(self) -> str:
        """One line for ``witwin init`` and the ProjectServer log."""
        if self.skipped:
            return f"skipped: {self.skipped}"
        if self.committed:
            return f'initialized on branch {self.branch}, committed "{self.message}"'
        return f"initialized on branch {self.branch}; no commit: {self.no_commit_reason}"


@dataclass
class GitIdentity:
    name: str = ""
    email: str = ""

    @property
    def complete(self) -> bool:
        return bool(self.name.strip() and self.email.strip())


def git_executable() -> Optional[str]:
    return shutil.which("git")


def without_hooks(env: Dict[str, str]) -> Dict[str, str]:
    """``env`` with git hooks and the fsmonitor turned off, for a hosted ProjectServer.

    Both run a program named by the repository, which the user controls; on a
    machine shared with other users that is their code running there. Passed as
    ``GIT_CONFIG_COUNT`` entries (git 2.31+) so they win over ``.git/config``.
    """
    count = int(env.get("GIT_CONFIG_COUNT") or 0)
    for key, value in (("core.hooksPath", os.devnull), ("core.fsmonitor", "false")):
        env[f"GIT_CONFIG_KEY_{count}"] = key
        env[f"GIT_CONFIG_VALUE_{count}"] = value
        count += 1
    env["GIT_CONFIG_COUNT"] = str(count)
    return env


def _env() -> Dict[str, str]:
    env = {key: value for key, value in os.environ.items() if key not in _REDIRECT_ENV}
    env["GIT_TERMINAL_PROMPT"] = "0"
    return without_hooks(env) if hosted() else env


def run_git(root: Path, *args: str) -> subprocess.CompletedProcess:
    """Run ``git -C root ...``; never raises for a non-zero exit."""
    exe = git_executable()
    if exe is None:
        raise FileNotFoundError("git")
    return subprocess.run(
        [exe, "-C", str(root), *args],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        env=_env(), stdin=subprocess.DEVNULL, timeout=_TIMEOUT,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0,
    )


def _error(done: subprocess.CompletedProcess) -> str:
    return (done.stderr or done.stdout or f"exit code {done.returncode}").strip().splitlines()[-1]


def work_tree_root(root: Path) -> Optional[Path]:
    """The top folder of the git work tree that holds ``root``; None outside any."""
    done = run_git(root, "rev-parse", "--show-toplevel")
    if done.returncode != 0 or not done.stdout.strip():
        return None
    return Path(done.stdout.strip()).resolve()


def ensure_gitattributes(root: Path) -> Optional[str]:
    """Add the lines a Project needs; "written", "updated", or None when complete.

    An existing file keeps every line it has; only missing lines are appended.
    """
    path = root / GITATTRIBUTES
    if not path.exists():
        path.write_text("".join(f"{line}\n" for line in GITATTRIBUTES_LINES), encoding="utf-8", newline="\n")
        return "written"
    text = path.read_text(encoding="utf-8")
    present = {" ".join(line.split()) for line in text.splitlines()}
    missing = [line for line in GITATTRIBUTES_LINES if line not in present]
    if not missing:
        return None
    prefix = "" if not text or text.endswith("\n") else "\n"
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(prefix + "".join(f"{line}\n" for line in missing))
    return "updated"


# The text ``git lfs track`` writes after a pattern.
LFS_ATTRS = "filter=lfs diff=lfs merge=lfs -text"


def _lfs_escape(pattern: str) -> str:
    # .gitattributes splits on whitespace; git lfs track writes spaces this way.
    return pattern.replace(" ", "[[:space:]]")


def lfs_pattern(line: str) -> Optional[str]:
    """The pattern of a ``.gitattributes`` line that routes files to LFS; None for any other line."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None
    parts = stripped.split()
    if len(parts) < 2 or "filter=lfs" not in parts[1:]:
        return None
    return parts[0].replace("[[:space:]]", " ")


def read_gitattributes(root: Path) -> List[str]:
    """The lines of ``<root>/.gitattributes``; [] when there is none."""
    path = Path(root) / GITATTRIBUTES
    return path.read_text(encoding="utf-8").splitlines() if path.is_file() else []


def write_gitattributes(root: Path, lines: Sequence[str]) -> None:
    """Replace ``.gitattributes`` with ``lines`` (LF line ends)."""
    text = "\n".join(lines)
    (Path(root) / GITATTRIBUTES).write_text(text + "\n" if text else "", encoding="utf-8", newline="\n")


def lfs_tracked(root: Path) -> List[str]:
    """Patterns ``.gitattributes`` routes to LFS, in file order, each once."""
    patterns: List[str] = []
    for line in read_gitattributes(root):
        pattern = lfs_pattern(line)
        if pattern and pattern not in patterns:
            patterns.append(pattern)
    return patterns


def lfs_track(root: Path, patterns: Sequence[str]) -> Tuple[List[str], List[str]]:
    """Append an LFS line for each pattern not tracked yet; returns ``(added, already)``.

    The same line ``git lfs track`` writes, written here so a pattern is never
    parsed as a command-line option and the file keeps its other lines and
    order. Does not check the patterns or that git-lfs is installed: callers
    do (the server's ``features/git/lfs.py``, ``lfs_problem``).
    """
    lines = read_gitattributes(root)
    present = set(lfs_tracked(root))
    added: List[str] = []
    already: List[str] = []
    for pattern in patterns:
        if pattern in present:
            already.append(pattern)
            continue
        lines.append(f"{_lfs_escape(pattern)} {LFS_ATTRS}")
        present.add(pattern)
        added.append(pattern)
    if added:
        write_gitattributes(root, lines)
    return added, already


def lfs_problem(root: Path) -> Optional[str]:
    """Why files under ``root`` cannot go to LFS, or None when they can.

    None when ``root`` is not inside a git work tree (or git is not
    installed): nothing is committed then. Inside one, git-lfs must be
    installed, its filters configured (``git lfs install``, global or
    ``--local``) and its pre-push hook present in this repository; otherwise
    the first commit would put the files in plain git.
    """
    if git_executable() is None or work_tree_root(root) is None:
        return None
    if run_git(root, "lfs", "version").returncode != 0:
        return "git-lfs is not installed; install it from https://git-lfs.com"
    if run_git(root, "config", "--get", "filter.lfs.clean").returncode != 0:
        return "Git LFS is not set up for this repository; run `git lfs install` or Enable LFS in the Git view"
    done = run_git(root, "rev-parse", "--git-path", "hooks/pre-push")
    hook = Path(done.stdout.strip()) if done.returncode == 0 else None
    if hook is not None and not hook.is_absolute():
        hook = Path(root) / hook
    try:
        installed = hook is not None and "git-lfs" in hook.read_text(encoding="utf-8", errors="replace")
    except OSError:
        installed = False
    if not installed:
        return "the Git LFS hooks are not installed in this repository; run `git lfs install` or Enable LFS in the Git view"
    return None


def _config_value(root: Path, key: str) -> str:
    done = run_git(root, "config", "--get", key)
    return done.stdout.strip() if done.returncode == 0 else ""


def environment_identity() -> GitIdentity:
    return GitIdentity(
        name=os.environ.get(AUTHOR_NAME_ENV, "").strip(),
        email=os.environ.get(AUTHOR_EMAIL_ENV, "").strip(),
    )


def _resolve_identity(root: Path, given: Optional[GitIdentity]) -> Tuple[Optional[str], List[Tuple[str, str]]]:
    """``(source, local_config_writes)``; source is None when no full identity exists.

    Each field comes from git's own config first, then the caller, then the
    environment. Only fields git lacked are written, and only when both end up
    known, so a half identity never lands in the repository config.
    """
    configured = GitIdentity(_config_value(root, "user.name"), _config_value(root, "user.email"))
    if configured.complete:
        return "config", []
    source = None
    final = GitIdentity(configured.name, configured.email)
    for candidate, label in ((given, "caller"), (environment_identity(), "environment")):
        if candidate is None:
            continue
        if not final.name and candidate.name.strip():
            final.name, source = candidate.name.strip(), source or label
        if not final.email and candidate.email.strip():
            final.email, source = candidate.email.strip(), source or label
    if not final.complete:
        return None, []
    writes = []
    if not configured.name:
        writes.append(("user.name", final.name))
    if not configured.email:
        writes.append(("user.email", final.email))
    return source, writes


def _init(root: Path) -> Optional[str]:
    """``git init`` on branch main; the error text on failure."""
    done = run_git(root, "init", "-b", DEFAULT_BRANCH)
    if done.returncode == 0:
        return None
    # git before 2.28 has no -b: init on its default branch, then point HEAD at
    # main while the repository has no commits yet.
    done = run_git(root, "init")
    if done.returncode != 0:
        return _error(done)
    run_git(root, "symbolic-ref", "HEAD", f"refs/heads/{DEFAULT_BRANCH}")
    return None


CREATION_SUBJECT = "Create project"


def commit_message(template_id: Optional[str] = None) -> str:
    return f"{CREATION_SUBJECT} from template {template_id}" if template_id else CREATION_SUBJECT


def init_project_repo(
    root: Path | str,
    *,
    identity: Optional[GitIdentity] = None,
    template_id: Optional[str] = None,
) -> GitInitResult:
    """Make a freshly created Project a git repository with one commit.

    Call it only for a Project created from nothing; see the module docstring.
    The caller writes ``.gitattributes`` first (``ensure_gitattributes``) so the
    commit carries it.
    """
    root = Path(root).resolve()
    result = GitInitResult()
    if git_executable() is None:
        result.skipped = SKIP_NO_GIT
        return result
    if (root / ".git").exists():
        # Checked before rev-parse, which fails on a repository git refuses to
        # read (another owner, "dubious ownership"); init there would reinitialize it.
        result.skipped = SKIP_ALREADY_REPO
        return result
    try:
        top = work_tree_root(root)
        if top is not None:
            result.skipped = SKIP_ALREADY_REPO if top == root else SKIP_INSIDE_REPO
            return result
        error = _init(root)
        if error:
            result.skipped = f"git init failed: {error}"
            return result
        result.initialized = True
        result.branch = DEFAULT_BRANCH
        source, writes = _resolve_identity(root, identity)
        if source is None:
            result.no_commit_reason = NO_IDENTITY
            return result
        for key, value in writes:
            run_git(root, "config", "--local", key, value)
        result.identity_source = source
        done = run_git(root, "add", "--all")
        if done.returncode != 0:
            result.no_commit_reason = f"git add failed: {_error(done)}"
            return result
        message = commit_message(template_id)
        done = run_git(root, "commit", "--quiet", "--message", message)
        if done.returncode != 0:
            result.no_commit_reason = f"git commit failed: {_error(done)}"
            return result
        result.committed = True
        result.message = message
    except (OSError, subprocess.SubprocessError) as exc:
        # A missing or hung git must never fail Project creation.
        if result.initialized:
            result.no_commit_reason = f"git failed: {exc}"
        else:
            result.skipped = f"git failed: {exc}"
    return result


MANIFEST = "witwin.toml"
# [project] keys the ProjectServer's first start may add to witwin.toml
# (``persistence.write_main_scene_id``).
FIRST_START_MANIFEST_KEYS = ("main_scene",)


@dataclass
class FoldResult:
    """What ``fold_into_creation_commit`` did. ``reason`` says why nothing was done."""

    amended: bool = False
    paths: List[str] = field(default_factory=list)
    reason: Optional[str] = None


def _porcelain(root: Path) -> Dict[str, str]:
    """``{path: XY}`` from ``git status --porcelain=v1 -z``; raises OSError when git fails."""
    done = run_git(root, "status", "--porcelain=v1", "-z", "--untracked-files=all")
    if done.returncode != 0:
        raise OSError(_error(done))
    tokens = done.stdout.split("\0")
    entries: Dict[str, str] = {}
    i = 0
    while i < len(tokens) and tokens[i]:
        xy, path = tokens[i][:2], tokens[i][3:]
        entries[path] = xy
        # A rename or copy is followed by its old path as a separate token.
        i += 2 if xy[:1] in ("R", "C") else 1
    return entries


def _manifest_gained_only_first_start_keys(root: Path) -> bool:
    """True when witwin.toml differs from HEAD only in ``FIRST_START_MANIFEST_KEYS``.

    Compared as parsed TOML, so a line-ending change (CRLF written by an older
    ``witwin init`` on Windows, LF by the server) does not count as an edit.
    """
    import tomllib

    head = run_git(root, "show", f"HEAD:{MANIFEST}")
    if head.returncode != 0:
        return False
    try:
        old = tomllib.loads(head.stdout)
        new = tomllib.loads((root / MANIFEST).read_text(encoding="utf-8"))
    except (tomllib.TOMLDecodeError, OSError, UnicodeDecodeError):
        return False
    for doc in (old, new):
        project = doc.get("project")
        if isinstance(project, dict):
            for key in FIRST_START_MANIFEST_KEYS:
                project.pop(key, None)
    return old == new


def _is_creation_subject(subject: str) -> bool:
    return subject == CREATION_SUBJECT or subject.startswith(f"{CREATION_SUBJECT} from template ")


def fold_into_creation_commit(root: Path | str, paths: Sequence[str]) -> FoldResult:
    """Add what the ProjectServer's first start wrote to the Project's creation commit.

    A Project created without a server (``witwin init``, ``ensure_witwin_project``
    on an empty folder, Control and Router creating one) is committed before
    any server runs. The first start then adds ``main_scene`` to witwin.toml
    and writes the empty main Scene, so the Project would open with two
    changes the user never made. The server passes the paths it wrote; they
    are amended into the creation commit only while that commit is provably
    private and untouched:

    - the repository has exactly one commit, named by ``commit_message``, and
      no remote (nothing can have been pushed or shared);
    - every changed path is one of ``paths``: the Scene file is new
      (untracked), and witwin.toml differs from the commit only in
      ``FIRST_START_MANIFEST_KEYS``.

    Anything else (a user edit, a second commit, a remote) leaves the
    repository alone and says why in ``reason``. Never raises.
    """
    root = Path(root).resolve()
    result = FoldResult()
    wanted = {str(path).replace("\\", "/") for path in paths if path}
    if not wanted:
        result.reason = "nothing to add"
        return result
    if git_executable() is None:
        result.reason = SKIP_NO_GIT
        return result
    if not (root / ".git").exists():
        result.reason = "not a git repository"
        return result
    try:
        heads = run_git(root, "rev-list", "--max-count=2", "HEAD")
        if heads.returncode != 0:
            result.reason = "no commit yet"
            return result
        if len(heads.stdout.split()) != 1:
            result.reason = "the repository has more than its creation commit"
            return result
        if not _is_creation_subject(run_git(root, "log", "-1", "--format=%s").stdout.strip()):
            result.reason = "the only commit is not a creation commit"
            return result
        if run_git(root, "remote").stdout.strip():
            result.reason = "the repository has a remote, so its commit may be shared"
            return result
        changed = _porcelain(root)
        if not changed:
            result.reason = "nothing changed"
            return result
        others = sorted(set(changed) - wanted)
        if others:
            result.reason = f"other files changed: {', '.join(others[:5])}"
            return result
        for path, xy in changed.items():
            if path == MANIFEST:
                if xy != " M" or not _manifest_gained_only_first_start_keys(root):
                    result.reason = f"{MANIFEST} has other changes"
                    return result
            elif xy != "??":
                result.reason = f"{path} is not a new file"
                return result
        staged = sorted(changed)
        done = run_git(root, "add", "--", *staged)
        if done.returncode != 0:
            result.reason = f"git add failed: {_error(done)}"
            return result
        done = run_git(root, "commit", "--amend", "--no-edit", "--quiet")
        if done.returncode != 0:
            # Leave the index as it was, so the files show as ordinary changes.
            run_git(root, "reset", "--quiet", "--", *staged)
            result.reason = f"git commit failed: {_error(done)}"
            return result
        result.amended = True
        result.paths = staged
    except (OSError, subprocess.SubprocessError) as exc:
        result.reason = f"git failed: {exc}"
    return result


def fold_template_into_creation_commit(root: Path | str, template_id: str) -> FoldResult:
    """Make a template's content part of the Project's creation commit.

    A hosted Project is created, and committed, before its sandbox exists; the
    ProjectServer fills it from a template afterwards
    (``_templates.apply_template``). The Project then reads as if it had been
    created from the template: everything is amended into the one creation
    commit, renamed ``Create project from template <id>``. Same guard as
    ``fold_into_creation_commit`` (exactly one creation commit, no remote);
    ``apply_template`` has already checked the Project held nothing else, so
    every change is the template's. Never raises.
    """
    root = Path(root).resolve()
    result = FoldResult()
    if git_executable() is None:
        result.reason = SKIP_NO_GIT
        return result
    if not (root / ".git").exists():
        result.reason = "not a git repository"
        return result
    try:
        heads = run_git(root, "rev-list", "--max-count=2", "HEAD")
        if heads.returncode != 0:
            result.reason = "no commit yet"
            return result
        if len(heads.stdout.split()) != 1:
            result.reason = "the repository has more than its creation commit"
            return result
        if not _is_creation_subject(run_git(root, "log", "-1", "--format=%s").stdout.strip()):
            result.reason = "the only commit is not a creation commit"
            return result
        if run_git(root, "remote").stdout.strip():
            result.reason = "the repository has a remote, so its commit may be shared"
            return result
        changed = sorted(_porcelain(root))
        done = run_git(root, "add", "--all")
        if done.returncode != 0:
            result.reason = f"git add failed: {_error(done)}"
            return result
        done = run_git(root, "commit", "--amend", "--quiet", "--message", commit_message(template_id))
        if done.returncode != 0:
            run_git(root, "reset", "--quiet")
            result.reason = f"git commit failed: {_error(done)}"
            return result
        result.amended = True
        result.paths = changed
    except (OSError, subprocess.SubprocessError) as exc:
        result.reason = f"git failed: {exc}"
    return result


def git_state(root: Path | str) -> str:
    """One line for ``witwin check``: whether the Project is under git, and where."""
    root = Path(root).resolve()
    if git_executable() is None:
        return SKIP_NO_GIT
    try:
        top = work_tree_root(root)
        if top is None:
            return "not a git repository"
        if top != root:
            return f"inside the git repository at {top}"
        head = run_git(root, "rev-parse", "--abbrev-ref", "HEAD")
        branch = head.stdout.strip() if head.returncode == 0 else ""
        if not branch or branch == "HEAD":
            # rev-parse fails before the first commit; symbolic-ref still names the branch.
            ref = run_git(root, "symbolic-ref", "--short", "HEAD")
            branch = ref.stdout.strip() if ref.returncode == 0 else "detached HEAD"
            if run_git(root, "rev-parse", "--verify", "--quiet", "HEAD").returncode != 0:
                return f"git repository on branch {branch}, no commits yet"
        return f"git repository on branch {branch}"
    except (OSError, subprocess.SubprocessError) as exc:
        return f"git failed: {exc}"
