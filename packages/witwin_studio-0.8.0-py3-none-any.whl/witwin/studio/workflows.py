"""Workflows: saved, re-runnable step graphs in ``tasks/<id>.toml``.

Design: ``dev_docs/tasks-panel-plan.md`` §3.2-3.6 and, for ``needs``,
``matrix`` and ``max_parallel``, ``dev_docs/workflow-graph-plan.md``. The
ProjectServer, the Tasks panel (through it) and ``witwin workflow`` all read
and write the files and the run history through this module, so the format
has one parser and one scheduler (``Schedule``).

A file::

    schema = 2
    title = "Antenna sweep"
    max_parallel = 4          # optional; steps (matrix instances) running at once
    [[params]]
    id = "mesh_size"
    type = "float"            # float | int | bool | string | choice
    default = 0.5
    [[steps]]
    id = "mesh"
    kind = "script"           # script | solve | study | agent
    entry = "scripts/build_mesh.py"
    args = ["--size", "${mesh_size}"]
    [[steps]]
    id = "solve"
    kind = "solve"
    needs = ["mesh"]          # optional; default: the step written before
    solver = "maxwell"
    matrix = { freq_ghz = [28, 39, 60] }
    config = { freq_ghz = "${matrix.freq_ghz}" }
    [[steps]]
    id = "train"
    kind = "study"            # runs studies/<study>.toml
    study = "radar-net"
    args = { lr = "${lr}" }   # train Studies only: overrides its args

- ``${name}`` names a param; it is replaced when a run starts. A string that
  is exactly ``"${name}"`` inside ``config`` keeps the param's type, so a
  number stays a number. Any other use is text. ``${matrix.key}`` works the
  same with the value of the step's matrix instance.
- ``needs`` may only name steps written before the step, so a file cannot
  hold a cycle and its order is always a valid order to run it in. A step
  without ``needs`` depends on the step before it; ``needs = []`` on none.
- A step that does not succeed skips the steps that depend on it, directly
  or not; other branches go on. A matrix step runs every instance, then
  succeeds only when all of them did.
- ``schema = 2`` is written only when a file uses ``needs``, ``matrix`` or
  ``max_parallel``, so a file an older Studio can run keeps ``schema = 1``.
- Unknown keys are warnings, so a newer Studio's file still loads here. A
  ``schema`` newer than ``SCHEMA_VERSION`` is refused.
- A run of a Workflow is a "Workflow run": one JSON record in
  ``.witwin/workflows/history/<id>.json``, rewritten as its steps progress.
  Only the newest ``HISTORY_KEEP`` records are kept.

A ``study`` step runs a Study (``witwin.studio.studies``) to its end and
succeeds when that Run does. ``args`` (typed like ``config``) override a train
Study's arguments for that Run; Studio runs such Runs side by side, so a
matrix trains several settings at once through the GPU queue.

``run_workflow`` runs ``script``, ``solve`` and ``study`` steps without Studio. An
``agent`` step needs the editor's Agent, so headless it fails with
``needs_studio``; ``witwin workflow run`` sends the whole run to a running
ProjectServer instead when there is one.
"""
from __future__ import annotations

import itertools
import json
import os
import re
import secrets
import subprocess
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import tomlkit

from ._ids import slugify, unique_slug

SCHEMA_VERSION = 2
FOLDER = "tasks"
SUFFIX = ".toml"
HISTORY_PARTS = (".witwin", "workflows", "history")
HISTORY_KEEP = 500

STEP_KINDS = ("script", "solve", "study", "agent")
DEFAULT_MAX_PARALLEL = 4
MAX_PARALLEL_LIMIT = 16
# Instances one matrix step may expand to; a sweep larger than this belongs in a Study.
MATRIX_LIMIT = 64
PARAM_TYPES = ("float", "int", "bool", "string", "choice")
AGENT_PROFILES = ("readonly", "build")

# Workflow run and step states. A step is pending until its turn, waiting while
# it queues for a Run slot, the write turn or a confirmation, and skipped when
# a step it depends on did not succeed or the run was cancelled.
RUN_STATUSES = ("running", "succeeded", "failed", "cancelled")
STEP_STATUSES = ("pending", "running", "waiting", "succeeded", "failed", "cancelled", "skipped")
TERMINAL = frozenset({"succeeded", "failed", "cancelled", "skipped"})

_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]*$")
_REF_RE = re.compile(r"\$\{((?:matrix\.)?[A-Za-z_][A-Za-z0-9_]*)\}")
_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
MATRIX_REF = "matrix."
_RUN_ID_ALPHABET = "0123456789abcdefghjkmnpqrstvwxyz"  # Crockford base32, as witwin_server.core.ids

_TOP_KEYS = {"schema", "title", "description", "max_parallel", "params", "steps"}
_PARAM_KEYS = {"id", "type", "label", "default", "unit", "choices", "description"}
_COMMON_STEP_KEYS = {"id", "kind", "title", "needs", "matrix"}
_STEP_KEYS = {
    "script": _COMMON_STEP_KEYS | {"entry", "args", "timeout"},
    "solve": _COMMON_STEP_KEYS | {"solver", "scene", "config"},
    "study": _COMMON_STEP_KEYS | {"study", "args"},
    "agent": _COMMON_STEP_KEYS | {"prompt", "profile"},
}


class WorkflowError(ValueError):
    """A Workflow file or a set of param values that cannot be used; ``problems`` lists each reason."""

    def __init__(self, problems: Sequence[str]):
        self.problems = list(problems)
        super().__init__("; ".join(self.problems))


@dataclass
class Param:
    id: str
    type: str = "string"
    label: Optional[str] = None
    default: Any = None
    unit: Optional[str] = None
    choices: List[str] = field(default_factory=list)
    description: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "type": self.type, "label": self.label, "default": self.default,
                "unit": self.unit, "choices": list(self.choices), "description": self.description}


@dataclass
class Step:
    id: str
    kind: str
    title: Optional[str] = None
    entry: Optional[str] = None
    args: List[str] = field(default_factory=list)
    timeout: Optional[float] = None
    solver: Optional[str] = None
    scene: Optional[str] = None
    config: Dict[str, Any] = field(default_factory=dict)
    prompt: Optional[str] = None
    profile: str = "readonly"
    study: Optional[str] = None
    # A study step's ``args`` table (``args`` above is a script step's command line).
    study_args: Dict[str, Any] = field(default_factory=dict)
    # Ids of the steps this one waits for, defaults filled in (see the module docstring).
    needs: List[str] = field(default_factory=list)
    # Key -> values; the step runs once per combination. Empty: no matrix.
    matrix: Dict[str, List[Any]] = field(default_factory=dict)

    @property
    def label(self) -> str:
        """What a list shows for the step: its title, else what it runs."""
        if self.title:
            return self.title
        if self.kind == "script":
            return str(self.entry)
        if self.kind == "solve":
            return f"Solve {self.solver}"
        if self.kind == "study":
            return f"Study {self.study}"
        return (self.prompt or "").strip().splitlines()[0][:80] if self.prompt else "Agent"

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {"id": self.id, "kind": self.kind, "title": self.title, "label": self.label,
                                "needs": list(self.needs), "matrix": {k: list(v) for k, v in self.matrix.items()}}
        if self.kind == "script":
            data.update(entry=self.entry, args=list(self.args), timeout=self.timeout)
        elif self.kind == "solve":
            data.update(solver=self.solver, scene=self.scene, config=dict(self.config))
        elif self.kind == "study":
            data.update(study=self.study, args=dict(self.study_args))
        else:
            data.update(prompt=self.prompt, profile=self.profile)
        return data


@dataclass
class Workflow:
    id: str
    title: str
    description: Optional[str] = None
    params: List[Param] = field(default_factory=list)
    steps: List[Step] = field(default_factory=list)
    path: Optional[Path] = None
    warnings: List[str] = field(default_factory=list)
    # As written in the file; None means DEFAULT_MAX_PARALLEL (see ``parallel``).
    max_parallel: Optional[int] = None

    @property
    def parallel(self) -> int:
        """How many steps (matrix instances) of one run may run at once."""
        return self.max_parallel or DEFAULT_MAX_PARALLEL

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "title": self.title, "description": self.description,
                "max_parallel": self.max_parallel,
                "params": [p.to_dict() for p in self.params], "steps": [s.to_dict() for s in self.steps],
                "warnings": list(self.warnings)}


def default_needs(steps: Sequence[Any], index: int) -> List[str]:
    """What step ``index`` (a Step or a run record's step) depends on when it does not say: the step before it."""
    if index <= 0:
        return []
    before = steps[index - 1]
    return [str(before["id"] if isinstance(before, Mapping) else before.id)]


# --------------------------------------------------------------------------- #
# Parsing
# --------------------------------------------------------------------------- #
def _refs(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield from _REF_RE.findall(value)
    elif isinstance(value, Mapping):
        for item in value.values():
            yield from _refs(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            yield from _refs(item)


def _coerce(param: Param, value: Any) -> Any:
    """``value`` as ``param``'s type; raises ValueError with a readable reason."""
    # float()/int() reasons ("invalid literal for int() with base 10") are
    # shown to users in the start dialog, so they are replaced.
    if param.type == "float":
        try:
            if isinstance(value, bool):
                raise ValueError
            return float(value)
        except (TypeError, ValueError):
            raise ValueError(f"expected a number, got {value!r}") from None
    if param.type == "int":
        try:
            if isinstance(value, bool) or (isinstance(value, float) and not value.is_integer()):
                raise ValueError
            return int(value)
        except (TypeError, ValueError):
            raise ValueError(f"expected a whole number, got {value!r}") from None
    if param.type == "bool":
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in ("true", "1", "yes", "on"):
            return True
        if text in ("false", "0", "no", "off"):
            return False
        raise ValueError("expected true or false")
    text = str(value)
    if param.type == "choice" and text not in param.choices:
        raise ValueError(f"expected one of {', '.join(param.choices)}")
    return text


def _parse_param(raw: Any, index: int, problems: List[str], warnings: List[str]) -> Optional[Param]:
    where = f"params[{index}]"
    if not isinstance(raw, Mapping):
        problems.append(f"{where} must be a table")
        return None
    param_id = str(raw.get("id") or "")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", param_id):
        problems.append(f"{where}.id must be a name of letters, digits and _ (got {param_id!r})")
        return None
    param_type = str(raw.get("type") or "string")
    if param_type not in PARAM_TYPES:
        problems.append(f"param {param_id}: type must be one of {', '.join(PARAM_TYPES)}")
        return None
    choices = [str(c) for c in raw.get("choices") or []]
    if param_type == "choice" and not choices:
        problems.append(f"param {param_id}: a choice param needs choices")
    param = Param(id=param_id, type=param_type, label=raw.get("label"), unit=raw.get("unit"),
                  choices=choices, description=raw.get("description"))
    if raw.get("default") is not None:
        try:
            param.default = _coerce(param, raw["default"])
        except (TypeError, ValueError) as exc:
            problems.append(f"param {param_id}: default {raw['default']!r}: {exc}")
    for key in set(raw) - _PARAM_KEYS:
        warnings.append(f"param {param_id}: unknown key {key!r}")
    return param


def _relative_entry(entry: str) -> bool:
    path = Path(entry)
    return bool(entry) and not path.is_absolute() and ".." not in path.parts and not entry.startswith(("/", "\\"))


def _parse_needs(raw: Any, step_id: str, earlier: Sequence[str], problems: List[str],
                 warnings: List[str]) -> List[str]:
    if raw is None:
        return [earlier[-1]] if earlier else []
    if not isinstance(raw, list) or any(not isinstance(n, str) for n in raw):
        problems.append(f"step {step_id}: needs must be a list of step ids")
        return []
    needs: List[str] = []
    for name in raw:
        if name in needs:
            warnings.append(f"step {step_id}: needs {name!r} twice")
        elif name not in earlier:
            problems.append(f"step {step_id}: needs {name!r}, which is not a step written before it")
        else:
            needs.append(name)
    return needs


def _parse_matrix(raw: Any, step_id: str, problems: List[str]) -> Dict[str, List[Any]]:
    if raw is None:
        return {}
    if not isinstance(raw, Mapping) or not raw:
        problems.append(f"step {step_id}: matrix must be a table of value lists, like {{ freq_ghz = [28, 39] }}")
        return {}
    matrix: Dict[str, List[Any]] = {}
    for key, values in raw.items():
        key = str(key)
        if not _NAME_RE.fullmatch(key):
            problems.append(f"step {step_id}: matrix key {key!r} must be a name of letters, digits and _")
        elif not isinstance(values, list) or not values \
                or any(isinstance(v, (Mapping, list)) or v is None for v in values):
            problems.append(f"step {step_id}: matrix.{key} must be a non-empty list of numbers, strings or booleans")
        else:
            matrix[key] = list(values)
    count = 1
    for values in matrix.values():
        count *= len(values)
    if count > MATRIX_LIMIT:
        problems.append(f"step {step_id}: matrix makes {count} instances; at most {MATRIX_LIMIT}")
    return matrix


def _parse_step(raw: Any, index: int, taken: set, problems: List[str], warnings: List[str],
                earlier: Sequence[str] = ()) -> Optional[Step]:
    where = f"steps[{index}]"
    if not isinstance(raw, Mapping):
        problems.append(f"{where} must be a table")
        return None
    kind = str(raw.get("kind") or "")
    if kind not in STEP_KINDS:
        problems.append(f"{where}.kind must be one of {', '.join(STEP_KINDS)} (got {kind!r})")
        return None
    step_id = str(raw.get("id") or f"step-{index + 1}")
    if not _ID_RE.fullmatch(step_id):
        problems.append(f"{where}.id must use a-z, 0-9, _ and - (got {step_id!r})")
    elif step_id in taken:
        problems.append(f"{where}.id {step_id!r} is used twice")
    taken.add(step_id)
    step = Step(id=step_id, kind=kind, title=raw.get("title") or None,
                needs=_parse_needs(raw.get("needs"), step_id, earlier, problems, warnings),
                matrix=_parse_matrix(raw.get("matrix"), step_id, problems))
    if kind == "script":
        entry = str(raw.get("entry") or "")
        if not _relative_entry(entry):
            problems.append(f"step {step_id}: entry must be a path inside the Project (got {entry!r})")
        step.entry = entry.replace("\\", "/")
        args = raw.get("args") or []
        if not isinstance(args, list) or any(isinstance(a, (Mapping, list)) for a in args):
            problems.append(f"step {step_id}: args must be a list of strings")
        else:
            step.args = [str(a).lower() if isinstance(a, bool) else str(a) for a in args]
        if raw.get("timeout") is not None:
            try:
                step.timeout = float(raw["timeout"])
                if step.timeout <= 0:
                    raise ValueError
            except (TypeError, ValueError):
                problems.append(f"step {step_id}: timeout must be a positive number of seconds")
    elif kind == "solve":
        step.solver = str(raw.get("solver") or "")
        if not step.solver:
            problems.append(f"step {step_id}: a solve step needs solver")
        step.scene = raw.get("scene") or None
        config = raw.get("config") or {}
        if not isinstance(config, Mapping):
            problems.append(f"step {step_id}: config must be a table")
        else:
            step.config = _plain(config)
    elif kind == "study":
        step.study = str(raw.get("study") or "")
        if not step.study:
            problems.append(f"step {step_id}: a study step needs study")
        args = raw.get("args") or {}
        if not isinstance(args, Mapping):
            problems.append(f"step {step_id}: args of a study step must be a table")
        else:
            step.study_args = _plain(args)
    else:
        step.prompt = str(raw.get("prompt") or "")
        if not step.prompt.strip():
            problems.append(f"step {step_id}: an agent step needs prompt")
        step.profile = str(raw.get("profile") or "readonly")
        if step.profile not in AGENT_PROFILES:
            problems.append(f"step {step_id}: profile must be one of {', '.join(AGENT_PROFILES)}")
    for key in set(raw) - _STEP_KEYS[kind]:
        warnings.append(f"step {step_id}: unknown key {key!r}")
    return step


def _plain(value: Any) -> Any:
    """tomlkit containers as plain dict / list / scalars."""
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if hasattr(value, "unwrap"):
        return value.unwrap()
    return value


def parse_workflow(data: Mapping[str, Any], workflow_id: str, *, path: Optional[Path] = None) -> Workflow:
    """Validate a Workflow's data (a parsed file or a proposal); raises WorkflowError."""
    data = _plain(data)
    problems: List[str] = []
    warnings: List[str] = []
    if not isinstance(data, Mapping):
        raise WorkflowError(["a Workflow must be a table"])
    schema = data.get("schema", SCHEMA_VERSION)
    if not isinstance(schema, int) or schema < 1:
        problems.append("schema must be a positive whole number")
    elif schema > SCHEMA_VERSION:
        problems.append(f"schema {schema} is newer than this version supports ({SCHEMA_VERSION}); update WiTwin")
    params: List[Param] = []
    raw_params = data.get("params") or []
    if not isinstance(raw_params, list):
        problems.append("params must be a list of tables ([[params]])")
        raw_params = []
    for index, raw in enumerate(raw_params):
        param = _parse_param(raw, index, problems, warnings)
        if param is None:
            continue
        if any(p.id == param.id for p in params):
            problems.append(f"param {param.id} is declared twice")
        params.append(param)
    steps: List[Step] = []
    raw_steps = data.get("steps") or []
    if not isinstance(raw_steps, list) or not raw_steps:
        problems.append("a Workflow needs at least one step ([[steps]])")
        raw_steps = raw_steps if isinstance(raw_steps, list) else []
    taken: set = set()
    for index, raw in enumerate(raw_steps):
        step = _parse_step(raw, index, taken, problems, warnings, [s.id for s in steps])
        if step is not None:
            steps.append(step)
    known = {p.id for p in params}
    for step in steps:
        for name in sorted(set(_refs([step.entry, step.args, step.config, step.prompt, step.scene]))):
            if name.startswith(MATRIX_REF):
                if name[len(MATRIX_REF):] not in step.matrix:
                    problems.append(f"step {step.id}: ${{{name}}} names no key of its matrix")
            elif name not in known:
                problems.append(f"step {step.id}: ${{{name}}} names no param")
    max_parallel = data.get("max_parallel")
    if max_parallel is not None and (isinstance(max_parallel, bool) or not isinstance(max_parallel, int)
                                     or not 1 <= max_parallel <= MAX_PARALLEL_LIMIT):
        problems.append(f"max_parallel must be a whole number from 1 to {MAX_PARALLEL_LIMIT}")
    for key in set(data) - _TOP_KEYS:
        warnings.append(f"unknown key {key!r}")
    if problems:
        raise WorkflowError(problems)
    return Workflow(id=workflow_id, title=str(data.get("title") or workflow_id),
                    description=data.get("description") or None, params=params, steps=steps,
                    path=path, warnings=warnings, max_parallel=max_parallel)


def workflows_dir(root: Path) -> Path:
    return Path(root) / FOLDER


def workflow_path(root: Path, workflow_id: str) -> Path:
    if not _ID_RE.fullmatch(workflow_id or ""):
        raise WorkflowError([f"not a Workflow id: {workflow_id!r}"])
    return workflows_dir(root) / f"{workflow_id}{SUFFIX}"


def load_workflow(path: Path) -> Workflow:
    path = Path(path)
    try:
        data = tomlkit.parse(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise WorkflowError([f"cannot read {path.name}: {exc}"]) from exc
    except Exception as exc:  # noqa: BLE001 - tomlkit raises its own parse errors
        raise WorkflowError([f"{path.name} is not valid TOML: {exc}"]) from exc
    return parse_workflow(data, path.stem, path=path)


def find_workflow(root: Path, workflow_id: str) -> Workflow:
    path = workflow_path(root, workflow_id)
    if not path.is_file():
        raise WorkflowError([f"no Workflow {workflow_id!r} in {FOLDER}/"])
    return load_workflow(path)


def list_workflows(root: Path) -> Tuple[List[Workflow], List[Dict[str, Any]]]:
    """Every ``tasks/*.toml``, sorted by id, and ``{id, path, problems}`` for those that fail to load."""
    folder = workflows_dir(root)
    workflows: List[Workflow] = []
    broken: List[Dict[str, Any]] = []
    for path in sorted(folder.glob(f"*{SUFFIX}")) if folder.is_dir() else []:
        try:
            workflows.append(load_workflow(path))
        except WorkflowError as exc:
            broken.append({"id": path.stem, "path": f"{FOLDER}/{path.name}", "problems": exc.problems})
    return workflows, broken


# --------------------------------------------------------------------------- #
# Values and rendering
# --------------------------------------------------------------------------- #
def resolve_values(workflow: Workflow, values: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    """Every param's value: the given one coerced to its type, else the default. Raises WorkflowError."""
    values = dict(values or {})
    problems: List[str] = []
    resolved: Dict[str, Any] = {}
    for param in workflow.params:
        raw = values.pop(param.id, None)
        if raw is None or raw == "":
            if param.default is None:
                problems.append(f"{param.id} needs a value")
            else:
                resolved[param.id] = param.default
            continue
        try:
            resolved[param.id] = _coerce(param, raw)
        except (TypeError, ValueError) as exc:
            problems.append(f"{param.id}: {exc}")
    for name in sorted(values):
        problems.append(f"{name} is not a param of {workflow.id}")
    if problems:
        raise WorkflowError(problems)
    return resolved


def _text(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float) and value.is_integer():
        return repr(value)
    return str(value)


def _fill(value: Any, values: Mapping[str, Any], *, typed: bool) -> Any:
    """``value`` with each ``${name}`` found in ``values`` replaced; other references stay as written.

    Params are filled first and ``${matrix.key}`` per instance later
    (``run_units``), so a reference ``values`` lacks waits for that pass.
    """
    if isinstance(value, str):
        whole = _REF_RE.fullmatch(value)
        if typed and whole and whole.group(1) in values:
            return values[whole.group(1)]
        return _REF_RE.sub(lambda m: _text(values[m.group(1)]) if m.group(1) in values else m.group(0), value)
    if isinstance(value, Mapping):
        return {k: _fill(v, values, typed=typed) for k, v in value.items()}
    if isinstance(value, list):
        return [_fill(v, values, typed=typed) for v in value]
    return value


def _render(step: Step, values: Mapping[str, Any]) -> Step:
    return Step(
        id=step.id, kind=step.kind, title=step.title,
        entry=_fill(step.entry, values, typed=False), args=_fill(step.args, values, typed=False),
        timeout=step.timeout, solver=step.solver, scene=_fill(step.scene, values, typed=False),
        config=_fill(step.config, values, typed=True), prompt=_fill(step.prompt, values, typed=False),
        profile=step.profile, study=_fill(step.study, values, typed=False),
        study_args=_fill(step.study_args, values, typed=True), needs=list(step.needs), matrix={k: list(v) for k, v in step.matrix.items()},
    )


def render_steps(workflow: Workflow, values: Mapping[str, Any]) -> List[Step]:
    """The steps with ``${param}`` replaced by ``values`` (from ``resolve_values``).

    ``${matrix.key}`` stays as written; ``run_units`` fills it per instance.
    """
    return [_render(step, values) for step in workflow.steps]


def matrix_instances(matrix: Mapping[str, Sequence[Any]]) -> List[Dict[str, Any]]:
    """Every combination of a matrix's values, in key order; ``[]`` without a matrix."""
    if not matrix:
        return []
    keys = list(matrix)
    return [dict(zip(keys, combo)) for combo in itertools.product(*(matrix[k] for k in keys))]


def instance_key(values: Mapping[str, Any]) -> str:
    """``freq_ghz=28,mode=te``: names an instance inside its step."""
    return ",".join(f"{k}={_text(v)}" for k, v in values.items())


def unit_key(step_id: str, instance: Optional[Mapping[str, Any]] = None) -> str:
    """The id of one thing a run executes: the step id, or ``step[instance key]`` for a matrix instance."""
    return f"{step_id}[{instance_key(instance)}]" if instance else step_id


def run_units(workflow: Workflow, values: Mapping[str, Any]) -> Dict[str, Step]:
    """Unit key -> the step to execute, every ``${...}`` filled; a matrix step gives one per instance."""
    units: Dict[str, Step] = {}
    for step in render_steps(workflow, values):
        instances = matrix_instances(step.matrix)
        if not instances:
            units[step.id] = step
            continue
        for instance in instances:
            filled = {f"{MATRIX_REF}{k}": v for k, v in instance.items()}
            units[unit_key(step.id, instance)] = _render(step, filled)
    return units


# --------------------------------------------------------------------------- #
# Writing
# --------------------------------------------------------------------------- #
def dumps(workflow: Workflow) -> str:
    """TOML text for a Workflow, in the key order of the format above."""
    defaults = [default_needs(workflow.steps, i) for i in range(len(workflow.steps))]
    uses_graph = workflow.max_parallel is not None or any(
        step.matrix or step.needs != defaults[i] for i, step in enumerate(workflow.steps))
    doc = tomlkit.document()
    doc.add("schema", SCHEMA_VERSION if uses_graph else 1)
    doc.add("title", workflow.title)
    if workflow.description:
        doc.add("description", workflow.description)
    if workflow.max_parallel is not None:
        doc.add("max_parallel", workflow.max_parallel)
    if workflow.params:
        params = tomlkit.aot()
        for param in workflow.params:
            table = tomlkit.table()
            table.add("id", param.id)
            table.add("type", param.type)
            for key in ("label", "default", "unit", "description"):
                value = getattr(param, key)
                if value is not None:
                    table.add(key, value)
            if param.choices:
                table.add("choices", list(param.choices))
            params.append(table)
        doc.add("params", params)
    steps = tomlkit.aot()
    for index, step in enumerate(workflow.steps):
        table = tomlkit.table()
        table.add("id", step.id)
        if step.title:
            table.add("title", step.title)
        table.add("kind", step.kind)
        if step.needs != defaults[index]:
            table.add("needs", list(step.needs))
        if step.matrix:
            matrix = tomlkit.inline_table()
            matrix.update({k: list(v) for k, v in step.matrix.items()})
            table.add("matrix", matrix)
        if step.kind == "script":
            table.add("entry", step.entry)
            if step.args:
                table.add("args", list(step.args))
            if step.timeout is not None:
                table.add("timeout", step.timeout)
        elif step.kind == "solve":
            table.add("solver", step.solver)
            if step.scene:
                table.add("scene", step.scene)
            if step.config:
                table.add("config", step.config)
        elif step.kind == "study":
            table.add("study", step.study)
            if step.study_args:
                args = tomlkit.inline_table()
                args.update(step.study_args)
                table.add("args", args)
        else:
            table.add("prompt", step.prompt)
            table.add("profile", step.profile)
        steps.append(table)
    doc.add("steps", steps)
    return tomlkit.dumps(doc)


def save_workflow(root: Path, data: Mapping[str, Any], *, workflow_id: Optional[str] = None) -> Workflow:
    """Write a new ``tasks/<id>.toml`` from ``data``; never overwrites a file.

    ``workflow_id`` defaults to a slug of the title; a taken id gets ``_2``,
    ``_3`` ... Raises WorkflowError when ``data`` is not a valid Workflow.
    """
    folder = workflows_dir(root)
    taken = {p.stem for p in folder.glob(f"*{SUFFIX}")} if folder.is_dir() else set()
    desired = workflow_id or slugify(str(data.get("title") or ""), fallback="workflow")
    new_id = unique_slug(desired, taken, fallback="workflow")
    workflow = parse_workflow(data, new_id)
    path = workflow_path(root, new_id)
    folder.mkdir(parents=True, exist_ok=True)
    with open(path, "x", encoding="utf-8", newline="\n") as handle:
        handle.write(dumps(workflow))
    workflow.path = path
    return workflow


def delete_workflow(root: Path, workflow_id: str) -> bool:
    path = workflow_path(root, workflow_id)
    if not path.is_file():
        return False
    path.unlink()
    return True


# --------------------------------------------------------------------------- #
# Run history
# --------------------------------------------------------------------------- #
def history_dir(root: Path) -> Path:
    return Path(root).joinpath(*HISTORY_PARTS)


def new_run_id() -> str:
    return "wfrun_" + "".join(secrets.choice(_RUN_ID_ALPHABET) for _ in range(6))


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _blank_progress() -> Dict[str, Any]:
    return {"status": "pending", "run_id": None, "session_id": None, "result_ids": [], "error": None,
            "started_at": None, "ended_at": None}


def new_run_record(workflow: Workflow, values: Mapping[str, Any], *, started_by: str,
                   run_id: Optional[str] = None) -> Dict[str, Any]:
    """A Workflow run record with every step pending (``status`` running).

    Each step lists its ``needs``; a matrix step also lists its ``instances``
    (``key``, ``label``, ``values`` and the same progress fields as a step).
    """
    steps = []
    for step in workflow.steps:
        entry = {"id": step.id, "kind": step.kind, "label": step.label, "needs": list(step.needs),
                 **_blank_progress()}
        instances = matrix_instances(step.matrix)
        if instances:
            entry["instances"] = [{"key": instance_key(v), "label": ", ".join(_text(x) for x in v.values()),
                                   "values": dict(v), **_blank_progress()} for v in instances]
        steps.append(entry)
    return {
        "id": run_id or new_run_id(),
        "workflow_id": workflow.id,
        "workflow_title": workflow.title,
        "params": dict(values),
        "status": "running",
        "started_at": now_iso(),
        "ended_at": None,
        "started_by": started_by,
        "error": None,
        "steps": steps,
    }


def write_run_record(root: Path, record: Mapping[str, Any]) -> Path:
    """Write ``record`` atomically and drop the oldest records past ``HISTORY_KEEP``."""
    folder = history_dir(root)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{record['id']}.json"
    temp = path.with_suffix(".json.tmp")
    temp.write_text(json.dumps(record, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    _replace(temp, path)
    _prune(folder)
    return path


def _replace(temp: Path, path: Path, attempts: int = 20) -> None:
    """``os.replace`` that waits out a reader on Windows.

    Windows refuses to replace a file another handle has open (WinError 5),
    and Studio reads these records while a run rewrites them on every step
    change. A read lasts milliseconds, so retrying for up to ~1 s is enough.
    """
    for attempt in range(attempts):
        try:
            os.replace(temp, path)
            return
        except PermissionError:
            if attempt == attempts - 1:
                raise
            time.sleep(0.05)


def _prune(folder: Path) -> None:
    files = sorted(folder.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    for stale in files[HISTORY_KEEP:]:
        stale.unlink(missing_ok=True)


def read_run_record(root: Path, run_id: str) -> Optional[Dict[str, Any]]:
    if not re.fullmatch(r"wfrun_[0-9a-z]+", run_id or ""):
        return None
    path = history_dir(root) / f"{run_id}.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def read_run_records(root: Path, limit: int = 200) -> List[Dict[str, Any]]:
    """The newest ``limit`` Workflow run records, newest start first; unreadable files are skipped."""
    folder = history_dir(root)
    records = []
    for path in folder.glob("*.json") if folder.is_dir() else []:
        try:
            records.append(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            continue
    records.sort(key=lambda r: str(r.get("started_at") or ""), reverse=True)
    return records[:max(1, int(limit))]


# --------------------------------------------------------------------------- #
# Scheduling
# --------------------------------------------------------------------------- #
LIVE = frozenset({"running", "waiting"})


class Schedule:
    """Which units of a Workflow run may start now, and what a unit's end does to the rest.

    A unit is a step, or one instance of a matrix step (``unit_key``). The
    schedule changes the run record in place and does no IO: after each call
    the caller writes the record and publishes it. The ProjectServer and
    ``run_workflow`` both drive their runs through it, so the two agree on
    what runs next and what a failure skips.

    Records written before ``needs`` existed have none; their steps depend on
    the step before, which is how they ran.
    """

    def __init__(self, record: Dict[str, Any], max_parallel: int = DEFAULT_MAX_PARALLEL) -> None:
        self.record = record
        self.max_parallel = max(1, int(max_parallel))
        self.cancelled = False
        steps = record["steps"]
        self._steps: List[Dict[str, Any]] = steps
        self._index = {str(s["id"]): i for i, s in enumerate(steps)}
        self._needs = [list(s["needs"]) if isinstance(s.get("needs"), list) else default_needs(steps, i)
                       for i, s in enumerate(steps)]
        # Unit key -> (step index, instance index or None).
        self._units: Dict[str, Tuple[int, Optional[int]]] = {}
        for i, step in enumerate(steps):
            instances = step.get("instances") or []
            if instances:
                for j, instance in enumerate(instances):
                    self._units[f"{step['id']}[{instance['key']}]"] = (i, j)
            else:
                self._units[str(step["id"])] = (i, None)

    # ---- reading ---------------------------------------------------------------

    @property
    def keys(self) -> List[str]:
        return list(self._units)

    @property
    def done(self) -> bool:
        return self.record["status"] != "running"

    def entry(self, key: str) -> Dict[str, Any]:
        """The record entry a unit's progress goes in: the step, or its instance."""
        i, j = self._units[key]
        step = self._steps[i]
        return step if j is None else step["instances"][j]

    def step_entry(self, key: str) -> Dict[str, Any]:
        return self._steps[self._units[key][0]]

    def instance(self, key: str) -> Optional[Dict[str, Any]]:
        """The matrix instance entry of ``key``, or None for a plain step."""
        i, j = self._units[key]
        return None if j is None else self._steps[i]["instances"][j]

    def needs(self, step_id: str) -> List[str]:
        return list(self._needs[self._index[step_id]])

    def upstream(self, step_id: str) -> List[str]:
        """Every step ``step_id`` depends on, directly or not, in file order."""
        found: set = set()
        stack = list(self._needs[self._index[step_id]])
        while stack:
            name = stack.pop()
            if name not in found and name in self._index:
                found.add(name)
                stack.extend(self._needs[self._index[name]])
        return [str(s["id"]) for s in self._steps if s["id"] in found]

    def active(self) -> List[str]:
        """Units that started and have not ended."""
        return [key for key in self._units if self.entry(key)["status"] in LIVE]

    def ready(self) -> List[str]:
        """Pending units whose steps' needs all succeeded, in file order, up to the free slots."""
        if self.cancelled or self.done:
            return []
        free = self.max_parallel - len(self.active())
        found: List[str] = []
        for key, (i, _) in self._units.items():
            if free <= 0:
                break
            if self.entry(key)["status"] != "pending":
                continue
            if all(self._steps[self._index[n]]["status"] == "succeeded" for n in self._needs[i]
                   if n in self._index):
                found.append(key)
                free -= 1
        return found

    # ---- changing --------------------------------------------------------------

    def start(self, key: str) -> None:
        entry = self.entry(key)
        entry.update(status="running", started_at=now_iso())
        step = self.step_entry(key)
        if step is not entry and step["status"] == "pending":
            step.update(status="running", started_at=entry["started_at"])

    def set_state(self, key: str, state: str) -> bool:
        """Move a started unit between ``running`` and ``waiting``; False when nothing changed."""
        entry = self.entry(key)
        if entry["status"] not in LIVE or entry["status"] == state:
            return False
        entry["status"] = state
        step = self.step_entry(key)
        if step is not entry:
            step["status"] = self._live_state(step)
        return True

    def finish(self, key: str, status: str, error: Optional[str] = None) -> None:
        """End a unit; a step that did not succeed skips its downstream steps."""
        entry = self.entry(key)
        entry.update(status=status, error=error, ended_at=now_iso())
        self._finalize(self._units[key][0])
        self._settle()

    def cancel(self) -> List[str]:
        """Stop the run: pending units are skipped; returns the started ones the caller must stop.

        Each of those ends with ``finish(key, "cancelled")``; the run is
        ``cancelled`` once the last one ends (at once when none runs).
        """
        self.cancelled = True
        self._skip_pending()
        self._settle()
        return self.active()

    def interrupt(self, error: str) -> None:
        """Mark a run a stopped process left behind as failed: started units fail, the rest are skipped."""
        for key in self.active():
            self.entry(key).update(status="failed", error=error, ended_at=now_iso())
        self._skip_pending()
        for i in range(len(self._steps)):
            self._finalize(i)
        if self.record["status"] == "running":
            self.record.update(status="failed", error=error, ended_at=now_iso())

    # ---- internals -------------------------------------------------------------

    @staticmethod
    def _live_state(step: Dict[str, Any]) -> str:
        states = {instance["status"] for instance in step["instances"]}
        return "waiting" if "waiting" in states and "running" not in states else "running"

    def _finalize(self, i: int) -> None:
        """Settle step ``i`` from its instances once all ended, then skip what depended on a failure."""
        step = self._steps[i]
        instances = step.get("instances") or []
        if instances:
            step["result_ids"] = [rid for instance in instances for rid in instance.get("result_ids") or []]
            if any(instance["status"] not in TERMINAL for instance in instances):
                if step["status"] not in TERMINAL:
                    step["status"] = self._live_state(step)
                return
            if step["status"] in TERMINAL:
                return
            bad = [instance for instance in instances if instance["status"] != "succeeded"]
            if not bad:
                step.update(status="succeeded", error=None)
            elif any(instance["status"] == "failed" for instance in bad):
                first = next(instance for instance in bad if instance["status"] == "failed")
                step.update(status="failed", error=f"{len(bad)} of {len(instances)} instances did not succeed "
                                                   f"({first['key']}: {first.get('error') or 'failed'})")
            else:
                step.update(status="cancelled", error="cancelled")
            step["ended_at"] = now_iso()
        if step["status"] in TERMINAL and step["status"] != "succeeded":
            self._skip_downstream(str(step["id"]))

    def _skip_downstream(self, step_id: str) -> None:
        blocked = {step_id}
        # needs point backwards, so one pass in file order reaches every descendant.
        for i, step in enumerate(self._steps):
            if any(n in blocked for n in self._needs[i]):
                blocked.add(str(step["id"]))
                self._skip_step(step)

    @staticmethod
    def _skip_step(step: Dict[str, Any]) -> None:
        for instance in step.get("instances") or []:
            if instance["status"] == "pending":
                instance["status"] = "skipped"
        if step["status"] == "pending":
            step["status"] = "skipped"

    def _skip_pending(self) -> None:
        for i, step in enumerate(self._steps):
            self._skip_step(step)
            if step.get("instances"):
                self._finalize(i)

    def _settle(self) -> None:
        if self.done or any(step["status"] not in TERMINAL for step in self._steps):
            return
        if all(step["status"] == "succeeded" for step in self._steps):
            status, error = "succeeded", None
        elif self.cancelled:
            status, error = "cancelled", "cancelled"
        else:
            status = "failed" if any(step["status"] == "failed" for step in self._steps) else "cancelled"
            first = next(step for step in self._steps if step["status"] in ("failed", "cancelled"))
            error = first.get("error") or status
        self.record.update(status=status, error=error, ended_at=now_iso())


def finish_step(record: Dict[str, Any], index: int, status: str, *, error: Optional[str] = None) -> None:
    """End step ``index`` of a run without matrix steps; ``Schedule.finish`` for one step."""
    Schedule(record).finish(str(record["steps"][index]["id"]), status, error)


# --------------------------------------------------------------------------- #
# Headless runner
# --------------------------------------------------------------------------- #
EventCallback = Callable[[Dict[str, Any]], None]


def _run_script(root: Path, step: Step) -> Optional[str]:
    """Run a script step like ``witwin run``; returns an error line, or None on success."""
    from ._environment import project_python

    script = (root / str(step.entry)).resolve()
    if not script.is_file() or root.resolve() not in script.parents:
        return f"script not found: {step.entry}"
    env = dict(os.environ)
    paths = [str(script.parent), str(root), str(root / "src")]
    env["PYTHONPATH"] = os.pathsep.join(paths + ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
    try:
        code = subprocess.run([project_python(root), str(script), *step.args], cwd=root, env=env,
                              timeout=step.timeout).returncode
    except subprocess.TimeoutExpired:
        return f"stopped after {step.timeout:g} s"
    except OSError as exc:
        return str(exc)
    return None if code == 0 else f"exited with code {code}"


def _run_study(project: Any, root: Path, step: Step) -> Tuple[Optional[str], Optional[str], List[str]]:
    """Run a study step's Study to its end; returns like ``_run_unit``.

    A train Study runs its script as Studio would (``studies._train``), with
    no ``WITWIN_RUN_ID``, so ``witwin.studio.tracking`` makes its own Run
    folder. Other Studies run ``python -m witwin.studio.studies`` with
    ``--out .witwin/runs/<run id>``. Headless runs have no GPU queue.
    """
    from ._environment import project_python
    from ._runs import run_dir
    from .studies import StudyError, StudyKind
    from .studies._train import cli_args, train_values
    from .tracking import STUDY_ARGS_ENV

    try:
        study = project.studies.get(str(step.study))
    except StudyError as exc:
        return f"{exc.code}: {exc.message}", None, []
    env = dict(os.environ)
    env.pop("WITWIN_RUN_ID", None)
    if study.kind is StudyKind.TRAIN:
        script = (root / str(study.script)).resolve()
        if not script.is_file() or root.resolve() not in script.parents:
            return f"script_not_found: {study.script}", None, []
        values = train_values(study, step.study_args)
        env[STUDY_ARGS_ENV] = json.dumps(values)
        paths = [str(script.parent), str(root), str(root / "src")]
        env["PYTHONPATH"] = os.pathsep.join(paths + ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
        command = [project_python(root), str(script), *cli_args(values)]
        run_id = None
    else:
        if step.study_args:
            return "invalid_study: only a train Study takes args", None, []
        run_id = "run_" + "".join(secrets.choice(_RUN_ID_ALPHABET) for _ in range(12))
        command = [project_python(root), "-m", "witwin.studio.studies", "--project", str(root),
                   "--study", study.id, "--out", str(run_dir(root, run_id))]
    try:
        code = subprocess.run(command, cwd=root, env=env).returncode
    except OSError as exc:
        return str(exc), run_id, []
    return (None if code == 0 else f"exited with code {code}"), run_id, []


def _run_unit(project: Any, root: Path, step: Step, plugin_paths: Sequence[Path]) -> Tuple[Optional[str], Optional[str], List[str]]:
    """Execute one unit in a worker thread; returns (error or None, Run id, Result ids)."""
    from .solver.client import SolverError

    if step.kind == "script":
        return _run_script(root, step), None, []
    if step.kind == "study":
        return _run_study(project, root, step)
    try:
        run = project.solve(str(step.solver), scene=step.scene, config=step.config, attach=False,
                            plugin_paths=plugin_paths)
    except SolverError as exc:
        return f"{exc.code}: {exc.message}", None, []
    try:
        run.result()
    except SolverError as exc:
        return f"{exc.code}: {exc.message}", run.id, []
    finally:
        run.close()
    return None, run.id, [str(run.result_version)] if run.result_version is not None else []


def run_workflow(
    project: Any,
    workflow_id: str,
    values: Optional[Mapping[str, Any]] = None,
    *,
    on_event: Optional[EventCallback] = None,
    plugin_paths: Sequence[Path] = (),
) -> Dict[str, Any]:
    """Run a Workflow of ``project`` (a ``witwin.studio.Project``) here.

    Independent steps run at once, up to the Workflow's ``max_parallel``, in
    worker threads; only this thread changes the record. Returns the finished
    record, which is also written to the run history. ``on_event(record)`` is
    called after every change. Raises WorkflowError when the file or
    ``values`` are not usable; a failing step does not raise.
    """
    root = Path(project.root)
    workflow = find_workflow(root, workflow_id)
    resolved = resolve_values(workflow, values)
    record = new_run_record(workflow, resolved, started_by="cli")
    units = run_units(workflow, resolved)
    schedule = Schedule(record, workflow.parallel)

    def changed() -> None:
        write_run_record(root, record)
        if on_event is not None:
            on_event(record)

    changed()
    running: Dict[Any, str] = {}
    with ThreadPoolExecutor(max_workers=workflow.parallel) as pool:
        while not schedule.done:
            for key in schedule.ready():
                schedule.start(key)
                if units[key].kind == "agent":
                    schedule.finish(key, "failed", "needs_studio: an agent step runs only in a running Studio")
                else:
                    running[pool.submit(_run_unit, project, root, units[key], plugin_paths)] = key
                changed()
            if not running:
                break
            finished, _ = wait(list(running), return_when=FIRST_COMPLETED)
            for future in finished:
                key = running.pop(future)
                error, run_id, result_ids = future.result()
                schedule.entry(key).update(run_id=run_id, result_ids=result_ids)
                schedule.finish(key, "failed" if error else "succeeded", error)
                changed()
    return record


__all__ = [
    "AGENT_PROFILES", "DEFAULT_MAX_PARALLEL", "FOLDER", "HISTORY_KEEP", "MATRIX_LIMIT", "MAX_PARALLEL_LIMIT",
    "PARAM_TYPES", "RUN_STATUSES", "SCHEMA_VERSION", "STEP_KINDS", "STEP_STATUSES", "TERMINAL", "Param",
    "Schedule", "Step", "Workflow", "WorkflowError", "default_needs", "delete_workflow", "dumps",
    "find_workflow", "finish_step", "history_dir", "instance_key", "list_workflows", "load_workflow",
    "matrix_instances", "new_run_id", "new_run_record", "now_iso", "parse_workflow", "read_run_record",
    "read_run_records", "render_steps", "resolve_values", "run_units", "run_workflow", "save_workflow",
    "unit_key", "workflow_path", "workflows_dir", "write_run_record",
]
