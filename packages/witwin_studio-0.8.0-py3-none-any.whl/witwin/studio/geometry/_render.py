"""Headless contact-sheet renderer: numpy z-buffer, no GPU or OpenGL.

Used by the Agent Tools ``scene.render`` and ``geometry.render`` (the server
module ``witwin_server.tools.scene_render`` re-exports this one) and by
``ws.preview`` outside Studio. It lives in the SDK so a model file can draw
itself with ``witwin-studio`` alone; it needs numpy, and Pillow for labels.

Why not pyrender / the viewport: the ProjectServer runs on machines without a
display or GPU (cloud workstations, CI), and the Agent needs to see geometry
there too. Flat-shaded orthographic views with outlines are enough to check
shape, placement and proportions; they are not meant to match the viewport.

Pipeline per view: project world-space triangles onto an orthographic camera,
rasterize them in buckets of similar on-screen size (every triangle of a
bucket is tested against the same k x k pixel window in one numpy pass), keep
the nearest fragment per pixel, shade by face normal, then darken pixels where
the object or the depth changes (outlines). A section plane drops fragments on
its far side; surfaces seen from behind (the inside of a cut solid) get a
hatched tint so a cut reads as a cut. Pillow, when present, writes the PNG and
the labels; without it the PNG is written by hand and has no text.
"""
from __future__ import annotations

import io
import math
import struct
import zlib
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

# Camera of each named view: (direction the camera looks, screen-up). Y is up.
VIEW_CAMERAS: Dict[str, Tuple[Tuple[float, float, float], Tuple[float, float, float]]] = {
    "front": ((0.0, 0.0, -1.0), (0.0, 1.0, 0.0)),    # from +Z
    "back": ((0.0, 0.0, 1.0), (0.0, 1.0, 0.0)),      # from -Z
    "right": ((-1.0, 0.0, 0.0), (0.0, 1.0, 0.0)),    # from +X
    "left": ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0)),      # from -X
    "top": ((0.0, -1.0, 0.0), (0.0, 0.0, -1.0)),     # from +Y, -Z at the top of the image
    "bottom": ((0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),    # from -Y
    "iso": ((-1.0, -1.0, -1.0), (0.0, 1.0, 0.0)),    # from (+1, +1, +1)
}
DEFAULT_VIEWS = ("front", "right", "top", "iso")
_AXIS_VIEWS = frozenset(VIEW_CAMERAS) - {"iso"}

_BACKGROUND = np.array([0.96, 0.96, 0.95])
_BACKFACE = np.array([0.85, 0.35, 0.30])   # inside of a cut solid
_OUTLINE = np.array([0.12, 0.12, 0.14])
_TEXT = (40, 40, 48)
_AXIS_COLORS = {"X": (210, 50, 50), "Y": (40, 160, 60), "Z": (50, 90, 220)}

# Fragment budget per numpy pass (triangles x window pixels).
_PASS_FRAGMENTS = 2_000_000
# Largest window rasterized in one pass; bigger triangles go one by one.
_MAX_WINDOW = 64


@dataclass
class Camera:
    name: str
    forward: np.ndarray
    right: np.ndarray
    up: np.ndarray
    center: np.ndarray
    metres_per_pixel: float
    width: int
    height: int

    def describe(self) -> Dict[str, object]:
        def r(v):
            return [round(float(x), 6) + 0.0 for x in v]

        return {
            "name": self.name,
            "look": r(self.forward),
            "screenRight": r(self.right),
            "screenUp": r(self.up),
            "center": r(self.center),
            "metresPerPixel": float(f"{self.metres_per_pixel:.6g}"),
            "widthMetres": float(f"{self.metres_per_pixel * self.width:.6g}"),
        }


@dataclass
class Section:
    point: np.ndarray
    normal: np.ndarray   # fragments with dot(p - point, normal) > 0 are removed


def camera_basis(name: str):
    look, up = VIEW_CAMERAS[name]
    forward = np.asarray(look, dtype=np.float64)
    forward /= np.linalg.norm(forward)
    up_hint = np.asarray(up, dtype=np.float64)
    right = np.cross(forward, up_hint)
    right /= np.linalg.norm(right)
    true_up = np.cross(right, forward)
    return forward, right, true_up


def fit_cameras(views: Sequence[str], lo: np.ndarray, hi: np.ndarray, size: int) -> List[Camera]:
    """One orthographic camera per view, framing the box ``lo..hi`` with a margin.

    The axis views share one scale, so the same length is the same number of
    pixels in front, right and top; the isometric view is framed on its own.
    """
    center = (lo + hi) / 2
    corners = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])

    def extent(name):
        _, right, up = camera_basis(name)
        rel = corners - center
        return max(np.ptp(rel @ right), np.ptp(rel @ up))

    shared = max([extent(n) for n in views if n in _AXIS_VIEWS] or [0.0])
    cameras = []
    for name in views:
        forward, right, up = camera_basis(name)
        span = shared if name in _AXIS_VIEWS else extent(name)
        span = max(span, 1e-6) * 1.25
        cameras.append(Camera(name, forward, right, up, center, span / size, size, size))
    return cameras


def _rasterize(camera: Camera, vertices: np.ndarray, faces: np.ndarray, section: Optional[Section],
               face_rank: Optional[np.ndarray] = None, tie: float = 0.0):
    """Nearest face per pixel: ``(face index or -1, depth)`` arrays of shape (H, W).

    Fragments whose depths differ by at most ``tie`` (metres) count as the
    same depth, and the higher ``face_rank`` wins them. Without this a copper
    sheet lying on its substrate z-fights with the substrate's face and shows
    as speckles: their depths differ only by float noise.
    """
    width, height = camera.width, camera.height
    face_buffer = np.full(width * height, -1, dtype=np.int64)
    depth_buffer = np.full(width * height, np.inf)
    rank_buffer = np.full(width * height, -np.inf)
    ranked = face_rank is not None and tie > 0
    if len(faces) == 0:
        return face_buffer.reshape(height, width), depth_buffer.reshape(height, width)

    rel = vertices - camera.center
    px = (rel @ camera.right) / camera.metres_per_pixel + width / 2
    py = height / 2 - (rel @ camera.up) / camera.metres_per_pixel
    depth = rel @ camera.forward

    tri_x = px[faces]
    tri_y = py[faces]
    tri_d = depth[faces]
    min_x = np.floor(tri_x.min(axis=1)).astype(np.int64)
    min_y = np.floor(tri_y.min(axis=1)).astype(np.int64)
    max_x = np.floor(tri_x.max(axis=1)).astype(np.int64)
    max_y = np.floor(tri_y.max(axis=1)).astype(np.int64)
    area = ((tri_x[:, 1] - tri_x[:, 0]) * (tri_y[:, 2] - tri_y[:, 0])
            - (tri_x[:, 2] - tri_x[:, 0]) * (tri_y[:, 1] - tri_y[:, 0]))
    on_screen = (max_x >= 0) & (max_y >= 0) & (min_x < width) & (min_y < height) & (np.abs(area) > 1e-12)
    window = np.maximum(max_x - min_x, max_y - min_y) + 1

    def first_per_pixel(pixel):
        first = np.ones(len(pixel), dtype=bool)
        first[1:] = pixel[1:] != pixel[:-1]
        return first

    def resolve(pixel, frag_depth, face):
        if len(pixel) == 0:
            return
        order = np.lexsort((frag_depth, pixel))
        pixel, frag_depth, face = pixel[order], frag_depth[order], face[order]
        if not ranked:
            first = first_per_pixel(pixel)
            pixel, frag_depth, face = pixel[first], frag_depth[first], face[first]
            closer = frag_depth < depth_buffer[pixel]
            depth_buffer[pixel[closer]] = frag_depth[closer]
            face_buffer[pixel[closer]] = face[closer]
            return
        # Keep the fragments within `tie` of each pixel's nearest one, then the
        # highest rank among them (the nearer one on equal rank).
        start = first_per_pixel(pixel)
        nearest = frag_depth[start][np.cumsum(start) - 1]
        near = frag_depth <= nearest + tie
        pixel, frag_depth, face = pixel[near], frag_depth[near], face[near]
        rank = face_rank[face]
        order = np.lexsort((frag_depth, -rank, pixel))
        pixel, frag_depth, face, rank = pixel[order], frag_depth[order], face[order], rank[order]
        first = first_per_pixel(pixel)
        pixel, frag_depth, face, rank = pixel[first], frag_depth[first], face[first], rank[first]
        held_depth, held_rank = depth_buffer[pixel], rank_buffer[pixel]
        same = np.abs(frag_depth - held_depth) <= tie
        better = (rank > held_rank) | ((rank == held_rank) & (frag_depth < held_depth))
        wins = (frag_depth < held_depth - tie) | (same & better)
        depth_buffer[pixel[wins]] = frag_depth[wins]
        face_buffer[pixel[wins]] = face[wins]
        rank_buffer[pixel[wins]] = rank[wins]

    def fragments(ids: np.ndarray, k: int):
        """Fragments of triangles ``ids`` tested against a k x k window at their bbox corner."""
        offsets = np.arange(k)
        dx = np.tile(offsets, k)
        dy = np.repeat(offsets, k)
        sx = min_x[ids, None] + dx[None, :] + 0.5
        sy = min_y[ids, None] + dy[None, :] + 0.5
        x0, x1, x2 = (tri_x[ids, i, None] for i in range(3))
        y0, y1, y2 = (tri_y[ids, i, None] for i in range(3))
        a = area[ids, None]
        w0 = ((x1 - sx) * (y2 - sy) - (x2 - sx) * (y1 - sy)) / a
        w1 = ((x2 - sx) * (y0 - sy) - (x0 - sx) * (y2 - sy)) / a
        w2 = 1.0 - w0 - w1
        inside = (w0 >= -1e-9) & (w1 >= -1e-9) & (w2 >= -1e-9)
        inside &= (sx >= 0) & (sx < width) & (sy >= 0) & (sy < height)
        frag_depth = w0 * tri_d[ids, 0, None] + w1 * tri_d[ids, 1, None] + w2 * tri_d[ids, 2, None]
        if section is not None:
            tri_v = vertices[faces[ids]]  # (T, 3, 3)
            side = (tri_v - section.point) @ section.normal  # (T, 3)
            frag_side = w0 * side[:, 0, None] + w1 * side[:, 1, None] + w2 * side[:, 2, None]
            inside &= frag_side <= 0
        rows, cols = np.nonzero(inside)
        pixel = (sy[rows, cols].astype(np.int64) * width + sx[rows, cols].astype(np.int64))
        resolve(pixel, frag_depth[rows, cols], ids[rows])

    candidates = np.nonzero(on_screen)[0]
    k = 1
    remaining = candidates
    while len(remaining) and k <= _MAX_WINDOW:
        k *= 2
        bucket = remaining[window[remaining] <= k]
        remaining = remaining[window[remaining] > k]
        step = max(1, _PASS_FRAGMENTS // (k * k))
        for start in range(0, len(bucket), step):
            fragments(bucket[start:start + step], k)
    for tri in remaining:
        # Large on screen: clip its window to the image and rasterize it alone.
        x_lo, y_lo = max(min_x[tri], 0), max(min_y[tri], 0)
        x_hi, y_hi = min(max_x[tri], width - 1), min(max_y[tri], height - 1)
        if x_hi < x_lo or y_hi < y_lo:
            continue
        saved_x, saved_y = min_x[tri], min_y[tri]
        min_x[tri], min_y[tri] = x_lo, y_lo
        span = int(max(x_hi - x_lo, y_hi - y_lo) + 1)
        for oy in range(0, span, 256):
            for ox in range(0, span, 256):
                min_x[tri], min_y[tri] = x_lo + ox, y_lo + oy
                fragments(np.array([tri]), min(256, span))
        min_x[tri], min_y[tri] = saved_x, saved_y
    return face_buffer.reshape(height, width), depth_buffer.reshape(height, width)


def _shade(camera: Camera, vertices, faces, face_colors, face_object, face_buffer, depth_buffer, mpp_scale):
    height, width = face_buffer.shape
    image = np.empty((height, width, 3))
    image[:] = _BACKGROUND
    covered = face_buffer >= 0
    if not covered.any():
        return image
    tri = vertices[faces]
    normals = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    lengths = np.linalg.norm(normals, axis=1)
    normals = normals / np.where(lengths > 0, lengths, 1.0)[:, None]
    # Key light over the viewer's left shoulder, plus a fixed fill so that
    # faces at right angles to each other never get the same grey.
    key = -camera.forward + 0.6 * camera.up - 0.4 * camera.right
    key /= np.linalg.norm(key)
    fill = np.array([0.3, 0.8, 0.5])
    fill /= np.linalg.norm(fill)
    facing = normals @ -camera.forward
    light = 0.30 + 0.55 * np.abs(normals @ key) + 0.15 * np.abs(normals @ fill)

    ids = face_buffer[covered]
    colors = face_colors[ids] * light[ids, None]
    back = facing[ids] < 0
    if back.any():
        # Seen from behind: the inside of a cut or open solid. Hatch it.
        ys, xs = np.nonzero(covered)
        hatch = ((xs + ys) // 4) % 2 == 0
        tint = np.where(hatch[back, None], _BACKFACE, _BACKFACE * 0.75)
        colors[back] = tint
    image[covered] = np.clip(colors, 0, 1)

    # Outlines: where the object under the pixel changes, or the depth jumps.
    obj = np.where(covered, face_object[np.maximum(face_buffer, 0)], -1)
    depth = np.where(covered, depth_buffer, np.inf)
    edge = np.zeros_like(covered)
    jump = 6 * mpp_scale
    for axis in (0, 1):
        diff_obj = np.diff(obj, axis=axis) != 0
        with np.errstate(invalid="ignore"):  # inf - inf on the background
            d = np.diff(depth, axis=axis)
        diff_depth = np.isfinite(d) & (np.abs(d) > jump)
        mark = diff_obj | diff_depth
        if axis == 0:
            edge[1:, :] |= mark
            edge[:-1, :] |= mark
        else:
            edge[:, 1:] |= mark
            edge[:, :-1] |= mark
    image[edge] = _OUTLINE
    return image


def _thin_first(vertices, faces, face_object, lo, hi) -> Tuple[Optional[np.ndarray], float]:
    """Per-face rank for coplanar ties (the thinner object wins) and the tie tolerance in metres.

    "Thin" is the smallest extent of the object's bounding box, so a copper
    sheet (0) or a 35 um trace wins over the 1.6 mm substrate it lies on, in
    every view. The tolerance, 1e-5 of the scene diagonal, is far above
    float32 noise and far below any gap between two faces that a picture of
    this size can show.
    """
    if len(faces) == 0 or len(face_object) != len(faces):
        return None, 0.0
    objects, inverse = np.unique(face_object, return_inverse=True)
    if len(objects) < 2:
        return None, 0.0
    tri = vertices[faces]
    low = np.full((len(objects), 3), np.inf)
    high = np.full((len(objects), 3), -np.inf)
    np.minimum.at(low, inverse, tri.min(axis=1))
    np.maximum.at(high, inverse, tri.max(axis=1))
    thickness = (high - low).min(axis=1)
    diagonal = float(np.linalg.norm(np.asarray(hi, dtype=float) - np.asarray(lo, dtype=float)))
    return -thickness[inverse], 1e-5 * diagonal


def render_views(
    vertices: np.ndarray,
    faces: np.ndarray,
    face_colors: np.ndarray,
    face_object: np.ndarray,
    *,
    bounds: Tuple[np.ndarray, np.ndarray],
    views: Sequence[str] = DEFAULT_VIEWS,
    size: int = 512,
    section: Optional[Section] = None,
    overlay: bool = False,
) -> Tuple[bytes, List[Dict[str, object]]]:
    """PNG contact sheet of ``views`` (2 columns) and the camera of each cell."""
    lo, hi = bounds
    cameras = fit_cameras(views, lo, hi, size)
    images = []
    described = []
    columns = 1 if len(cameras) == 1 else 2
    face_rank, tie = _thin_first(vertices, faces, face_object, lo, hi)
    for index, camera in enumerate(cameras):
        face_buffer, depth_buffer = _rasterize(camera, vertices, faces, section, face_rank, tie)
        image = _shade(camera, vertices, faces, face_colors, face_object, face_buffer, depth_buffer,
                       camera.metres_per_pixel)
        images.append(image)
        info = camera.describe()
        info["cell"] = [index % columns, index // columns]
        described.append(info)
    rows = math.ceil(len(images) / columns)
    sheet = np.empty((rows * size, columns * size, 3))
    sheet[:] = 1.0
    for index, image in enumerate(images):
        col, row = index % columns, index // columns
        sheet[row * size:(row + 1) * size, col * size:(col + 1) * size] = image
    pixels = (sheet * 255).round().astype(np.uint8)
    return _encode(pixels, cameras, columns, size, lo, hi, section, overlay), described


# --------------------------------------------------------------------------- #
# Encoding and annotation
# --------------------------------------------------------------------------- #
def _encode(pixels, cameras, columns, size, lo, hi, section, overlay) -> bytes:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:  # Pillow is optional in the SDK: a plain PNG without labels
        return _png_bytes(pixels)
    image = Image.fromarray(pixels)  # uint8 (H, W, 3) is RGB
    draw = ImageDraw.Draw(image)
    font = _font(ImageFont, 14)
    small = _font(ImageFont, 12)
    for index, camera in enumerate(cameras):
        ox, oy = (index % columns) * size, (index // columns) * size
        title = camera.name.upper()
        if section is not None:
            title += "  (section)"
        draw.text((ox + 8, oy + 6), title, fill=_TEXT, font=font)
        _axis_triad(draw, camera, ox + 34, oy + size - 34, small)
        if overlay and camera.name in _AXIS_VIEWS:
            _dimensions(draw, camera, ox, oy, lo, hi, small)
        if index % columns:
            draw.line([(ox, oy), (ox, oy + size)], fill=(200, 200, 200))
        if index >= columns:
            draw.line([(ox, oy), (ox + size, oy)], fill=(200, 200, 200))
    buffer = io.BytesIO()
    image.save(buffer, "PNG", optimize=True)
    return buffer.getvalue()


def _font(image_font, size):
    try:
        return image_font.load_default(size=size)
    except TypeError:  # Pillow < 10.1 has one bitmap size
        return image_font.load_default()


def _axis_triad(draw, camera: Camera, cx: int, cy: int, font) -> None:
    for label, axis in (("X", (1, 0, 0)), ("Y", (0, 1, 0)), ("Z", (0, 0, 1))):
        vector = np.asarray(axis, dtype=float)
        sx, sy = float(vector @ camera.right), -float(vector @ camera.up)
        if math.hypot(sx, sy) < 0.2:
            # Pointing at or away from the viewer: a dot with the label.
            sign = "+" if float(vector @ camera.forward) < 0 else "-"
            draw.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], fill=_AXIS_COLORS[label])
            draw.text((cx + 5, cy + 2), f"{sign}{label}", fill=_AXIS_COLORS[label], font=font)
            continue
        ex, ey = cx + sx * 24, cy + sy * 24
        draw.line([(cx, cy), (ex, ey)], fill=_AXIS_COLORS[label], width=2)
        draw.text((ex + 3 * np.sign(sx), ey - 6 + 3 * np.sign(sy)), label, fill=_AXIS_COLORS[label], font=font)


def _dimensions(draw, camera: Camera, ox: int, oy: int, lo, hi, font) -> None:
    """Bounding box of the target in this view with its two in-plane sizes, in metres."""
    corners = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
    rel = corners - camera.center
    sx = (rel @ camera.right) / camera.metres_per_pixel + camera.width / 2
    sy = camera.height / 2 - (rel @ camera.up) / camera.metres_per_pixel
    x0, x1, y0, y1 = ox + sx.min(), ox + sx.max(), oy + sy.min(), oy + sy.max()
    draw.rectangle([x0, y0, x1, y1], outline=(30, 110, 200), width=1)
    horizontal = _axis_name(camera.right)
    vertical = _axis_name(camera.up)
    width_m = float((hi - lo) @ np.abs(camera.right))
    height_m = float((hi - lo) @ np.abs(camera.up))
    draw.text(((x0 + x1) / 2 - 30, y1 + 4), f"{horizontal} {_metres(width_m)}", fill=(30, 110, 200), font=font)
    draw.text((x1 + 4, (y0 + y1) / 2 - 6), f"{vertical} {_metres(height_m)}", fill=(30, 110, 200), font=font)


def _axis_name(vector: np.ndarray) -> str:
    index = int(np.argmax(np.abs(vector)))
    return "XYZ"[index]


def _metres(value: float) -> str:
    if value >= 1:
        return f"{value:.3g} m"
    if value >= 1e-3:
        return f"{value * 1e3:.3g} mm"
    return f"{value * 1e6:.3g} um"


def _png_bytes(pixels: np.ndarray) -> bytes:
    """Minimal RGB PNG writer, for an environment without Pillow."""
    height, width, _ = pixels.shape
    raw = b"".join(b"\x00" + pixels[row].tobytes() for row in range(height))

    def chunk(kind: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw, 6))
            + chunk(b"IEND", b""))


# --------------------------------------------------------------------------- #
# Lists of meshes (model bodies)
# --------------------------------------------------------------------------- #
# Body colours by GeometryBody role when the material gives none.
ROLE_COLORS = {
    "conductor": (0.85, 0.62, 0.32),
    "dielectric": (0.40, 0.66, 0.46),
    "port": (0.86, 0.26, 0.24),
    "other": (0.62, 0.64, 0.68),
}


def section_plane(axis: str, lo: np.ndarray, hi: np.ndarray, offset: Optional[float] = None,
                  keep: str = "below") -> Section:
    """A cut perpendicular to ``axis`` at ``offset`` (default the middle of ``lo..hi``)."""
    index = "xyz".index(axis)
    if offset is None:
        offset = float((lo[index] + hi[index]) / 2)
    normal = np.zeros(3)
    # "below" keeps the part with the smaller coordinate: the far side is removed.
    normal[index] = 1.0 if keep == "below" else -1.0
    point = np.zeros(3)
    point[index] = float(offset)
    return Section(point=point, normal=normal)


def render_meshes(meshes: Sequence[Tuple[np.ndarray, np.ndarray, Sequence[float]]], *,
                  views: Sequence[str] = DEFAULT_VIEWS, size: int = 512,
                  section: Optional[Dict[str, object]] = None, overlay: bool = False,
                  ) -> Tuple[bytes, List[Dict[str, object]], Tuple[np.ndarray, np.ndarray]]:
    """Contact sheet of meshes ``(vertices, faces, rgb)``; each mesh is one colour and outline group.

    ``section`` is ``{"axis": "x"|"y"|"z", "offset": metres (optional), "keep": "below"|"above"}``.
    Returns ``(png, cameras, (lo, hi))``.
    """
    parts = [(np.asarray(v, dtype=np.float64).reshape(-1, 3), np.asarray(f, dtype=np.int64).reshape(-1, 3), c)
             for v, f, c in meshes if len(f)]
    if not parts:
        raise ValueError("nothing to render: no triangles")
    offsets = np.cumsum([0] + [len(v) for v, _, _ in parts[:-1]])
    vertices = np.concatenate([v for v, _, _ in parts])
    faces = np.concatenate([f + o for (_, f, _), o in zip(parts, offsets)])
    face_object = np.concatenate([np.full(len(f), i, dtype=np.int64) for i, (_, f, _) in enumerate(parts)])
    colors = np.array([np.clip(np.asarray(c, dtype=float)[:3], 0.08, 1.0) for _, _, c in parts])
    lo, hi = vertices.min(axis=0), vertices.max(axis=0)
    cut = None
    if section:
        cut = section_plane(str(section["axis"]), lo, hi, section.get("offset"),  # type: ignore[arg-type]
                            str(section.get("keep") or "below"))
    png, cameras = render_views(vertices, faces, colors[face_object], face_object, bounds=(lo, hi),
                                views=views, size=size, section=cut, overlay=overlay)
    return png, cameras, (lo, hi)


def body_color(material: object, role: Optional[str]) -> Tuple[float, float, float]:
    """The colour a body is drawn in: the material's ``color`` when it has one, else its role's."""
    if isinstance(material, dict):
        color = material.get("color")
        if isinstance(color, (list, tuple)) and len(color) >= 3:
            return float(color[0]), float(color[1]), float(color[2])
    return ROLE_COLORS.get(role or "other", ROLE_COLORS["other"])
