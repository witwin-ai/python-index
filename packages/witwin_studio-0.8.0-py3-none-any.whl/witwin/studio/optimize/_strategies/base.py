"""The method interface: ``Strategy`` (ask/tell) and its registration ``Optimizer`` (plan §3.1).

Two families of drivers run a Study (``optimize.run`` picks one by the
method's ``family``):

- ``gradient``: ``GradientDriver`` keeps torch leaf tensors and a torch
  optimizer in one process; one point per step. It does not use ``Strategy``.
- everything else (``explore``, ``blackbox``, ``agentic``): ``BatchDriver``
  runs an ask/tell loop. The method's ``Strategy`` proposes a batch of points
  (``ask``), the driver evaluates them and hands the records back (``tell``).
  Stopping, progress, failures, caching and parallel evaluation are the
  driver's job, so a strategy only decides the next points.

A method is registered with an ``Optimizer`` object: the built-in ones in
``_strategies/<kind>.py`` (``OPTIMIZER``), third-party ones under the entry
point group ``witwin.optimizers``::

    [project.entry-points."witwin.optimizers"]
    annealing = "my_pkg.annealing:OPTIMIZER"

The Studies panel renders ``settings_schema`` (the ``method``
table) and ``variable_schema`` (each ``variables.<name>`` table) as forms; the
same schemas validate records (``_schema.check_settings``).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Mapping, Protocol, runtime_checkable

from ...studies._errors import ErrorCode

if TYPE_CHECKING:
    from .._records import EvalRecord
    from .._space import DesignSpace
    from ...studies._model import Budget, Direction


class Family(StrEnum):
    """How a method is driven and where the panel lists it."""
    EXPLORE = "explore"    # BatchDriver; maps the space (sweeps, sampling); panel group "Explore"
    BLACKBOX = "blackbox"  # BatchDriver; searches for the best point; panel group "Optimize"
    GRADIENT = "gradient"  # GradientDriver; panel group "Optimize"
    AGENTIC = "agentic"    # BatchDriver; an Agent proposes the points; panel group "Agentic"


@dataclass(frozen=True)
class Unavailable:
    """Why a registered method cannot run here; ``code`` is the refusal ``optimize.run`` raises."""
    code: ErrorCode
    reason: str


# Reason of a built-in method whose strategy is not written yet.
def not_implemented() -> Unavailable:
    return Unavailable(ErrorCode.METHOD_UNAVAILABLE, "not implemented")


# Reason of a method planned for a later release (the Agentic slot).
def coming_soon() -> Unavailable:
    return Unavailable(ErrorCode.METHOD_UNAVAILABLE, "coming soon")


def missing_dependency(module: str, hint: str) -> Unavailable | None:
    """``dependency_missing`` when ``module`` cannot be found, else None; never imports it."""
    import importlib.util

    if importlib.util.find_spec(module) is not None:
        return None
    return Unavailable(ErrorCode.DEPENDENCY_MISSING, f"needs {module}; {hint}")


@dataclass(frozen=True)
class Candidate:
    """A point a strategy asks for, with an optional ``note`` kept on its record."""
    values: Mapping[str, float]
    note: str | None = None


@dataclass(frozen=True)
class StrategySetup:
    """What a strategy factory receives.

    ``settings`` is the Study's ``method`` table without ``kind``, defaults
    filled. ``seed`` is the Study's seed, or one drawn for this run (it is
    written to the result, so a run can be repeated). ``space`` holds the
    variables with their per-variable settings.
    """
    space: "DesignSpace"
    settings: Mapping[str, Any]
    seed: int
    budget: "Budget"
    direction: "Direction"
    project_root: Path | None = None

    @property
    def maximize(self) -> bool:
        return str(self.direction) == "maximize"

    def score(self, record: "EvalRecord") -> float:
        """The record's loss as a number to minimize: negated for maximize, +inf when it failed."""
        if record.loss is None or not record.ok or not math.isfinite(record.loss):
            return math.inf
        return -record.loss if self.maximize else record.loss


@runtime_checkable
class Strategy(Protocol):
    """One black-box method run; ``BatchDriver`` calls ``ask`` and ``tell`` in turn.

    ``ask`` returns the next batch of points, as ``{name: value}`` dicts or
    ``Candidate`` objects, in parameter units (use ``setup.space.from_unit``
    to work in [0, 1]^n). Names left out keep their current value; the
    driver rounds to ``step`` and clamps to the bounds. An empty list ends
    the run. ``ask`` may block (the Agentic method waits for a model).

    ``tell`` gets one record per asked point, in the order asked, including
    failed ones (``loss`` None) and repeats served from the driver's cache
    (the earlier record). A run may stop between ``ask`` and ``tell`` or in
    the middle of a batch; then ``tell`` gets only the points evaluated.

    ``summary`` is the method's own part of the result (``optimization.json``
    ``summary``) and of each batch partial; keep it small and JSON-ready.
    ``state_dict`` / ``load_state_dict`` save and restore the strategy for a
    resumed run (JSON-ready too).

    Optional attributes the driver reads when present: ``expected_evals``
    (int, for the progress bar when the budget sets no ``max_evals``) and
    ``converged`` (bool, read when ``ask`` returns nothing: the run then ends
    with ``stopped_by = "converged"`` instead of ``"max_iters"``).
    """

    def ask(self) -> list[Mapping[str, float] | Candidate]: ...

    def tell(self, records: list["EvalRecord"]) -> None: ...

    def summary(self) -> dict[str, Any]: ...

    def state_dict(self) -> dict[str, Any]: ...

    def load_state_dict(self, state: Mapping[str, Any]) -> None: ...


class StrategyBase:
    """Optional base class: keeps the setup and gives every optional member a default."""
    expected_evals: int | None = None
    converged: bool = False

    def __init__(self, setup: StrategySetup) -> None:
        self.setup = setup

    def ask(self) -> list[Mapping[str, float] | Candidate]:
        raise NotImplementedError

    def tell(self, records: list["EvalRecord"]) -> None:
        pass

    def summary(self) -> dict[str, Any]:
        return {}

    def state_dict(self) -> dict[str, Any]:
        return {}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        pass


StrategyFactory = Callable[[StrategySetup], Strategy]


@dataclass(frozen=True)
class Optimizer:
    """A registered method; what a ``witwin.optimizers`` entry point names.

    ``kind`` is the record's ``method.kind`` (a third-party kind should carry
    its package name, ``my_pkg.annealing``). ``factory`` builds the strategy
    for one run; the gradient family has none (its driver is built in).
    ``requires_bounds``: every variable needs ``lower`` and ``upper``, else
    the run is refused with ``bounds_missing``. ``unavailable`` returns why
    the method cannot run here, or None; it must be cheap and must not import
    heavy packages (use ``missing_dependency``).

    ``validate(setup)`` checks a Study's settings against its design space
    and raises ``StudyError`` (``invalid_study``, ``bounds_missing``,
    ...) for one that cannot run. ``optimize.check_study`` calls it, and the
    ProjectServer through it, so a bad Study is refused before its Run
    starts. It must be cheap, import nothing heavy and run no user code
    (no Project script); the factory should call the same function, so the
    two never disagree.

    ``illustration``: optional SVG source (at most 8 KB) Studio draws on the
    method's card instead of its family's picture. Colours are
    ``currentColor`` and ``var(--accent)`` only; Studio drops scripts,
    styles, links and other colours (dev_docs/studies-page-plan.md §5.3).

    ``default_max_evals``: the evaluations a run makes when the Study's
    budget sets no ``max_evals``, for a method that always stops (the panel
    shows it in the budget field); None for a method that runs until its
    own settings or the time limit stop it.
    """
    kind: str
    title: str
    family: Family
    factory: StrategyFactory | None = None
    settings_schema: Mapping[str, Any] = field(default_factory=dict)
    variable_schema: Mapping[str, Any] = field(default_factory=dict)
    requires_bounds: bool = True
    description: str = ""
    unavailable: Callable[[], Unavailable | None] | None = None
    validate: Callable[[StrategySetup], None] | None = None
    default_max_evals: int | None = None
    illustration: str = ""

    # The reason it cannot run here, or None.
    def check(self) -> Unavailable | None:
        if self.unavailable is not None:
            found = self.unavailable()
            if found is not None:
                return found
        if self.factory is None and self.family is not Family.GRADIENT:
            return not_implemented()
        return None


# An object schema from its properties.
def object_schema(**properties: Mapping[str, Any]) -> dict[str, Any]:
    return {"type": "object", "properties": {name: dict(prop) for name, prop in properties.items()}}
