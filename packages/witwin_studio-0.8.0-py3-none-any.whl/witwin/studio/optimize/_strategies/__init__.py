"""The method registry: built-in methods plus the ``witwin.optimizers`` entry point group.

Every built-in kind has one module here that defines ``OPTIMIZER`` (an
``Optimizer``): ``sweep``, ``custom_sweep``, ``monte_carlo``, ``genetic``,
``pso``, ``bayesian``, ``gradient`` and ``agentic``. A module whose strategy
is not written yet registers ``factory=None`` and reports ``available =
false`` with the reason "not implemented"; ``agentic`` says "coming soon".
Built-in modules must import quickly and without numpy or torch: records are
validated through them (``check_method_settings``) on every Study read.

Third-party methods register under ``witwin.optimizers``; a kind that
collides with a built-in one is ignored with a warning. Their record
settings are checked only when a run starts (loading entry points on every
record read would be slow), by ``resolve``.
"""
from __future__ import annotations

import importlib
import logging
from dataclasses import dataclass
from importlib import metadata
from typing import Any, Mapping

from ...studies._errors import ErrorCode, StudyError
from .._schema import check_settings
from .base import (
    Candidate, Family, Optimizer, Strategy, StrategyBase, StrategySetup, Unavailable,
    coming_soon, missing_dependency, not_implemented, object_schema,
)

ENTRY_POINT_GROUP = "witwin.optimizers"
BUILTIN_SOURCE = "witwin-studio"

# kind -> module of this package, in the panel's display order.
BUILTIN_KINDS: dict[str, str] = {
    "sweep": "sweep",
    "custom_sweep": "custom_sweep",
    "monte_carlo": "monte_carlo",
    "gradient": "gradient",
    "genetic": "genetic",
    "pso": "pso",
    "bayesian": "bayesian",
    "agentic": "agentic",
}

logger = logging.getLogger("witwin.studio")

__all__ = [
    "BUILTIN_KINDS", "Candidate", "ENTRY_POINT_GROUP", "Family", "Optimizer", "Strategy",
    "StrategyBase", "StrategySetup", "Unavailable", "builtin", "check_method_settings",
    "check_variable_settings", "coming_soon", "list_methods", "missing_dependency",
    "not_implemented", "object_schema", "resolve",
]


@dataclass(frozen=True)
class Registered:
    optimizer: Optimizer
    source: str  # BUILTIN_SOURCE, the distribution name, else the entry point value


def builtin(kind: str) -> Optimizer | None:
    """The built-in method of ``kind``, or None."""
    module = BUILTIN_KINDS.get(kind)
    if module is None:
        return None
    return importlib.import_module(f"{__name__}.{module}").OPTIMIZER


def registered() -> list[Registered]:
    """Every method: built-in ones first, then entry points (broken ones skipped with a warning)."""
    found = [Registered(builtin(kind), BUILTIN_SOURCE) for kind in BUILTIN_KINDS]
    for entry in metadata.entry_points(group=ENTRY_POINT_GROUP):
        try:
            obj = entry.load()
            if not all(hasattr(obj, name) for name in ("kind", "title", "family")):
                raise AttributeError("needs kind, title and family")
        except (ImportError, AttributeError) as exc:
            logger.warning("optimizer entry point %s = %s not loaded: %s", entry.name, entry.value, exc)
            continue
        if obj.kind in BUILTIN_KINDS:
            logger.warning("optimizer entry point %s = %s ignored: '%s' is a built-in method",
                           entry.name, entry.value, obj.kind)
            continue
        found.append(Registered(obj, entry.dist.name if entry.dist is not None else entry.value))
    return found


def list_methods() -> list[dict[str, Any]]:
    """Every method as ``{kind, title, family, description, settings_schema, variable_schema,
    requires_bounds, default_max_evals, illustration, source, available, reason, code}``; ``reason`` and ``code`` are ``""``
    when ``available``."""
    rows = []
    for item in registered():
        opt = item.optimizer
        problem = _check(opt)
        rows.append({
            "kind": str(opt.kind), "title": str(opt.title), "family": str(Family(opt.family)),
            "description": str(getattr(opt, "description", "") or ""),
            "settings_schema": dict(getattr(opt, "settings_schema", None) or {}),
            "variable_schema": dict(getattr(opt, "variable_schema", None) or {}),
            "requires_bounds": bool(getattr(opt, "requires_bounds", True)),
            "default_max_evals": getattr(opt, "default_max_evals", None),
            "illustration": str(getattr(opt, "illustration", "") or ""),
            "source": item.source, "available": problem is None,
            "reason": "" if problem is None else problem.reason,
            "code": "" if problem is None else str(problem.code),
        })
    return rows


def resolve(kind: str) -> Optimizer:
    """The method a run uses; raises ``method_not_found``, ``method_unavailable`` or
    ``dependency_missing``."""
    opt = builtin(kind)
    if opt is None:
        opt = next((item.optimizer for item in registered() if item.optimizer.kind == kind), None)
    if opt is None:
        raise StudyError(ErrorCode.METHOD_NOT_FOUND,
                                f"no installed package registers the optimization method '{kind}'",
                                kind=kind)
    problem = _check(opt)
    if problem is not None:
        raise StudyError(problem.code, f"{opt.title} is not available: {problem.reason}",
                                kind=kind)
    return opt


def check_method_settings(kind: str, settings: Mapping[str, Any]) -> dict[str, Any]:
    """A ``method`` table (without ``kind``) checked against a built-in method's schema."""
    opt = builtin(kind)
    if opt is None:
        return dict(settings)
    return check_settings(opt.settings_schema, settings, "method")


def check_variable_settings(kind: str, settings: Mapping[str, Any], what: str) -> dict[str, Any]:
    """One ``variables.<name>`` table checked against a built-in method's variable schema."""
    opt = builtin(kind)
    if opt is None or not opt.variable_schema:
        return check_settings({}, settings, what)
    return check_settings(opt.variable_schema, settings, what)


# Optimizer.check(), also for duck-typed third-party objects without it.
def _check(opt: Any) -> Unavailable | None:
    if isinstance(opt, Optimizer):
        return opt.check()
    unavailable = getattr(opt, "unavailable", None)
    found = unavailable() if callable(unavailable) else None
    if found is None and getattr(opt, "factory", None) is None and str(opt.family) != Family.GRADIENT:
        return not_implemented()
    return found
