"""Optimization methods and the drivers that run an optimize Study on a Scene.

    import witwin.studio as ws
    from witwin.studio import optimize

    project = ws.open_project(".")
    study = project.studies.add(
        "Fit width", scene="main",
        objective={"kind": "script", "path": "scripts/objective.py", "function": "objective"},
        variables={"w": {"lower": 1e-3, "upper": 4e-3}},
        method={"kind": "gradient", "optimizer": "adam", "lr": 0.05, "max_iters": 300})
    scene = project.scene(study.scene)
    result = optimize.run(scene, study)
    result.apply(scene)        # write the best values back into the parameters
    scene.save()

with ``scripts/objective.py``::

    def objective(ctx):
        width = ctx.binding("box", "Transform.scale", 0)   # SI, carries the gradient
        return (width - 3e-6) ** 2

A Study's ``variables`` name the free parameters it varies and their range
(``witwin.studio.studies``). Its ``method`` names a registered method
(``list_methods``): the gradient method, or a black-box one driven through
the ``Strategy`` ask/tell interface. Methods register under the entry point
group ``witwin.optimizers`` (``Optimizer``). The core knows no solver: the
objective, a Project script function or a Plugin entry point of group
``witwin.objectives`` (``Objective``), turns field values into a loss.

The gradient method also optimizes tensor design variables (``Study.tensors``,
read with ``ctx.tensor(id)``, filtered and projected by ``transforms``), keeps
to the objective's constraints with MMA and checks its gradient
(``check_gradient``). Every method resumes from its Run's checkpoint
(``run(resume_from=...)``); ``check_study`` refuses a Study that cannot run
without evaluating anything.

This package imports torch only when ``run`` starts. Studio's Runs start
``python -m witwin.studio.studies``, which calls ``run``.
"""
from __future__ import annotations

from . import transforms
from ._gradcheck import GradientCheck, GradientCheckRow, check_gradient, gradient_check_cost
from ._objectives import ENTRY_POINT_GROUP, Objective, ObjectiveContext, list_objectives, resolve
from ._records import EvalRecord, EvalStatus, StepRecord, StopReason
from ._report import read_evaluations
from ._result import OptimizationResult
from ._runner import check_study, run
from ._space import DesignSpace, Variable
from ._strategies import ENTRY_POINT_GROUP as OPTIMIZERS_ENTRY_POINT_GROUP
from ._strategies import list_methods
from ._strategies.base import (
    Candidate, Family, Optimizer, Strategy, StrategyBase, StrategySetup, Unavailable,
)

__all__ = [
    "Candidate", "DesignSpace", "ENTRY_POINT_GROUP", "EvalRecord", "EvalStatus", "Family",
    "GradientCheck", "GradientCheckRow", "OPTIMIZERS_ENTRY_POINT_GROUP", "Objective", "ObjectiveContext",
    "OptimizationResult", "Optimizer", "StepRecord", "StopReason", "Strategy", "StrategyBase",
    "StrategySetup", "Unavailable", "Variable", "check_gradient", "check_study", "gradient_check_cost",
    "list_methods", "list_objectives", "read_evaluations", "resolve", "run", "transforms",
]
