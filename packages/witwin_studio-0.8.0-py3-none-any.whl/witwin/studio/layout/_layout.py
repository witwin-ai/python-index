"""``Layout``: 2D shapes on named layers, vias, ports, and the build to 3D bodies.

The Layout holds shapes in its own ``unit`` (usually mm). ``to_bodies(stack)``
turns them into ``ws.Body`` objects in meters, one per layer plus one for the
via barrels, ready for ``Scene.add_mesh(unit="m")`` (the default) or
``witwin_agent.scene.create_mesh_op``.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

from ..geometry import Body
from ._stack import Layer, LayerStack, length_factor

__all__ = ["DEFAULT_SURFACE_BELOW", "LayerBody", "Layout", "Port", "Via"]

Point2 = Tuple[float, float]

# A conductor layer thinner than this (meters) becomes a fill="surface" sheet
# when no grid is given: 100 um covers 0.5-3 oz copper (17-105 um), which no
# practical RF grid resolves. With a grid the threshold is the grid step.
DEFAULT_SURFACE_BELOW = 100e-6

# Snap grid for layer polygons, in meters. Boolean results carry float noise
# (slivers of 1e-15 of the board); snapping to 1 nm removes them and is far
# below any manufacturing or solver scale.
SNAP = 1e-9


@dataclass(frozen=True)
class Via:
    """A via in layout units: drill and pad diameters, connected layers."""

    position: Point2
    drill: float
    pad: Optional[float]
    from_layer: str
    to_layer: str


@dataclass(frozen=True)
class Port:
    """A named feed point on a conductor layer, in layout units.

    ``direction`` points out of the conductor along the line (into the
    port). ``reference`` names the return layer (usually the ground);
    ``to_bodies`` puts an anchor ``<name>_ref`` on it at the same x, y.
    """

    name: str
    layer: str
    point: Point2
    direction: Optional[Point2] = None
    width: Optional[float] = None
    reference: Optional[str] = None
    kind: str = "port"


class LayerBody(Body):
    """A ``ws.Body`` built from one layout layer; lengths in meters.

    Extra attributes: ``layer`` (layer name, or ``"vias"``), ``kind``
    (``dielectric`` / ``conductor`` / ``ground`` / ``via``), ``z_min``,
    ``z_max`` and ``thickness`` (the real layer thickness). The inherited
    ``surface_thickness`` is the thickness the solver should give a
    ``fill="surface"`` sheet (None for solids); ``Scene.add_mesh`` and
    ``create_mesh_op`` write it to ``GeometryBody.surface_thickness``.

    Layers stack along +z, so ``up`` is ``"z"``: ``Scene.add_mesh`` and
    ``create_mesh_op`` turn the body into the Y-up Scene frame (the board
    lies flat, its top copper faces +Y), and a model with another
    ``CONFIG["up"]`` turns it into its own frame.
    """

    unit = "m"
    up = "z"

    def __init__(self, mesh: Any, *, layer: str, kind: str, z_min: float, z_max: float,
                 surface_thickness: Optional[float] = None, **kwargs: Any):
        super().__init__(mesh, surface_thickness=surface_thickness, **kwargs)
        self.layer = layer
        self.kind = kind
        self.z_min = float(z_min)
        self.z_max = float(z_max)
        self.thickness = self.z_max - self.z_min

    def __repr__(self) -> str:
        extra = f", surface_thickness={self.surface_thickness:.4g}" if self.surface_thickness else ""
        return (f"LayerBody({self.name!r}, kind={self.kind!r}, fill={self.fill!r}, "
                f"{self.mesh.triangle_count} triangles, z {self.z_min:.6g}..{self.z_max:.6g} m{extra})")


@dataclass
class _Anchor:
    name: str
    layer: str
    point: Point2
    normal: Optional[Tuple[float, float, float]]
    kind: str


class Layout:
    """Shapes on named layers, in ``unit`` (``"mm"``, ``"um"``, ``"m"``, ...).

        from witwin.studio import layout as L

        lay = L.Layout(unit="mm")
        lay.outline = L.rect(60, 60)
        lay.add("top", L.rect(37.3, 28.8))
        lay.add("top", L.path([(0, -14.4), (0, -30)], width=3.06))
        lay.port("feed", "top", (0, -30), direction=(0, -1), reference="bottom")
        bodies = lay.to_bodies(L.LayerStack.fr4())

    Shapes are shapely polygons (``rect``, ``path``, ... or any shapely
    geometry). Shapes on one layer are unioned; ``cut`` removes area
    (clearances, slots). ``outline`` is the board shape: dielectric slabs and
    empty ground layers fill it; without one it is the bounding box of all
    shapes.
    """

    def __init__(self, *, unit: str, outline: Any = None):
        self.unit = unit
        self.factor = length_factor(unit)  # meters per layout unit
        self._adds: Dict[str, List[Any]] = {}
        self._cuts: Dict[str, List[Any]] = {}
        self._outline = outline
        self.vias: List[Via] = []
        self.ports: Dict[str, Port] = {}
        self._anchors: Dict[str, _Anchor] = {}
        self.warnings: List[str] = []

    # ------------------------------------------------------------------ #
    # Building
    # ------------------------------------------------------------------ #
    def add(self, layer: str, shape: Any) -> Any:
        """Add copper (or any material) ``shape`` on ``layer``; returns the shape."""
        from ._shapes import clean

        self._check_layer_name(layer)
        shape = clean(shape)
        if not shape.is_empty:
            self._adds.setdefault(layer, []).append(shape)
        return shape

    def cut(self, layer: str, shape: Any) -> Any:
        """Remove ``shape`` from ``layer`` after everything is added (clearances, slots, DGS)."""
        from ._shapes import clean

        self._check_layer_name(layer)
        shape = clean(shape)
        if not shape.is_empty:
            self._cuts.setdefault(layer, []).append(shape)
        return shape

    def via(self, position: Point2, *, drill: float, pad: Optional[float] = None,
            from_layer: str, to_layer: str) -> Via:
        """A plated via: a solid barrel of ``drill`` diameter between the two layers.

        ``pad`` (diameter) adds round pads on ``from_layer`` and ``to_layer``.
        The barrel replaces the dielectric (and any copper of layers in
        between) inside the drill.
        """
        if not drill > 0:
            raise ValueError("via drill must be positive")
        if pad is not None and pad < drill:
            raise ValueError(f"via pad {pad} is smaller than the drill {drill}")
        if from_layer == to_layer:
            raise ValueError("a via needs two different layers")
        via = Via((float(position[0]), float(position[1])), float(drill), None if pad is None else float(pad),
                  from_layer, to_layer)
        self.vias.append(via)
        return via

    def port(self, name: str, layer: str, point: Point2, *, direction: Optional[Point2] = None,
             width: Optional[float] = None, reference: Optional[str] = None) -> Port:
        """A named feed point (an anchor with ``kind="port"`` on the layer's body)."""
        self._check_anchor_name(name)
        if direction is not None:
            dx, dy = (float(v) for v in direction)
            length = math.hypot(dx, dy)
            if length == 0:
                raise ValueError("port direction cannot be zero")
            direction = (dx / length, dy / length)
        port = Port(name, layer, (float(point[0]), float(point[1])), direction,
                    None if width is None else float(width), reference)
        self.ports[name] = port
        return port

    def anchor(self, name: str, layer: str, point: Point2, *, normal: Optional[Sequence[float]] = None,
               kind: str = "point") -> None:
        """A named point on ``layer``'s body (placement, measurement)."""
        self._check_anchor_name(name)
        n = None if normal is None else tuple(float(v) for v in normal)
        self._anchors[name] = _Anchor(name, layer, (float(point[0]), float(point[1])), n, kind)  # type: ignore[arg-type]

    def _check_layer_name(self, layer: str) -> None:
        if not isinstance(layer, str) or not layer:
            raise ValueError("layer must be a non-empty name")

    def _check_anchor_name(self, name: str) -> None:
        if name in self.ports or name in self._anchors:
            raise ValueError(f"anchor or port {name!r} already exists")

    # ------------------------------------------------------------------ #
    # Reading
    # ------------------------------------------------------------------ #
    @property
    def outline(self) -> Any:
        """The board outline: the one set, else the bounding box of every shape and via pad."""
        if self._outline is not None:
            return self._outline
        from shapely.geometry import box

        bounds = self.bounds
        return None if bounds is None else box(*bounds)

    @outline.setter
    def outline(self, shape: Any) -> None:
        from ._shapes import clean

        self._outline = None if shape is None else clean(shape)

    @property
    def layers(self) -> List[str]:
        """Names of layers that have shapes, cuts, vias or ports, in first-use order."""
        names: List[str] = []
        for name in [*self._adds, *self._cuts, *(v.from_layer for v in self.vias), *(v.to_layer for v in self.vias),
                     *(p.layer for p in self.ports.values())]:
            if name not in names:
                names.append(name)
        return names

    def shapes(self, layer: str) -> Any:
        """Union of the shapes added to ``layer`` minus its cuts (no via pads, no ground fill)."""
        import shapely
        from shapely.geometry import Polygon

        from ._shapes import clean

        adds = self._adds.get(layer, [])
        merged = shapely.union_all(adds) if adds else Polygon()
        cuts = self._cuts.get(layer, [])
        if cuts and not merged.is_empty:
            merged = merged.difference(shapely.union_all(cuts))
        return clean(merged)

    @property
    def bounds(self) -> Optional[Tuple[float, float, float, float]]:
        """(xmin, ymin, xmax, ymax) of every shape and via pad in layout units, or None."""
        boxes = [s.bounds for shapes in self._adds.values() for s in shapes if not s.is_empty]
        for v in self.vias:
            r = (v.pad or v.drill) / 2.0
            boxes.append((v.position[0] - r, v.position[1] - r, v.position[0] + r, v.position[1] + r))
        if self._outline is not None and not self._outline.is_empty:
            boxes.append(self._outline.bounds)
        if not boxes:
            return None
        return (min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes))

    def area(self, layer: str) -> float:
        """Area of ``layer``'s shapes in layout units squared."""
        return float(self.shapes(layer).area)

    def __repr__(self) -> str:
        return (f"Layout(unit={self.unit!r}, layers={self.layers}, vias={len(self.vias)}, "
                f"ports={list(self.ports)})")

    # ------------------------------------------------------------------ #
    # Resolution: the final 2D geometry of each stack layer
    # ------------------------------------------------------------------ #
    def resolve(self, stack: LayerStack, *, via_segments: int = 16) -> Dict[str, Any]:
        """Final 2D geometry per stack layer, in layout units.

        conductor: added shapes + via pads - cuts - drills of vias passing
        through. ground: the outline + added shapes, then the same removals.
        dielectric: the outline minus drills of vias passing through.
        """
        import shapely
        from shapely.geometry import Polygon

        from ._shapes import circle, clean

        unknown = [name for name in self.layers if name not in stack]
        if unknown:
            raise KeyError(f"layout layers {unknown} are not in the stack ({', '.join(stack.names)})")
        outline = self.outline
        through: Dict[str, List[Any]] = {}
        pads: Dict[str, List[Any]] = {}
        for via in self.vias:
            drill = circle(via.drill / 2.0, center=via.position, segments=via_segments)
            for layer in stack.between(via.from_layer, via.to_layer):
                through.setdefault(layer.name, []).append(drill)
            if via.pad:
                pad = circle(via.pad / 2.0, center=via.position, segments=max(via_segments, 16))
                for name in (via.from_layer, via.to_layer):
                    pads.setdefault(name, []).append(pad)
        out: Dict[str, Any] = {}
        snap = SNAP / self.factor
        for layer in stack:
            if layer.kind == "dielectric":
                parts = [] if outline is None else [outline]
                removals = list(through.get(layer.name, []))
            else:
                parts = list(self._adds.get(layer.name, [])) + pads.get(layer.name, [])
                if layer.kind == "ground" and outline is not None:
                    parts.append(outline)
                removals = list(self._cuts.get(layer.name, [])) + through.get(layer.name, [])
            geom = shapely.union_all(parts) if parts else Polygon()
            if removals and not geom.is_empty:
                geom = geom.difference(shapely.union_all(removals))
            out[layer.name] = clean(shapely.set_precision(clean(geom), snap)) if not geom.is_empty else Polygon()
        return out

    # ------------------------------------------------------------------ #
    # 3D build
    # ------------------------------------------------------------------ #
    def surface_layers(self, stack: LayerStack, *, surface_below: Optional[float] = None,
                       grid: Any = None) -> List[str]:
        """Conductor layers that ``to_bodies`` builds as ``fill="surface"`` sheets.

        A conductor is a sheet when its thickness is below ``surface_below``
        (meters). Without it, the threshold is the grid step when ``grid`` is
        given (one cell cannot resolve the layer), else ``DEFAULT_SURFACE_BELOW``.
        """
        threshold = _surface_threshold(surface_below, grid)
        return [layer.name for layer in stack.conductors() if layer.thickness < threshold]

    def to_bodies(self, stack: LayerStack, *, surface_below: Optional[float] = None, grid: Any = None,
                  layers: Optional[Iterable[str]] = None, via_segments: int = 16,
                  via_material: Any = None) -> List[LayerBody]:
        """Extrude every layer into a ``LayerBody`` (meters), bottom layer first, then ``vias``.

        - Dielectric layers become closed slabs over the outline, drilled
          where vias pass (role ``dielectric``, fill ``solid``).
        - Conductor and ground layers become closed prisms (fill ``solid``)
          or, when thinner than the threshold (``surface_layers``), one flat
          sheet (fill ``surface``) on the face that touches a dielectric,
          with ``surface_thickness`` set to the real thickness.
        - All via barrels form one body ``vias`` (solid cylinders, drill
          diameter, ``via_segments`` sides). A barrel ends where the
          connected layers' bodies begin, so bodies touch and never overlap.
        - Ports and anchors land on their layer's body: on the sheet, or at
          mid-thickness of a solid.

        ``surface_below`` is in meters; ``grid`` takes the forms
        ``ws.geometry.validate`` takes. ``layers`` limits the output to some
        layer names (``"vias"`` for the barrels). Empty conductor layers are
        skipped.
        """
        from shapely import affinity

        from ._extrude import prism, sheet
        from ._shapes import circle

        wanted = None if layers is None else set(layers)
        resolved = self.resolve(stack, via_segments=via_segments)
        surfaces = set(self.surface_layers(stack, surface_below=surface_below, grid=grid))
        f = self.factor

        def to_m(shape: Any) -> Any:
            return affinity.scale(shape, xfact=f, yfact=f, origin=(0.0, 0.0))

        anchors_by_layer: Dict[str, List[Any]] = {}
        bodies: List[LayerBody] = []
        sheet_z = {layer.name: _sheet_z(stack, layer) for layer in stack.conductors()}

        def anchor_z(layer: Layer) -> float:
            return sheet_z[layer.name] if layer.name in surfaces else layer.z_mid

        for port in self.ports.values():
            layer = stack[port.layer]
            normal = None if port.direction is None else (port.direction[0], port.direction[1], 0.0)
            point = (port.point[0] * f, port.point[1] * f, anchor_z(layer))
            anchors_by_layer.setdefault(layer.name, []).append(_mk_anchor(port.name, point, normal, port.kind))
            if port.reference:
                ref = stack[port.reference]
                z = anchor_z(ref) if ref.is_conductor else ref.z_mid
                anchors_by_layer.setdefault(ref.name, []).append(
                    _mk_anchor(f"{port.name}_ref", (point[0], point[1], z), None, "point"))
        for item in self._anchors.values():
            layer = stack[item.layer]
            z = anchor_z(layer) if layer.is_conductor else layer.z_mid
            anchors_by_layer.setdefault(layer.name, []).append(
                _mk_anchor(item.name, (item.point[0] * f, item.point[1] * f, z), item.normal, item.kind))

        for layer in stack:
            geom = resolved[layer.name]
            if wanted is not None and layer.name not in wanted:
                continue
            if geom.is_empty:
                if layer.kind == "dielectric":
                    raise ValueError(f"dielectric layer {layer.name!r} has no area: set Layout.outline")
                if anchors_by_layer.get(layer.name):
                    raise ValueError(f"layer {layer.name!r} has ports or anchors but no shapes")
                continue
            material = layer.material_dict(stack.frequency)
            anchors = anchors_by_layer.get(layer.name, [])
            if layer.is_conductor and layer.name in surfaces:
                z = sheet_z[layer.name]
                v, faces = sheet(to_m(geom), z)
                bodies.append(LayerBody((v, faces), name=layer.name, material=material, fill="surface",
                                        role="conductor", anchors=anchors, layer=layer.name, kind=layer.kind,
                                        z_min=layer.z_min, z_max=layer.z_max,
                                        surface_thickness=layer.thickness))
            else:
                v, faces = prism(to_m(geom), layer.z_min, layer.z_max)
                bodies.append(LayerBody((v, faces), name=layer.name, material=material, fill="solid",
                                        role="conductor" if layer.is_conductor else "dielectric",
                                        anchors=anchors, layer=layer.name, kind=layer.kind,
                                        z_min=layer.z_min, z_max=layer.z_max))

        if self.vias and (wanted is None or "vias" in wanted):
            import numpy as np

            verts, faces, offset = [], [], 0
            z_lo, z_hi = math.inf, -math.inf
            for via in self.vias:
                a, b = stack[via.from_layer], stack[via.to_layer]
                lower, upper = (a, b) if a.z_min <= b.z_min else (b, a)
                z0 = sheet_z[lower.name] if lower.name in surfaces else lower.z_max
                z1 = sheet_z[upper.name] if upper.name in surfaces else upper.z_min
                if not lower.is_conductor or not upper.is_conductor:
                    raise ValueError(f"via from {via.from_layer!r} to {via.to_layer!r} must join conductor layers")
                if z1 <= z0:
                    raise ValueError(f"via between adjacent layers {lower.name!r} and {upper.name!r} has no length")
                drill = circle(via.drill / 2.0, center=via.position, segments=via_segments)
                v, fc = prism(to_m(drill), z0, z1)
                verts.append(v)
                faces.append(fc + offset)
                offset += len(v)
                z_lo, z_hi = min(z_lo, z0), max(z_hi, z1)
            material = via_material
            if material is None:
                material = stack[self.vias[0].from_layer].material_dict(stack.frequency)
            bodies.append(LayerBody((np.vstack(verts), np.vstack(faces)), name="vias", material=material,
                                    fill="solid", role="conductor", layer="vias", kind="via",
                                    z_min=z_lo, z_max=z_hi))
        return bodies

    def add_to_scene(self, scene: Any, stack: LayerStack, *, name: str = "Layout", parent: Any = None,
                     position: Optional[Sequence[float]] = None, grid: Any = None,
                     surface_below: Optional[float] = None, max_triangles: Optional[int] = None,
                     force: bool = False, up: str = "z") -> Any:
        """Write the bodies into ``scene`` (a ``ws.Scene``) under a group named ``name``.

        Each body goes through ``Scene.add_mesh`` (validated against ``grid``;
        errors raise ``GeometryValidationError`` unless ``force``). A sheet's
        real thickness goes with the body to ``GeometryBody.surface_thickness``
        (meters). ``position`` is in meters, in the Scene frame. Returns the
        group entity; ``group.validation`` holds the merged report of all
        bodies.

        ``up`` is the Scene axis the stack's +z maps to: ``"z"`` (default)
        turns the board into the Y-up Scene frame, so it lies flat with its
        layers along Scene +Y; ``"y"`` keeps the layout coordinates as they
        are (layers along Scene +Z, the board stands on edge in the viewport).
        """
        from ..geometry import ValidationReport

        bodies = self.to_bodies(stack, surface_below=surface_below, grid=grid)
        group = scene.add(name, parent=parent, position=position)
        report = ValidationReport()
        for body in bodies:
            entity = scene.add_mesh(body.name, body, unit="m", parent=group, grid=grid,
                                    max_triangles=max_triangles, force=force, up=up)
            if entity.validation is not None:
                report.extend(entity.validation)
                report.grid_step = entity.validation.grid_step
                report.max_triangles = entity.validation.max_triangles
        group.validation = report
        return group

    # ------------------------------------------------------------------ #
    # 2D outputs
    # ------------------------------------------------------------------ #
    def top_view(self, target: Any = None, *, stack: Optional[LayerStack] = None,
                 layers: Optional[Sequence[str]] = None, size: int = 1024, per_layer: bool = False,
                 labels: bool = True) -> Any:
        """Render the layout seen from +z as PNG; see ``witwin.studio.layout.top_view``."""
        from ._render import top_view

        return top_view(self, target, stack=stack, layers=layers, size=size, per_layer=per_layer, labels=labels)

    def to_gds(self, path: Any, *, layer_map: Optional[Mapping[str, Any]] = None, cell: str = "TOP",
               stack: Optional[LayerStack] = None) -> Dict[str, Tuple[int, int]]:
        """Write a GDSII file; see ``witwin.studio.layout.write_gds``."""
        from ._io_gds import write_gds

        return write_gds(self, path, layer_map=layer_map, cell=cell, stack=stack)

    def to_dxf(self, path: Any, *, stack: Optional[LayerStack] = None) -> None:
        """Write a DXF file; see ``witwin.studio.layout.write_dxf``."""
        from ._io_dxf import write_dxf

        write_dxf(self, path, stack=stack)

    def geometry_for_export(self, stack: Optional[LayerStack]) -> Dict[str, Any]:
        """Per-layer 2D geometry for exporters: resolved through ``stack`` when given."""
        if stack is not None:
            resolved = self.resolve(stack)
            return {name: geom for name, geom in resolved.items() if not geom.is_empty}
        out = {}
        for name in self.layers:
            geom = self.shapes(name)
            if not geom.is_empty:
                out[name] = geom
        return out


def _mk_anchor(name: str, point: Tuple[float, float, float], normal: Any, kind: str):
    from ..geometry import anchor

    return anchor(name, point=point, normal=normal, kind=kind)


def _surface_threshold(surface_below: Optional[float], grid: Any) -> float:
    if surface_below is not None:
        return float(surface_below)
    if grid is not None:
        from ..geometry._validate import _grid

        step, _ = _grid(grid)
        if step is not None:
            return step
    return DEFAULT_SURFACE_BELOW


def _sheet_z(stack: LayerStack, layer: Layer) -> float:
    """Height of a conductor's sheet: the face it shares with a dielectric.

    Top copper on a substrate sits on the substrate's top face; a ground under
    it on the substrate's bottom face. With dielectrics on both sides or none,
    the sheet is at mid-thickness.
    """
    below, above = stack.neighbors(layer.name)
    below_d = below is not None and below.kind == "dielectric"
    above_d = above is not None and above.kind == "dielectric"
    if below_d and not above_d:
        return layer.z_min
    if above_d and not below_d:
        return layer.z_max
    return layer.z_mid
