"""``witwin.toml`` project manifest: read, write and bootstrap.

Moved from ``witwin_server.projects`` (decision D11), which re-exports every
name here. Internal to ``witwin.studio``; ``witwin_server`` may import it, other
code goes through ``open_project``.
"""
from __future__ import annotations

import datetime as _dt
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import tomlkit


MANIFEST_NAME = "witwin.toml"
MANIFEST_FORMAT_VERSION = "1.0"


@dataclass(frozen=True)
class ProjectInfo:
    path: Path
    project_id: str
    name: str


def manifest_path(project_dir: Path | str) -> Path:
    return Path(project_dir).resolve() / MANIFEST_NAME


def _write_manifest(manifest: Path, doc: Any) -> None:
    # LF on every platform, as the ProjectServer writes it (persistence
    # ``_write_text``). With the platform default, Windows wrote CRLF here and
    # LF on the next server start, so every open rewrote every line and a new
    # Project's first commit no longer matched its file.
    manifest.write_text(tomlkit.dumps(doc), encoding="utf-8", newline="\n")


def read_project_table(project_dir: Path | str) -> dict[str, Any]:
    """The ``[project]`` table as plain values; raises ValueError when absent."""
    manifest = manifest_path(project_dir)
    if not manifest.exists():
        raise ValueError(f"missing {MANIFEST_NAME}: {manifest.parent}")
    doc = tomlkit.parse(manifest.read_text(encoding="utf-8"))
    project = doc.get("project")
    if not isinstance(project, dict):
        raise ValueError(f"missing [project] table: {manifest}")
    return project.unwrap() if hasattr(project, "unwrap") else dict(project)


def read_witwin_project(project_dir: Path | str) -> ProjectInfo:
    directory = Path(project_dir).resolve()
    project = read_project_table(directory)
    project_id = str(project.get("id") or "").strip()
    if not project_id:
        raise ValueError(f"missing project id: {manifest_path(directory)}")
    name = str(project.get("name") or directory.name or "WiTwin Project")
    return ProjectInfo(path=directory, project_id=project_id, name=name)


MAX_PROJECT_NAME = 200


def project_settings(project_dir: Path | str) -> dict[str, Any]:
    """The ``[project]`` fields the Settings dialog shows, plus the folder."""
    directory = Path(project_dir).resolve()
    info = read_witwin_project(directory)
    project: Any = tomlkit.parse(manifest_path(directory).read_text(encoding="utf-8")).get("project") or {}
    main_scene = str(project.get("main_scene") or "").strip()
    created = str(project.get("created") or "").strip()
    return {
        "id": info.project_id,
        "name": info.name,
        "path": str(directory),
        "main_scene": main_scene or None,
        "created": created or None,
    }


def set_project_name(project_dir: Path | str, name: str) -> None:
    """Write ``[project].name``, keeping every other key and comment."""
    text = (name or "").strip()
    if not text:
        raise ValueError("Project name is required.")
    if len(text) > MAX_PROJECT_NAME:
        raise ValueError("Project name is too long.")
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in text):
        raise ValueError("Project name contains a control character.")
    manifest = manifest_path(project_dir)
    doc = tomlkit.parse(manifest.read_text(encoding="utf-8"))
    project: Any = doc.get("project")
    if not isinstance(project, dict):
        raise ValueError(f"missing [project] table: {manifest}")
    project["name"] = text
    _write_manifest(manifest, doc)


def ensure_witwin_project(
    project_dir: Path | str,
    *,
    project_id: str | None = None,
    scaffold_new: bool = True,
) -> ProjectInfo:
    """Make ``project_dir`` a Project: write or complete ``[project]`` in ``witwin.toml``.

    A Project created in a new or empty folder also gets its Python files
    (``pyproject.toml``, ``README.md``, ``.gitignore``; decision D11),
    ``.gitattributes``, and starts as a git repository with one commit. A
    folder that already has content only gets the manifest: turning it into a
    Python project is an explicit step (``witwin init`` or "Make Python
    Project"), and so is starting a repository there.
    ``scaffold_new=False`` skips the Python files for a caller that writes them
    itself (``witwin init`` sets the name first).
    """
    directory = Path(project_dir).resolve()
    fresh = not directory.exists() or (directory.is_dir() and not any(directory.iterdir()))
    directory.mkdir(parents=True, exist_ok=True)
    if not directory.is_dir():
        raise ValueError(f"project path is not a directory: {directory}")

    manifest = manifest_path(directory)
    now = _dt.datetime.now(_dt.timezone.utc).isoformat().replace("+00:00", "Z")
    if manifest.exists():
        doc = tomlkit.parse(manifest.read_text(encoding="utf-8"))
    else:
        doc = tomlkit.document()
    project: Any = doc.get("project")
    if not isinstance(project, dict):
        project = tomlkit.table()
        doc["project"] = project
    if not str(project.get("id") or "").strip():
        project["id"] = project_id or str(uuid.uuid4())
    if not str(project.get("name") or "").strip():
        project["name"] = directory.name or "WiTwin Project"
    if not str(project.get("format_version") or "").strip():
        project["format_version"] = MANIFEST_FORMAT_VERSION
    if not str(project.get("created") or "").strip():
        project["created"] = now
    project["modified"] = str(project.get("modified") or now)
    _write_manifest(manifest, doc)

    (directory / ".witwin" / "cache" / "thumbnails").mkdir(parents=True, exist_ok=True)
    if fresh and scaffold_new:
        from ._scaffold import scaffold_project

        scaffold_project(directory, init_git=True)
    return read_witwin_project(directory)
