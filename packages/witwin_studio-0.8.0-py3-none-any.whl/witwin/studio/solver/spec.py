"""Declarative solver specifications from `contributes.solvers` in ``witwin.toml``.

Moved from ``witwin_server.features.solvers.spec`` (decision D11, phase P5);
that path stays an alias of this module. The ProjectServer and headless solves
(``witwin.studio.solver.client``) parse runtimes the same way.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from .._environment import project_python as _project_python

_ENV_PATTERN = re.compile(r"\$\{env:([A-Za-z_][A-Za-z0-9_]*)\}")
# The Project interpreter (decision D11.7): the Project's .venv, or the one the
# user chose, else the caller's own. See witwin.studio._environment.
PROJECT_PYTHON = "${project:python}"


@dataclass(frozen=True)
class SolverRuntimeSpec:
    kind: str
    executable: str
    args: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    # True for `python = "${project:python}"`. The host resolves the
    # interpreter again at each spawn, so a .venv created after the
    # ProjectServer started is used without a restart.
    project_python: bool = False
    # Project folder for ${project:python}; None means WITWIN_PROJECT_DIR (the
    # ProjectServer sets it), else the current folder.
    project_dir: Optional[str] = None

    def spawn_executable(self) -> str:
        if self.project_python:
            return _project_python(Path(self.project_dir) if self.project_dir else None)
        return self.executable


@dataclass(frozen=True)
class SolverSpec:
    solver_id: str
    plugin_id: str
    plugin_root: Path
    entry: Path
    runtime: SolverRuntimeSpec
    title: str = ""
    # Producer code version (per-solver override else the plugin package version).
    # Folded into a bake's dependencyKey so a plugin upgrade invalidates datasets
    # baked by an older version (Play Mode & Baked Playback plan 搂3.4). Empty when
    # undeclared, which the bake staleness check treats as "unknown / don't invalidate".
    version: str = ""
    lifecycle: str = "warm"
    idle_timeout_sec: float = 300.0
    cancel_grace_sec: float = 5.0
    heartbeat_interval_sec: float = 30.0
    heartbeat_timeout_sec: float = 5.0
    heartbeat_misses: int = 2
    max_parallel: int = 1
    capabilities: Dict[str, Any] = field(default_factory=dict)

    @property
    def id(self) -> str:
        return self.solver_id

    @classmethod
    def from_manifest(
        cls,
        plugin_id: str,
        plugin_root: Path,
        item: Dict[str, Any],
        *,
        plugin_version: Optional[str] = None,
        project_dir: Optional[Path] = None,
    ) -> "SolverSpec":
        if not isinstance(item, dict):
            raise ValueError("contributes.solvers entries must be objects")
        solver_id = str(item.get("id") or "").strip()
        if not solver_id:
            raise ValueError("contributes.solvers entry requires id")
        entry_raw = str(item.get("entry") or "").strip()
        if not entry_raw:
            raise ValueError(f"{solver_id}: entry is required")

        root = Path(plugin_root).resolve()
        entry = (root / entry_raw).resolve()
        try:
            entry.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"{solver_id}: entry must resolve inside plugin root") from exc
        if not entry.exists():
            raise ValueError(f"{solver_id}: entry does not exist: {entry_raw}")

        lifecycle = str(item.get("lifecycle") or "warm")
        if lifecycle != "warm":
            raise ValueError(f"{solver_id}: only warm lifecycle is supported in RFC-012 Layer A")
        max_parallel = int(item.get("maxParallel", 1))
        if max_parallel != 1:
            raise ValueError(f"{solver_id}: maxParallel > 1 is not supported in RFC-012 Layer A")

        runtime = _parse_runtime(solver_id, root, item.get("runtime"), project_dir)
        return cls(
            solver_id=solver_id,
            plugin_id=plugin_id,
            plugin_root=root,
            entry=entry,
            runtime=runtime,
            title=str(item.get("title") or solver_id),
            # A per-solver `version` overrides the plugin package version.
            version=str(item.get("version") or plugin_version or "").strip(),
            lifecycle=lifecycle,
            idle_timeout_sec=float(item.get("idleTimeoutSec", 300.0)),
            cancel_grace_sec=float(item.get("cancelGraceSec", 5.0)),
            heartbeat_interval_sec=float(item.get("heartbeatIntervalSec", 30.0)),
            heartbeat_timeout_sec=float(item.get("heartbeatTimeoutSec", 5.0)),
            heartbeat_misses=max(1, int(item.get("heartbeatMisses", 2))),
            max_parallel=max_parallel,
            capabilities=dict(item.get("capabilities") or {}),
        )


def _expand_env(value: str, project_dir: Optional[Path] = None) -> str:
    value = value.replace("${backend:python}", sys.executable)
    if PROJECT_PYTHON in value:
        value = value.replace(PROJECT_PYTHON, _project_python(project_dir))

    def repl(match: re.Match[str]) -> str:
        name = match.group(1)
        if name not in os.environ:
            raise ValueError(f"unresolved environment variable in solver runtime: {name}")
        return os.environ[name]

    return _ENV_PATTERN.sub(repl, value)


def _parse_runtime(
    solver_id: str, plugin_root: Path, runtime: Any, project_dir: Optional[Path] = None,
) -> SolverRuntimeSpec:
    if not isinstance(runtime, dict):
        raise ValueError(f"{solver_id}: runtime is required")

    def _expand(value: str) -> str:
        return _expand_env(value, project_dir)

    runtime_env = {
        str(k): _expand(str(v))
        for k, v in (runtime.get("env") or {}).items()
        if isinstance(k, str)
    }
    if runtime.get("python"):
        raw_python = str(runtime["python"])
        executable = _resolve_executable(plugin_root, _expand(raw_python))
        args = [_expand(str(arg)) for arg in (runtime.get("args") or [])]
        return SolverRuntimeSpec(
            kind="python",
            executable=executable,
            args=args,
            env=runtime_env,
            project_python=raw_python.strip() == PROJECT_PYTHON,
            project_dir=str(project_dir) if project_dir is not None else None,
        )
    if runtime.get("conda"):
        args = [_expand(str(arg)) for arg in (runtime.get("args") or [])]
        return SolverRuntimeSpec(
            kind="conda",
            executable=_resolve_conda_python(_expand(str(runtime["conda"]))),
            args=args,
            env=runtime_env,
        )
    if runtime.get("command"):
        command = _expand(str(runtime["command"]))
        args = [_expand(str(arg)) for arg in (runtime.get("args") or [])]
        return SolverRuntimeSpec(kind="command", executable=command, args=args, env=runtime_env)
    raise ValueError(f"{solver_id}: runtime must declare python, conda, or command")


def _resolve_executable(plugin_root: Path, raw: str) -> str:
    candidate = Path(raw)
    if not candidate.is_absolute():
        candidate = (plugin_root / candidate).resolve()
    if not candidate.exists():
        raise ValueError(f"solver runtime executable does not exist: {raw}")
    return str(candidate)


def _conda_base_fast() -> Optional[Path]:
    """Locate the conda install without paying for `conda info --base`.

    That subprocess costs ~4s on Windows, and solver specs are parsed while
    plugins register, so it lands on every ProjectServer startup. The layout is
    derivable in every normal case: the interpreter is either the base itself or
    `<base>/envs/<name>`, and conda exports its root.
    """
    candidates: List[Path] = []
    for var in ("CONDA_ROOT", "CONDA_PREFIX_1"):
        value = os.environ.get(var)
        if value:
            candidates.append(Path(value))
    prefix = Path(sys.prefix)
    candidates.extend([prefix, prefix.parent.parent])
    conda = shutil.which("conda")
    if conda:
        # <base>/Library/bin/conda.bat, <base>/Scripts/conda.exe, <base>/bin/conda
        conda_path = Path(conda)
        candidates.extend([conda_path.parents[1], conda_path.parents[2]])
    for candidate in candidates:
        try:
            if (candidate / "envs").is_dir():
                return candidate
        except OSError:
            continue
    return None


def _resolve_conda_python(env_name: str) -> str:
    base = _conda_base_fast()
    if base is None:
        conda = shutil.which("conda")
        if not conda:
            raise ValueError("solver runtime conda requested, but conda is not on PATH")
        result = subprocess.run(
            [conda, "info", "--base"],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            raise ValueError("unable to resolve conda base for solver runtime")
        raw = (result.stdout or "").strip()
        if not raw:
            raise ValueError("conda base path is empty")
        base = Path(raw)
    if os.name == "nt":
        python = base / "envs" / env_name / "python.exe"
    else:
        python = base / "envs" / env_name / "bin" / "python"
    if not python.exists():
        raise ValueError(f"conda env python does not exist for solver runtime: {env_name}")
    return str(python)
