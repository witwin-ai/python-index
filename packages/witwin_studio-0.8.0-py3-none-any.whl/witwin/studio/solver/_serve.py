"""Child-side SDK for RFC-012 solver entries (`solver_host.py`).

Moved from ``witwin_server.features.solvers.sdk`` (decision D11, phase P5);
that path stays an alias of this module. Import it as ``witwin.studio.solver``.
"""
from __future__ import annotations

import json
import base64
import hashlib
import os
import sys
import threading
import traceback
import uuid
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from .protocol import encode_message
from .scene_ref import SCENE_DOCUMENT, SCENE_LIVE, load_scene_ref

QueryHandler = Callable[["SolveContext", Any, Dict[str, Any]], Any]
MethodHandler = Callable[["SolveContext", Dict[str, Any]], Any]
_QUERIES: Dict[str, QueryHandler] = {}
_METHODS: Dict[str, MethodHandler] = {}


class SolverCancelled(Exception):
    """Raised inside the child when a cooperative cancel is observed."""


class SolveContext:
    def __init__(self, run_id: str, send: Callable[[Dict[str, Any]], None], cancel_event: threading.Event):
        self.run_id = run_id
        self._send = send
        self._cancel_event = cancel_event
        self._outputs: Dict[str, Any] = {}

    @property
    def is_cancelled(self) -> bool:
        return self._cancel_event.is_set()

    def progress(self, frac: float, message: Optional[str] = None) -> None:
        self._send({
            "jsonrpc": "2.0",
            "method": "$/progress",
            "params": {"runId": self.run_id, "frac": frac, "message": message},
        })

    def set_outputs(self, *, summary: Any = None, plots: Optional[List[Dict[str, Any]]] = None) -> None:
        """What this run returns besides its result (or result handle).

        A solver with queries returns only a handle, which dies with the
        process; ``summary`` (JSON) and ``plots`` (Results-panel entries,
        ``{"type": "line" | "imshow" | ..., "data": ...}``) go into the run's
        outputs and the Result the solve records, so a caller such as the
        Agent's ``solver.run`` sees the numbers without a query.
        """
        if summary is not None:
            self._outputs["summary"] = _jsonable(summary)
        if plots:
            self._outputs["plots"] = [_jsonable(p) for p in plots]

    def partial(self, seq: Optional[int], data: Any) -> None:
        self._send({
            "jsonrpc": "2.0",
            "method": "$/partial",
            "params": {"runId": self.run_id, "seq": seq, "data": data},
        })

    def log(self, message: str, level: str = "info") -> None:
        self._send({
            "jsonrpc": "2.0",
            "method": "$/log",
            "params": {"runId": self.run_id, "level": level, "message": message},
        })

    def stream_open(
        self,
        stream_id: str,
        *,
        label: Optional[str] = None,
        channels: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None,
        owner: Optional[Dict[str, Any]] = None,
        kind: str = "custom",
        retention: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._send({
            "jsonrpc": "2.0",
            "method": "$/stream/open",
            "params": {
                "runId": self.run_id,
                "streamId": str(stream_id),
                "label": label,
                "channels": channels,
                "metadata": metadata,
                "owner": owner,
                "kind": kind,
                "retention": retention,
            },
        })

    def stream_update(
        self,
        stream_id: str,
        *,
        label: Optional[str] = None,
        channels: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None,
        status: Optional[str] = None,
        owner: Optional[Dict[str, Any]] = None,
        kind: Optional[str] = None,
        retention: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._send({
            "jsonrpc": "2.0",
            "method": "$/stream/update",
            "params": {
                "runId": self.run_id,
                "streamId": str(stream_id),
                "label": label,
                "channels": channels,
                "metadata": metadata,
                "status": status,
                "owner": owner,
                "kind": kind,
                "retention": retention,
            },
        })

    def stream_publish(
        self,
        stream_id: str,
        channel_id: str,
        payload: Any = None,
        *,
        metadata: Optional[Dict[str, Any]] = None,
        asset: Optional[Dict[str, Any]] = None,
        timestamp_us: Optional[int] = None,
        flags: int = 0,
    ) -> None:
        payload_bytes, inferred = _payload_bytes(payload)
        frame_metadata = {**inferred, **dict(metadata or {})}
        params: Dict[str, Any] = {
            "runId": self.run_id,
            "streamId": str(stream_id),
            "channelId": str(channel_id),
            "metadata": frame_metadata,
            "asset": asset,
            "timestampUs": timestamp_us,
            "flags": int(flags),
        }
        if payload_bytes:
            params["payloadEncoding"] = "base64"
            params["payload"] = base64.b64encode(payload_bytes).decode("ascii")
        self._send({"jsonrpc": "2.0", "method": "$/stream/publish", "params": params})

    def frame(
        self,
        time: float,
        channel: str,
        payload: Any = None,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Emit one baked timeline frame for the active ``bake_sequence`` call.

        Mirrors :meth:`stream_publish`'s payload handling (base64 with inferred
        ``dtype``/``shape``) but carries a scene ``time`` and ``channel`` so the
        host-side bake sink can content-address the payload into a persistent
        dataset frame. Only meaningful while a host bake call is in flight; the
        host routes ``$/frame`` to the per-call sink and ignores it otherwise.
        """
        payload_bytes, inferred = _payload_bytes(payload)
        frame_metadata = {**inferred, **dict(metadata or {})}
        params: Dict[str, Any] = {
            "runId": self.run_id,
            "time": float(time),
            "channel": str(channel),
            "metadata": frame_metadata,
        }
        if payload_bytes:
            params["payloadEncoding"] = "base64"
            params["payload"] = base64.b64encode(payload_bytes).decode("ascii")
        self._send({"jsonrpc": "2.0", "method": "$/frame", "params": params})

    def stream_close(self, stream_id: str, *, reason: str = "closed") -> None:
        self._send({
            "jsonrpc": "2.0",
            "method": "$/stream/close",
            "params": {"runId": self.run_id, "streamId": str(stream_id), "reason": reason},
        })

    def stream_error(self, stream_id: str, message: str, *, code: Optional[str] = None) -> None:
        self._send({
            "jsonrpc": "2.0",
            "method": "$/stream/error",
            "params": {
                "runId": self.run_id,
                "streamId": str(stream_id),
                "message": str(message),
                "code": code,
            },
        })

    def throw_if_cancelled(self) -> None:
        if self._cancel_event.is_set():
            raise SolverCancelled("cancelled")

    def result_ref(
        self,
        payload: bytes,
        *,
        kind: str = "binary",
        extension: str = ".bin",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        root = os.environ.get("WITWIN_SOLVER_RESULT_DIR")
        if not root:
            raise RuntimeError("WITWIN_SOLVER_RESULT_DIR is not configured")
        digest = hashlib.sha256(payload).hexdigest()
        suffix = extension if extension.startswith(".") else f".{extension}"
        path = Path(root) / f"result-{digest[:16]}{suffix}"
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_bytes(payload)
            tmp.replace(path)
        ref = {
            "kind": kind,
            "path": str(path),
            "contentHash": f"sha256:{digest}",
            "size": len(payload),
        }
        if metadata:
            ref.update(metadata)
        return ref


def query(op: str):
    """Register a child-side query handler for a result handle."""
    def decorator(fn: QueryHandler):
        _QUERIES[op] = fn
        return fn

    return decorator


def method(name: str):
    """Register a child-side custom method handler."""
    def decorator(fn: MethodHandler):
        _METHODS[name] = fn
        return fn

    return decorator


def _payload_bytes(value: Any) -> tuple[bytes, Dict[str, Any]]:
    if value is None:
        return b"", {}
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value), {}

    try:
        import numpy as np
    except Exception:  # pragma: no cover - numpy is part of the server runtime
        np = None

    if np is not None:
        if hasattr(value, "detach") and callable(value.detach):
            value = value.detach().cpu().numpy()
        array = np.asarray(value)
        metadata = {"dtype": str(array.dtype), "shape": list(array.shape)}
        return array.tobytes(order="C"), metadata

    if hasattr(value, "tobytes"):
        return value.tobytes(), {}
    raise TypeError(f"stream payload must be bytes or array-like, got {type(value).__name__}")


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if is_dataclass(value):
        return _jsonable(asdict(value))
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    if hasattr(value, "tolist"):
        return _jsonable(value.tolist())
    if hasattr(value, "item"):
        return _jsonable(value.item())
    return value


def _preload_scene_runtime(scene_ref: Any, scene: str = SCENE_LIVE) -> None:
    """Import the live scene model before ``solve`` starts its thread (live mode only)."""
    if scene != SCENE_LIVE:
        return
    if isinstance(scene_ref, dict) and (
        isinstance(scene_ref.get("scene"), dict) or isinstance(scene_ref.get("sceneDoc"), dict)
    ):
        from witwin_server.core import Scene  # noqa: F401


def serve(
    solve_fn: Callable[[SolveContext, Any, Dict[str, Any]], Any],
    *,
    threaded_solve: bool = True,
    scene: str = SCENE_LIVE,
) -> None:
    """Run the solver JSON-RPC loop on stdin/stdout.

    ``scene`` picks what ``solve_fn`` receives: ``"live"`` (default) the
    ProjectServer's ``Scene`` model, which imports ``witwin_server`` until phase
    P7; ``"document"`` the scene document as a dict, so the child never imports
    ``witwin_server`` and runs on any Project interpreter.
    """
    if scene not in (SCENE_LIVE, SCENE_DOCUMENT):
        raise ValueError(f"scene must be {SCENE_LIVE!r} or {SCENE_DOCUMENT!r}, got {scene!r}")
    send_lock = threading.RLock()
    shutdown = threading.Event()
    results: Dict[str, Any] = {}
    cancel_events: Dict[str, threading.Event] = {}

    def send(message: Dict[str, Any]) -> None:
        with send_lock:
            print(encode_message(message), flush=True)

    def send_result(message_id: Any, result: Any) -> None:
        send({"jsonrpc": "2.0", "id": message_id, "result": result})

    def send_error(message_id: Any, code: str, message: str, detail: Any = None) -> None:
        error = {"code": code, "message": message}
        if detail is not None:
            error["data"] = detail
        send({"jsonrpc": "2.0", "id": message_id, "error": error})

    def run_solve(message_id: Any, params: Dict[str, Any]) -> None:
        run_id = str(params.get("runId") or "")
        cancel_event = cancel_events.setdefault(run_id, threading.Event())
        ctx = SolveContext(run_id, send, cancel_event)
        try:
            solve_scene = load_scene_ref(params.get("sceneRef"), scene=scene)
            result = solve_fn(ctx, solve_scene, params.get("config") or {})
            ctx.throw_if_cancelled()
        except SolverCancelled:
            send_error(message_id, "cancelled", "cancelled")
        except BaseException as exc:  # noqa: BLE001 - cross-process error channel
            send_error(
                message_id,
                "solver_error",
                str(exc),
                {"traceback": traceback.format_exc()},
            )
        else:
            if _QUERIES:
                handle = uuid.uuid4().hex
                results.clear()
                results[handle] = result
                send_result(message_id, {**ctx._outputs, "resultHandle": handle})
            else:
                send_result(message_id, {**ctx._outputs, "result": _jsonable(result)})
        finally:
            cancel_events.pop(run_id, None)

    def run_query(message_id: Any, params: Dict[str, Any]) -> None:
        op = str(params.get("op") or "")
        handle = str(params.get("resultHandle") or "")
        handler = _QUERIES.get(op)
        if handler is None:
            send_error(message_id, "unknown_query", f"unknown query op: {op}")
            return
        if handle not in results:
            send_error(message_id, "unknown_result_handle", f"unknown result handle: {handle}")
            return
        run_id = str(params.get("runId") or "")
        ctx = SolveContext(run_id, send, cancel_events.setdefault(run_id, threading.Event()))
        try:
            data = handler(ctx, results[handle], params.get("params") or {})
        except BaseException as exc:  # noqa: BLE001
            send_error(message_id, "query_error", str(exc), {"traceback": traceback.format_exc()})
        else:
            send_result(message_id, {"data": _jsonable(data)})

    def run_method(message_id: Any, method_name: str, params: Dict[str, Any]) -> None:
        handler = _METHODS.get(method_name)
        if handler is None:
            send_error(message_id, "unknown_method", f"unknown method: {method_name}")
            return
        run_id = str(params.get("runId") or params.get("sessionId") or "")
        ctx = SolveContext(run_id, send, cancel_events.setdefault(run_id, threading.Event()))
        try:
            result = handler(ctx, params)
        except BaseException as exc:  # noqa: BLE001
            send_error(message_id, "method_error", str(exc), {"traceback": traceback.format_exc()})
        else:
            send_result(message_id, _jsonable(result))

    send({"jsonrpc": "2.0", "method": "$/ready", "params": {}})

    for raw in sys.stdin:
        if shutdown.is_set():
            break
        try:
            message = json.loads(raw)
        except json.JSONDecodeError:
            continue
        method = message.get("method")
        message_id = message.get("id")
        params = message.get("params") or {}

        if method == "initialize":
            send_result(
                message_id,
                {
                    "ready": True,
                    "capabilities": {
                        "query": sorted(_QUERIES),
                        "method": sorted(_METHODS),
                        "stream": True,
                    },
                },
            )
            continue
        if method == "ping":
            send_result(message_id, {"ok": True})
            continue
        if method == "shutdown":
            send_result(message_id, {})
            shutdown.set()
            break
        if method == "$/cancelRequest":
            run_id = str(params.get("runId") or "")
            if run_id:
                cancel_events.setdefault(run_id, threading.Event()).set()
            continue
        if method == "solve":
            try:
                _preload_scene_runtime(params.get("sceneRef"), scene)
            except BaseException as exc:  # noqa: BLE001
                send_error(
                    message_id,
                    "scene_ref_error",
                    str(exc),
                    {"traceback": traceback.format_exc()},
                )
                continue
            if threaded_solve:
                thread = threading.Thread(target=run_solve, args=(message_id, params), daemon=True)
                thread.start()
            else:
                run_solve(message_id, params)
            continue
        if method == "query":
            run_query(message_id, params)
            continue
        if method == "releaseResult":
            handle = str(params.get("resultHandle") or "")
            released = handle in results
            results.pop(handle, None)
            send_result(message_id, {"released": released})
            continue
        if isinstance(method, str) and method in _METHODS:
            run_method(message_id, method, params)
            continue
        if message_id is not None:
            send_error(message_id, "unknown_method", f"unknown method: {method}")
