"""Scene references: how a solver child receives the scene (RFC-012).

The host writes the scene document to a content-hashed sidecar file and sends
its path; the child reads and verifies it. Moved from
``witwin_server.features.solvers.scene_ref`` (decision D11, phase P5), which
re-exports these names and keeps ``make_scene_ref`` for the live ``Scene``.
"""
from __future__ import annotations

import hashlib
import json
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

FORMAT = "witwin.solver.sceneRef.v1"
SCENE_LIVE = "live"
SCENE_DOCUMENT = "document"


def externalize_scene_ref(scene_ref: Any, ref_dir: Path) -> Any:
    """Move an inline scene document to a sidecar file before RPC transport."""
    if not isinstance(scene_ref, dict):
        return scene_ref
    if "sceneDoc" in scene_ref:
        out = dict(scene_ref)
        out["sceneDoc"] = _validate_scene_doc_ref(out.get("sceneDoc"), ref_dir)
        return out
    scene_doc = scene_ref.get("scene")
    if not isinstance(scene_doc, dict):
        return scene_ref
    out = {k: v for k, v in scene_ref.items() if k != "scene"}
    out["sceneDoc"] = _write_scene_doc(scene_doc, ref_dir, transient=True)
    return out


def scene_doc_from_ref(scene_ref: Any) -> Optional[Dict[str, Any]]:
    """The scene document a reference carries (inline or as a hashed sidecar file)."""
    if not isinstance(scene_ref, dict):
        return None
    scene_doc = scene_ref.get("scene")
    if not isinstance(scene_doc, dict):
        scene_doc = _read_scene_doc(scene_ref.get("sceneDoc"))
    return scene_doc if isinstance(scene_doc, dict) else None


def load_scene_ref(scene_ref: Any, *, scene: str = SCENE_LIVE) -> Any:
    """What a solver's ``solve(ctx, scene, config)`` receives.

    ``scene="live"`` (the default, and what every existing Plugin expects)
    rebuilds the ProjectServer's ``Scene`` model with typed components. That
    model lives in ``witwin_server`` until phase P7 moves it, so this mode
    imports it, lazily. ``scene="document"`` returns the scene document (the
    ``.wtscene`` content as a dict) and never imports ``witwin_server``.
    """
    scene_doc = scene_doc_from_ref(scene_ref)
    if scene_doc is None:
        return scene_ref
    if scene == SCENE_DOCUMENT:
        return scene_doc
    from witwin_server.core import Scene

    return Scene.from_dict(scene_doc)


def make_document_scene_ref(scene_doc: Dict[str, Any], ref_dir: Optional[Path] = None) -> Dict[str, Any]:
    """A scene reference for a scene document, e.g. a ``.wtscene`` file read headless."""
    if ref_dir is None:
        return {"format": FORMAT, "scene": scene_doc}
    return {"format": FORMAT, "sceneDoc": _write_scene_doc(scene_doc, ref_dir, transient=True)}


def summarize_scene_ref(scene_ref: Any) -> Any:
    if not isinstance(scene_ref, dict):
        return scene_ref
    stored = {k: v for k, v in scene_ref.items() if k != "scene"}
    scene_doc = scene_ref.get("scene")
    if isinstance(scene_doc, dict):
        stored["sceneDoc"] = _write_summary(scene_doc)
    elif isinstance(stored.get("sceneDoc"), dict):
        stored["sceneDoc"] = {
            key: value
            for key, value in stored["sceneDoc"].items()
            if key in {"contentHash", "size", "sceneId", "sceneName", "objectCount"}
        }
    return stored


def _write_scene_doc(scene_doc: Dict[str, Any], ref_dir: Path, *, transient: bool = False) -> Dict[str, Any]:
    payload = json.dumps(scene_doc, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    digest = hashlib.sha256(payload).hexdigest()
    ref_dir = Path(ref_dir)
    ref_dir.mkdir(parents=True, exist_ok=True)
    path = ref_dir / f"scene-{digest[:16]}-{uuid.uuid4().hex[:8]}.json"
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(payload)
    tmp.replace(path)
    summary = _write_summary(scene_doc)
    summary.update({
        "kind": "json",
        "path": str(path),
        "contentHash": f"sha256:{digest}",
        "size": len(payload),
    })
    if transient:
        summary["transient"] = True
    return summary


def _read_scene_doc(ref: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(ref, dict):
        return None
    path_raw = ref.get("path")
    if not path_raw:
        return None
    payload = Path(str(path_raw)).read_bytes()
    expected = str(ref.get("contentHash") or "")
    _verify_sha256("sceneRef", payload, expected)
    return json.loads(payload.decode("utf-8"))


def _validate_scene_doc_ref(ref: Any, ref_dir: Path) -> Dict[str, Any]:
    if not isinstance(ref, dict):
        raise ValueError("sceneRef sceneDoc must be an object")
    path_raw = ref.get("path")
    if not path_raw:
        raise ValueError("sceneRef sceneDoc path is required")
    path = Path(str(path_raw))
    try:
        resolved = path.resolve()
        resolved.relative_to(Path(ref_dir).resolve())
    except Exception as exc:  # noqa: BLE001
        raise ValueError("sceneRef path must stay inside solver scene-ref directory") from exc
    payload = resolved.read_bytes()
    expected = str(ref.get("contentHash") or "")
    _verify_sha256("sceneRef", payload, expected)
    size = ref.get("size")
    if size is not None and int(size) != len(payload):
        raise ValueError("sceneRef size mismatch")
    out = dict(ref)
    out["path"] = str(resolved)
    return out


def _verify_sha256(label: str, payload: bytes, expected: str) -> None:
    if not expected.startswith("sha256:") or len(expected.split(":", 1)[1]) != 64:
        raise ValueError(f"{label} contentHash must be sha256")
    actual = hashlib.sha256(payload).hexdigest()
    if actual != expected.split(":", 1)[1]:
        raise ValueError(f"{label} content hash mismatch")


def _write_summary(scene_doc: Dict[str, Any]) -> Dict[str, Any]:
    objects = scene_doc.get("objects")
    return {
        "sceneId": scene_doc.get("scene_id"),
        "sceneName": scene_doc.get("name"),
        "objectCount": len(objects) if isinstance(objects, dict) else None,
    }
