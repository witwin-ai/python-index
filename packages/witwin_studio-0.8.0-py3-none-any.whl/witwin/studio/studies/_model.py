"""Study records: one ``studies/<id>.toml`` file of a Project (``_store``).

A Study is one of three kinds; each kind uses its own keys and refuses the
others' (``invalid_study``)::

    # optimize: vary Scene parameters to minimize or maximize an objective
    kind = "optimize"
    scene = "main"
    direction = "minimize"
    objective = {kind = "script", path = "scripts/objective.py", function = "objective"}
    method = {kind = "sweep", mode = "grid"}
    budget = {max_evals = 400, max_time_s = 7200, parallel = 1}
    [variables.w]
    lower = 1e-3
    upper = 4e-3
    steps = 21                 # a setting of the sweep method

    # dataset: sample Scene parameters and export one sample per point
    kind = "dataset"
    scene = "main"
    method = {kind = "monte_carlo", sampler = "sobol", samples = 20000}
    export = {kind = "script", path = "scripts/sample.py", function = "export"}
    dataset = {dir = "datasets/radar", shard_size = 500, splits = {train = 0.8, val = 0.1, test = 0.1}}
    [variables.target_range]
    lower = 5.0
    upper = 80.0

    # train: run a Project script that trains a model and logs metrics
    kind = "train"
    script = "scripts/train.py"
    args = {lr = 1e-3, batch_size = 64}
    inputs = {train = "datasets/radar"}
    metric = {name = "val/loss", direction = "minimize"}
    resources = {gpus = 1}

``variables`` names the Scene parameters the Study varies. Each table holds
the range every method shares (``lower``, ``upper``, ``step``, ``scale``)
and the settings of this Study's method, checked against that method's
``variable_schema``. A variable must be a free parameter (its formula reads
no other parameter); the run checks that against the Scene. ``method.kind``
names an entry of the method registry (``witwin.studio.optimize``); the
other ``method`` keys are its settings. ``tensors`` holds tensor design
variables (``optimize._tensors``); only the gradient method runs them.

``Study.from_dict`` is the one validator of the record shape; the
ProjectServer uses it too, so a record the SDK accepts is a record the server
accepts.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Mapping

from ._errors import ErrorCode, StudyError, invalid

GRADIENT_KIND = "gradient"
# A Study id is its file name: lowercase letters, digits, "-" and "_".
STUDY_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
# Keys every variable table may hold whatever the method; the rest are the method's.
VARIABLE_RANGE_KEYS = ("lower", "upper", "step", "scale")
LINEAR = "linear"
LOG = "log"

__all__ = [
    "Budget", "DatasetSettings", "Direction", "ErrorCode", "GradientOptimizer", "MethodSettings",
    "MetricGoal", "ObjectiveKind", "ObjectiveRef", "OnError", "Resources", "Study", "StudyError",
    "StudyKind",
]


class StudyKind(StrEnum):
    OPTIMIZE = "optimize"
    DATASET = "dataset"
    TRAIN = "train"


class Direction(StrEnum):
    MINIMIZE = "minimize"
    MAXIMIZE = "maximize"


class GradientOptimizer(StrEnum):
    """``method.optimizer`` of the gradient method: three torch ones and MMA."""
    ADAM = "adam"
    SGD = "sgd"
    LBFGS = "lbfgs"
    MMA = "mma"  # Method of Moving Asymptotes (``optimize._mma``); needs bounds, honours constraints


class ObjectiveKind(StrEnum):
    SCRIPT = "script"  # a function in a ``.py`` file of the Project
    PLUGIN = "plugin"  # an entry point of group ``witwin.objectives``


class OnError(StrEnum):
    """What a black-box or dataset run does when one evaluation fails."""
    SKIP = "skip"  # record it with status "failed" and go on
    STOP = "stop"  # end the run with stopped_by "error"


# Keys each kind reads; ``id``, ``name``, ``kind`` and ``resources`` belong to every kind.
_KIND_KEYS = {
    StudyKind.OPTIMIZE: {"scene", "variables", "method", "budget", "seed", "on_error", "direction",
                         "objective", "tensors"},
    StudyKind.DATASET: {"scene", "variables", "method", "budget", "seed", "on_error", "export", "dataset"},
    StudyKind.TRAIN: {"script", "args", "inputs", "metric"},
}
_COMMON_KEYS = {"id", "name", "kind", "resources"}
_DEFAULT_METHOD = {StudyKind.OPTIMIZE: GRADIENT_KIND, StudyKind.DATASET: "monte_carlo"}


@dataclass(frozen=True)
class MethodSettings:
    """``method`` of a Study: the registry ``kind`` and that method's settings.

    ``settings`` holds every key but ``kind``, with the method's schema
    defaults filled in. A kind no installed package registers is kept with
    its settings unchecked, so a record survives a missing Plugin; running it
    raises ``method_not_found``.
    """
    kind: str = GRADIENT_KIND
    settings: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "MethodSettings":
        """Validate a record's ``method`` table."""
        _require_mapping(data, "method")
        kind = _text(data.get("kind", GRADIENT_KIND), "method.kind")
        if not all(part.isidentifier() for part in kind.split(".")):
            raise invalid(f"method.kind must be a name like 'sweep' or 'my_pkg.annealing', not {kind!r}")
        from ..optimize._strategies import check_method_settings

        settings = {key: value for key, value in data.items() if key != "kind"}
        return cls(kind, check_method_settings(kind, settings))

    # Record form: ``{kind, **settings}``.
    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, **_plain(self.settings)}

    # One setting, or ``default`` when it is not set.
    def get(self, key: str, default: Any = None) -> Any:
        return self.settings.get(key, default)


@dataclass(frozen=True)
class Budget:
    """When a run stops at the latest.

    ``max_evals``: objective evaluations (dataset samples), >= 1 (a gradient
    step is one evaluation); None leaves it to the method (sweep size,
    generations ...). ``max_time_s``: wall-clock seconds, > 0; None is
    unlimited. ``parallel``: evaluations run at once, >= 1 (black-box and
    dataset runs; see ``optimize._evaluators``).
    """
    max_evals: int | None = None
    max_time_s: float | None = None
    parallel: int = 1

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Budget":
        _require_mapping(data, "budget")
        max_evals = data.get("max_evals")
        if max_evals is not None and not _whole(max_evals, 1):
            raise invalid(f"budget.max_evals must be a whole number >= 1, not {max_evals!r}")
        max_time = data.get("max_time_s")
        if max_time is not None and _number(max_time, "budget.max_time_s") <= 0:
            raise invalid(f"budget.max_time_s must be > 0, not {max_time!r}")
        parallel = data.get("parallel", 1)
        if not _whole(parallel, 1):
            raise invalid(f"budget.parallel must be a whole number >= 1, not {parallel!r}")
        return cls(max_evals, None if max_time is None else float(max_time), parallel)

    # Record form; keys at their default are left out, so an unset budget is ``{}``.
    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        if self.max_evals is not None:
            out["max_evals"] = self.max_evals
        if self.max_time_s is not None:
            out["max_time_s"] = self.max_time_s
        if self.parallel != 1:
            out["parallel"] = self.parallel
        return out


@dataclass(frozen=True)
class Resources:
    """What a Run of the Study holds while it runs. ``gpus``: GPUs from the Run queue's pool, >= 0."""
    gpus: int = 0

    @classmethod
    def from_dict(cls, data: Mapping[str, Any], default_gpus: int) -> "Resources":
        _require_mapping(data, "resources")
        gpus = data.get("gpus", default_gpus)
        if not _whole(gpus, 0):
            raise invalid(f"resources.gpus must be a whole number >= 0, not {gpus!r}")
        return cls(gpus)

    def to_dict(self) -> dict[str, Any]:
        return {"gpus": self.gpus}


@dataclass(frozen=True)
class ObjectiveRef:
    """Where a function the run calls comes from: the objective, or a dataset's export.

    Script: ``path`` is relative to the Project root (``scripts/objective.py``)
    and ``function`` names a function in it. Plugin: ``id`` is the registered
    objective id and ``args`` its keyword arguments.
    """
    kind: ObjectiveKind
    path: str = ""
    function: str = "objective"
    id: str = ""
    args: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any], what: str = "objective",
                  default_function: str = "objective") -> "ObjectiveRef":
        """Validate a record's ``objective`` (or ``export``) table."""
        _require_mapping(data, what)
        kind = _choice(ObjectiveKind, data.get("kind"), f"{what}.kind")
        if kind is ObjectiveKind.SCRIPT:
            path = _text(data.get("path"), f"{what}.path")
            function = _text(data.get("function", default_function), f"{what}.function")
            if not function.isidentifier():
                raise invalid(f"{what}.function must be a Python name, not {function!r}")
            return cls(kind, path=path, function=function)
        args = data.get("args", {})
        _require_mapping(args, f"{what}.args")
        return cls(kind, id=_text(data.get("id"), f"{what}.id"), args=dict(args))

    # Record form: script ``{kind, path, function}``, plugin ``{kind, id, args}``.
    def to_dict(self) -> dict[str, Any]:
        if self.kind is ObjectiveKind.SCRIPT:
            return {"kind": str(self.kind), "path": self.path, "function": self.function}
        return {"kind": str(self.kind), "id": self.id, "args": dict(self.args)}


@dataclass(frozen=True)
class DatasetSettings:
    """``dataset`` of a dataset Study: where the samples go and how they are split.

    ``dir`` is relative to the Project root (default ``datasets/<study id>``).
    ``shard_size`` samples go in one shard file, >= 1; a shard is the unit a
    resumed run keeps or redoes. ``splits`` maps a split name to its share;
    the shares are > 0 and add up to 1.
    """
    dir: str
    shard_size: int = 500
    splits: Mapping[str, float] = field(default_factory=lambda: {"train": 0.8, "val": 0.1, "test": 0.1})

    @classmethod
    def from_dict(cls, data: Mapping[str, Any], study_id: str) -> "DatasetSettings":
        _require_mapping(data, "dataset")
        folder = _text(data.get("dir", f"datasets/{study_id}"), "dataset.dir")
        if folder.startswith(("/", "\\")) or ".." in re.split(r"[\\/]", folder) or ":" in folder:
            raise invalid(f"dataset.dir must be a folder inside the Project, not {folder!r}")
        shard_size = data.get("shard_size", 500)
        if not _whole(shard_size, 1):
            raise invalid(f"dataset.shard_size must be a whole number >= 1, not {shard_size!r}")
        splits = data.get("splits")
        if splits is None:
            return cls(folder, shard_size)
        _require_mapping(splits, "dataset.splits")
        shares = {}
        for name, share in splits.items():
            if not isinstance(name, str) or not name.isidentifier():
                raise invalid(f"dataset.splits keys must be names like 'train', not {name!r}")
            if _number(share, f"dataset.splits.{name}") <= 0:
                raise invalid(f"dataset.splits.{name} must be > 0, not {share!r}")
            shares[name] = float(share)
        if not shares or abs(sum(shares.values()) - 1.0) > 1e-6:
            raise invalid(f"dataset.splits must add up to 1, not {sum(shares.values()):g}")
        return cls(folder, shard_size, shares)

    def to_dict(self) -> dict[str, Any]:
        return {"dir": self.dir, "shard_size": self.shard_size, "splits": dict(self.splits)}


@dataclass(frozen=True)
class MetricGoal:
    """``metric`` of a train Study: the logged metric that ranks its Runs, and which way is better."""
    name: str
    direction: Direction = Direction.MINIMIZE

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "MetricGoal":
        _require_mapping(data, "metric")
        return cls(_text(data.get("name"), "metric.name"),
                   _choice(Direction, data.get("direction", Direction.MINIMIZE), "metric.direction"))

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "direction": str(self.direction)}


@dataclass(frozen=True)
class Study:
    """One Study of a Project; fields a kind does not use keep their defaults.

    ``scene`` is the Scene id of an optimize or dataset Study, None for a
    train one. ``objective`` is None only for an optimize Study built in code
    and run with an explicit ``objective=`` function (``optimize.run``); a
    saved record always has one. ``seed`` makes random methods repeatable;
    None picks one per run.
    """
    id: str
    name: str
    kind: StudyKind = StudyKind.OPTIMIZE
    resources: Resources = Resources()
    scene: str | None = None
    variables: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    method: MethodSettings = field(default_factory=MethodSettings)
    budget: Budget = Budget()
    seed: int | None = None
    on_error: OnError = OnError.SKIP
    direction: Direction = Direction.MINIMIZE
    objective: ObjectiveRef | None = None
    tensors: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    export: ObjectiveRef | None = None
    dataset: DatasetSettings | None = None
    script: str | None = None
    args: Mapping[str, Any] = field(default_factory=dict)
    inputs: Mapping[str, str] = field(default_factory=dict)
    metric: MetricGoal | None = None

    @classmethod
    def from_dict(cls, data: Mapping[str, Any], *, require_objective: bool = True) -> "Study":
        """Validate a record; raises ``StudyError(invalid_study)``.

        ``id`` is required; a missing ``name`` is the id, a missing ``kind``
        is ``optimize``. A key the kind does not use is refused, so a typo
        never silently does nothing.
        """
        _require_mapping(data, "study")
        study_id = _text(data.get("id"), "id")
        if not STUDY_ID_PATTERN.match(study_id):
            raise invalid(f"id must be lowercase letters, digits, '-' and '_', not {study_id!r}")
        kind = _choice(StudyKind, data.get("kind", StudyKind.OPTIMIZE), "kind")
        allowed = _COMMON_KEYS | _KIND_KEYS[kind]
        stray = sorted(key for key, value in data.items() if key not in allowed and value is not None)
        if stray:
            raise invalid(f"{', '.join(stray)} does not apply to a {kind} Study")
        fields: dict[str, Any] = {
            "id": study_id,
            "name": _text(data.get("name", study_id), "name"),
            "kind": kind,
            "resources": Resources.from_dict(data.get("resources") or {},
                                             1 if kind is StudyKind.TRAIN else 0),
        }
        if kind is StudyKind.TRAIN:
            fields.update(_train_fields(data))
        else:
            fields.update(_sampled_fields(data, kind, study_id, require_objective))
        return cls(**fields)

    def to_dict(self) -> dict[str, Any]:
        """Record form, the content of ``studies/<id>.toml``; empty optional tables are left out."""
        record: dict[str, Any] = {"id": self.id, "name": self.name, "kind": str(self.kind)}
        if self.kind is StudyKind.TRAIN:
            record["script"] = self.script
            if self.args:
                record["args"] = _plain(self.args)
            if self.inputs:
                record["inputs"] = dict(self.inputs)
            if self.metric is not None:
                record["metric"] = self.metric.to_dict()
        else:
            record["scene"] = self.scene
            if self.kind is StudyKind.OPTIMIZE:
                record["direction"] = str(self.direction)
                if self.objective is not None:
                    record["objective"] = self.objective.to_dict()
            else:
                record["export"] = self.export.to_dict() if self.export is not None else None
                record["dataset"] = self.dataset.to_dict() if self.dataset is not None else None
            record["method"] = self.method.to_dict()
            budget = self.budget.to_dict()
            if budget:
                record["budget"] = budget
            if self.seed is not None:
                record["seed"] = self.seed
            record["on_error"] = str(self.on_error)
            if self.variables:
                record["variables"] = {name: _plain(settings) for name, settings in self.variables.items()}
            if self.tensors:
                record["tensors"] = {name: _plain(settings) for name, settings in self.tensors.items()}
        record["resources"] = self.resources.to_dict()
        return record

    def updated(self, changes: Mapping[str, Any]) -> "Study":
        """A validated copy with the fields in ``changes`` replaced.

        ``method`` merges key by key into the current method when its
        ``kind`` is absent or the same, and replaces it (other settings back
        to their defaults) when the kind changes. ``budget``, ``resources`` and
        ``dataset`` merge key by key. Inside those tables a key set to None
        goes back to its default. Every other key replaces the field. A
        top-level key set to None goes back to its default too (``seed=None``
        lets each Run draw its own seed); ``id`` and ``kind`` cannot change.
        """
        record = self.to_dict()
        for key, value in changes.items():
            if key in ("id", "kind"):
                continue
            if value is None:
                record.pop(key, None)
                continue
            if key == "method":
                _require_mapping(value, "method")
                kind = value.get("kind") or self.method.kind
                base = record["method"] if kind == self.method.kind else {}
                record["method"] = _without_none({**base, **value, "kind": kind})
            elif key in ("budget", "resources", "dataset"):
                _require_mapping(value, key)
                record[key] = _without_none({**(record.get(key) or {}), **value})
            else:
                record[key] = value
        return Study.from_dict(record, require_objective=self.objective is not None
                               or self.kind is not StudyKind.OPTIMIZE)

    def renamed_variable(self, old: str, new: str) -> "Study":
        """A copy that names parameter ``old`` as ``new``; ``self`` when it never names ``old``.

        A Study names its variables by parameter name, so whoever renames a
        parameter of the Study's Scene calls this (the ProjectServer does it
        in ``parameter_update``). It rewrites the ``variables`` key and the
        keys of a ``rows`` table list in the method settings (the
        ``custom_sweep`` table source). A CSV file or a ``points`` script is
        Project content and keeps the old name.
        """
        if old == new or self.kind is StudyKind.TRAIN:
            return self
        record = self.to_dict()
        changed = False
        variables = record.get("variables") or {}
        if old in variables:
            record["variables"] = {new if name == old else name: s for name, s in variables.items()}
            changed = True
        rows = record["method"].get("rows")
        if isinstance(rows, list) and any(isinstance(row, Mapping) and old in row for row in rows):
            record["method"]["rows"] = [
                {new if name == old else name: value for name, value in row.items()}
                if isinstance(row, Mapping) else row for row in rows]
            changed = True
        if not changed:
            return self
        return Study.from_dict(record, require_objective=self.objective is not None
                               or self.kind is not StudyKind.OPTIMIZE)

    def without_variable(self, name: str) -> "Study":
        """A copy that no longer varies parameter ``name``; ``self`` when it never named it.

        Whoever deletes a parameter of the Study's Scene calls this (the
        ProjectServer does it in ``parameter_delete``), so the next Run does
        not fail with ``variable_not_found``. It drops the ``variables`` entry
        and that key of every ``rows`` entry (``custom_sweep``). A Study left
        with no variable stays valid on disk; a Run of it refuses with
        ``no_variables``.
        """
        if self.kind is StudyKind.TRAIN:
            return self
        record = self.to_dict()
        changed = False
        variables = record.get("variables") or {}
        if name in variables:
            record["variables"] = {key: s for key, s in variables.items() if key != name}
            changed = True
        rows = record["method"].get("rows")
        if isinstance(rows, list) and any(isinstance(row, Mapping) and name in row for row in rows):
            record["method"]["rows"] = [
                {key: value for key, value in row.items() if key != name}
                if isinstance(row, Mapping) else row for row in rows]
            changed = True
        if not changed:
            return self
        return Study.from_dict(record, require_objective=self.objective is not None
                               or self.kind is not StudyKind.OPTIMIZE)


# The fields of an optimize or dataset Study.
def _sampled_fields(data: Mapping[str, Any], kind: StudyKind, study_id: str,
                    require_objective: bool) -> dict[str, Any]:
    method = MethodSettings.from_dict(data.get("method") or {"kind": _DEFAULT_METHOD[kind]})
    seed = data.get("seed")
    if seed is not None and not _whole(seed, 0):
        raise invalid(f"seed must be a whole number >= 0, not {seed!r}")
    fields: dict[str, Any] = {
        "scene": _text(data.get("scene"), "scene"),
        "variables": _variables(data.get("variables") or {}, method.kind),
        "method": method,
        "budget": Budget.from_dict(data.get("budget") or {}),
        "seed": seed,
        "on_error": _choice(OnError, data.get("on_error", OnError.SKIP), "on_error"),
    }
    if kind is StudyKind.OPTIMIZE:
        objective = data.get("objective")
        if objective is None and require_objective:
            raise invalid("an optimize Study needs an objective")
        fields["direction"] = _choice(Direction, data.get("direction", Direction.MINIMIZE), "direction")
        fields["objective"] = None if objective is None else ObjectiveRef.from_dict(objective)
        fields["tensors"] = _tensors(data.get("tensors") or {})
    else:
        export = data.get("export")
        if export is None:
            raise invalid("a dataset Study needs an export function")
        fields["export"] = ObjectiveRef.from_dict(export, "export", "export")
        fields["dataset"] = DatasetSettings.from_dict(data.get("dataset") or {}, study_id)
    return fields


# The fields of a train Study.
def _train_fields(data: Mapping[str, Any]) -> dict[str, Any]:
    script = _text(data.get("script"), "script")
    if not script.endswith(".py"):
        raise invalid(f"script must be a .py file of the Project, not {script!r}")
    args = data.get("args") or {}
    _require_mapping(args, "args")
    for name, value in args.items():
        if not isinstance(name, str) or not re.match(r"^[A-Za-z_][A-Za-z0-9_-]*$", name):
            raise invalid(f"args keys must be option names like 'lr', not {name!r}")
        if not _arg_value(value):
            raise invalid(f"args.{name} must be a number, string, bool or a list of them, not {value!r}")
    inputs = data.get("inputs") or {}
    _require_mapping(inputs, "inputs")
    for name, path in inputs.items():
        if not isinstance(name, str) or not name.isidentifier():
            raise invalid(f"inputs keys must be names like 'train', not {name!r}")
        _text(path, f"inputs.{name}")
    metric = data.get("metric")
    return {"script": script, "args": _plain(args), "inputs": dict(inputs),
            "metric": None if metric is None else MetricGoal.from_dict(metric)}


# A command-line value: a scalar, or a flat list of scalars.
def _arg_value(value: Any) -> bool:
    if isinstance(value, (list, tuple)):
        return all(_arg_value(item) and not isinstance(item, (list, tuple)) for item in value)
    if isinstance(value, float):
        return math.isfinite(value)
    return isinstance(value, (str, int, bool))


# ``variables``: parameter name -> range keys plus the method's per-variable settings.
def _variables(data: Any, kind: str) -> dict[str, dict[str, Any]]:
    _require_mapping(data, "variables")
    from ..optimize._strategies import check_variable_settings

    out: dict[str, dict[str, Any]] = {}
    for name, settings in data.items():
        if not isinstance(name, str) or not name.isidentifier():
            raise invalid(f"variables keys must be parameter names, not {name!r}")
        settings = settings or {}
        _require_mapping(settings, f"variables.{name}")
        own = {key: value for key, value in settings.items() if key not in VARIABLE_RANGE_KEYS}
        out[name] = {**_variable_range(settings, f"variables.{name}"),
                     **check_variable_settings(kind, own, f"variables.{name}")}
    return out


# The range keys of one variable table, checked: lower <= upper, step > 0, a log scale needs lower > 0.
def _variable_range(settings: Mapping[str, Any], what: str) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key in ("lower", "upper", "step"):
        if settings.get(key) is not None:
            out[key] = _number(settings[key], f"{what}.{key}")
    if "lower" in out and "upper" in out and out["lower"] > out["upper"]:
        raise invalid(f"{what}: lower {out['lower']:g} is above upper {out['upper']:g}")
    if "step" in out and out["step"] <= 0:
        raise invalid(f"{what}.step must be > 0, not {out['step']:g}")
    scale = settings.get("scale", LINEAR)
    if scale not in (LINEAR, LOG):
        raise invalid(f"{what}.scale must be linear or log, not {scale!r}")
    if scale == LOG:
        if out.get("lower") is None or out["lower"] <= 0:
            raise invalid(f"{what} uses a log scale, so its lower bound must be > 0")
        out["scale"] = LOG
    return out


# ``tensors``: tensor design variable id -> settings table (keys in ``optimize._tensors``).
def _tensors(data: Any) -> dict[str, dict[str, Any]]:
    _require_mapping(data, "tensors")
    from ..optimize._tensors import check_tensor

    return {tensor_id: check_tensor(tensor_id, settings) for tensor_id, settings in data.items()}


def _without_none(data: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in data.items() if value is not None}


# A deep plain-dict/list copy, so records never share nested containers with a Study.
def _plain(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    return value


def _require_mapping(value: Any, what: str) -> None:
    if not isinstance(value, Mapping):
        raise invalid(f"{what} must be a table, not {type(value).__name__}")


# A non-empty string field.
def _text(value: Any, what: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise invalid(f"{what} must be a non-empty string, not {value!r}")
    return value


# A finite real number field (bool is not a number here).
def _number(value: Any, what: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise invalid(f"{what} must be a finite number, not {value!r}")
    return float(value)


# A whole number >= ``least`` (bool is not a number here).
def _whole(value: Any, least: int) -> bool:
    return not isinstance(value, bool) and isinstance(value, int) and value >= least


# One member of a StrEnum, by value.
def _choice(enum: type[StrEnum], value: Any, what: str) -> Any:
    try:
        return enum(value)
    except ValueError:
        allowed = ", ".join(str(member) for member in enum)
        raise invalid(f"{what} must be one of {allowed}, not {value!r}") from None
