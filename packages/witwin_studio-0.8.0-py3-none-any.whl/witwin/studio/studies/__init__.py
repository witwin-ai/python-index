"""Studies: saved, re-runnable studies of a Project, one ``studies/<id>.toml`` each.

    import witwin.studio as ws

    project = ws.open_project(".")
    study = project.studies.add(
        "Fit width", scene="main",
        objective={"kind": "script", "path": "scripts/objective.py"},
        variables={"w": {"lower": 1e-3, "upper": 4e-3}},
        method={"kind": "bayesian"})
    for study in project.studies:
        print(study.id, study.kind)

A Study is one of three kinds (``StudyKind``):

- ``optimize``: vary Scene parameters to minimize or maximize an objective
  (``witwin.studio.optimize`` runs it);
- ``dataset``: sample Scene parameters and export one sample per point into a
  dataset folder;
- ``train``: run a Project script that trains a model and logs its metrics
  (``witwin.studio.tracking``).

``_model`` validates the record, ``_store`` reads and writes the files.
``python -m witwin.studio.studies`` is the process entry Studio's Runs use.
This package imports no solver and no torch.
"""
from __future__ import annotations

from ._errors import ErrorCode, StudyError
from ._model import (
    Budget,
    DatasetSettings,
    Direction,
    GradientOptimizer,
    MethodSettings,
    MetricGoal,
    ObjectiveKind,
    ObjectiveRef,
    OnError,
    Resources,
    Study,
    StudyKind,
)
from ._store import FOLDER, StudyStore

__all__ = [
    "FOLDER", "Budget", "DatasetSettings", "Direction", "ErrorCode", "GradientOptimizer", "MethodSettings",
    "MetricGoal", "ObjectiveKind", "ObjectiveRef", "OnError", "Resources", "Study", "StudyError",
    "StudyKind", "StudyStore",
]
