"""``.witwin/runtime/server.json``: which ProjectServer serves this folder.

The ProjectServer writes the file once its socket is bound and removes it on
exit (``witwin_server.server_entry``). Code that opens the Project headless
reads it to attach instead of starting a second solver child next to the
editor's (design section 3.3, "Attach mode").

A crashed server leaves the file behind, so a record only counts when its
process is alive and ``GET /health`` answers for the same folder.

Format (JSON object): ``schema`` (``witwin.server.v1``), ``url``, ``host``,
``port``, ``pid``, ``projectDir``, ``projectId``, ``startedAt`` (ISO 8601)
and ``token`` (the bearer token, or null). ``.witwin/runtime`` is local state:
gitignored and never uploaded to the cloud (``features/compute/snapshot.py``).
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

SCHEMA = "witwin.server.v1"
RECORD_PARTS = (".witwin", "runtime", "server.json")


@dataclass(frozen=True)
class ServerRecord:
    url: str
    pid: int
    project_dir: str
    project_id: Optional[str] = None
    token: Optional[str] = None
    started_at: Optional[str] = None

    def headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self.token}"} if self.token else {}


def record_path(project_root: Path) -> Path:
    return Path(project_root).joinpath(*RECORD_PARTS)


def _client_host(host: str) -> str:
    # A server bound to every interface is reached on loopback from this machine.
    if host in ("", "0.0.0.0"):
        return "127.0.0.1"
    if host == "::":
        return "[::1]"
    return f"[{host}]" if ":" in host and not host.startswith("[") else host


def write_server_record(
    project_root: Path,
    *,
    host: str,
    port: int,
    project_id: Optional[str] = None,
    token: Optional[str] = None,
    pid: Optional[int] = None,
) -> Path:
    path = record_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    data: Dict[str, Any] = {
        "schema": SCHEMA,
        "url": f"http://{_client_host(host)}:{int(port)}",
        "host": host,
        "port": int(port),
        "pid": int(pid if pid is not None else os.getpid()),
        "projectDir": str(Path(project_root).resolve()),
        "projectId": project_id,
        "startedAt": datetime.now(timezone.utc).isoformat(),
        "token": token,
    }
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(path)
    return path


def remove_server_record(project_root: Path, *, pid: Optional[int] = None) -> bool:
    """Remove the record if it is this process's (a newer server may have replaced it)."""
    path = record_path(project_root)
    record = read_server_record(project_root)
    if record is None or record.pid != int(pid if pid is not None else os.getpid()):
        return False
    path.unlink(missing_ok=True)
    return True


def read_server_record(project_root: Path) -> Optional[ServerRecord]:
    path = record_path(project_root)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("schema") != SCHEMA or not data.get("url"):
        return None
    try:
        return ServerRecord(
            url=str(data["url"]).rstrip("/"),
            pid=int(data["pid"]),
            project_dir=str(data.get("projectDir") or ""),
            project_id=data.get("projectId"),
            token=data.get("token"),
            started_at=data.get("startedAt"),
        )
    except (KeyError, TypeError, ValueError):
        return None


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes

        process_query_limited_information = 0x1000
        still_active = 259
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(process_query_limited_information, False, pid)
        if not handle:
            return False
        try:
            code = ctypes.c_ulong()
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(code)):
                return False
            return code.value == still_active
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _same_folder(a: str, b: Path) -> bool:
    try:
        return os.path.normcase(str(Path(a).resolve())) == os.path.normcase(str(Path(b).resolve()))
    except OSError:
        return False


def running_server(project_root: Path, *, timeout: float = 2.0) -> Optional[ServerRecord]:
    """The live ProjectServer serving ``project_root``, or None."""
    record = read_server_record(project_root)
    if record is None or not _pid_alive(record.pid) or not _same_folder(record.project_dir, project_root):
        return None
    request = urllib.request.Request(f"{record.url}/health", headers=record.headers())
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            health = json.loads(response.read().decode("utf-8"))
    except (OSError, ValueError, urllib.error.URLError):
        return None
    served = health.get("project_path") if isinstance(health, dict) else None
    if served and not _same_folder(str(served), project_root):
        return None
    return record
