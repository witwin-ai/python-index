"""Backend adapter subpackage."""
