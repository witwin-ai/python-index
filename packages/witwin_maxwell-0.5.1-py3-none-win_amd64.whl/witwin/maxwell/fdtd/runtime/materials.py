from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch

from ...compiler.materials import (
    evaluate_material_permeability,
    evaluate_material_permittivity,
    material_model_has_full_anisotropy,
    material_model_has_modulation,
    material_model_has_nonlinearity,
)
from ..boundary import BOUNDARY_PERIODIC, has_complex_fields


def build_materials(solver, scene):
    material_model = scene.compile_materials()
    # A Bloch-periodic run carries complex phase-shifted field state. The
    # instantaneous |E|^2 nonlinearity, the additive off-diagonal anisotropic
    # curl correction, and the per-step modulation factor are all implemented on
    # the real-valued Yee update kernels, and their coefficients are undefined on
    # a complex field (|E|^2 is not analytic, and the real additive/scaling
    # corrections would break the Bloch phase). Each needs a complex-field kernel
    # variant before it can compose with Bloch periodicity.
    if scene.boundary.uses_kind("bloch") and material_model_has_nonlinearity(material_model):
        raise NotImplementedError(
            "FDTD nonlinear media require the real-valued update kernels: a Bloch-periodic run carries "
            "complex phase-shifted fields, for which the instantaneous |E|^2 Kerr/chi2/TPA coefficient is "
            "not defined. Use a real-field boundary (PML/PEC/PMC/periodic) with the nonlinearity."
        )
    if scene.boundary.uses_kind("bloch") and material_model_has_full_anisotropy(material_model):
        raise NotImplementedError(
            "FDTD full (off-diagonal) anisotropic media use a real additive curl(H) correction: a "
            "Bloch-periodic run carries complex phase-shifted fields, and applying the real off-diagonal "
            "correction to a complex field would break the Bloch phase relation. Use a real-field boundary "
            "(PML/PEC/PMC/periodic) or an axis-aligned DiagonalTensor3."
        )
    if scene.boundary.uses_kind("bloch") and material_model_has_modulation(material_model):
        raise NotImplementedError(
            "FDTD time-modulated media scale the real-valued update coefficients by a per-step modulation "
            "factor: a Bloch-periodic run carries complex phase-shifted fields, and the real scaling does "
            "not track the complex Bloch phase. Use a real-field boundary (PML/PEC/PMC/periodic) with the "
            "modulation."
        )

    solver._compiled_material_model = material_model
    eps_components = material_model["eps_components"]
    mu_components = material_model["mu_components"]
    solver.epsilon_r_components = eps_components
    solver.mu_r_components = mu_components
    solver.epsilon_r = material_model["eps_r"]
    solver.mu_r = material_model["mu_r"]
    solver.material_eps_r = evaluate_material_permittivity(material_model, solver.source_frequency)
    solver.material_mu_r = evaluate_material_permeability(material_model, solver.source_frequency)

    sigma_e_components = material_model["sigma_e_components"]
    sigma_m_components = material_model["sigma_m_components"]
    edge_components = material_model.get("edge_components")
    if edge_components is not None:
        # Edge-native path: the compiler evaluated the diagonal permittivity /
        # permeability and the static conductivities at each Yee component's own
        # staggered location (SDF occupancy, interface normal and region density
        # sampled there), so no node->edge average is applied. These fields carry
        # the interface subpixel blend natively at the edge/face where the update
        # coefficient consumes it.
        eps_edge = edge_components["eps"]
        mu_edge = edge_components["mu"]
        sigma_e_edge = edge_components["sigma_e"]
        sigma_m_edge = edge_components["sigma_m"]
        solver.eps_Ex = (eps_edge["Ex"] * solver.eps0).contiguous()
        solver.eps_Ey = (eps_edge["Ey"] * solver.eps0).contiguous()
        solver.eps_Ez = (eps_edge["Ez"] * solver.eps0).contiguous()
        solver.sigma_e_Ex = sigma_e_edge["Ex"]
        solver.sigma_e_Ey = sigma_e_edge["Ey"]
        solver.sigma_e_Ez = sigma_e_edge["Ez"]
        solver.mu_Hx = (mu_edge["Hx"] * solver.mu0).contiguous()
        solver.mu_Hy = (mu_edge["Hy"] * solver.mu0).contiguous()
        solver.mu_Hz = (mu_edge["Hz"] * solver.mu0).contiguous()
        solver.sigma_m_Hx = sigma_m_edge["Hx"]
        solver.sigma_m_Hy = sigma_m_edge["Hy"]
        solver.sigma_m_Hz = sigma_m_edge["Hz"]
    else:
        # Node->edge fallback retained for material families whose per-Yee-component
        # sampling is not yet edge-native (full off-diagonal anisotropy, sheets,
        # surface-impedance metals): the node-centered Kottke blend is arithmetically
        # averaged onto the Yee edges/faces. PerturbationMedium is edge-native and
        # takes the branch above (its eps offset is sampled at the Yee edge).
        eps_x_node = eps_components["x"] * solver.eps0
        eps_y_node = eps_components["y"] * solver.eps0
        eps_z_node = eps_components["z"] * solver.eps0
        mu_x_node = mu_components["x"] * solver.mu0
        mu_y_node = mu_components["y"] * solver.mu0
        mu_z_node = mu_components["z"] * solver.mu0
        solver.eps_Ex = average_node_to_component(solver, eps_x_node, "Ex")
        solver.eps_Ey = average_node_to_component(solver, eps_y_node, "Ey")
        solver.eps_Ez = average_node_to_component(solver, eps_z_node, "Ez")
        solver.sigma_e_Ex = average_node_to_component(solver, sigma_e_components["x"], "Ex")
        solver.sigma_e_Ey = average_node_to_component(solver, sigma_e_components["y"], "Ey")
        solver.sigma_e_Ez = average_node_to_component(solver, sigma_e_components["z"], "Ez")
        solver.mu_Hx = average_node_to_magnetic_component(solver, mu_x_node, "Hx")
        solver.mu_Hy = average_node_to_magnetic_component(solver, mu_y_node, "Hy")
        solver.mu_Hz = average_node_to_magnetic_component(solver, mu_z_node, "Hz")
        # Static magnetic conductivity averaged onto the H components (same node->face
        # stencil as mu): folds semi-implicitly into the H-update decay/curl exactly as
        # sigma_e folds into the E-update, giving a magnetic conduction loss on Faraday's law.
        solver.sigma_m_Hx = average_node_to_magnetic_component(solver, sigma_m_components["x"], "Hx")
        solver.sigma_m_Hy = average_node_to_magnetic_component(solver, sigma_m_components["y"], "Hy")
        solver.sigma_m_Hz = average_node_to_magnetic_component(solver, sigma_m_components["z"], "Hz")
    # Derive the conduction flags from the per-component fields actually installed
    # on the solver (edge-native or node->edge averaged), not from the node model,
    # so the flag provenance matches the coefficients the update kernels consume.
    solver.conductive_enabled = bool(
        torch.any(solver.sigma_e_Ex != 0).item()
        or torch.any(solver.sigma_e_Ey != 0).item()
        or torch.any(solver.sigma_e_Ez != 0).item()
    )
    solver.magnetically_conductive_enabled = bool(
        torch.any(solver.sigma_m_Hx != 0).item()
        or torch.any(solver.sigma_m_Hy != 0).item()
        or torch.any(solver.sigma_m_Hz != 0).item()
    )

    build_nonlinear_channels(solver, material_model)

    solver.full_aniso_enabled = bool(material_model_has_full_anisotropy(material_model))
    solver.modulation_enabled = bool(material_model_has_modulation(material_model))
    solver.dispersive_enabled = any(material_model.get(prefix + kind + "_poles")
        for prefix in ("", "mu_") for kind in ("debye", "drude", "lorentz"))

    from .timestep import compile_fdtd_time_step

    compile_fdtd_time_step(solver, material_model)


def build_material_update_coefficients(solver):
    """Bind every material recurrence only after the joint step is final."""
    material_model = solver._compiled_material_model

    build_full_anisotropy(solver, material_model)

    build_modulation(solver, material_model)

    build_dispersive_templates(solver, material_model)
    build_magnetic_dispersive_templates(solver, material_model)
    # Gyromagnetic (Polder) ferrite: the background eps/mu_inf/sigma already
    # compiled through the diagonal path above; this only wires the local
    # magnetization-ADE state that produces the non-reciprocal off-diagonal mu.
    from .gyromagnetic import build_gyromagnetic

    build_gyromagnetic(solver, solver.scene)
    solver.dispersive_enabled = solver.electric_dispersive_enabled or solver.magnetic_dispersive_enabled
    # Full (off-diagonal) anisotropic permittivity now composes with dispersion:
    # electric poles enter isotropically and the ADE polarization current is folded
    # through the same reciprocal inverse-material operator as curl(H) (see
    # _apply_aniso_dispersive_corrections); magnetic dispersion is an independent
    # H-side channel and does not touch the electric tensor.
    # Space-time modulation now composes with electric/magnetic dispersion and with
    # the instantaneous nonlinear channels: the modulation scales the eps_inf
    # background (the modulated E-update coefficients) while the ADE polarization
    # current and the field-dependent nonlinear coefficients are folded through the
    # same per-step 1/m_next factor, so a modulated dispersive/nonlinear cell stays
    # mutually consistent (electro-optic-modulator physics). The full off-diagonal
    # anisotropic tensor is the one edge left out: modulating the crystal-frame
    # tensor would require a per-step re-inversion of the coupled 3x3 permittivity,
    # which the current diagonalized effective-eps + additive off-diagonal split
    # cannot express.
    if solver.modulation_enabled and solver.full_aniso_enabled:
        raise NotImplementedError(
            "FDTD time-modulated media cannot be combined with full (off-diagonal) anisotropic "
            "media: modulating the crystal-frame permittivity tensor needs a per-step re-inversion "
            "of the coupled 3x3 tensor, which the diagonalized effective-permittivity update path "
            "does not provide. Use a diagonal (axis-aligned) tensor or drop the modulation."
        )


def build_nonlinear_channels(solver, material_model):
    """Set the nonlinear feature flags and edge-averaged nonlinear channel fields.

    ``kerr_enabled`` marks the instantaneous chi3 (Kerr) channel and keeps the
    existing dynamic-curl fast path when it is the only nonlinearity.
    ``nonlinear_general_enabled`` switches to the general nonlinear coefficient
    kernel, which additionally handles the chi2 channel and a field-dependent
    conductivity and therefore rewrites both the decay and curl coefficients
    every step.
    """
    solver.kerr_enabled = bool(torch.any(material_model["kerr_chi3"] != 0).item())
    solver.chi2_enabled = bool(torch.any(material_model["chi2"] != 0).item())
    solver.tpa_enabled = bool(torch.any(material_model["tpa_sigma"] != 0).item())
    solver.nonlinear_enabled = solver.kerr_enabled or solver.chi2_enabled or solver.tpa_enabled
    solver.nonlinear_general_enabled = solver.chi2_enabled or solver.tpa_enabled
    solver.kerr_chi3 = material_model["kerr_chi3"]
    if solver.nonlinear_enabled:
        solver.kerr_chi3_Ex = average_node_to_component(solver, solver.kerr_chi3, "Ex")
        solver.kerr_chi3_Ey = average_node_to_component(solver, solver.kerr_chi3, "Ey")
        solver.kerr_chi3_Ez = average_node_to_component(solver, solver.kerr_chi3, "Ez")
        solver.cex_curl_dynamic = torch.empty_like(solver.eps_Ex)
        solver.cey_curl_dynamic = torch.empty_like(solver.eps_Ey)
        solver.cez_curl_dynamic = torch.empty_like(solver.eps_Ez)
    else:
        solver.kerr_chi3_Ex = None
        solver.kerr_chi3_Ey = None
        solver.kerr_chi3_Ez = None
        solver.cex_curl_dynamic = None
        solver.cey_curl_dynamic = None
        solver.cez_curl_dynamic = None
    if solver.nonlinear_general_enabled:
        chi2 = material_model["chi2"]
        solver.nonlinear_chi2_Ex = average_node_to_component(solver, chi2, "Ex")
        solver.nonlinear_chi2_Ey = average_node_to_component(solver, chi2, "Ey")
        solver.nonlinear_chi2_Ez = average_node_to_component(solver, chi2, "Ez")
        # Field-dependent conductivity channel of the general nonlinear kernel:
        # sigma_NL = tpa_sigma * |E|^2, from TwoPhotonAbsorption descriptors.
        tpa_sigma = material_model["tpa_sigma"]
        solver.tpa_sigma_Ex = average_node_to_component(solver, tpa_sigma, "Ex")
        solver.tpa_sigma_Ey = average_node_to_component(solver, tpa_sigma, "Ey")
        solver.tpa_sigma_Ez = average_node_to_component(solver, tpa_sigma, "Ez")
        solver.cex_decay_dynamic = torch.empty_like(solver.eps_Ex)
        solver.cey_decay_dynamic = torch.empty_like(solver.eps_Ey)
        solver.cez_decay_dynamic = torch.empty_like(solver.eps_Ez)
    else:
        solver.nonlinear_chi2_Ex = None
        solver.nonlinear_chi2_Ey = None
        solver.nonlinear_chi2_Ez = None
        solver.tpa_sigma_Ex = None
        solver.tpa_sigma_Ey = None
        solver.tpa_sigma_Ez = None
        solver.cex_decay_dynamic = None
        solver.cey_decay_dynamic = None
        solver.cez_decay_dynamic = None


def build_modulation(solver, material_model):
    """Set the space-time modulation flag and its per-edge quadrature fields.

    The compiled ``modulation_cos`` / ``modulation_sin`` node fields
    (``amplitude*cos(phase)`` and ``amplitude*sin(phase)``) are averaged onto the
    Yee E edges once here; the per-step modulation factor
    ``m(t) = 1 + cos_field*cos(Omega*t) - sin_field*sin(Omega*t)`` is evaluated
    inside the modulated E-update kernels from these static fields and a persistent
    two-element device clock, so no coefficient tensor or host phase is rebuilt per
    step.
    """
    solver.modulation_enabled = bool(material_model_has_modulation(material_model))
    if not solver.modulation_enabled:
        solver._modulation_time = None
        solver.mod_cos_Ex = None
        solver.mod_cos_Ey = None
        solver.mod_cos_Ez = None
        solver.mod_sin_Ex = None
        solver.mod_sin_Ey = None
        solver.mod_sin_Ez = None
        solver.mod_omega_Ex = None
        solver.mod_omega_Ey = None
        solver.mod_omega_Ez = None
        return
    solver._modulation_time = torch.full(
        (2,), -float(solver.dt), device=solver.device, dtype=solver.Ex.dtype
    )
    modulation_cos = material_model["modulation_cos"]
    modulation_sin = material_model["modulation_sin"]
    modulation_omega = material_model["modulation_omega"]
    solver.mod_cos_Ex = average_node_to_component(solver, modulation_cos, "Ex")
    solver.mod_cos_Ey = average_node_to_component(solver, modulation_cos, "Ey")
    solver.mod_cos_Ez = average_node_to_component(solver, modulation_cos, "Ez")
    solver.mod_sin_Ex = average_node_to_component(solver, modulation_sin, "Ex")
    solver.mod_sin_Ey = average_node_to_component(solver, modulation_sin, "Ey")
    solver.mod_sin_Ez = average_node_to_component(solver, modulation_sin, "Ez")
    # Frequency is a per-cell label, not an amplitude: reduce it onto each Yee edge
    # with a MAX over the averaging stencil so a modulated/unmodulated interface
    # edge keeps the modulated cell's full angular frequency (its quadrature depth
    # already fades through the arithmetic cos/sin blend), letting disjoint
    # structures modulate at independent frequencies in one run.
    solver.mod_omega_Ex = _max_node_to_electric_component(modulation_omega, "Ex")
    solver.mod_omega_Ey = _max_node_to_electric_component(modulation_omega, "Ey")
    solver.mod_omega_Ez = _max_node_to_electric_component(modulation_omega, "Ez")


def _symmetric3_inverse(a, b, c, d, e, f):
    """Closed-form inverse of the symmetric 3x3 tensor [[a,d,e],[d,b,f],[e,f,c]].

    Returns the six independent entries of the (symmetric) inverse as a dict
    keyed by ``xx, yy, zz, xy, xz, yz`` plus the determinant for validation.
    """
    det = a * (b * c - f * f) - d * (d * c - f * e) + e * (d * f - b * e)
    inv_det = 1.0 / det
    return {
        "xx": (b * c - f * f) * inv_det,
        "yy": (a * c - e * e) * inv_det,
        "zz": (a * b - d * d) * inv_det,
        "xy": (e * f - d * c) * inv_det,
        "xz": (d * f - b * e) * inv_det,
        "yz": (d * e - a * f) * inv_det,
    }, det


def build_full_anisotropy(solver, material_model):
    """Assemble an energy-symmetric positive inverse material operator.

    Invert the tensor at nodes before scattering to Yee edges. With the weighted
    edge-to-node gather C and its volume-weighted transpose C*, the operator is
    C* A C plus each component's positive local weighted-variance term. Its
    diagonal is the endpoint average of A_ii; cross terms are C_i* A_ij C_j.
    Thus node bounds a I <= A <= b I also bound the assembled edge operator,
    including spatially varying tensors and nonuniform grids.
    """
    solver.full_aniso_enabled = bool(material_model_has_full_anisotropy(material_model))
    solver._aniso_eps_eff = None
    solver._aniso_inverse_nodes = None
    # Effective inverse permittivity (1/eps_eff) reused for the diagonal ADE
    # polarization-current subtraction, and the accumulated per-component
    # polarization current buffers used by the off-diagonal tensor subtraction.
    solver._aniso_disp_inv_eps = None
    solver._aniso_disp_current = None
    # Per-component conduction-current buffers (sigma . E at the pre-update field),
    # subtracted through the off-diagonal inverse tensor when the anisotropic
    # medium is also conductive; None otherwise.
    solver._aniso_cond_current = None
    solver._aniso_edge_open = None
    solver.cex_aniso_y = None
    solver.cex_aniso_z = None
    solver.cey_aniso_x = None
    solver.cey_aniso_z = None
    solver.cez_aniso_x = None
    solver.cez_aniso_y = None
    # Per-direction CPML psi accumulators for the off-diagonal coupling, allocated
    # only when the anisotropic structure runs under a CPML absorber; kept as
    # attributes so a graph capture snapshots them like the base CPML psi.
    for component in ("ex", "ey", "ez"):
        for axis in ("x", "y", "z"):
            setattr(solver, f"psi_{component}_aniso_{axis}", None)
    solver._full_aniso_cpml_overlap = False
    if not solver.full_aniso_enabled:
        return

    if solver.nonlinear_enabled:
        raise NotImplementedError(
            "FDTD full (off-diagonal) anisotropic media cannot be combined with nonlinear media."
        )

    eps_components = material_model["eps_components"]
    offdiag = material_model["eps_offdiag_components"]
    sigma_components = material_model["sigma_e_components"]
    node = {
        "xx": eps_components["x"],
        "yy": eps_components["y"],
        "zz": eps_components["z"],
        "xy": offdiag["xy"],
        "xz": offdiag["xz"],
        "yz": offdiag["yz"],
    }
    diagonal_key = {"Ex": "xx", "Ey": "yy", "Ez": "zz"}
    # The local conductive shift preserves node positive definiteness. Scattering
    # these local inverses is not a global implicit conduction solve; the joint
    # time-step bound also includes the explicit edge-current feedback rate.
    conductive = solver.conductive_enabled
    conductive_shift = solver.dt / (2.0 * solver.eps0)
    if conductive:
        for diag_key, axis in (("xx", "x"), ("yy", "y"), ("zz", "z")):
            node[diag_key] = node[diag_key] + conductive_shift * sigma_components[axis]
    inverse, det = _symmetric3_inverse(
        node["xx"], node["yy"], node["zz"], node["xy"], node["xz"], node["yz"]
    )
    solver._aniso_inverse_nodes = inverse
    solver._aniso_eps_eff = {}
    for target_axis, component_name in enumerate(("Ex", "Ey", "Ez")):
        diagonal_inverse = average_node_to_component(solver, inverse[diagonal_key[component_name]], component_name)
        if bool(torch.any(det <= 0).item()) or bool(torch.any(diagonal_inverse <= 0).item()):
            raise ValueError(
                "The blended anisotropic permittivity tensor is not positive-definite on the "
                f"{component_name} Yee edges; check overlapping structures and material regions."
            )
        # Effective scalar permittivity reproducing the diagonal inverse entry:
        # the base curl coefficient dt/eps_eff == dt * inv_diag / eps0 == B_ii, and
        # (when conductive) the diagonal decay 1 - sigma * B_ii is folded in by
        # _electric_update_coefficients through the aniso_shifted branch.
        solver._aniso_eps_eff[component_name] = (solver.eps0 / diagonal_inverse).contiguous()
        # Source injection, ADE templates and adjoint material leaves must use
        # the same diagonal inverse as the electric update. Physical tensors
        # remain in the compiled material model and public material diagnostics.
        setattr(solver, "eps_" + component_name, solver._aniso_eps_eff[component_name])

    if conductive:
        # Buffers for the pre-update conduction current sigma . E^n, subtracted
        # through the off-diagonal inverse tensor each step (the diagonal part is
        # already folded into the decay coefficient).
        solver._aniso_cond_current = {
            "Ex": torch.zeros_like(solver.Ex),
            "Ey": torch.zeros_like(solver.Ey),
            "Ez": torch.zeros_like(solver.Ez),
        }


def _aniso_cross_weights(solver, inverse_node, target_axis, source_axis):
    """Four reciprocal, volume-weighted node contributions per target Yee edge."""
    previous, following = _aniso_node_gather_weights(solver.scene, source_axis, inverse_node)
    view = [1, 1, 1]
    view[source_axis] = -1
    pieces = {}
    for target_side in range(2):
        selector = [slice(None)] * 3
        selector[target_axis] = slice(target_side, inverse_node.shape[target_axis] - 1 + target_side)
        for source_side, weight in enumerate((previous, following)):
            pieces[target_side, source_side] = 0.5 * (inverse_node * weight.reshape(view))[tuple(selector)]
    # Native loops visit the two transverse axes in ascending coordinate order.
    order = ((t, s) for t in range(2) for s in range(2)) if target_axis < source_axis else (
        (t, s) for s in range(2) for t in range(2))
    return torch.stack([pieces[key] for key in order], dim=-1).contiguous()


def _aniso_node_gather_weights(scene, source_axis, reference):
    """Yee-volume weights from the two incident edges into their common node."""
    axis = "xyz"[source_axis]
    primal = torch.as_tensor(getattr(scene, f"d{axis}_primal64"), device=reference.device, dtype=reference.dtype)
    dual = torch.as_tensor(getattr(scene, f"d{axis}_dual64"), device=reference.device, dtype=reference.dtype)
    periodic = scene.boundary.axis_kind(axis) == "periodic"
    previous = torch.cat((primal[-1:] if periodic else primal[:1], primal)) / (2 * dual)
    following = torch.cat((primal, primal[:1] if periodic else primal[-1:])) / (2 * dual)
    return previous, following


def average_node_to_component(solver, node_tensor, component_name):
    del solver
    if component_name == "Ex":
        return (0.5 * (node_tensor[:-1, :, :] + node_tensor[1:, :, :])).contiguous()
    if component_name == "Ey":
        return (0.5 * (node_tensor[:, :-1, :] + node_tensor[:, 1:, :])).contiguous()
    if component_name == "Ez":
        return (0.5 * (node_tensor[:, :, :-1] + node_tensor[:, :, 1:])).contiguous()
    raise ValueError(f"Unsupported electric field component {component_name!r}.")


def _max_node_to_electric_component(node_tensor, component_name):
    """Reduce a per-node field onto a Yee E edge with a MAX over the two-node
    stencil that ``average_node_to_component`` averages. Used for the modulation
    angular-frequency label, where the arithmetic mean would halve the frequency at
    an interface edge; the max keeps the modulated cell's frequency there."""
    if component_name == "Ex":
        return torch.maximum(node_tensor[:-1, :, :], node_tensor[1:, :, :]).contiguous()
    if component_name == "Ey":
        return torch.maximum(node_tensor[:, :-1, :], node_tensor[:, 1:, :]).contiguous()
    if component_name == "Ez":
        return torch.maximum(node_tensor[:, :, :-1], node_tensor[:, :, 1:]).contiguous()
    raise ValueError(f"Unsupported electric field component {component_name!r}.")


def average_node_to_magnetic_component(solver, node_tensor, component_name):
    del solver
    if component_name == "Hx":
        return (
            0.25
            * (
                node_tensor[:, :-1, :-1]
                + node_tensor[:, :-1, 1:]
                + node_tensor[:, 1:, :-1]
                + node_tensor[:, 1:, 1:]
            )
        ).contiguous()
    if component_name == "Hy":
        return (
            0.25
            * (
                node_tensor[:-1, :, :-1]
                + node_tensor[:-1, :, 1:]
                + node_tensor[1:, :, :-1]
                + node_tensor[1:, :, 1:]
            )
        ).contiguous()
    if component_name == "Hz":
        return (
            0.25
            * (
                node_tensor[:-1, :-1, :]
                + node_tensor[:-1, 1:, :]
                + node_tensor[1:, :-1, :]
                + node_tensor[1:, 1:, :]
            )
        ).contiguous()
    raise ValueError(f"Unsupported magnetic field component {component_name!r}.")


_ELECTRIC_COMPONENT_AXIS = {"Ex": "x", "Ey": "y", "Ez": "z"}


def _electric_pole_components(entry):
    """The E components a pole entry drives (sheet poles restrict to tangential axes)."""
    axes = entry.get("axes")
    if axes is None:
        return ("Ex", "Ey", "Ez")
    return tuple(
        component_name
        for component_name, axis in _ELECTRIC_COMPONENT_AXIS.items()
        if axis in axes
    )


def _magnetic_pole_components(entry):
    """Magnetic poles always drive all three H components (no sheet restriction)."""
    del entry
    return _H_DISPERSIVE_COMPONENTS


@dataclass(frozen=True)
class _DispersiveFamily:
    """Descriptor of the E-vs-H differences in the mirrored ADE dispersion helpers.

    The electric (E, eps) and magnetic (H, mu) dispersive channels share the same
    Debye/Drude/Lorentz ADE discretization and launch the same kernels; a family
    only selects which solver attributes, compiled pole lists, vacuum constant,
    and Yee node->component averaging stencil are consumed, plus which components
    a pole entry drives (electric sheet poles restrict to tangential axes).
    """

    components: tuple[str, ...]
    background_prefix: str  # solver attr prefix of the absolute eps/mu per component
    inverse_key: str  # templates key holding 1/eps or 1/mu
    pole_prefix: str  # material-model pole list prefix ("" or "mu_")
    vacuum_attr: str  # solver attr of the vacuum constant (eps0 or mu0)
    templates_attr: str
    enabled_attr: str
    average: object  # node->component averaging function for this family
    entry_components: object  # pole entry -> driven component names


_E_DISPERSIVE_COMPONENTS = ("Ex", "Ey", "Ez")
_H_DISPERSIVE_COMPONENTS = ("Hx", "Hy", "Hz")

_ELECTRIC_DISPERSIVE_FAMILY = _DispersiveFamily(
    components=_E_DISPERSIVE_COMPONENTS,
    background_prefix="eps_",
    inverse_key="inv_eps",
    pole_prefix="",
    vacuum_attr="eps0",
    templates_attr="_dispersive_templates",
    enabled_attr="electric_dispersive_enabled",
    average=average_node_to_component,
    entry_components=_electric_pole_components,
)

_MAGNETIC_DISPERSIVE_FAMILY = _DispersiveFamily(
    components=_H_DISPERSIVE_COMPONENTS,
    background_prefix="mu_",
    inverse_key="inv_mu",
    pole_prefix="mu_",
    vacuum_attr="mu0",
    templates_attr="_magnetic_dispersive_templates",
    enabled_attr="magnetic_dispersive_enabled",
    average=average_node_to_magnetic_component,
    entry_components=_magnetic_pole_components,
)


def _build_family_dispersive_templates(solver, material_model, family):
    if not any(material_model[f"{family.pole_prefix}{kind}_poles"]
               for kind in ("debye", "drude", "lorentz")):
        setattr(solver, family.templates_attr, {})
        setattr(solver, family.enabled_attr, False)
        return
    templates = {
        component_name: {
            family.inverse_key: (
                1.0 / getattr(solver, f"{family.background_prefix}{component_name}")
            ).contiguous(),
            "debye": [],
            "drude": [],
            "lorentz": [],
        }
        for component_name in family.components
    }
    vacuum = getattr(solver, family.vacuum_attr)

    for entry in material_model[f"{family.pole_prefix}debye_poles"]:
        pole = entry["pole"]
        decay = (2.0 * pole.tau - solver.dt) / (2.0 * pole.tau + solver.dt)
        base_scale = 2.0 * vacuum * pole.delta_eps * solver.dt / (2.0 * pole.tau + solver.dt)
        for component_name in family.entry_components(entry):
            weight = family.average(solver, entry["weight"], component_name)
            templates[component_name]["debye"].append(
                {
                    "decay": float(decay),
                    "drive": (weight * base_scale).contiguous(),
                }
            )

    for entry in material_model[f"{family.pole_prefix}drude_poles"]:
        pole = entry["pole"]
        omega_p = 2.0 * np.pi * pole.plasma_frequency
        gamma = 2.0 * np.pi * pole.gamma
        denom = 2.0 + gamma * solver.dt
        decay = (2.0 - gamma * solver.dt) / denom
        base_scale = 2.0 * vacuum * omega_p * omega_p * solver.dt / denom
        for component_name in family.entry_components(entry):
            weight = family.average(solver, entry["weight"], component_name)
            templates[component_name]["drude"].append(
                {
                    "decay": float(decay),
                    "drive": (weight * base_scale).contiguous(),
                }
            )

    for entry in material_model[f"{family.pole_prefix}lorentz_poles"]:
        pole = entry["pole"]
        omega_0 = 2.0 * np.pi * pole.resonance_frequency
        gamma = 2.0 * np.pi * pole.gamma
        denom = 2.0 + gamma * solver.dt
        decay = (2.0 - gamma * solver.dt) / denom
        restoring = 2.0 * omega_0 * omega_0 * solver.dt / denom
        base_scale = 2.0 * vacuum * pole.delta_eps * omega_0 * omega_0 * solver.dt / denom
        for component_name in family.entry_components(entry):
            weight = family.average(solver, entry["weight"], component_name)
            templates[component_name]["lorentz"].append(
                {
                    "decay": float(decay),
                    "restoring": float(restoring),
                    "drive": (weight * base_scale).contiguous(),
                }
            )

    setattr(solver, family.templates_attr, templates)
    setattr(
        solver,
        family.enabled_attr,
        any(
            templates[component_name][model_name]
            for component_name in family.components
            for model_name in ("debye", "drude", "lorentz")
        ),
    )


def build_dispersive_templates(solver, material_model):
    _build_family_dispersive_templates(solver, material_model, _ELECTRIC_DISPERSIVE_FAMILY)


def build_magnetic_dispersive_templates(solver, material_model):
    _build_family_dispersive_templates(solver, material_model, _MAGNETIC_DISPERSIVE_FAMILY)


def _initialize_component_dispersive_entries(solver, component_templates, field):
    complex_fields = has_complex_fields(solver)
    for entry in component_templates["debye"]:
        entry["polarization"] = torch.zeros_like(field)
        entry["current"] = torch.zeros_like(field)
        entry["polarization_imag"] = torch.zeros_like(field) if complex_fields else None
        entry["current_imag"] = torch.zeros_like(field) if complex_fields else None
    for entry in component_templates["drude"]:
        entry["current"] = torch.zeros_like(field)
        entry["current_imag"] = torch.zeros_like(field) if complex_fields else None
    for entry in component_templates["lorentz"]:
        entry["polarization"] = torch.zeros_like(field)
        entry["current"] = torch.zeros_like(field)
        if complex_fields:
            entry["polarization_imag"] = torch.zeros_like(field)
            entry["current_imag"] = torch.zeros_like(field)
        else:
            entry["polarization_imag"] = None
            entry["current_imag"] = None


def _initialize_family_dispersive_state(solver, family):
    templates = getattr(solver, family.templates_attr)
    if not templates:
        setattr(solver, family.enabled_attr, False)
        return False
    for component_name in family.components:
        _initialize_component_dispersive_entries(
            solver, templates[component_name], getattr(solver, component_name)
        )
    return True


def initialize_dispersive_state(solver):
    if not solver._dispersive_templates:
        solver.electric_dispersive_enabled = False
        return

    if getattr(solver, "full_aniso_enabled", False) and solver.electric_dispersive_enabled:
        # Accumulator for the total per-component polarization current, summed over
        # all electric poles, consumed by the coupled tensor ADE subtraction.
        solver._aniso_disp_current = {
            "Ex": torch.zeros_like(solver.Ex),
            "Ey": torch.zeros_like(solver.Ey),
            "Ez": torch.zeros_like(solver.Ez),
        }

    _initialize_family_dispersive_state(solver, _ELECTRIC_DISPERSIVE_FAMILY)


def initialize_magnetic_dispersive_state(solver):
    _initialize_family_dispersive_state(solver, _MAGNETIC_DISPERSIVE_FAMILY)


def _advance_component_dispersive_entries(solver, component_templates, field, *, imag):
    for entry in component_templates["debye"]:
        polarization = entry["polarization_imag"] if imag else entry["polarization"]
        current = entry["current_imag"] if imag else entry["current"]
        solver.fdtd_module.updateDebyeCurrent3D(
            ElectricField=field,
            Polarization=polarization,
            PolarizationCurrent=current,
            DebyeDrive=entry["drive"],
            decay=entry["decay"],
            dt=solver.dt,
        ).launchRaw()

    for entry in component_templates["drude"]:
        current = entry["current_imag"] if imag else entry["current"]
        solver.fdtd_module.updateDrudeCurrent3D(
            ElectricField=field,
            PolarizationCurrent=current,
            DrudeDrive=entry["drive"],
            decay=entry["decay"],
        ).launchRaw()

    for entry in component_templates["lorentz"]:
        polarization = entry["polarization_imag"] if imag else entry["polarization"]
        current = entry["current_imag"] if imag else entry["current"]
        solver.fdtd_module.updateLorentzCurrent3D(
            ElectricField=field,
            Polarization=polarization,
            PolarizationCurrent=current,
            LorentzDrive=entry["drive"],
            decay=entry["decay"],
            restoring=entry["restoring"],
            dt=solver.dt,
        ).launchRaw()


def _family_component_templates(solver, family, component_name):
    """The component's templates when the family is active, else ``None``."""
    if not getattr(solver, family.enabled_attr):
        return None
    return getattr(solver, family.templates_attr).get(component_name)


def _apply_to_family_fields(solver, family, component_fn):
    """Run a per-component helper over the family's real (then imaginary) fields."""
    for component_name in family.components:
        component_fn(solver, component_name, getattr(solver, component_name), imag=False)
    if has_complex_fields(solver):
        for component_name in family.components:
            component_fn(
                solver, component_name, getattr(solver, f"{component_name}_imag"), imag=True
            )


def advance_component_dispersive_state(solver, component_name, field, *, imag=False):
    component_templates = _family_component_templates(
        solver, _ELECTRIC_DISPERSIVE_FAMILY, component_name
    )
    if not component_templates:
        return
    _advance_component_dispersive_entries(solver, component_templates, field, imag=imag)


def advance_dispersive_state(solver):
    if not solver.electric_dispersive_enabled:
        return
    _apply_to_family_fields(solver, _ELECTRIC_DISPERSIVE_FAMILY, advance_component_dispersive_state)


def advance_magnetic_component_dispersive_state(solver, component_name, field, *, imag=False):
    component_templates = _family_component_templates(
        solver, _MAGNETIC_DISPERSIVE_FAMILY, component_name
    )
    if not component_templates:
        return
    _advance_component_dispersive_entries(solver, component_templates, field, imag=imag)


def advance_magnetic_dispersive_state(solver):
    if not solver.magnetic_dispersive_enabled:
        return
    _apply_to_family_fields(
        solver, _MAGNETIC_DISPERSIVE_FAMILY, advance_magnetic_component_dispersive_state
    )


def _dispersive_current_coefficient(solver, component_name, component_templates):
    """The ``(coefficient, dt)`` pair for the subtraction ``E -= dt * J_p * coefficient``.

    In the linear path the polarization current is divided by the static
    permittivity (``coefficient = 1/eps_lin``, ``dt = solver.dt``). When an
    instantaneous nonlinearity is active the same Yee edge's displacement-current
    term in the E update is scaled by the field-dependent ``c*_curl_dynamic``
    coefficient (``external * (dt / eps_eff) / (1 + half)``); reusing that
    coefficient here (with ``dt = 1``) subtracts the ADE current against the SAME
    effective permittivity the ``curl(H)`` term saw this step, so the
    instantaneous-nonlinear index shift and the dispersive response stay mutually
    consistent (dividing the ADE current by ``eps_lin`` instead would detune the
    dispersion by the nonlinear index shift). In a purely dispersive cell the
    dynamic curl reduces to ``dt / eps_lin``, so the linear path is unchanged.
    """
    if getattr(solver, "nonlinear_enabled", False):
        dynamic_curl = {
            "Ex": solver.cex_curl_dynamic,
            "Ey": solver.cey_curl_dynamic,
            "Ez": solver.cez_curl_dynamic,
        }[component_name]
        return dynamic_curl, 1.0
    return component_templates["inv_eps"], solver.dt


_MODULATION_QUADRATURE_FIELDS = {
    "Ex": ("mod_cos_Ex", "mod_sin_Ex", "mod_omega_Ex"),
    "Ey": ("mod_cos_Ey", "mod_sin_Ey", "mod_omega_Ey"),
    "Ez": ("mod_cos_Ez", "mod_sin_Ez", "mod_omega_Ez"),
}


def _apply_plain_dispersive_currents(solver, component_templates, field, inverse, apply_dt, *, imag):
    """Subtract every pole's polarization current with the unmodulated kernel.

    Shared by both field families: the magnetic channel always takes this path
    (with ``inverse = 1/mu``), and the electric channel takes it whenever no
    space-time modulation is active. The kernel's ``ElectricField`` argument is
    simply the updated field component (E or H).
    """
    for model_name in ("debye", "drude", "lorentz"):
        for entry in component_templates[model_name]:
            solver.fdtd_module.applyPolarizationCurrent3D(
                ElectricField=field,
                PolarizationCurrent=entry["current_imag"] if imag else entry["current"],
                InvPermittivity=inverse,
                dt=apply_dt,
            ).launchRaw()


def apply_component_dispersive_currents(solver, component_name, field, *, imag=False):
    component_templates = _family_component_templates(
        solver, _ELECTRIC_DISPERSIVE_FAMILY, component_name
    )
    if not component_templates:
        return
    inv_eps, apply_dt = _dispersive_current_coefficient(solver, component_name, component_templates)

    # When the electric dispersion co-exists with a space-time modulation, the ADE
    # polarization current is divided by the same instantaneous eps_inf * m_next as
    # the modulated curl(H) term (see apply_polarization_modulated_kernel); in a
    # purely dispersive cell (m_next == 1) this reduces to the plain subtraction.
    modulated = bool(getattr(solver, "modulation_enabled", False)) and not imag
    if not modulated:
        _apply_plain_dispersive_currents(
            solver, component_templates, field, inv_eps, apply_dt, imag=imag
        )
        return

    cos_name, sin_name, omega_name = _MODULATION_QUADRATURE_FIELDS[component_name]
    mod_cos = getattr(solver, cos_name)
    mod_sin = getattr(solver, sin_name)
    mod_omega = getattr(solver, omega_name)
    for model_name in ("debye", "drude", "lorentz"):
        for entry in component_templates[model_name]:
            solver.fdtd_module.applyPolarizationCurrentModulated3D(
                ElectricField=field,
                PolarizationCurrent=entry["current_imag"] if imag else entry["current"],
                InvPermittivity=inv_eps,
                ModCos=mod_cos,
                ModSin=mod_sin,
                ModOmega=mod_omega,
                ModulationTime=solver._modulation_time,
                dt=apply_dt,
            ).launchRaw()


def _aniso_periodic_flags(solver):
    return (
        int(solver.boundary_x_low_code == BOUNDARY_PERIODIC and solver.boundary_x_high_code == BOUNDARY_PERIODIC),
        int(solver.boundary_y_low_code == BOUNDARY_PERIODIC and solver.boundary_y_high_code == BOUNDARY_PERIODIC),
        int(solver.boundary_z_low_code == BOUNDARY_PERIODIC and solver.boundary_z_high_code == BOUNDARY_PERIODIC),
    )


def _apply_aniso_dispersive_corrections(solver):
    """Subtract the ADE polarization current through the full inverse permittivity tensor.

    For a full (off-diagonal) anisotropic permittivity the instantaneous
    constitutive relation is ``D = eps_inf . E + P``, so the Ampere update is
    ``E += dt * eps_inf^-1 . (curl H - J_p)``. The base and off-diagonal curl
    kernels already apply ``eps_inf^-1`` (diagonal via ``dt/eps_eff`` and
    off-diagonal via ``c*_aniso_*``) to ``curl H``; this applies the same operator
    to the accumulated polarization current ``J_p``. Electric poles enter
    isotropically (``P_i`` is driven by ``E_i``), so the per-component ADE state
    advance is unchanged and only the subtraction becomes a tensor contraction.
    Full anisotropy runs on real fields only (Bloch/complex is rejected upstream).
    """
    templates = solver._dispersive_templates
    totals = solver._aniso_disp_current
    for component_name in ("Ex", "Ey", "Ez"):
        buffer = totals[component_name]
        buffer.zero_()
        component_templates = templates[component_name]
        for model_name in ("debye", "drude", "lorentz"):
            for entry in component_templates[model_name]:
                buffer.add_(entry["current"])

    inv_eps = solver._aniso_disp_inv_eps
    for component_name, field in (("Ex", solver.Ex), ("Ey", solver.Ey), ("Ez", solver.Ez)):
        solver.fdtd_module.applyPolarizationCurrent3D(
            ElectricField=field,
            PolarizationCurrent=totals[component_name],
            InvPermittivity=inv_eps[component_name],
            dt=solver.dt,
        ).launchRaw()

    periodic_x, periodic_y, periodic_z = _aniso_periodic_flags(solver)
    solver.fdtd_module.applyAnisoOffdiagCurrentEx3D(
        Ex=solver.Ex,
        Jy=totals["Ey"],
        Jz=totals["Ez"],
        CoeffY=solver.cex_aniso_y,
        CoeffZ=solver.cex_aniso_z,
        periodicX=periodic_x,
        periodicY=periodic_y,
        periodicZ=periodic_z,
    ).launchRaw()
    solver.fdtd_module.applyAnisoOffdiagCurrentEy3D(
        Ey=solver.Ey,
        Jx=totals["Ex"],
        Jz=totals["Ez"],
        CoeffX=solver.cey_aniso_x,
        CoeffZ=solver.cey_aniso_z,
        periodicX=periodic_x,
        periodicY=periodic_y,
        periodicZ=periodic_z,
    ).launchRaw()
    solver.fdtd_module.applyAnisoOffdiagCurrentEz3D(
        Ez=solver.Ez,
        Jx=totals["Ex"],
        Jy=totals["Ey"],
        CoeffX=solver.cez_aniso_x,
        CoeffY=solver.cez_aniso_y,
        periodicX=periodic_x,
        periodicY=periodic_y,
        periodicZ=periodic_z,
    ).launchRaw()


def apply_dispersive_corrections(solver):
    if not solver.electric_dispersive_enabled:
        return

    if getattr(solver, "full_aniso_enabled", False):
        _apply_aniso_dispersive_corrections(solver)
        return

    _apply_to_family_fields(solver, _ELECTRIC_DISPERSIVE_FAMILY, apply_component_dispersive_currents)


def apply_magnetic_component_dispersive_currents(solver, component_name, field, *, imag=False):
    component_templates = _family_component_templates(
        solver, _MAGNETIC_DISPERSIVE_FAMILY, component_name
    )
    if not component_templates:
        return
    _apply_plain_dispersive_currents(
        solver, component_templates, field, component_templates["inv_mu"], solver.dt, imag=imag
    )


def apply_magnetic_dispersive_corrections(solver):
    if not solver.magnetic_dispersive_enabled:
        return

    _apply_to_family_fields(
        solver, _MAGNETIC_DISPERSIVE_FAMILY, apply_magnetic_component_dispersive_currents
    )


def _electric_update_coefficients(solver, eps, sigma_e, pml_decay, *, aniso_shifted=False):
    """Compose the semi-implicit lossy-dielectric decay/curl factors for one E component.

    ``eps`` is the absolute permittivity (eps_r * eps0) and ``sigma_e`` the static
    electric conductivity averaged onto the same Yee component. When conductivity is
    inactive the material factors reduce to (decay=1, curl=dt/eps), so non-conductive
    scenes keep the exact existing coefficients. ``pml_decay`` folds the CPML decay in
    multiplicatively when present.

    ``aniso_shifted`` selects the full-tensor conductive path: ``eps`` is then the
    effective permittivity ``eps0 / [(eps_inf + dt/2 diag(sigma))^-1]_ii`` whose
    reciprocal is the diagonal of the conductively-shifted inverse tensor, so the
    diagonal curl is already the semi-implicit ``B_ii = dt/eps`` and the decay is
    ``1 - sigma * B_ii`` (the same ``decay = 1 - sigma * curl`` identity the scalar
    lossy fold satisfies). The off-diagonal conduction coupling is applied separately
    through ``B_ij`` by the conduction-current subtraction.
    """
    if solver.conductive_enabled:
        if aniso_shifted:
            curl = solver.dt / eps
            material_decay = 1.0 - sigma_e * curl
        else:
            half = 0.5 * sigma_e * solver.dt / eps
            denom = 1.0 + half
            material_decay = (1.0 - half) / denom
            curl = (solver.dt / eps) / denom
    else:
        material_decay = None
        curl = solver.dt / eps

    if pml_decay is None:
        decay = material_decay if material_decay is not None else torch.ones_like(eps)
    else:
        decay = pml_decay if material_decay is None else material_decay * pml_decay
        curl = curl * pml_decay
    return decay.contiguous(), curl.contiguous()


def _magnetic_update_coefficients(solver, mu, sigma_m, pml_decay):
    """Compose the semi-implicit magnetically-lossy decay/curl factors for one H component.

    This is the exact magnetic dual of ``_electric_update_coefficients``: ``mu`` is
    the absolute permeability (mu_r * mu0) and ``sigma_m`` the static magnetic
    conductivity averaged onto the same Yee H component. A magnetic conduction
    current ``sigma_m * H`` on Faraday's law, discretized semi-implicitly with H
    averaged over the two half steps, gives the fold ``decay = (1 - h)/(1 + h)`` and
    ``curl = (dt/mu)/(1 + h)`` with ``h = 0.5 * sigma_m * dt / mu``. When magnetic
    conductivity is inactive the factors reduce to ``(decay=1, curl=dt/mu)``, so a
    non-magnetically-conductive scene keeps the exact existing coefficients.
    ``pml_decay`` folds the split-field CPML decay in multiplicatively when present,
    matching the electric path (the per-cell decay tensor the H kernels already read).
    """
    if solver.magnetically_conductive_enabled:
        half = 0.5 * sigma_m * solver.dt / mu
        denom = 1.0 + half
        material_decay = (1.0 - half) / denom
        curl = (solver.dt / mu) / denom
    else:
        material_decay = None
        curl = solver.dt / mu

    if pml_decay is None:
        decay = material_decay if material_decay is not None else torch.ones_like(mu)
    else:
        decay = pml_decay if material_decay is None else material_decay * pml_decay
        curl = curl * pml_decay
    return decay.contiguous(), curl.contiguous()


def _pec_edge_open_fractions(solver):
    """Per-E-edge open fractions ``1 - fill``, or ``None`` when the scene has no PEC.

    ``staircase`` mode thresholds the two-endpoint node->edge average of the smoothed
    PEC occupancy at 0.5, so every edge is either a hard short or fully open.

    ``conformal`` mode consumes the compiler's per-edge coverage fraction
    (``pec_edge_fill``): the fraction of that Yee edge's length that lies inside the
    conductor, obtained by interpolating the PEC signed distance along the edge. That
    quantity has compact support -- exactly 0 for an edge the surface does not reach
    and exactly 1 for an edge wholly inside -- so a conductor face that is parallel to
    an edge (every tangential edge of an axis-aligned face) reproduces the staircase
    result bit for bit, and only genuinely cut edges take a fractional open fraction.
    The node-average path must not be used here: the smoothed node occupancy has
    tails several cells wide, and because the open fraction multiplies the E update
    every step, a tail value ``f`` acts as a spurious conductivity ``eps*f/dt`` on
    vacuum edges around the conductor.
    """
    model = getattr(solver, "_compiled_material_model", None)
    pec_occupancy = None if model is None else model.get("pec_occupancy")
    if pec_occupancy is None:
        return None
    mode = model.get("pec_mode", "staircase")
    edge_fill = model.get("pec_edge_fill") if mode == "conformal" else None
    open_fractions = {}
    for component_name in ("Ex", "Ey", "Ez"):
        if edge_fill is not None:
            fill = edge_fill[component_name]
        else:
            fill = average_node_to_component(solver, pec_occupancy, component_name)
            fill = (fill >= 0.5).to(fill.dtype)
        open_fractions[component_name] = 1.0 - fill
    return open_fractions


def _apply_pec_edge_suppression(solver):
    """Fold the PEC open fraction into the electric decay/curl coefficients.

    Scaling both ``decay`` and ``curl`` by ``open = 1 - fill`` turns the update into
    ``E_new = open * (decay*E_old + curl*(curlH - J))``, so a fully covered edge
    (``fill = 1``) keeps tangential E exactly zero while a fractional edge acts as a
    soft short. Never amplifies (``open <= 1``), so the scheme is unconditionally
    stable and needs no cut-area floor.

    The soft short is a per-step multiplicative factor, i.e. an effective
    conductivity ``eps*fill/dt`` on that edge. It is therefore only meaningful on
    edges the conductor surface genuinely cuts; see
    :func:`_pec_edge_open_fractions` for why the fill must have compact support.
    """
    open_fractions = _pec_edge_open_fractions(solver)
    if open_fractions is None:
        return
    solver.cex_decay = (solver.cex_decay * open_fractions["Ex"]).contiguous()
    solver.cex_curl = (solver.cex_curl * open_fractions["Ex"]).contiguous()
    solver.cey_decay = (solver.cey_decay * open_fractions["Ey"]).contiguous()
    solver.cey_curl = (solver.cey_curl * open_fractions["Ey"]).contiguous()
    solver.cez_decay = (solver.cez_decay * open_fractions["Ez"]).contiguous()
    solver.cez_curl = (solver.cez_curl * open_fractions["Ez"]).contiguous()
    if getattr(solver, "cex_decay_external", None) is not None:
        # The general nonlinear kernel recomposes decay/curl from this external
        # factor each step, so the PEC open fraction must fold into it too.
        solver.cex_decay_external = (solver.cex_decay_external * open_fractions["Ex"]).contiguous()
        solver.cey_decay_external = (solver.cey_decay_external * open_fractions["Ey"]).contiguous()
        solver.cez_decay_external = (solver.cez_decay_external * open_fractions["Ez"]).contiguous()
    if getattr(solver, "full_aniso_enabled", False):
        # The off-diagonal coupling terms are additive corrections to the same
        # E edges, so PEC-covered edges must suppress them identically.
        solver._aniso_edge_open = open_fractions
        solver.cex_aniso_y = (solver.cex_aniso_y * open_fractions["Ex"][..., None]).contiguous()
        solver.cex_aniso_z = (solver.cex_aniso_z * open_fractions["Ex"][..., None]).contiguous()
        solver.cey_aniso_x = (solver.cey_aniso_x * open_fractions["Ey"][..., None]).contiguous()
        solver.cey_aniso_z = (solver.cey_aniso_z * open_fractions["Ey"][..., None]).contiguous()
        solver.cez_aniso_x = (solver.cez_aniso_x * open_fractions["Ez"][..., None]).contiguous()
        solver.cez_aniso_y = (solver.cez_aniso_y * open_fractions["Ez"][..., None]).contiguous()


_E_COMPONENTS = ("Ex", "Ey", "Ez")
_H_COMPONENTS = ("Hx", "Hy", "Hz")


def _axis_index_tuple(ndim, axis, index_or_slice):
    selector = [slice(None)] * ndim
    selector[axis] = index_or_slice
    return tuple(selector)


def _surface_box_interior_mask(solver, metal):
    """Zero the E-update coefficients inside one metal box (a good-conductor fill).

    The surface-impedance boundary masks the metal interior so its E edges stay at
    their zero initial value (a zero open-fraction folded into the decay/curl
    coefficients, exactly as PEC does); the exposed-face tangential-E writes then
    override the surface plane each step. The masked window is the box's node cell
    region, extended to the tensor end on any axis-side flush against the physical
    domain boundary so a boundary-backed metal is a full half-space (the same
    coverage the single-plane path used). Masking the surface-plane tangential edges
    too is harmless: the per-step write overwrites them before any field reads them.
    """
    windows = []
    for axis in range(3):
        cell_slice = metal.cell_slices[axis]
        lo = 0 if metal.touches_lower[axis] else int(cell_slice.start)
        hi = None if metal.touches_upper[axis] else int(cell_slice.stop)
        windows.append(slice(lo, hi))
    for component in _E_COMPONENTS:
        decay = getattr(solver, f"c{component.lower()}_decay", None)
        if decay is None:
            continue
        mask = torch.ones_like(decay)
        index = tuple(
            slice(w.start, None if w.stop is None else min(w.stop, size))
            for w, size in zip(windows, mask.shape)
        )
        mask[index] = 0.0
        for suffix in ("decay", "curl"):
            name = f"c{component.lower()}_{suffix}"
            setattr(solver, name, (getattr(solver, name) * mask).contiguous())


def _surface_discrete_state_space(solver, material):
    """Discretize a generic rational surface impedance into a Z-form ADE at ``dt``.

    The generic per-edge surface update steps the impedance relation
    ``E_t = Z_s(omega) * (n_hat x H)`` (an E-from-H overwrite), so it needs the
    impedance (Z) realization. The user model may be fit as an admittance (``Y``,
    the good-conductor default, whose ``Z_s ~ sqrt(omega)`` is bounded only over the
    band), so ``Z_s`` is resampled over the declared band and refit as a passive
    ``Z``-form rational through the shared fitter, then discretized with the bilinear
    (trapezoidal, ``|z| < 1``) transform. Passivity is a compile exit gate: a fit
    that is accurate but not certified passive over the band is rejected here, before
    any step runs -- a non-passive surface injects energy and diverges. Returns the
    discrete ``(A, B, C, D)`` tensors (real, on the solver device) for a scalar
    surface.

    The passivity certificate bounds the continuous surface response, not the coupled
    surface-plus-Yee discrete stability: a certified-passive high-order fit at coarse
    resolution (e.g. order ~10 near ~40 cells/wavelength) can still diverge. Stability is
    established in the moderate-order / adequate-resolution regime the acceptance suite
    covers; use a moderate fit order at adequate cells-per-wavelength.
    """
    from ...compiler.surface_impedance import fit_surface_impedance

    impedance = material.impedance
    band = impedance.frequency_range
    samples = impedance.sample_frequencies
    if samples is None:
        samples = torch.logspace(
            float(np.log10(band[0])), float(np.log10(band[1])), 200, dtype=torch.float64
        )
    else:
        samples = samples.detach().to(dtype=torch.float64)
    z_values = impedance.surface_impedance(samples).to(dtype=torch.complex128)
    order = int(impedance.model.poles.numel())
    fitted = fit_surface_impedance(
        (samples, z_values),
        band=band,
        order=order,
        dt=float(solver.dt),
        device=solver.device,
        representation="Z",
        dtype=torch.float32,
    )
    discrete = fitted.discrete
    return (
        discrete.A.contiguous(),
        discrete.B.contiguous(),
        discrete.C.contiguous(),
        discrete.D.contiguous(),
        fitted,
    )


def _configure_surface_impedance(solver):
    """Set up the generalized surface-impedance boundary from the compiled layout.

    Consumes the ``CompiledSurfaceImpedanceLayout`` (``model["surface_impedance"]``):
    it masks every metal interior to a good-conductor termination and builds one
    per-tangential-component surface write for every exposed axis-aligned face
    (finite blocks, mid-domain double-sided plates, multiple metals, multiple
    orientations). Each write realizes the Leontovich relation
    ``E_t = Z_s * (n_hat x H)`` with the metal outward normal ``n_hat`` from the
    vacuum-side tangential H: ``E_b = +sn * Z_s{H_c}``, ``E_c = -sn * Z_s{H_b}``,
    ``sn = +1`` for a metal on the high side of the surface (``n_hat = -axis``) and
    ``-1`` for the low side -- the passive (energy-absorbing) branch.

    Two realizations of the same contract share one code path:

    * a narrowband good-conductor ``LossyMetalMedium`` is order-0 (pure resistance):
      ``Z_s = R = sqrt(omega0 * mu0 / (2 * sigma))`` at the operating frequency, no
      auxiliary state. A full-plane order-0 face uses the fused native kernel
      (``applySibcSurface3D``); its output ``sign * R * H`` is bit-identical to the
      generic ``D * (sign * H)`` scalar path (multiplication by ``sign = +/-1`` is
      exact), so the fused path is a pure optimization of the same relation.
    * a generic rational ``SurfaceImpedanceMedium`` is a passive Z-form ADE
      discretized at ``dt`` (``_surface_discrete_state_space``); each edge carries a
      state vector advanced by ``x <- A x + B u`` with output ``E = C x + D u`` and
      input ``u = sign * H``. ``apply_surface_impedance`` in ``stepping.py`` steps it.
    """
    solver.surface_impedance_enabled = False
    solver._surface_impedance = None
    model = getattr(solver, "_compiled_material_model", None)
    layout = None if model is None else model.get("surface_impedance")
    if not layout:
        return

    omega0 = 2.0 * np.pi * float(solver.source_frequency)
    discrete_cache: dict[int, tuple] = {}
    writes = []
    for metal in layout.metals:
        if getattr(metal, "interior_node_mask", None) is not None:
            _surface_occupancy_interior_mask(solver, metal)
        else:
            _surface_box_interior_mask(solver, metal)

    for face in layout.faces:
        metal = layout.metals[face.metal_index]
        axis = face.axis
        b = (axis + 1) % 3
        c = (axis + 2) % 3
        sn = 1.0 if face.metal_side == "high" else -1.0
        if getattr(face, "transverse_mask", None) is not None:
            writes.extend(_voxel_surface_writes(solver, face, metal, axis, b, c, sn, omega0))
            continue
        components = (
            (_E_COMPONENTS[b], _H_COMPONENTS[c], +sn),
            (_E_COMPONENTS[c], _H_COMPONENTS[b], -sn),
        )
        b_slice, c_slice = face.transverse_slices
        if face.full_plane:
            # A full-plane face owns the entire transverse surface E plane. The node-
            # coverage slices under-cover by one the tangential component whose transverse
            # dimension is node-length (an exact-fill box gives b_slice.stop == cell_count,
            # missing the last node row), which would leave a masked-zero PEC seam where
            # the fused order-0 kernel writes the Leontovich value. Widen to the whole
            # plane so the generic sliced write and the fused kernel share one footprint.
            b_slice = slice(None)
            c_slice = slice(None)

        surface_r = None
        discrete = None
        if metal.conductivity is not None:
            if omega0 <= 0.0:
                raise ValueError(
                    "A narrowband good-conductor surface requires a positive operating "
                    "frequency."
                )
            surface_r = float(np.sqrt(omega0 * solver.mu0 / (2.0 * metal.conductivity)))
        else:
            key = id(metal.material)
            if key not in discrete_cache:
                discrete_cache[key] = _surface_discrete_state_space(solver, metal.material)
            discrete = discrete_cache[key]

        for e_name, h_name, sign in components:
            entry = {
                "e_name": e_name,
                "h_name": h_name,
                "sign": float(sign),
                "axis": axis,
                "electric_index": int(face.surface_node),
                "magnetic_index": int(face.magnetic_index),
                "full_plane": bool(face.full_plane),
                "b_axis": b,
                "c_axis": c,
                "b_slice": b_slice,
                "c_slice": c_slice,
                "surface_r": surface_r,
            }
            if discrete is not None:
                a_d, b_d, c_d, d_d, _fitted = discrete
                # One state vector per edge in this face's transverse write window.
                electric = getattr(solver, e_name)
                e_index = _surface_write_index(
                    electric.dim(), axis, int(face.surface_node), b, b_slice, c, c_slice
                )
                edge_count = electric[e_index].numel()
                order = a_d.shape[0]
                entry["ade"] = {
                    "A": a_d,
                    "B": b_d,
                    "C": c_d,
                    "D": d_d,
                    "state": torch.zeros(
                        (order, edge_count), device=solver.device, dtype=electric.dtype
                    ),
                }
            writes.append(entry)

    solver._surface_impedance = {"writes": writes}
    solver.surface_impedance_enabled = True


def _surface_occupancy_interior_mask(solver, metal):
    """Zero the E-update coefficients inside a staircased (voxelized) good conductor.

    The node occupancy is averaged onto each Yee E edge (the same node->edge stencil as
    the permittivity), and an edge whose fill reaches half is treated as inside the metal
    and clamped to zero (decay and curl scaled by zero), exactly the PEC-staircase
    treatment. Surface edges are also zeroed here; the per-face Leontovich write overrides
    the exposed transverse footprint each step before any field reads it.
    """
    occupancy = metal.interior_node_mask.to(device=solver.device, dtype=torch.float32)
    for component in _E_COMPONENTS:
        decay = getattr(solver, f"c{component.lower()}_decay", None)
        if decay is None:
            continue
        fill = average_node_to_component(solver, occupancy, component)
        keep = (fill < 0.5).to(fill.dtype)
        for suffix in ("decay", "curl"):
            name = f"c{component.lower()}_{suffix}"
            setattr(solver, name, (getattr(solver, name) * keep).contiguous())


def _voxel_surface_writes(solver, face, metal, axis, b, c, sn, omega0):
    """Build the two tangential-E mask writes for one staircased face.

    The face carries a boolean node-plane mask in ascending non-normal-axis order (the same
    layout as a field tensor's transverse plane). For each tangential E component the mask
    is reduced to that component's edge grid (an edge is on the surface when both bounding
    nodes are), matching the paired vacuum-side H plane's transverse shape. The runtime
    write is ``E_plane = where(mask, sign * R * H_plane, E_plane)``, static-shape and
    graph-capturable. Only the narrowband good-conductor (order-0 resistance) surface is
    supported for the staircase; ``metal.conductivity`` is guaranteed non-None by the
    compiler.
    """
    if omega0 <= 0.0:
        raise ValueError(
            "A narrowband good-conductor surface requires a positive operating frequency."
        )
    surface_r = float(np.sqrt(omega0 * solver.mu0 / (2.0 * metal.conductivity)))
    node_mask = face.transverse_mask.to(device=solver.device)
    naxes = tuple(a for a in range(3) if a != axis)
    writes = []
    for e_axis, h_axis, sign in ((b, c, +sn), (c, b, -sn)):
        # Reduce the node mask along the E component's own (edge) direction.
        position = naxes.index(e_axis)
        if position == 0:
            edge_mask = node_mask[:-1, :] & node_mask[1:, :]
        else:
            edge_mask = node_mask[:, :-1] & node_mask[:, 1:]
        writes.append(
            {
                "e_name": _E_COMPONENTS[e_axis],
                "h_name": _H_COMPONENTS[h_axis],
                "sign": float(sign),
                "axis": axis,
                "electric_index": int(face.surface_node),
                "magnetic_index": int(face.magnetic_index),
                "full_plane": False,
                "surface_r": surface_r,
                "mask": edge_mask.contiguous(),
            }
        )
    return writes


def _surface_write_index(ndim, axis, axis_index, b_axis, b_slice, c_axis, c_slice):
    """Index tuple selecting a face's transverse write window on a field tensor.

    The paired tangential-E and vacuum-side-H tensors have identical sizes on the two
    transverse (``b_axis``, ``c_axis``) dimensions of a surface plane, so the same node
    cell window slices both to matching shapes; torch clamps a full-span stop to the
    tensor size. ``axis_index`` is the (component-specific) plane index along the
    outward-normal axis.
    """
    index = [slice(None)] * ndim
    index[axis] = int(axis_index)
    index[b_axis] = b_slice
    index[c_axis] = c_slice
    return tuple(index)


def _store_nonlinear_external_decay(solver, ex_decay, ey_decay, ez_decay):
    """Keep the material-independent (PML) decay factors for the nonlinear kernel.

    The general nonlinear coefficient kernel recomposes the semi-implicit lossy
    decay/curl factors from the linear permittivity, the static conductivity, and
    the field-dependent nonlinear terms every step, so it needs the external
    (PML split-field) decay separately from the static material decay that
    ``_electric_update_coefficients`` folds into ``c*_decay``. The PEC open
    fractions are folded in afterwards by ``_apply_pec_edge_suppression``.
    """
    if not getattr(solver, "nonlinear_general_enabled", False):
        solver.cex_decay_external = None
        solver.cey_decay_external = None
        solver.cez_decay_external = None
        return
    solver.cex_decay_external = (
        torch.ones_like(solver.eps_Ex) if ex_decay is None else ex_decay.clone()
    ).contiguous()
    solver.cey_decay_external = (
        torch.ones_like(solver.eps_Ey) if ey_decay is None else ey_decay.clone()
    ).contiguous()
    solver.cez_decay_external = (
        torch.ones_like(solver.eps_Ez) if ez_decay is None else ez_decay.clone()
    ).contiguous()


def _electric_epsilon_tensors(solver):
    """The absolute permittivity tensors feeding the electric curl coefficients.

    Full anisotropy uses the reciprocal endpoint-average of the node inverse;
    other materials retain their compiled diagonal Yee permittivity.
    """
    if getattr(solver, "full_aniso_enabled", False):
        eps_eff = solver._aniso_eps_eff
        return eps_eff["Ex"], eps_eff["Ey"], eps_eff["Ez"]
    return solver.eps_Ex, solver.eps_Ey, solver.eps_Ez


def _build_full_aniso_curl_coefficients(solver):
    """Materialize the off-diagonal coupling coefficient tensors.

    Four ``dt / eps0``-scaled node-inverse and Yee-volume weights multiply the
    four source edges separately. This placement keeps spatially varying
    cross-component contributions reciprocal in the Yee volume inner product.
    """
    if not getattr(solver, "full_aniso_enabled", False):
        return
    scale = solver.dt / solver.eps0
    inverse = solver._aniso_inverse_nodes
    for target_axis, target in enumerate("xyz"):
        for source_axis, source in enumerate("xyz"):
            if target_axis == source_axis:
                continue
            pair = "".join(sorted((target, source)))
            weights = _aniso_cross_weights(solver, inverse[pair], target_axis, source_axis)
            setattr(solver, f"ce{target}_aniso_{source}", weights.mul_(scale))
    # The diagonal ADE polarization-current subtraction must divide by the same
    # effective permittivity the base curl coefficient uses (dt/eps_eff), not the
    # plain per-axis average, so the dispersive response and the tensor curl stay
    # consistent on off-diagonal edges (they coincide for a diagonal tensor).
    if getattr(solver, "electric_dispersive_enabled", False):
        eps_eff = solver._aniso_eps_eff
        solver._aniso_disp_inv_eps = {
            component_name: (1.0 / eps_eff[component_name]).contiguous()
            for component_name in ("Ex", "Ey", "Ez")
        }
    _handle_full_aniso_absorber_overlap(solver)


def _absorbing_region_node_mask(solver):
    """Boolean node mask of the absorbing-boundary region, or ``None``.

    Covers both the graded-sigma split-field absorbers (3D ``sigma_*`` node
    profiles) and CPML/stable-PML (1D stretching profiles per axis).
    """
    if solver.active_absorber_type in ("pml", "absorber"):
        return (solver.sigma_x != 0) | (solver.sigma_y != 0) | (solver.sigma_z != 0)
    if getattr(solver, "uses_cpml", False):
        masks = []
        for axis_name, view in (("x", (-1, 1, 1)), ("y", (1, -1, 1)), ("z", (1, 1, -1))):
            c_e = getattr(solver, f"cpml_c_e_{axis_name}", None)
            inv_kappa = getattr(solver, f"cpml_inv_kappa_e_{axis_name}", None)
            axis_mask = None
            if c_e is not None:
                axis_mask = c_e != 0
            if inv_kappa is not None:
                kappa_mask = inv_kappa != 1
                axis_mask = kappa_mask if axis_mask is None else (axis_mask | kappa_mask)
            if axis_mask is not None:
                masks.append(axis_mask.reshape(view))
        if not masks:
            return None
        mask = masks[0]
        for axis_mask in masks[1:]:
            mask = mask | axis_mask
        return mask.expand(solver.Nx, solver.Ny, solver.Nz)
    return None


def _full_aniso_offdiag_overlaps_absorber(solver):
    """Whether any off-diagonal coupling coefficient reaches into the absorber."""
    mask = _absorbing_region_node_mask(solver)
    if mask is None:
        return False
    mask = mask.to(dtype=torch.float32)
    component_coefficients = (
        ("Ex", (solver.cex_aniso_y, solver.cex_aniso_z)),
        ("Ey", (solver.cey_aniso_x, solver.cey_aniso_z)),
        ("Ez", (solver.cez_aniso_x, solver.cez_aniso_y)),
    )
    # The soft SDF occupancy leaves a vanishing (denormal-scale) tail far outside
    # the structure, so compare against a relative threshold instead of != 0.
    peak = max(
        float(coefficient.abs().max())
        for _, coefficients in component_coefficients
        for coefficient in coefficients
    )
    if peak == 0.0:
        return False
    threshold = 1.0e-6 * peak
    for component_name, coefficients in component_coefficients:
        edge_mask = average_node_to_component(solver, mask, component_name) > 0
        for coefficient in coefficients:
            if bool(torch.any(edge_mask & (coefficient.abs().amax(dim=-1) > threshold)).item()):
                return True
    return False


def _initialize_full_aniso_cpml_psi(solver):
    """Allocate the per-direction off-diagonal CPML psi accumulators.

    The CPML off-diagonal correction kernel coordinate-stretches each of the
    three spatial derivative directions with an independent recursive-convolution
    memory owned by the target E edge. The buffers share the E-field shapes and
    start at zero, so a structure that never reaches the absorber leaves them at
    zero and the correction is byte-consistent with the raw (no-stretch) update.
    """
    for field_name, component in (("Ex", "ex"), ("Ey", "ey"), ("Ez", "ez")):
        field = getattr(solver, field_name)
        for axis in ("x", "y", "z"):
            setattr(solver, f"psi_{component}_aniso_{axis}", torch.zeros_like(field))


def _handle_full_aniso_absorber_overlap(solver):
    """Route an anisotropic structure that overlaps the absorbing boundary.

    Under CPML the dedicated off-diagonal kernel coordinate-stretches the tensor
    coupling with its own psi memory (allocated here), so the overlap is
    supported; the overlap is recorded because the reverse adjoint replay does
    not yet stretch the off-diagonal, and the split-field graded-sigma absorbers
    ('pml'/'absorber') carry no per-direction auxiliary memory to stretch the
    coupling, so an overlap there is rejected with a physical reason.
    """
    solver._full_aniso_cpml_overlap = False
    if getattr(solver, "uses_cpml", False):
        _initialize_full_aniso_cpml_psi(solver)
        solver._full_aniso_cpml_overlap = _full_aniso_offdiag_overlaps_absorber(solver)
        return
    if _full_aniso_offdiag_overlaps_absorber(solver):
        raise NotImplementedError(
            "FDTD full (off-diagonal) anisotropic media overlapping a split-field "
            "PML/absorber layer are not supported: the graded-sigma absorber carries no "
            "per-direction auxiliary memory to coordinate-stretch the off-diagonal tensor "
            "coupling. Use the default CPML absorber for anisotropic structures that reach "
            "the boundary region."
        )


def _uniform_coefficient_value(tensor: torch.Tensor) -> float | None:
    minimum, maximum = torch.aminmax(tensor)
    if not bool(torch.eq(minimum, maximum).item()):
        return None
    return float(minimum.item())


def _store_coefficient_uniformity(solver) -> None:
    solver._coefficient_uniformity = {
        name: _uniform_coefficient_value(getattr(solver, name))
        for name in (
            "cex_decay",
            "cex_curl",
            "cey_decay",
            "cey_curl",
            "cez_decay",
            "cez_curl",
            "chx_decay",
            "chx_curl",
            "chy_decay",
            "chy_curl",
            "chz_decay",
            "chz_curl",
        )
    }


def build_update_coefficients(solver):
    eps_ex, eps_ey, eps_ez = _electric_epsilon_tensors(solver)
    # Under full anisotropy eps_e* is the conductively-shifted effective permittivity,
    # so the diagonal decay/curl must use the aniso_shifted semi-implicit identity
    # rather than re-applying the scalar (1 + half) denominator.
    aniso_shifted = getattr(solver, "full_aniso_enabled", False)
    if solver.active_absorber_type not in ("pml", "absorber"):
        solver.cex_decay, solver.cex_curl = _electric_update_coefficients(solver, eps_ex, solver.sigma_e_Ex, None, aniso_shifted=aniso_shifted)
        solver.cey_decay, solver.cey_curl = _electric_update_coefficients(solver, eps_ey, solver.sigma_e_Ey, None, aniso_shifted=aniso_shifted)
        solver.cez_decay, solver.cez_curl = _electric_update_coefficients(solver, eps_ez, solver.sigma_e_Ez, None, aniso_shifted=aniso_shifted)
        solver.chx_decay, solver.chx_curl = _magnetic_update_coefficients(solver, solver.mu_Hx, solver.sigma_m_Hx, None)
        solver.chy_decay, solver.chy_curl = _magnetic_update_coefficients(solver, solver.mu_Hy, solver.sigma_m_Hy, None)
        solver.chz_decay, solver.chz_curl = _magnetic_update_coefficients(solver, solver.mu_Hz, solver.sigma_m_Hz, None)
        _store_nonlinear_external_decay(solver, None, None, None)
        _build_full_aniso_curl_coefficients(solver)
        _apply_pec_edge_suppression(solver)
        _configure_surface_impedance(solver)
        _store_coefficient_uniformity(solver)
        return

    ex_sigma_y = 0.5 * (solver.sigma_y[:-1, :, :] + solver.sigma_y[1:, :, :])
    ex_sigma_z = 0.5 * (solver.sigma_z[:-1, :, :] + solver.sigma_z[1:, :, :])
    ex_decay = 1.0 / (1.0 + solver.dt * (ex_sigma_y + ex_sigma_z))
    solver.cex_decay, solver.cex_curl = _electric_update_coefficients(solver, eps_ex, solver.sigma_e_Ex, ex_decay, aniso_shifted=aniso_shifted)

    ey_sigma_x = 0.5 * (solver.sigma_x[:, :-1, :] + solver.sigma_x[:, 1:, :])
    ey_sigma_z = 0.5 * (solver.sigma_z[:, :-1, :] + solver.sigma_z[:, 1:, :])
    ey_decay = 1.0 / (1.0 + solver.dt * (ey_sigma_x + ey_sigma_z))
    solver.cey_decay, solver.cey_curl = _electric_update_coefficients(solver, eps_ey, solver.sigma_e_Ey, ey_decay, aniso_shifted=aniso_shifted)

    ez_sigma_x = 0.5 * (solver.sigma_x[:, :, :-1] + solver.sigma_x[:, :, 1:])
    ez_sigma_y = 0.5 * (solver.sigma_y[:, :, :-1] + solver.sigma_y[:, :, 1:])
    ez_decay = 1.0 / (1.0 + solver.dt * (ez_sigma_x + ez_sigma_y))
    solver.cez_decay, solver.cez_curl = _electric_update_coefficients(solver, eps_ez, solver.sigma_e_Ez, ez_decay, aniso_shifted=aniso_shifted)

    hx_sigma_y = 0.25 * (
        solver.sigma_y[:, :-1, :-1]
        + solver.sigma_y[:, 1:, :-1]
        + solver.sigma_y[:, :-1, 1:]
        + solver.sigma_y[:, 1:, 1:]
    )
    hx_sigma_z = 0.25 * (
        solver.sigma_z[:, :-1, :-1]
        + solver.sigma_z[:, 1:, :-1]
        + solver.sigma_z[:, :-1, 1:]
        + solver.sigma_z[:, 1:, 1:]
    )
    hx_decay = 1.0 / (1.0 + solver.dt * (hx_sigma_y + hx_sigma_z))
    solver.chx_decay, solver.chx_curl = _magnetic_update_coefficients(solver, solver.mu_Hx, solver.sigma_m_Hx, hx_decay)

    hy_sigma_x = 0.25 * (
        solver.sigma_x[:-1, :, :-1]
        + solver.sigma_x[1:, :, :-1]
        + solver.sigma_x[:-1, :, 1:]
        + solver.sigma_x[1:, :, 1:]
    )
    hy_sigma_z = 0.25 * (
        solver.sigma_z[:-1, :, :-1]
        + solver.sigma_z[1:, :, :-1]
        + solver.sigma_z[:-1, :, 1:]
        + solver.sigma_z[1:, :, 1:]
    )
    hy_decay = 1.0 / (1.0 + solver.dt * (hy_sigma_x + hy_sigma_z))
    solver.chy_decay, solver.chy_curl = _magnetic_update_coefficients(solver, solver.mu_Hy, solver.sigma_m_Hy, hy_decay)

    hz_sigma_x = 0.25 * (
        solver.sigma_x[:-1, :-1, :]
        + solver.sigma_x[1:, :-1, :]
        + solver.sigma_x[:-1, 1:, :]
        + solver.sigma_x[1:, 1:, :]
    )
    hz_sigma_y = 0.25 * (
        solver.sigma_y[:-1, :-1, :]
        + solver.sigma_y[1:, :-1, :]
        + solver.sigma_y[:-1, 1:, :]
        + solver.sigma_y[1:, 1:, :]
    )
    hz_decay = 1.0 / (1.0 + solver.dt * (hz_sigma_x + hz_sigma_y))
    solver.chz_decay, solver.chz_curl = _magnetic_update_coefficients(solver, solver.mu_Hz, solver.sigma_m_Hz, hz_decay)

    _store_nonlinear_external_decay(solver, ex_decay, ey_decay, ez_decay)
    _build_full_aniso_curl_coefficients(solver)
    _apply_pec_edge_suppression(solver)
    _configure_surface_impedance(solver)
    _store_coefficient_uniformity(solver)


def update_nonlinear_electric_coefficients(solver):
    """Recompute the field-dependent electric update coefficients for this step.

    Pure-chi3 (Kerr) scenes keep the existing curl-only kernel; scenes with a
    chi2 channel or field-dependent conductivity use the general nonlinear
    kernel that rewrites both the decay and curl coefficients.
    """
    from .timestep import record_nonlinear_field_envelope

    record_nonlinear_field_envelope(solver)
    if not getattr(solver, "nonlinear_enabled", False):
        return
    if getattr(solver, "nonlinear_general_enabled", False):
        update_general_nonlinear_coefficients(solver)
        return
    update_kerr_electric_curls(solver)


def update_general_nonlinear_coefficients(solver):
    for component_name, decay_dynamic, curl_dynamic, eps, external, sigma_static, chi2, chi3, tpa in (
        (
            "Ex",
            solver.cex_decay_dynamic,
            solver.cex_curl_dynamic,
            solver.eps_Ex,
            solver.cex_decay_external,
            solver.sigma_e_Ex,
            solver.nonlinear_chi2_Ex,
            solver.kerr_chi3_Ex,
            solver.tpa_sigma_Ex,
        ),
        (
            "Ey",
            solver.cey_decay_dynamic,
            solver.cey_curl_dynamic,
            solver.eps_Ey,
            solver.cey_decay_external,
            solver.sigma_e_Ey,
            solver.nonlinear_chi2_Ey,
            solver.kerr_chi3_Ey,
            solver.tpa_sigma_Ey,
        ),
        (
            "Ez",
            solver.cez_decay_dynamic,
            solver.cez_curl_dynamic,
            solver.eps_Ez,
            solver.cez_decay_external,
            solver.sigma_e_Ez,
            solver.nonlinear_chi2_Ez,
            solver.kerr_chi3_Ez,
            solver.tpa_sigma_Ez,
        ),
    ):
        solver.fdtd_module.updateNonlinearElectricCoefficients3D(
            DynamicDecay=decay_dynamic,
            DynamicCurl=curl_dynamic,
            Ex=solver.Ex,
            Ey=solver.Ey,
            Ez=solver.Ez,
            LinearPermittivity=eps,
            ExternalDecay=external,
            SigmaStatic=sigma_static,
            Chi2=chi2,
            Chi3=chi3,
            TpaSigma=tpa,
            component=component_name,
            dt=solver.dt,
            eps0=solver.eps0,
        ).launchRaw()


def update_kerr_electric_curls(solver):
    if not solver.kerr_enabled:
        return

    solver.fdtd_module.updateKerrElectricFieldExCurl3D(
        DynamicCurl=solver.cex_curl_dynamic,
        Ex=solver.Ex,
        Ey=solver.Ey,
        Ez=solver.Ez,
        LinearPermittivity=solver.eps_Ex,
        ExDecay=solver.cex_decay,
        KerrChi3=solver.kerr_chi3_Ex,
        dt=solver.dt,
        eps0=solver.eps0,
    ).launchRaw()
    solver.fdtd_module.updateKerrElectricFieldEyCurl3D(
        DynamicCurl=solver.cey_curl_dynamic,
        Ex=solver.Ex,
        Ey=solver.Ey,
        Ez=solver.Ez,
        LinearPermittivity=solver.eps_Ey,
        EyDecay=solver.cey_decay,
        KerrChi3=solver.kerr_chi3_Ey,
        dt=solver.dt,
        eps0=solver.eps0,
    ).launchRaw()
    solver.fdtd_module.updateKerrElectricFieldEzCurl3D(
        DynamicCurl=solver.cez_curl_dynamic,
        Ex=solver.Ex,
        Ey=solver.Ey,
        Ez=solver.Ez,
        LinearPermittivity=solver.eps_Ez,
        EzDecay=solver.cez_decay,
        KerrChi3=solver.kerr_chi3_Ez,
        dt=solver.dt,
        eps0=solver.eps0,
    ).launchRaw()
